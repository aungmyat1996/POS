<?php
/**
 * Cron Job Entry Point for Automatic Backups
 * This file should be called by cron job to trigger automatic backups
 * 
 * Example cron job entries:
 * 
 * Daily backup at 2:00 AM:
 * 0 2 * * * /usr/bin/php /path/to/pos_system/cron_backup.php
 * 
 * Weekly backup every Sunday at 3:00 AM:
 * 0 3 * * 0 /usr/bin/php /path/to/pos_system/cron_backup.php
 * 
 * Monthly backup on 1st day at 4:00 AM:
 * 0 4 1 * * /usr/bin/php /path/to/pos_system/cron_backup.php
 */

// Set the base path
define('BASEPATH', __DIR__ . '/');

// Include the automatic backup system
require_once BASEPATH . 'includes/auto_backup.php';

// Log that cron job was executed
error_log("Cron Backup: Automatic backup cron job executed at " . date('Y-m-d H:i:s'));

// The actual backup logic is handled in auto_backup.php
// This file just serves as the cron entry point
?>
