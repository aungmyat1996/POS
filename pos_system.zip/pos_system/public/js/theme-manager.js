/**
 * Theme Manager for BitsTech POS System
 * Handles dynamic theme switching and color management
 */

class ThemeManager {
    constructor() {
        // Use preloaded theme if available
        if (window.preloadedTheme) {
            this.currentTheme = window.preloadedTheme.mode;
            this.colors = window.preloadedTheme.colors;
            console.log('🎨 Using preloaded theme:', this.currentTheme);
        } else {
            // Fallback to default
            this.currentTheme = 'dark';
            this.colors = {
                primary_color: '#007bff',
                secondary_color: '#6c757d',
                accent_color: '#17a2b8',
                background_color: '#21243A',
                sidebar_color: '#2A2D35',
                text_color: '#ffffff',
                success_color: '#28a745',
                warning_color: '#ffc107',
                danger_color: '#dc3545',
                info_color: '#17a2b8'
            };
        }

        this.init();
    }

    init() {
        console.log('🎨 Initializing Theme Manager...');

        // If theme is already preloaded, skip loading and just setup
        if (!window.preloadedTheme) {
            this.loadThemeFromSettings();
            this.applyTheme();
        } else {
            // Theme already applied, just ensure consistency
            this.ensureThemeConsistency();
        }

        this.setupEventListeners();
        this.setupThemeToggle();

        // Minimal delay for DOM readiness
        setTimeout(() => {
            this.ensureThemeConsistency();
            console.log('🎨 Theme consistency ensured');
        }, 100);
    }

    ensureThemeConsistency() {
        // Ensure all elements have correct theme without flash
        const root = document.documentElement;
        const body = document.body;

        // Check if colors object exists and has required properties
        if (!this.colors || typeof this.colors !== 'object') {
            console.warn('🎨 Colors object is not properly initialized, using defaults');
            this.colors = this.getDefaultColors();
        }

        // Ensure attributes are set
        root.setAttribute('data-theme', this.currentTheme);
        if (body) {
            body.setAttribute('data-theme', this.currentTheme);
        }

        // Add theme-loaded class to prevent flash
        root.classList.add('theme-loaded');

        // Ensure CSS variables are applied safely
        try {
            Object.entries(this.colors).forEach(([key, value]) => {
                if (key && value) {
                    const cssVar = `--${key.replace('_', '-')}`;
                    root.style.setProperty(cssVar, value);
                }
            });
        } catch (error) {
            console.error('🎨 Error applying CSS variables:', error);
        }

        // Ensure body styles without transition
        if (body && this.colors.background_color && this.colors.text_color) {
            body.style.transition = 'none';
            body.style.backgroundColor = this.colors.background_color;
            body.style.color = this.colors.text_color;

            // Re-enable transitions after a frame
            requestAnimationFrame(() => {
                if (body) {
                    body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
                }
            });
        }
    }

    getDefaultColors() {
        return {
            primary_color: '#007bff',
            secondary_color: '#6c757d',
            accent_color: '#17a2b8',
            background_color: this.currentTheme === 'light' ? '#f8f9fa' : '#21243A',
            sidebar_color: this.currentTheme === 'light' ? '#ffffff' : '#2A2D35',
            text_color: this.currentTheme === 'light' ? '#212529' : '#ffffff',
            success_color: '#28a745',
            warning_color: '#ffc107',
            danger_color: '#dc3545',
            info_color: '#17a2b8'
        };
    }

    setupThemeToggle() {
        // Wait for DOM to be ready
        setTimeout(() => {
            // Look for existing theme toggle button
            let themeToggle = document.querySelector('#themeToggle');

            if (themeToggle) {
                // Update existing button
                this.updateThemeToggleButton();

                // Remove existing event listeners and add new one
                themeToggle.replaceWith(themeToggle.cloneNode(true));
                themeToggle = document.querySelector('#themeToggle');

                themeToggle.addEventListener('click', () => {
                    this.toggleTheme();
                });

                console.log('🎨 Theme toggle button updated');
            } else {
                // Create new theme toggle button if it doesn't exist
                const navbar = document.querySelector('.navbar-top, .navbar, .nav-right');
                if (navbar) {
                    themeToggle = document.createElement('button');
                    themeToggle.id = 'themeToggle';
                    themeToggle.className = 'nav-link theme-toggle';
                    themeToggle.type = 'button';
                    themeToggle.innerHTML = this.currentTheme === 'light' ?
                        '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                    themeToggle.title = this.currentTheme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode';

                    // Find the best place to insert
                    const navRight = document.querySelector('.nav-right');
                    const currencySelect = document.querySelector('#currency-select');

                    if (navRight && currencySelect) {
                        // Insert after currency select
                        currencySelect.parentNode.insertAdjacentElement('afterend', themeToggle);
                    } else if (navRight) {
                        // Insert at beginning of nav-right
                        navRight.insertBefore(themeToggle, navRight.firstChild);
                    } else if (navbar) {
                        // Insert at end of navbar
                        navbar.appendChild(themeToggle);
                    }

                    themeToggle.addEventListener('click', () => {
                        this.toggleTheme();
                    });

                    console.log('🎨 Theme toggle button created');
                }
            }
        }, 200);
    }

    loadThemeFromSettings() {
        // Load theme settings from localStorage or server
        const savedTheme = localStorage.getItem('theme_mode');
        const savedColors = localStorage.getItem('theme_colors');

        if (savedTheme) {
            this.currentTheme = savedTheme;
        }

        if (savedColors) {
            try {
                const colors = JSON.parse(savedColors);
                this.colors = { ...this.colors, ...colors };
            } catch (e) {
                console.warn('🎨 Failed to parse saved colors:', e);
            }
        }

        // Also try to load from PHP settings if available
        if (typeof window.phpThemeSettings !== 'undefined') {
            console.log('🎨 Loading theme from PHP settings:', window.phpThemeSettings);
            if (window.phpThemeSettings.theme_mode) {
                this.currentTheme = window.phpThemeSettings.theme_mode;
            }

            // Load colors from PHP settings
            const phpColors = {};
            Object.keys(this.colors).forEach(key => {
                if (window.phpThemeSettings[key]) {
                    phpColors[key] = window.phpThemeSettings[key];
                }
            });

            if (Object.keys(phpColors).length > 0) {
                this.colors = { ...this.colors, ...phpColors };
            }
        }

        console.log('🎨 Loaded theme:', this.currentTheme, this.colors);
    }

    toggleTheme() {
        const newTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        console.log('🎨 Toggling theme to:', newTheme);

        // Prepare for smooth transition
        const body = document.body;
        const root = document.documentElement;

        // Add transition class for smooth change
        body.classList.add('theme-transitioning');

        // Update theme
        this.currentTheme = newTheme;

        // Save to localStorage immediately
        localStorage.setItem('theme_mode', this.currentTheme);

        // Update colors based on new theme mode
        this.updateColorsForTheme(newTheme);

        // Apply theme immediately for navbar
        this.applyThemeImmediately();

        // Update toggle button
        this.updateThemeToggleButton();

        // Sync with settings page if available
        this.syncWithSettingsPage();

        // Save to server
        this.saveThemeToServer();

        // Dispatch theme changed event for charts and other components
        const themeChangedEvent = new CustomEvent('themeChanged', {
            detail: { theme: this.currentTheme, colors: this.colors }
        });
        document.dispatchEvent(themeChangedEvent);
        console.log('🎨 Theme changed event dispatched:', this.currentTheme);

        // Remove transition class after animation
        setTimeout(() => {
            body.classList.remove('theme-transitioning');
            // Update preloaded theme for consistency
            window.preloadedTheme = {
                mode: this.currentTheme,
                colors: this.colors
            };
        }, 300);
    }

    // Sync theme with settings page toggle
    syncWithSettingsPage() {
        console.log('🎨 Syncing with settings page, current theme:', this.currentTheme);

        // Sync with settings page radio buttons
        const settingsRadio = document.querySelector(`input[name="theme_mode"][value="${this.currentTheme}"]`);
        if (settingsRadio && !settingsRadio.checked) {
            settingsRadio.checked = true;
            console.log('🎨 Synced with settings page radio:', this.currentTheme);

            // Trigger change event to update settings page UI
            const changeEvent = new Event('change', { bubbles: true });
            settingsRadio.dispatchEvent(changeEvent);
        }

        // Also sync with toggle switch if exists
        const settingsToggle = document.querySelector('#themeMode');
        if (settingsToggle) {
            const shouldBeChecked = this.currentTheme === 'light';
            if (settingsToggle.checked !== shouldBeChecked) {
                settingsToggle.checked = shouldBeChecked;
                console.log('🎨 Synced with settings page toggle:', this.currentTheme);
            }
        }

        // Also update any other theme-related UI elements
        const themePreview = document.querySelector('.theme-preview');
        if (themePreview) {
            themePreview.setAttribute('data-theme', this.currentTheme);
        }

        // Update theme preview if function exists
        if (typeof updateThemePreview === 'function') {
            updateThemePreview();
        }
    }

    // Save theme to server
    saveThemeToServer() {
        // Only save if we're on a page with proper backend access
        if (typeof $ !== 'undefined') {
            // Determine the correct URL based on current page
            let saveUrl = window.location.pathname;

            // If we're on settings page, use it directly
            if (saveUrl.includes('settings.php')) {
                saveUrl = 'settings.php';
            } else {
                // For other pages, try to use settings.php
                saveUrl = '../pages/settings.php';
            }

            $.ajax({
                url: saveUrl,
                type: 'POST',
                data: {
                    action: 'update_theme_mode',
                    theme_mode: this.currentTheme
                },
                dataType: 'json',
                success: (response) => {
                    console.log('🎨 Theme saved to server:', response);
                    if (response && response.success) {
                        console.log('✅ Theme mode saved successfully via theme manager');
                    }
                },
                error: (xhr, status, error) => {
                    console.warn('🎨 Failed to save theme to server:', error);
                    console.warn('🎨 Response text:', xhr.responseText);
                }
            });
        }
    }

    // Method to be called from settings page
    setThemeFromSettings(mode) {
        console.log('🎨 Setting theme from settings page:', mode);

        if (this.currentTheme !== mode) {
            // Add transition class for smooth change
            const body = document.body;
            body.classList.add('theme-transitioning');

            this.currentTheme = mode;

            // Save to localStorage immediately
            localStorage.setItem('theme_mode', this.currentTheme);

            // Update colors based on new theme mode
            this.updateColorsForTheme(mode);

            // Apply theme immediately without delay
            this.applyThemeImmediately();

            // Update navbar toggle button
            this.updateThemeToggleButton();

            // Dispatch theme changed event for charts and other components
            const themeChangedEvent = new CustomEvent('themeChanged', {
                detail: { theme: this.currentTheme, colors: this.colors }
            });
            document.dispatchEvent(themeChangedEvent);
            console.log('🎨 Theme changed event dispatched from settings:', this.currentTheme);

            // Update preloaded theme for consistency
            window.preloadedTheme = {
                mode: this.currentTheme,
                colors: this.colors
            };

            // Remove transition class after animation
            setTimeout(() => {
                body.classList.remove('theme-transitioning');
            }, 300);

            console.log('🎨 Theme updated from settings:', mode);
        }
    }

    // Alias method for settings page compatibility
    setThemeMode(mode) {
        console.log('🎨 setThemeMode called (alias for setThemeFromSettings):', mode);
        this.setThemeFromSettings(mode);
    }

    // Force apply theme for settings page consistency
    forceApplyTheme(theme) {
        console.log('🎨 Force applying theme:', theme);

        this.currentTheme = theme;
        this.updateColorsForTheme(theme);

        // Save to localStorage immediately
        localStorage.setItem('theme_mode', theme);
        localStorage.setItem('theme_colors', JSON.stringify(this.colors));

        // Apply immediately
        this.applyThemeImmediately();

        // Update preloaded theme
        window.preloadedTheme = {
            mode: this.currentTheme,
            colors: this.colors
        };

        console.log('🎨 Theme force applied:', theme);
    }

    // Apply theme immediately without smooth transitions
    applyThemeImmediately() {
        const root = document.documentElement;
        const body = document.body;

        // Set theme attributes immediately
        root.setAttribute('data-theme', this.currentTheme);
        if (body) {
            body.setAttribute('data-theme', this.currentTheme);
        }

        // Add theme-loaded class to prevent flash
        root.classList.add('theme-loaded');

        // Apply CSS variables immediately
        if (this.colors && typeof this.colors === 'object') {
            Object.entries(this.colors).forEach(([key, value]) => {
                if (key && value) {
                    const cssVar = `--${key.replace('_', '-')}`;
                    root.style.setProperty(cssVar, value);
                }
            });
        }

        // Apply body styles immediately
        if (body && this.colors.background_color && this.colors.text_color) {
            body.style.backgroundColor = this.colors.background_color;
            body.style.color = this.colors.text_color;
        }

        // Update theme class
        root.classList.remove('theme-light', 'theme-dark');
        root.classList.add(`theme-${this.currentTheme}`);

        // Force update navbar and sidebar immediately
        this.forceUpdateNavbarElements();

        // Force update all themed elements
        this.forceRefreshAllElements();

        console.log('🎨 Theme applied immediately:', this.currentTheme);
    }

    // Force update navbar elements specifically
    forceUpdateNavbarElements() {
        console.log('🎨 Force updating navbar elements for theme:', this.currentTheme);

        const navbar = document.querySelector('.navbar-top');
        const sidebar = document.querySelector('.left-sidebar');

        if (navbar) {
            navbar.setAttribute('data-theme', this.currentTheme);

            if (this.currentTheme === 'light') {
                navbar.style.backgroundColor = '#ffffff';
                navbar.style.color = '#212529';
            } else {
                navbar.style.backgroundColor = '#2A2D35';
                navbar.style.color = '#ffffff';
            }
        }

        if (sidebar) {
            sidebar.setAttribute('data-theme', this.currentTheme);

            if (this.currentTheme === 'light') {
                sidebar.style.backgroundColor = '#ffffff';
                sidebar.style.color = '#212529';
            } else {
                sidebar.style.backgroundColor = '#2A2D35';
                sidebar.style.color = '#ffffff';
            }
        }

        // Force update all navbar elements
        const navbarElements = document.querySelectorAll('.navbar-top .nav-link, .navbar-top .theme-toggle, .navbar-top .notification-bell, .navbar-top .calculator-toggle, .navbar-top .language-btn, .navbar-top button, .navbar-top #currency-select');

        navbarElements.forEach(element => {
            element.setAttribute('data-theme', this.currentTheme);

            // Force CSS re-evaluation
            element.style.display = 'none';
            element.offsetHeight; // Trigger reflow
            element.style.display = '';
        });

        console.log('🎨 Navbar elements force updated');
    }

    updateColorsForTheme(theme) {
        if (theme === 'light') {
            this.colors.background_color = '#f8f9fa';
            this.colors.sidebar_color = '#ffffff';
            this.colors.text_color = '#212529';
        } else {
            this.colors.background_color = '#21243A';
            this.colors.sidebar_color = '#2A2D35';
            this.colors.text_color = '#ffffff';
        }

        // Save colors to localStorage
        localStorage.setItem('theme_colors', JSON.stringify(this.colors));
    }

    applyThemeSmoothly() {
        const root = document.documentElement;
        const body = document.body;

        // Set theme attributes
        root.setAttribute('data-theme', this.currentTheme);
        body.setAttribute('data-theme', this.currentTheme);

        // Apply CSS variables
        Object.entries(this.colors).forEach(([key, value]) => {
            const cssVar = `--${key.replace('_', '-')}`;
            root.style.setProperty(cssVar, value);
        });

        // Apply body styles with transition
        body.style.backgroundColor = this.colors.background_color;
        body.style.color = this.colors.text_color;

        console.log('🎨 Theme applied smoothly:', this.currentTheme);
    }

    forceRefreshAllElements() {
        console.log('🎨 Force refreshing all elements for theme:', this.currentTheme);

        // Force apply to all major containers
        const allContainers = document.querySelectorAll('body, .main-content, .container, .container-fluid, .content-wrapper, .page-content-wrapper, .layout-container, .dashboard-container, .pos-container, .settings-container');
        const allCards = document.querySelectorAll('.card, .stats-card, .dashboard-card, .product-card, .stat-box, .product-item, .cart-item, .settings-content, .settings-nav, .page-header');
        const allTables = document.querySelectorAll('.table, .table-responsive, .dataTables_wrapper');
        const allForms = document.querySelectorAll('.form-control, .form-select, .input-group');

        if (this.currentTheme === 'light') {
            // Light mode styles
            allContainers.forEach(el => {
                el.style.backgroundColor = '#f8f9fa';
                el.style.color = '#212529';
                el.setAttribute('data-theme', 'light');
            });

            allCards.forEach(el => {
                el.style.backgroundColor = '#ffffff';
                el.style.color = '#212529';
                el.style.borderColor = '#dee2e6';
                el.setAttribute('data-theme', 'light');
            });

            allTables.forEach(el => {
                el.style.backgroundColor = '#ffffff';
                el.style.color = '#212529';
            });

            allForms.forEach(el => {
                el.style.backgroundColor = '#ffffff';
                el.style.color = '#212529';
                el.style.borderColor = '#ced4da';
            });

        } else {
            // Dark mode styles
            allContainers.forEach(el => {
                el.style.backgroundColor = '#21243A';
                el.style.color = '#ffffff';
            });

            allCards.forEach(el => {
                el.style.backgroundColor = '#2A2D35';
                el.style.color = '#ffffff';
                el.style.borderColor = 'rgba(255,255,255,0.1)';
            });

            allTables.forEach(el => {
                el.style.backgroundColor = '#2A2D35';
                el.style.color = '#ffffff';
            });

            allForms.forEach(el => {
                el.style.backgroundColor = '#2A2D35';
                el.style.color = '#ffffff';
                el.style.borderColor = 'rgba(255,255,255,0.2)';
            });
        }

        console.log('🎨 All elements refreshed for', this.currentTheme, 'mode');
    }

    updateThemeToggleButton() {
        const themeToggle = document.querySelector('#themeToggle');
        if (themeToggle) {
            themeToggle.innerHTML = this.currentTheme === 'light' ?
                '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
            themeToggle.title = this.currentTheme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode';
            console.log('🎨 Theme toggle button updated to:', this.currentTheme);
        } else {
            console.warn('🎨 Theme toggle button not found');
        }
    }

    applyTheme() {
        console.log('🎨 Applying theme:', this.currentTheme);

        // Set theme mode attribute on both html and body
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        document.body.setAttribute('data-theme', this.currentTheme);

        // Add theme-loaded class to prevent flash
        document.documentElement.classList.add('theme-loaded');

        // Apply to navbar and sidebar specifically
        const navbar = document.querySelector('.navbar-top');
        const sidebar = document.querySelector('.left-sidebar');

        if (navbar) navbar.setAttribute('data-theme', this.currentTheme);
        if (sidebar) sidebar.setAttribute('data-theme', this.currentTheme);

        // Apply custom colors
        this.applyColors();

        // Force immediate style application
        if (this.currentTheme === 'light') {
            document.body.style.backgroundColor = '#f8f9fa';
            document.body.style.color = '#212529';

            // Force sidebar colors
            if (sidebar) {
                sidebar.style.backgroundColor = '#ffffff';
                sidebar.style.color = '#212529';
            }
            if (navbar) {
                navbar.style.backgroundColor = '#ffffff';
                navbar.style.color = '#212529';
            }

            // Force all major containers
            const containers = document.querySelectorAll('.main-content, .container, .container-fluid, .content-wrapper, .page-content-wrapper, .layout-container');
            containers.forEach(container => {
                container.style.backgroundColor = '#f8f9fa';
                container.style.color = '#212529';
            });

            // Force all cards and components
            const cards = document.querySelectorAll('.card, .stats-card, .dashboard-card, .product-card, .stat-box');
            cards.forEach(card => {
                card.style.backgroundColor = '#ffffff';
                card.style.color = '#212529';
                card.style.borderColor = '#dee2e6';
            });

        } else {
            document.body.style.backgroundColor = '#21243A';
            document.body.style.color = '#ffffff';

            // Force sidebar colors
            if (sidebar) {
                sidebar.style.backgroundColor = '#2A2D35';
                sidebar.style.color = '#ffffff';
            }
            if (navbar) {
                navbar.style.backgroundColor = '#2A2D35';
                navbar.style.color = '#ffffff';
            }

            // Force all major containers
            const containers = document.querySelectorAll('.main-content, .container, .container-fluid, .content-wrapper, .page-content-wrapper, .layout-container');
            containers.forEach(container => {
                container.style.backgroundColor = '#21243A';
                container.style.color = '#ffffff';
            });

            // Force all cards and components
            const cards = document.querySelectorAll('.card, .stats-card, .dashboard-card, .product-card, .stat-box');
            cards.forEach(card => {
                card.style.backgroundColor = '#2A2D35';
                card.style.color = '#ffffff';
                card.style.borderColor = 'rgba(255,255,255,0.1)';
            });
        }

        // Add transition class for smooth changes
        document.body.classList.add('theme-transition');

        // Remove transition class after animation
        setTimeout(() => {
            document.body.classList.remove('theme-transition');
        }, 300);

        console.log('🎨 Theme applied successfully:', this.currentTheme);
    }

    applyColors() {
        const root = document.documentElement;

        // Apply all color variables
        Object.entries(this.colors).forEach(([key, value]) => {
            const cssVar = `--${key.replace('_', '-')}`;
            root.style.setProperty(cssVar, value);
        });

        // Calculate derived colors
        this.calculateDerivedColors();

        console.log('🎨 Applied colors:', this.colors);
    }

    calculateDerivedColors() {
        const root = document.documentElement;

        // Helper function to lighten/darken colors
        const adjustColor = (color, amount) => {
            const num = parseInt(color.replace('#', ''), 16);
            const amt = Math.round(2.55 * amount);
            const R = (num >> 16) + amt;
            const G = (num >> 8 & 0x00FF) + amt;
            const B = (num & 0x0000FF) + amt;
            return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
                (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
                (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
        };

        // Calculate hover and active states based on theme mode
        let primaryHover, primaryActive, backgroundLight, backgroundDark, sidebarLight, sidebarDark;
        let textMuted, borderColor;

        if (this.currentTheme === 'light') {
            // Light theme calculations
            primaryHover = adjustColor(this.colors.primary_color, -15);
            primaryActive = adjustColor(this.colors.primary_color, -25);
            backgroundLight = '#ffffff';
            backgroundDark = '#e9ecef';
            sidebarLight = '#f8f9fa';
            sidebarDark = '#e9ecef';
            textMuted = '#6c757d';
            borderColor = '#dee2e6';
        } else {
            // Dark theme calculations
            primaryHover = adjustColor(this.colors.primary_color, 15);
            primaryActive = adjustColor(this.colors.primary_color, -15);
            backgroundLight = adjustColor(this.colors.background_color, 10);
            backgroundDark = adjustColor(this.colors.background_color, -10);
            sidebarLight = adjustColor(this.colors.sidebar_color, 10);
            sidebarDark = adjustColor(this.colors.sidebar_color, -10);
            textMuted = this.colors.text_color + 'B3'; // 70% opacity
            borderColor = this.colors.text_color + '33'; // 20% opacity
        }

        // Apply derived colors
        root.style.setProperty('--primary-hover', primaryHover);
        root.style.setProperty('--primary-active', primaryActive);
        root.style.setProperty('--background-light', backgroundLight);
        root.style.setProperty('--background-dark', backgroundDark);
        root.style.setProperty('--sidebar-light', sidebarLight);
        root.style.setProperty('--sidebar-dark', sidebarDark);
        root.style.setProperty('--text-muted', textMuted);
        root.style.setProperty('--border-color', borderColor);
    }

    setThemeMode(mode) {
        console.log('🎨 Setting theme mode:', mode);
        this.currentTheme = mode;

        // Update colors based on theme mode
        if (mode === 'light') {
            // Light mode colors
            this.colors.background_color = '#f8f9fa';
            this.colors.sidebar_color = '#ffffff';
            this.colors.text_color = '#212529';
            this.colors.primary_color = this.colors.primary_color || '#007bff';
            this.colors.secondary_color = '#6c757d';
            this.colors.success_color = '#198754';
            this.colors.warning_color = '#ffc107';
            this.colors.danger_color = '#dc3545';
            this.colors.info_color = '#0dcaf0';
        } else {
            // Dark mode colors
            this.colors.background_color = '#21243A';
            this.colors.sidebar_color = '#2A2D35';
            this.colors.text_color = '#ffffff';
            this.colors.primary_color = this.colors.primary_color || '#007bff';
            this.colors.secondary_color = '#6c757d';
            this.colors.success_color = '#28a745';
            this.colors.warning_color = '#ffc107';
            this.colors.danger_color = '#dc3545';
            this.colors.info_color = '#17a2b8';
        }

        this.applyTheme();
        this.saveTheme();

        // Also save to database via AJAX
        this.saveThemeToDatabase();
    }

    setColors(newColors) {
        console.log('🎨 Setting new colors:', newColors);
        this.colors = { ...this.colors, ...newColors };
        this.applyColors();
        this.saveTheme();
    }

    setColor(colorName, colorValue) {
        console.log('🎨 Setting color:', colorName, colorValue);
        this.colors[colorName] = colorValue;
        this.applyColors();
        this.saveTheme();
    }

    saveTheme() {
        // Save to localStorage
        localStorage.setItem('theme_mode', this.currentTheme);
        localStorage.setItem('theme_colors', JSON.stringify(this.colors));
        console.log('🎨 Theme saved to localStorage');
    }

    setupEventListeners() {
        try {
            // Listen for theme changes from settings page
            window.addEventListener('themeChanged', (event) => {
                console.log('🎨 Theme change event received:', event.detail);

                if (event.detail && event.detail.mode) {
                    this.setThemeMode(event.detail.mode);
                }

                if (event.detail && event.detail.colors) {
                    this.setColors(event.detail.colors);
                }
            });

            // Listen for storage changes (sync across tabs)
            window.addEventListener('storage', (event) => {
                if (event.key === 'theme_mode' || event.key === 'theme_colors') {
                    console.log('🎨 Theme storage changed, reloading...');
                    this.loadThemeFromSettings();
                    this.applyTheme();
                }
            });

            // Listen for page visibility changes to ensure theme consistency
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    setTimeout(() => {
                        this.ensureThemeConsistency();
                    }, 100);
                }
            });

            console.log('🎨 Event listeners setup successfully');
        } catch (error) {
            console.error('🎨 Error setting up event listeners:', error);
        }
    }

    saveThemeToDatabase() {
        // Save theme settings to database via AJAX
        const themeData = {
            theme_mode: this.currentTheme,
            ...this.colors
        };

        console.log('🎨 Saving theme to database:', themeData);

        // Create form data
        const formData = new FormData();
        formData.append('action', 'save_settings');

        // Add all theme settings
        Object.keys(themeData).forEach(key => {
            formData.append(key, themeData[key]);
        });

        // Send AJAX request to settings page
        fetch('../pages/settings.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('🎨 Theme saved to database successfully');
            } else {
                console.error('🎨 Failed to save theme to database:', data.message);
            }
        })
        .catch(error => {
            console.error('🎨 Error saving theme to database:', error);
        });
    }

    // Preset color schemes
    getPresets() {
        return {
            default: {
                primary_color: '#007bff',
                secondary_color: '#6c757d',
                accent_color: '#17a2b8',
                background_color: '#21243A',
                sidebar_color: '#2A2D35',
                text_color: '#ffffff',
                success_color: '#28a745',
                warning_color: '#ffc107',
                danger_color: '#dc3545',
                info_color: '#17a2b8'
            },
            ocean: {
                primary_color: '#0ea5e9',
                secondary_color: '#64748b',
                accent_color: '#06b6d4',
                background_color: '#0f172a',
                sidebar_color: '#1e293b',
                text_color: '#ffffff',
                success_color: '#10b981',
                warning_color: '#f59e0b',
                danger_color: '#ef4444',
                info_color: '#06b6d4'
            },
            forest: {
                primary_color: '#10b981',
                secondary_color: '#64748b',
                accent_color: '#34d399',
                background_color: '#0f1419',
                sidebar_color: '#1a2e1a',
                text_color: '#ffffff',
                success_color: '#22c55e',
                warning_color: '#f59e0b',
                danger_color: '#ef4444',
                info_color: '#34d399'
            },
            sunset: {
                primary_color: '#f97316',
                secondary_color: '#64748b',
                accent_color: '#fb923c',
                background_color: '#1a0f0a',
                sidebar_color: '#2d1b1b',
                text_color: '#ffffff',
                success_color: '#10b981',
                warning_color: '#fbbf24',
                danger_color: '#ef4444',
                info_color: '#fb923c'
            },
            royal: {
                primary_color: '#8b5cf6',
                secondary_color: '#64748b',
                accent_color: '#a78bfa',
                background_color: '#1e1065',
                sidebar_color: '#312e81',
                text_color: '#ffffff',
                success_color: '#10b981',
                warning_color: '#f59e0b',
                danger_color: '#ef4444',
                info_color: '#a78bfa'
            },
            crimson: {
                primary_color: '#ef4444',
                secondary_color: '#64748b',
                accent_color: '#f87171',
                background_color: '#1a0a0a',
                sidebar_color: '#2d1b1b',
                text_color: '#ffffff',
                success_color: '#10b981',
                warning_color: '#f59e0b',
                danger_color: '#dc2626',
                info_color: '#f87171'
            }
        };
    }

    applyPreset(presetName) {
        const presets = this.getPresets();
        const preset = presets[presetName];

        if (preset) {
            console.log('🎨 Applying preset:', presetName);
            this.setColors(preset);
        } else {
            console.warn('🎨 Preset not found:', presetName);
        }
    }

    // Get current theme info
    getCurrentTheme() {
        return {
            mode: this.currentTheme,
            colors: { ...this.colors }
        };
    }

    // Reset to default theme
    resetToDefault() {
        console.log('🎨 Resetting to default theme');
        this.currentTheme = 'dark';
        this.applyPreset('default');
    }
}

// Initialize theme manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit for PHP settings to be available
    setTimeout(() => {
        window.themeManager = new ThemeManager();
        console.log('🎨 Theme Manager initialized');

        // Force apply theme on initialization
        if (window.themeManager) {
            window.themeManager.applyTheme();
        }
    }, 100);
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ThemeManager;
}
