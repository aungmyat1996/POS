/**
 * Products management JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips and popovers
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    if (tooltips.length > 0) {
        tooltips.forEach(tooltip => {
            new bootstrap.Tooltip(tooltip);
        });
    }
    
    // Product image preview
    const productImageInput = document.getElementById('product_image');
    const imagePreview = document.getElementById('imagePreview');
    
    if (productImageInput && imagePreview) {
        productImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.classList.remove('d-none');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Generate barcode button
    const generateBarcodeBtn = document.getElementById('generateBarcode');
    const barcodeInput = document.getElementById('barcode');
    const productNameInput = document.getElementById('product_name');
    
    if (generateBarcodeBtn && barcodeInput) {
        generateBarcodeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Generate a barcode based on product name if available or random string
            let prefix = '';
            if (productNameInput && productNameInput.value.trim() !== '') {
                prefix = productNameInput.value.trim().substring(0, 3).toUpperCase();
            } else {
                prefix = 'PRD';
            }
            
            // Generate random string
            const randomPart = Math.random().toString(36).substring(2, 7).toUpperCase();
            const timestamp = new Date().getTime().toString().substring(9, 13);
            
            barcodeInput.value = `${prefix}-${randomPart}${timestamp}`;
        });
    }
    
    // Category management
    const addCategoryBtn = document.getElementById('addCategoryBtn');
    const newCategoryInput = document.getElementById('newCategory');
    const categorySelect = document.getElementById('category_id');
    
    if (addCategoryBtn && newCategoryInput && categorySelect) {
        addCategoryBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const categoryName = newCategoryInput.value.trim();
            if (categoryName === '') {
                alert('Please enter a category name');
                return;
            }
            
            // Send AJAX request to add category
            fetch('../pages/add_category.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `category_name=${encodeURIComponent(categoryName)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new option to select
                    const option = document.createElement('option');
                    option.value = data.category_id;
                    option.textContent = categoryName;
                    categorySelect.appendChild(option);
                    
                    // Select the new option
                    categorySelect.value = data.category_id;
                    
                    // Clear the input
                    newCategoryInput.value = '';
                    
                    // Close modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addCategoryModal'));
                    if (modal) {
                        modal.hide();
                    }
                } else {
                    alert(data.message || 'Failed to add category');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the category');
            });
        });
    }
    
    // Delete product confirmation
    const deleteButtons = document.querySelectorAll('.delete-product');
    if (deleteButtons.length > 0) {
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.dataset.id;
                const productName = this.dataset.name;
                
                if (confirm(`Are you sure you want to delete "${productName}"?`)) {
                    window.location.href = `products.php?action=delete&id=${productId}`;
                }
            });
        });
    }
    
    // Search functionality
    const searchInput = document.getElementById('searchProducts');
    const productCards = document.querySelectorAll('.product-item');
    
    if (searchInput && productCards.length > 0) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.trim().toLowerCase();
            
            productCards.forEach(card => {
                const productName = card.dataset.name.toLowerCase();
                const productId = card.dataset.id.toLowerCase();
                const productBarcode = (card.dataset.barcode || '').toLowerCase();
                
                if (
                    productName.includes(searchTerm) || 
                    productId.includes(searchTerm) || 
                    productBarcode.includes(searchTerm)
                ) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // Category filter
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter && productCards.length > 0) {
        categoryFilter.addEventListener('change', function() {
            const categoryId = this.value;
            
            productCards.forEach(card => {
                if (categoryId === '' || card.dataset.category === categoryId) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // Product quantity increment/decrement
    const quantityInputs = document.querySelectorAll('.product-quantity');
    if (quantityInputs.length > 0) {
        quantityInputs.forEach(input => {
            const minusBtn = input.previousElementSibling;
            const plusBtn = input.nextElementSibling;
            
            if (minusBtn && plusBtn) {
                minusBtn.addEventListener('click', function() {
                    if (input.value > 1) {
                        input.value = parseInt(input.value) - 1;
                        // Trigger change event to update any dependent elements
                        input.dispatchEvent(new Event('change'));
                    }
                });
                
                plusBtn.addEventListener('click', function() {
                    input.value = parseInt(input.value) + 1;
                    // Trigger change event to update any dependent elements
                    input.dispatchEvent(new Event('change'));
                });
            }
        });
    }
}); 