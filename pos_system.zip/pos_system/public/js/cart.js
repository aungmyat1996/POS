/**
 * Shopping Cart JavaScript functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Cart initialization
    let cart = [];
    const taxRate = parseFloat(document.getElementById('taxRate')?.value || 0);
    const shippingFee = parseFloat(document.getElementById('shippingFee')?.value || 0);
    
    // DOM Elements
    const cartItems = document.getElementById('cartItems');
    const subtotalElem = document.getElementById('subtotal');
    const taxElem = document.getElementById('tax');
    const shippingElem = document.getElementById('shipping');
    const discountElem = document.getElementById('discount');
    const grandTotalElem = document.getElementById('grandTotal');
    const discountInput = document.getElementById('discountAmount');
    const cartCount = document.getElementById('cartCount');
    const checkoutBtn = document.getElementById('checkoutBtn');
    const clearCartBtn = document.getElementById('clearCartBtn');
    const customerForm = document.getElementById('customerForm');
    
    // Initialize cart from session if available
    if (typeof sessionCart !== 'undefined' && Array.isArray(sessionCart)) {
        cart = sessionCart;
        updateCartDisplay();
    }
    
    // Add to cart buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    if (addToCartButtons.length > 0) {
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.dataset.id;
                const productName = this.dataset.name;
                const productPrice = parseFloat(this.dataset.price);
                const productImage = this.dataset.image;
                
                // Check if product already in cart
                const existingItem = cart.find(item => item.id === productId);
                
                if (existingItem) {
                    // Increment quantity if already in cart
                    existingItem.quantity += 1;
                } else {
                    // Add new item to cart
                    cart.push({
                        id: productId,
                        name: productName,
                        price: productPrice,
                        quantity: 1,
                        image: productImage
                    });
                }
                
                // Update cart display
                updateCartDisplay();
                
                // Send cart to server to update session
                updateCartSession();
                
                // Show success message
                showToast(`${productName} added to cart!`);
            });
        });
    }
    
    // Clear cart
    if (clearCartBtn) {
        clearCartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (cart.length === 0) {
                showToast('Cart is already empty!');
                return;
            }
            
            if (confirm('Are you sure you want to clear the cart?')) {
                cart = [];
                updateCartDisplay();
                updateCartSession();
                showToast('Cart cleared!');
            }
        });
    }
    
    // Update quantity for cart items
    function handleQuantityChange(e) {
        const productId = e.target.dataset.id;
        const newQuantity = parseInt(e.target.value);
        
        if (newQuantity < 1) {
            removeFromCart(productId);
            return;
        }
        
        // Find and update the item in the cart
        const item = cart.find(item => item.id === productId);
        if (item) {
            item.quantity = newQuantity;
            updateCartDisplay();
            updateCartSession();
        }
    }
    
    // Remove item from cart
    function removeFromCart(productId) {
        const itemIndex = cart.findIndex(item => item.id === productId);
        
        if (itemIndex !== -1) {
            const removedItem = cart[itemIndex];
            cart.splice(itemIndex, 1);
            updateCartDisplay();
            updateCartSession();
            showToast(`${removedItem.name} removed from cart`);
        }
    }
    
    // Update cart display
    function updateCartDisplay() {
        // Update cart count badge
        if (cartCount) {
            const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
            cartCount.textContent = totalItems;
            cartCount.style.display = totalItems > 0 ? 'block' : 'none';
        }
        
        // Update cart items list
        if (cartItems) {
            if (cart.length === 0) {
                cartItems.innerHTML = '<div class="text-center py-3">Cart is empty</div>';
                if (checkoutBtn) checkoutBtn.disabled = true;
            } else {
                cartItems.innerHTML = '';
                
                cart.forEach(item => {
                    const itemRow = document.createElement('div');
                    itemRow.className = 'cart-item';
                    itemRow.innerHTML = `
                        <div class="cart-item-info">
                            <h6 class="mb-0">${item.name}</h6>
                            <small class="text-muted">${parseFloat(item.price).toFixed(2)} × ${item.quantity}</small>
                        </div>
                        <div class="cart-item-quantity">
                            <div class="input-group input-group-sm">
                                <button class="btn btn-outline-secondary btn-sm quantity-minus" data-id="${item.id}">-</button>
                                <input type="number" class="form-control text-center item-quantity" value="${item.quantity}" min="1" data-id="${item.id}">
                                <button class="btn btn-outline-secondary btn-sm quantity-plus" data-id="${item.id}">+</button>
                            </div>
                        </div>
                        <div class="cart-item-price">
                            ${(item.price * item.quantity).toFixed(2)}
                            <button class="btn btn-sm text-danger remove-item" data-id="${item.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                    cartItems.appendChild(itemRow);
                    
                    // Add event listeners for quantity buttons and remove button
                    const quantityInput = itemRow.querySelector('.item-quantity');
                    const minusBtn = itemRow.querySelector('.quantity-minus');
                    const plusBtn = itemRow.querySelector('.quantity-plus');
                    const removeBtn = itemRow.querySelector('.remove-item');
                    
                    if (quantityInput) {
                        quantityInput.addEventListener('change', handleQuantityChange);
                    }
                    
                    if (minusBtn) {
                        minusBtn.addEventListener('click', function() {
                            const id = this.dataset.id;
                            const item = cart.find(item => item.id === id);
                            if (item && item.quantity > 1) {
                                item.quantity -= 1;
                                updateCartDisplay();
                                updateCartSession();
                            } else if (item && item.quantity === 1) {
                                removeFromCart(id);
                            }
                        });
                    }
                    
                    if (plusBtn) {
                        plusBtn.addEventListener('click', function() {
                            const id = this.dataset.id;
                            const item = cart.find(item => item.id === id);
                            if (item) {
                                item.quantity += 1;
                                updateCartDisplay();
                                updateCartSession();
                            }
                        });
                    }
                    
                    if (removeBtn) {
                        removeBtn.addEventListener('click', function() {
                            removeFromCart(this.dataset.id);
                        });
                    }
                });
                
                if (checkoutBtn) checkoutBtn.disabled = false;
            }
        }
        
        // Update totals
        updateTotals();
    }
    
    // Update cart totals
    function updateTotals() {
        const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        const discount = parseFloat(discountInput?.value || 0);
        const tax = subtotal * (taxRate / 100);
        const grandTotal = subtotal + tax + shippingFee - discount;
        
        if (subtotalElem) subtotalElem.textContent = subtotal.toFixed(2);
        if (taxElem) taxElem.textContent = tax.toFixed(2);
        if (shippingElem) shippingElem.textContent = shippingFee.toFixed(2);
        if (discountElem) discountElem.textContent = discount.toFixed(2);
        if (grandTotalElem) grandTotalElem.textContent = grandTotal.toFixed(2);
    }
    
    // Update discount when input changes
    if (discountInput) {
        discountInput.addEventListener('input', function() {
            updateTotals();
        });
    }
    
    // Update cart session via AJAX
    function updateCartSession() {
        // Convert array to object with product IDs as keys
        const cartObj = {};
        cart.forEach(item => {
            cartObj[item.id] = item.quantity;
        });
        
        fetch('../pages/update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cart: cartObj })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update the cart count in the UI if needed
                if (cartCount && data.cart_count !== undefined) {
                    cartCount.textContent = data.cart_count;
                    cartCount.style.display = data.cart_count > 0 ? 'block' : 'none';
                }
                
                // Update totals if available
                if (data.cart_total !== undefined && grandTotalElem) {
                    grandTotalElem.textContent = data.cart_total;
                }
            } else {
                console.error('Failed to update cart session:', data.message);
            }
        })
        .catch(error => {
            console.error('Error updating cart session:', error);
        });
    }
    
    // Show toast notification
    function showToast(message) {
        const toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-primary border-0';
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, {
            autohide: true,
            delay: 3000
        });
        
        bsToast.show();
        
        // Remove the toast element after it's hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
    
    // Checkout button
    if (checkoutBtn && customerForm) {
        checkoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Validate customer form if needed
            if (cart.length === 0) {
                showToast('Cart is empty!');
                return;
            }
            
            // Submit the form
            customerForm.submit();
        });
    }
    
    // Initialize cart display on page load
    updateCartDisplay();
}); 