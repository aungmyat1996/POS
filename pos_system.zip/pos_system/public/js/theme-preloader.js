/**
 * Theme Preloader - Prevents flash of unstyled content
 * This script runs immediately to apply theme before page renders
 */

(function() {
    'use strict';

    // Load theme from localStorage immediately
    const savedTheme = localStorage.getItem('theme_mode') || 'dark';
    const savedColors = localStorage.getItem('theme_colors');

    // Default colors
    let colors = {
        primary_color: '#007bff',
        secondary_color: '#6c757d',
        accent_color: '#17a2b8',
        background_color: '#21243A',
        sidebar_color: '#2A2D35',
        text_color: '#ffffff',
        success_color: '#28a745',
        warning_color: '#ffc107',
        danger_color: '#dc3545',
        info_color: '#17a2b8'
    };

    // Parse saved colors if available
    if (savedColors) {
        try {
            const parsedColors = JSON.parse(savedColors);
            colors = { ...colors, ...parsedColors };
        } catch (e) {
            console.warn('Failed to parse saved colors:', e);
        }
    }

    // Update colors based on theme mode
    if (savedTheme === 'light') {
        colors.background_color = '#f8f9fa';
        colors.sidebar_color = '#ffffff';
        colors.text_color = '#212529';
    } else {
        colors.background_color = '#21243A';
        colors.sidebar_color = '#2A2D35';
        colors.text_color = '#ffffff';
    }

    // Apply theme immediately to prevent flash
    const root = document.documentElement;
    const body = document.body;

    // Set CSS variables
    Object.entries(colors).forEach(([key, value]) => {
        const cssVar = `--${key.replace('_', '-')}`;
        root.style.setProperty(cssVar, value);
    });

    // Set theme attributes
    root.setAttribute('data-theme', savedTheme);
    root.classList.add('theme-loaded'); // Prevent flash
    if (body) {
        body.setAttribute('data-theme', savedTheme);
        body.style.backgroundColor = colors.background_color;
        body.style.color = colors.text_color;
    }

    // Add theme class to html for immediate styling
    root.classList.add(`theme-${savedTheme}`);

    console.log('🎨 Theme preloaded:', savedTheme, colors);

    // Store theme info globally for theme manager
    window.preloadedTheme = {
        mode: savedTheme,
        colors: colors
    };

    // Listen for theme changes from other tabs/windows
    window.addEventListener('storage', function(e) {
        if (e.key === 'theme_mode' && e.newValue !== e.oldValue) {
            console.log('🎨 Theme changed in another tab:', e.newValue);

            // Update current page theme
            const newTheme = e.newValue || 'dark';
            root.setAttribute('data-theme', newTheme);
            if (body) {
                body.setAttribute('data-theme', newTheme);
            }

            // Update colors based on new theme
            if (newTheme === 'light') {
                colors.background_color = '#f8f9fa';
                colors.sidebar_color = '#ffffff';
                colors.text_color = '#212529';
            } else {
                colors.background_color = '#21243A';
                colors.sidebar_color = '#2A2D35';
                colors.text_color = '#ffffff';
            }

            // Apply new colors
            Object.entries(colors).forEach(([key, value]) => {
                const cssVar = `--${key.replace('_', '-')}`;
                root.style.setProperty(cssVar, value);
            });

            if (body) {
                body.style.backgroundColor = colors.background_color;
                body.style.color = colors.text_color;
            }

            // Update theme class
            root.classList.remove('theme-light', 'theme-dark');
            root.classList.add(`theme-${newTheme}`);

            // Update global theme info
            window.preloadedTheme = {
                mode: newTheme,
                colors: colors
            };

            // Notify theme manager if available
            if (typeof window.themeManager !== 'undefined') {
                window.themeManager.currentTheme = newTheme;
                window.themeManager.colors = colors;
                window.themeManager.updateThemeToggleButton();
                console.log('🎨 Theme manager updated from storage event');
            }
        }
    });
})();
