// Shared navbar functionality
// Wait for jQuery to be loaded
function initializeNavbarFunctions() {
    if (typeof jQuery === 'undefined') {
        console.warn('jQuery not loaded - navbar functions will not work');
        return;
    }

    console.log('✅ jQuery loaded, initializing navbar functions');

    // Note: All handlers are now in navbar.php to avoid conflicts
    console.log('📝 navbar-functions.js loaded - handlers are in navbar.php');
}

// Auto-initialize when script loads
(function() {
    function tryInitialize() {
        if (typeof jQuery !== 'undefined' && typeof $ !== 'undefined') {
            console.log('✅ jQuery detected, initializing navbar functions');
            initializeNavbarFunctions();
            return true;
        }
        return false;
    }

    // Try immediate initialization
    if (!tryInitialize()) {
        console.log('⏳ jQuery not ready, waiting...');

        // Wait for jQuery to load
        let attempts = 0;
        let checkJQuery = setInterval(function() {
            attempts++;
            if (tryInitialize()) {
                clearInterval(checkJQuery);
            } else if (attempts >= 100) { // 10 seconds
                clearInterval(checkJQuery);
                console.warn('❌ jQuery not loaded after 10 seconds - navbar functions will not work');
            }
        }, 100);
    }
})();

// Global image error handler for all pages
function handleImageError(img) {
    img.onerror = null;
    img.src = '../public/images/default.jpg'; // fallback image path
    img.classList.add('image-error');
}