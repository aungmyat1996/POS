/**
 * Notification Management System
 * Handles all notification functionality for the POS system
 */

class NotificationManager {
    constructor() {
        this.enabled = localStorage.getItem('notificationsEnabled') !== 'false';
        this.types = {
            low_stock_notifications: localStorage.getItem('low_stock_notifications') !== 'false',
            sales_notifications: localStorage.getItem('sales_notifications') !== 'false',
            system_notifications: localStorage.getItem('system_notifications') !== 'false'
        };
        this.notifications = [];
        this.checkInterval = 30000; // Check every 30 seconds
        this.intervalId = null;
        this.init();
    }
    
    init() {
        console.log('🔔 Notification Manager: Initializing...');
        this.createNotificationContainer();
        this.loadSettings();
        this.startMonitoring();
        this.setupEventListeners();
    }
    
    createNotificationContainer() {
        if ($('#notificationContainer').length === 0) {
            $('body').append(`
                <div id="notificationContainer" style="
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 10000;
                    max-width: 400px;
                    pointer-events: none;
                "></div>
            `);
        }
    }
    
    loadSettings() {
        // Load settings from localStorage
        this.enabled = localStorage.getItem('notificationsEnabled') !== 'false';
        this.types = {
            low_stock_notifications: localStorage.getItem('low_stock_notifications') !== 'false',
            sales_notifications: localStorage.getItem('sales_notifications') !== 'false',
            system_notifications: localStorage.getItem('system_notifications') !== 'false'
        };
        
        console.log('🔔 Notification settings loaded:', {
            enabled: this.enabled,
            types: this.types
        });
    }
    
    setupEventListeners() {
        // Listen for settings changes
        $(document).on('notificationSettingsChanged', (event, data) => {
            this.handleSettingsChange(data);
        });
        
        // Listen for manual notification triggers
        $(document).on('showNotification', (event, data) => {
            this.show(data.message, data.type, data.options);
        });
    }
    
    handleSettingsChange(data) {
        console.log('🔔 Notification settings changed:', data);
        
        if (data.enabled !== undefined) {
            this.enabled = data.enabled;
            localStorage.setItem('notificationsEnabled', data.enabled);
        }
        
        if (data.types) {
            Object.keys(data.types).forEach(type => {
                this.types[type] = data.types[type];
                localStorage.setItem(type, data.types[type]);
            });
        }
        
        // Restart monitoring if enabled
        if (this.enabled) {
            this.startMonitoring();
        } else {
            this.stopMonitoring();
        }
    }
    
    startMonitoring() {
        if (!this.enabled || this.intervalId) {
            return;
        }
        
        console.log('🔔 Starting notification monitoring...');
        
        // Initial check
        this.checkForNotifications();
        
        // Set up periodic checks
        this.intervalId = setInterval(() => {
            this.checkForNotifications();
        }, this.checkInterval);
    }
    
    stopMonitoring() {
        if (this.intervalId) {
            console.log('🔔 Stopping notification monitoring...');
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }
    
    async checkForNotifications() {
        if (!this.enabled) return;
        
        try {
            // Check for low stock notifications
            if (this.types.low_stock_notifications) {
                await this.checkLowStock();
            }
            
            // Check for system notifications
            if (this.types.system_notifications) {
                await this.checkSystemNotifications();
            }
            
        } catch (error) {
            console.error('🔔 Error checking notifications:', error);
        }
    }
    
    async checkLowStock() {
        try {
            const response = await $.ajax({
                url: '../pages/get_notifications.php',
                type: 'GET',
                data: { type: 'low_stock' },
                dataType: 'json'
            });
            
            if (response && response.success && response.notifications) {
                response.notifications.forEach(notification => {
                    this.show(
                        `Low stock alert: ${notification.product_name} (${notification.stock} remaining)`,
                        'warning',
                        { 
                            persistent: true,
                            action: {
                                text: 'View Inventory',
                                url: '../pages/inventory.php'
                            }
                        }
                    );
                });
            }
        } catch (error) {
            console.error('🔔 Error checking low stock:', error);
        }
    }
    
    async checkSystemNotifications() {
        try {
            const response = await $.ajax({
                url: '../pages/get_notifications.php',
                type: 'GET',
                data: { type: 'system' },
                dataType: 'json'
            });
            
            if (response && response.success && response.notifications) {
                response.notifications.forEach(notification => {
                    this.show(notification.message, notification.type || 'info');
                });
            }
        } catch (error) {
            console.error('🔔 Error checking system notifications:', error);
        }
    }
    
    show(message, type = 'info', options = {}) {
        if (!this.enabled) return;
        
        const id = 'notification_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        const duration = options.duration || (type === 'error' ? 8000 : 5000);
        const persistent = options.persistent || false;
        
        const icons = {
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-triangle',
            'warning': 'fas fa-exclamation-circle',
            'info': 'fas fa-info-circle'
        };
        
        const colors = {
            'success': '#28a745',
            'error': '#dc3545',
            'warning': '#ffc107',
            'info': '#17a2b8'
        };
        
        const notification = $(`
            <div id="${id}" class="notification-item" style="
                background: ${colors[type] || colors.info};
                color: white;
                padding: 1rem;
                margin-bottom: 0.5rem;
                border-radius: 0.5rem;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                opacity: 0;
                transform: translateX(100%);
                transition: all 0.3s ease;
                pointer-events: auto;
                position: relative;
            ">
                <div style="display: flex; align-items: flex-start; gap: 0.75rem;">
                    <i class="${icons[type] || icons.info}" style="margin-top: 0.125rem; flex-shrink: 0;"></i>
                    <div style="flex: 1;">
                        <div style="font-weight: 500; margin-bottom: 0.25rem;">${message}</div>
                        ${options.action ? `
                            <button onclick="window.location.href='${options.action.url}'" style="
                                background: rgba(255,255,255,0.2);
                                border: 1px solid rgba(255,255,255,0.3);
                                color: white;
                                padding: 0.25rem 0.75rem;
                                border-radius: 0.25rem;
                                font-size: 0.875rem;
                                cursor: pointer;
                                margin-top: 0.5rem;
                            ">${options.action.text}</button>
                        ` : ''}
                    </div>
                    ${!persistent ? `
                        <button onclick="notificationManager.hide('${id}')" style="
                            background: none;
                            border: none;
                            color: white;
                            font-size: 1.2rem;
                            cursor: pointer;
                            padding: 0;
                            opacity: 0.7;
                            flex-shrink: 0;
                        ">&times;</button>
                    ` : ''}
                </div>
            </div>
        `);
        
        $('#notificationContainer').append(notification);
        
        // Animate in
        setTimeout(() => {
            notification.css({
                opacity: 1,
                transform: 'translateX(0)'
            });
        }, 100);
        
        // Auto hide if not persistent
        if (!persistent) {
            setTimeout(() => {
                this.hide(id);
            }, duration);
        }
        
        // Store notification
        this.notifications.push({
            id: id,
            message: message,
            type: type,
            timestamp: new Date(),
            persistent: persistent
        });
        
        console.log('🔔 Notification shown:', { id, message, type });
    }
    
    hide(id) {
        const notification = $(`#${id}`);
        if (notification.length) {
            notification.css({
                opacity: 0,
                transform: 'translateX(100%)'
            });
            
            setTimeout(() => {
                notification.remove();
            }, 300);
            
            // Remove from stored notifications
            this.notifications = this.notifications.filter(n => n.id !== id);
            
            console.log('🔔 Notification hidden:', id);
        }
    }
    
    hideAll() {
        $('.notification-item').each((index, element) => {
            const id = $(element).attr('id');
            this.hide(id);
        });
    }
    
    // Public methods
    setEnabled(enabled) {
        this.enabled = enabled;
        localStorage.setItem('notificationsEnabled', enabled);
        
        if (enabled) {
            this.startMonitoring();
        } else {
            this.stopMonitoring();
            this.hideAll();
        }
    }
    
    setTypeEnabled(type, enabled) {
        this.types[type] = enabled;
        localStorage.setItem(type, enabled);
    }
    
    showSuccess(message, options = {}) {
        this.show(message, 'success', options);
    }
    
    showError(message, options = {}) {
        this.show(message, 'error', options);
    }
    
    showWarning(message, options = {}) {
        this.show(message, 'warning', options);
    }
    
    showInfo(message, options = {}) {
        this.show(message, 'info', options);
    }
    
    getNotifications() {
        return [...this.notifications];
    }
    
    getSettings() {
        return {
            enabled: this.enabled,
            types: { ...this.types }
        };
    }
}

// Initialize notification manager when DOM is ready
$(document).ready(function() {
    window.notificationManager = new NotificationManager();
    
    // Expose global notification functions
    window.showNotification = function(message, type = 'info', options = {}) {
        if (window.notificationManager) {
            window.notificationManager.show(message, type, options);
        }
    };
    
    window.showSuccess = function(message, options = {}) {
        if (window.notificationManager) {
            window.notificationManager.showSuccess(message, options);
        }
    };
    
    window.showError = function(message, options = {}) {
        if (window.notificationManager) {
            window.notificationManager.showError(message, options);
        }
    };
    
    window.showWarning = function(message, options = {}) {
        if (window.notificationManager) {
            window.notificationManager.showWarning(message, options);
        }
    };
    
    window.showInfo = function(message, options = {}) {
        if (window.notificationManager) {
            window.notificationManager.showInfo(message, options);
        }
    };
    
    console.log('🔔 Notification system initialized');
});
