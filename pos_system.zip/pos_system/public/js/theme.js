/**
 * Theme Management System
 * Handles theme switching, color management, and visual preferences
 */

class ThemeManager {
    constructor() {
        this.currentTheme = {
            color: window.themeColor || '#8b5cf6',
            mode: window.themeMode || 'dark',
            fontSize: window.fontSize || '16px'
        };
        this.init();
    }
    
    init() {
        console.log('🎨 Theme Manager: Initializing...');
        this.loadThemeFromStorage();
        this.applyTheme();
        this.setupEventListeners();
    }
    
    loadThemeFromStorage() {
        // Load theme from localStorage if available
        const savedTheme = localStorage.getItem('posTheme');
        if (savedTheme) {
            try {
                const theme = JSON.parse(savedTheme);
                this.currentTheme = { ...this.currentTheme, ...theme };
            } catch (e) {
                console.warn('🎨 Failed to load saved theme:', e);
            }
        }
    }
    
    saveThemeToStorage() {
        localStorage.setItem('posTheme', JSON.stringify(this.currentTheme));
    }
    
    setupEventListeners() {
        // Listen for theme change events
        $(document).on('themeChanged', (event, data) => {
            this.handleThemeChange(data);
        });
        
        // Listen for manual theme updates
        $(document).on('updateTheme', () => {
            this.applyTheme();
        });
        
        // Listen for color picker changes
        $(document).on('input', 'input[name="theme_color"]', (e) => {
            this.updateColor($(e.target).val());
        });
        
        // Listen for theme mode changes
        $(document).on('change', 'select[name="theme_mode"]', (e) => {
            this.updateMode($(e.target).val());
        });
        
        // Listen for font size changes
        $(document).on('change', 'select[name="font_size"]', (e) => {
            this.updateFontSize($(e.target).val());
        });
    }
    
    handleThemeChange(data) {
        console.log('🎨 Theme changed:', data);
        
        if (data.color) this.currentTheme.color = data.color;
        if (data.mode) this.currentTheme.mode = data.mode;
        if (data.fontSize) this.currentTheme.fontSize = data.fontSize;
        
        this.applyTheme();
        this.saveThemeToStorage();
        
        // Trigger custom event for other components
        $(document).trigger('themeUpdated', this.currentTheme);
    }
    
    applyTheme() {
        console.log('🎨 Applying theme:', this.currentTheme);
        
        // Update CSS custom properties
        this.updateCSSVariables();
        
        // Update body classes
        this.updateBodyClasses();
        
        // Update theme preview if exists
        this.updateThemePreview();
        
        // Update global variables
        this.updateGlobalVariables();
    }
    
    updateCSSVariables() {
        const root = document.documentElement;
        
        // Primary color variations
        const primaryColor = this.currentTheme.color;
        root.style.setProperty('--accent', primaryColor);
        root.style.setProperty('--accent-purple', primaryColor);
        root.style.setProperty('--gradient-start', primaryColor);
        
        // Generate color variations
        const rgb = this.hexToRgb(primaryColor);
        if (rgb) {
            root.style.setProperty('--accent-rgb', `${rgb.r}, ${rgb.g}, ${rgb.b}`);
            root.style.setProperty('--accent-light', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.1)`);
            root.style.setProperty('--accent-hover', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.8)`);
        }
        
        // Font size
        root.style.setProperty('--font-size', this.currentTheme.fontSize);
        
        // Theme mode specific colors
        if (this.currentTheme.mode === 'light') {
            root.style.setProperty('--primary-bg', '#ffffff');
            root.style.setProperty('--card-bg', '#f8f9fa');
            root.style.setProperty('--text-primary', '#212529');
            root.style.setProperty('--text-secondary', '#6c757d');
            root.style.setProperty('--border-color', '#dee2e6');
        } else {
            root.style.setProperty('--primary-bg', '#1A1D2E');
            root.style.setProperty('--card-bg', '#21243A');
            root.style.setProperty('--text-primary', '#FFFFFF');
            root.style.setProperty('--text-secondary', '#D1D5DB');
            root.style.setProperty('--border-color', '#2D314D');
        }
    }
    
    updateBodyClasses() {
        const body = document.body;
        
        // Remove existing theme classes
        body.classList.remove('theme-light', 'theme-dark');
        
        // Add current theme class
        body.classList.add(`theme-${this.currentTheme.mode}`);
    }
    
    updateThemePreview() {
        const preview = $('#themePreview');
        if (preview.length) {
            preview.css({
                'background-color': this.currentTheme.color,
                'opacity': this.currentTheme.mode === 'dark' ? 1 : 0.8
            });
        }
    }
    
    updateGlobalVariables() {
        window.themeColor = this.currentTheme.color;
        window.themeMode = this.currentTheme.mode;
        window.fontSize = this.currentTheme.fontSize;
    }
    
    // Color utility methods
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }
    
    rgbToHex(r, g, b) {
        return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
    }
    
    lightenColor(hex, percent) {
        const rgb = this.hexToRgb(hex);
        if (!rgb) return hex;
        
        const factor = 1 + (percent / 100);
        const r = Math.min(255, Math.round(rgb.r * factor));
        const g = Math.min(255, Math.round(rgb.g * factor));
        const b = Math.min(255, Math.round(rgb.b * factor));
        
        return this.rgbToHex(r, g, b);
    }
    
    darkenColor(hex, percent) {
        const rgb = this.hexToRgb(hex);
        if (!rgb) return hex;
        
        const factor = 1 - (percent / 100);
        const r = Math.max(0, Math.round(rgb.r * factor));
        const g = Math.max(0, Math.round(rgb.g * factor));
        const b = Math.max(0, Math.round(rgb.b * factor));
        
        return this.rgbToHex(r, g, b);
    }
    
    // Public methods
    updateColor(color) {
        this.currentTheme.color = color;
        this.applyTheme();
        this.saveThemeToStorage();
    }
    
    updateMode(mode) {
        this.currentTheme.mode = mode;
        this.applyTheme();
        this.saveThemeToStorage();
    }
    
    updateFontSize(fontSize) {
        this.currentTheme.fontSize = fontSize;
        this.applyTheme();
        this.saveThemeToStorage();
    }
    
    getTheme() {
        return { ...this.currentTheme };
    }
    
    setTheme(theme) {
        this.currentTheme = { ...this.currentTheme, ...theme };
        this.applyTheme();
        this.saveThemeToStorage();
    }
    
    resetTheme() {
        this.currentTheme = {
            color: '#8b5cf6',
            mode: 'dark',
            fontSize: '16px'
        };
        this.applyTheme();
        this.saveThemeToStorage();
    }
    
    // Animation utilities
    animateColorChange(fromColor, toColor, duration = 300) {
        const startTime = Date.now();
        const fromRgb = this.hexToRgb(fromColor);
        const toRgb = this.hexToRgb(toColor);
        
        if (!fromRgb || !toRgb) return;
        
        const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const r = Math.round(fromRgb.r + (toRgb.r - fromRgb.r) * progress);
            const g = Math.round(fromRgb.g + (toRgb.g - fromRgb.g) * progress);
            const b = Math.round(fromRgb.b + (toRgb.b - fromRgb.b) * progress);
            
            const currentColor = this.rgbToHex(r, g, b);
            document.documentElement.style.setProperty('--accent', currentColor);
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                this.updateColor(toColor);
            }
        };
        
        requestAnimationFrame(animate);
    }
}

// Initialize theme manager when DOM is ready
$(document).ready(function() {
    window.themeManager = new ThemeManager();
    
    // Expose global theme functions
    window.updateTheme = function(theme) {
        if (window.themeManager) {
            window.themeManager.setTheme(theme);
        }
    };
    
    window.getTheme = function() {
        return window.themeManager ? window.themeManager.getTheme() : null;
    };
    
    window.resetTheme = function() {
        if (window.themeManager) {
            window.themeManager.resetTheme();
        }
    };
    
    console.log('🎨 Theme system initialized');
});
