function updateCart(productId, action) {
    const productCard = document.querySelector(`.product-card[data-product-id="${productId}"]`);
    const quantityInput = productCard.querySelector('.quantity-input');
    const quantityControls = productCard.querySelector('.quantity-controls');

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'home.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.onload = function () {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            const quantity = response.quantity;

            if (quantity > 0) {
                productCard.classList.add('added');
                quantityInput.value = quantity;
            } else {
                productCard.classList.remove('added');
            }
        } else {
            alert('Error updating cart');
        }
    };

    xhr.onerror = function () {
        alert('Error communicating with server');
    };

    const data = `action=${action}&product_id=${productId}`;
    xhr.send(data);
}