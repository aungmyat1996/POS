/**
 * Dashboard JavaScript functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    if (tooltips.length > 0) {
        tooltips.forEach(tooltip => {
            new bootstrap.Tooltip(tooltip);
        });
    }
    
    // Initialize popovers
    const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
    if (popovers.length > 0) {
        popovers.forEach(popover => {
            new bootstrap.Popover(popover);
        });
    }
    
    // Dashboard charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        // Sales Chart
        const salesCtx = document.getElementById('salesChart');
        if (salesCtx) {
            new Chart(salesCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [{
                        label: 'Sales',
                        data: [12, 19, 3, 5, 2, 3, 10, 15, 8, 12, 9, 14],
                        borderColor: '#F97316',
                        tension: 0.1,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
        
        // Products Chart
        const productsCtx = document.getElementById('productsChart');
        if (productsCtx) {
            new Chart(productsCtx, {
                type: 'pie',
                data: {
                    labels: ['Laptops', 'Accessories', 'Monitors', 'Keyboards'],
                    datasets: [{
                        label: 'Categories',
                        data: [12, 19, 3, 5],
                        backgroundColor: [
                            '#F97316',
                            '#3f37c9',
                            '#f72585',
                            '#4cc9f0'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }
    
    // Quick date range selectors
    const dateRangeButtons = document.querySelectorAll('.date-range-selector');
    if (dateRangeButtons.length > 0) {
        dateRangeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const range = this.dataset.range;
                const fromDate = document.getElementById('fromDate');
                const toDate = document.getElementById('toDate');
                
                if (!fromDate || !toDate) return;
                
                const today = new Date();
                let startDate = new Date();
                
                switch(range) {
                    case 'today':
                        // Already set to today
                        break;
                    case 'yesterday':
                        startDate.setDate(today.getDate() - 1);
                        break;
                    case 'week':
                        startDate.setDate(today.getDate() - 7);
                        break;
                    case 'month':
                        startDate.setMonth(today.getMonth() - 1);
                        break;
                    case 'year':
                        startDate.setFullYear(today.getFullYear() - 1);
                        break;
                }
                
                fromDate.value = formatDate(startDate);
                toDate.value = formatDate(today);
                
                // Update active state
                dateRangeButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
    
    // Helper function to format date as YYYY-MM-DD
    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    // Show notification count if there are new notifications
    const notificationCounter = document.getElementById('notificationCounter');
    if (notificationCounter) {
        // This would be populated from server-side in a real app
        const notificationCount = 3;
        if (notificationCount > 0) {
            notificationCounter.textContent = notificationCount;
            notificationCounter.classList.remove('d-none');
        }
    }
    
    // Toggle sidebar (for mobile view)
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.body.classList.toggle('sidebar-collapsed');
        });
    }
});