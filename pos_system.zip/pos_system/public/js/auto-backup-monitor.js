/**
 * Automatic Backup Monitor
 * This script runs in the background to check and trigger automatic backups
 */

class AutoBackupMonitor {
    constructor() {
        this.checkInterval = 5 * 60 * 1000; // Check every 5 minutes
        this.isRunning = false;
        this.intervalId = null;
        this.lastCheck = null;

        // Start monitoring when page loads
        this.init();
    }

    init() {
        console.log('🤖 Auto Backup Monitor: Initializing...');

        // Start monitoring if on settings page or if auto backup is enabled
        this.startMonitoring();

        // Listen for settings changes
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Check if jQuery is available
        if (typeof $ === 'undefined') {
            console.warn('🤖 Auto Backup Monitor: jQuery not available, using vanilla JS');

            // Use vanilla JS event listeners
            document.addEventListener('change', (e) => {
                if (e.target.name === 'backup_enabled' || e.target.name === 'backup_frequency') {
                    setTimeout(() => this.checkAndStart(), 1000);
                }
            });
        } else {
            // Listen for backup settings changes
            $(document).on('change', 'input[name="backup_enabled"]', () => {
                setTimeout(() => this.checkAndStart(), 1000);
            });

            $(document).on('change', 'select[name="backup_frequency"]', () => {
                setTimeout(() => this.checkAndStart(), 1000);
            });
        }

        // Listen for page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.checkAndStart();
            }
        });
    }

    startMonitoring() {
        if (this.isRunning) {
            return;
        }

        console.log('🤖 Auto Backup Monitor: Starting background monitoring...');
        this.isRunning = true;

        // Initial check
        this.checkBackupStatus();

        // Set up periodic checks
        this.intervalId = setInterval(() => {
            this.checkBackupStatus();
        }, this.checkInterval);
    }

    stopMonitoring() {
        if (!this.isRunning) {
            return;
        }

        console.log('🤖 Auto Backup Monitor: Stopping background monitoring...');
        this.isRunning = false;

        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }

    async checkBackupStatus() {
        try {
            console.log('🤖 Auto Backup Monitor: Checking backup status...');
            this.lastCheck = new Date();

            let response;

            // Check if jQuery is available
            if (typeof $ !== 'undefined') {
                response = await $.ajax({
                    url: window.location.pathname,
                    type: 'POST',
                    data: { action: 'check_auto_backup_status' },
                    dataType: 'json',
                    timeout: 10000
                });
            } else {
                // Use fetch API as fallback
                const formData = new FormData();
                formData.append('action', 'check_auto_backup_status');

                const fetchResponse = await fetch(window.location.pathname, {
                    method: 'POST',
                    body: formData
                });
                response = await fetchResponse.json();
            }

            if (response && response.success) {
                console.log('🤖 Auto Backup Status:', response);

                // Check if backup is enabled and due
                if (response.enabled && response.is_due) {
                    console.log('🤖 Auto Backup Monitor: Backup is due, triggering automatic backup...');
                    await this.triggerAutomaticBackup();
                } else if (response.enabled) {
                    console.log('🤖 Auto Backup Monitor: Backup enabled but not due yet');
                    console.log('🤖 Next backup:', response.next_backup);
                } else {
                    console.log('🤖 Auto Backup Monitor: Automatic backup is disabled');
                }

                // Update UI if status display is visible
                if (typeof displayAutoBackupStatus === 'function') {
                    const statusElement = document.querySelector('#autoBackupStatus .auto-backup-info');
                    if (statusElement || (typeof $ !== 'undefined' && $('#autoBackupStatus .auto-backup-info').length > 0)) {
                        displayAutoBackupStatus(response);
                    }
                }
            }
        } catch (error) {
            console.error('🤖 Auto Backup Monitor: Error checking status:', error);
        }
    }

    async triggerAutomaticBackup() {
        try {
            console.log('🤖 Auto Backup Monitor: Triggering automatic backup...');

            // Show notification that backup is starting
            this.showBackupNotification('Starting automatic backup...', 'info');

            let response;

            // Check if jQuery is available
            if (typeof $ !== 'undefined') {
                response = await $.ajax({
                    url: window.location.pathname,
                    type: 'POST',
                    data: { action: 'trigger_auto_backup' },
                    dataType: 'json',
                    timeout: 60000 // 1 minute timeout for backup
                });
            } else {
                // Use fetch API as fallback
                const formData = new FormData();
                formData.append('action', 'trigger_auto_backup');

                const fetchResponse = await fetch(window.location.pathname, {
                    method: 'POST',
                    body: formData
                });
                response = await fetchResponse.json();
            }

            if (response && response.success) {
                console.log('🤖 Auto Backup Monitor: Automatic backup completed successfully');
                console.log('🤖 Backup file:', response.filename);
                console.log('🤖 Backup size:', response.size);

                // Show success notification
                this.showBackupNotification(
                    `Automatic backup completed successfully!\nFile: ${response.filename}\nSize: ${response.size}`,
                    'success'
                );

                // Refresh backup list if visible
                if (typeof loadBackupList === 'function') {
                    const backupListElement = document.querySelector('#backupList .backup-item');
                    if (backupListElement || (typeof $ !== 'undefined' && $('#backupList .backup-item').length > 0)) {
                        loadBackupList();
                    }
                }

            } else {
                console.error('🤖 Auto Backup Monitor: Automatic backup failed:', response);
                this.showBackupNotification(
                    `Automatic backup failed: ${response.message || 'Unknown error'}`,
                    'error'
                );
            }
        } catch (error) {
            console.error('🤖 Auto Backup Monitor: Error triggering backup:', error);
            this.showBackupNotification(
                'Automatic backup failed due to network error',
                'error'
            );
        }
    }

    showBackupNotification(message, type = 'info') {
        // Only show notifications if user is on settings page
        if (!window.location.pathname.includes('settings.php')) {
            return;
        }

        const icon = {
            'info': 'fas fa-info-circle',
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-triangle'
        }[type] || 'fas fa-info-circle';

        const color = {
            'info': '#17a2b8',
            'success': '#28a745',
            'error': '#dc3545'
        }[type] || '#17a2b8';

        // Create notification element
        const notificationHTML = `
            <div class="auto-backup-notification" style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${color};
                color: white;
                padding: 1rem;
                border-radius: 0.5rem;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 9999;
                max-width: 350px;
                font-size: 0.875rem;
                opacity: 0;
                transform: translateX(100%);
                transition: all 0.3s ease;
            ">
                <div style="display: flex; align-items: flex-start; gap: 0.5rem;">
                    <i class="${icon}" style="margin-top: 0.125rem; flex-shrink: 0;"></i>
                    <div style="flex: 1; white-space: pre-line;">${message}</div>
                    <button onclick="this.closest('.auto-backup-notification').remove()" style="
                        background: none;
                        border: none;
                        color: white;
                        font-size: 1.2rem;
                        cursor: pointer;
                        padding: 0;
                        margin-left: 0.5rem;
                        opacity: 0.7;
                        flex-shrink: 0;
                    ">&times;</button>
                </div>
            </div>
        `;

        let notification;

        // Check if jQuery is available
        if (typeof $ !== 'undefined') {
            notification = $(notificationHTML);
            $('body').append(notification);
        } else {
            // Use vanilla JS
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = notificationHTML;
            notification = tempDiv.firstElementChild;
            document.body.appendChild(notification);
        }

        // Animate in
        setTimeout(() => {
            if (typeof $ !== 'undefined' && notification.css) {
                notification.css({
                    opacity: 1,
                    transform: 'translateX(0)'
                });
            } else {
                notification.style.opacity = '1';
                notification.style.transform = 'translateX(0)';
            }
        }, 100);

        // Auto remove after delay
        const autoRemoveDelay = type === 'error' ? 10000 : 5000;
        setTimeout(() => {
            if (typeof $ !== 'undefined' && notification.css) {
                notification.css({
                    opacity: 0,
                    transform: 'translateX(100%)'
                });
                setTimeout(() => notification.remove(), 300);
            } else {
                notification.style.opacity = '0';
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => notification.remove(), 300);
            }
        }, autoRemoveDelay);
    }

    checkAndStart() {
        // Always restart monitoring to pick up new settings
        this.stopMonitoring();
        setTimeout(() => this.startMonitoring(), 500);
    }

    getStatus() {
        return {
            isRunning: this.isRunning,
            lastCheck: this.lastCheck,
            checkInterval: this.checkInterval
        };
    }
}

// Initialize auto backup monitor when DOM is ready
function initializeAutoBackupMonitor() {
    // Only initialize on settings page or if auto backup might be enabled
    if (window.location.pathname.includes('settings.php') ||
        localStorage.getItem('autoBackupEnabled') === 'true') {

        window.autoBackupMonitor = new AutoBackupMonitor();

        // Expose status check for debugging
        window.checkAutoBackupMonitorStatus = function() {
            if (window.autoBackupMonitor) {
                console.log('🤖 Auto Backup Monitor Status:', window.autoBackupMonitor.getStatus());
            } else {
                console.log('🤖 Auto Backup Monitor: Not initialized');
            }
        };
    }
}

// Check if jQuery is available
if (typeof $ !== 'undefined') {
    $(document).ready(initializeAutoBackupMonitor);

    // Clean up when page unloads
    $(window).on('beforeunload', function() {
        if (window.autoBackupMonitor) {
            window.autoBackupMonitor.stopMonitoring();
        }
    });
} else {
    // Use vanilla JS
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeAutoBackupMonitor);
    } else {
        initializeAutoBackupMonitor();
    }

    // Clean up when page unloads
    window.addEventListener('beforeunload', function() {
        if (window.autoBackupMonitor) {
            window.autoBackupMonitor.stopMonitoring();
        }
    });
}
