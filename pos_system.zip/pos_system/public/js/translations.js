/**
 * Translation Management System
 * Handles language switching and text updates across the POS system
 */

class TranslationManager {
    constructor() {
        this.currentLanguage = window.currentLanguage || 'en';
        this.translations = window.translations || {};
        this.fallbackTranslations = {};
        this.init();
    }
    
    init() {
        console.log('🌐 Translation Manager: Initializing...');
        this.loadFallbackTranslations();
        this.setupEventListeners();
    }
    
    loadFallbackTranslations() {
        // English fallback translations
        this.fallbackTranslations = {
            'en': {
                'dashboard': 'Dashboard',
                'products': 'Products',
                'inventory': 'Inventory',
                'sales': 'Sales',
                'reports': 'Reports',
                'users': 'Users',
                'settings': 'Settings',
                'profile': 'Profile',
                'logout': 'Logout',
                'search': 'Search',
                'add': 'Add',
                'edit': 'Edit',
                'delete': 'Delete',
                'save': 'Save',
                'cancel': 'Cancel',
                'close': 'Close',
                'loading': 'Loading...',
                'saving': 'Saving...',
                'success': 'Success',
                'error': 'Error',
                'warning': 'Warning',
                'info': 'Information'
            },
            'mm': {
                'dashboard': 'ဒက်ရှ်ဘုတ်',
                'products': 'ကုန်ပစ္စည်းများ',
                'inventory': 'စာရင်းကောက်ယူခြင်း',
                'sales': 'ရောင်းချမှုများ',
                'reports': 'အစီရင်ခံစာများ',
                'users': 'အသုံးပြုသူများ',
                'settings': 'ဆက်တင်များ',
                'profile': 'ပရိုဖိုင်',
                'logout': 'ထွက်ရန်',
                'search': 'ရှာဖွေရန်',
                'add': 'ထည့်ရန်',
                'edit': 'ပြင်ဆင်ရန်',
                'delete': 'ဖျက်ရန်',
                'save': 'သိမ်းရန်',
                'cancel': 'ပယ်ဖျက်ရန်',
                'close': 'ပိတ်ရန်',
                'loading': 'ဖွင့်နေသည်...',
                'saving': 'သိမ်းနေသည်...',
                'success': 'အောင်မြင်သည်',
                'error': 'အမှား',
                'warning': 'သတိပေးချက်',
                'info': 'အချက်အလက်'
            }
        };
    }
    
    setupEventListeners() {
        // Listen for language change events
        $(document).on('languageChanged', (event, data) => {
            this.handleLanguageChange(data.language, data.translations);
        });
        
        // Listen for manual translation updates
        $(document).on('updateTranslations', () => {
            this.updateAllTranslations();
        });
    }
    
    handleLanguageChange(newLanguage, newTranslations) {
        console.log('🌐 Language changed to:', newLanguage);
        
        this.currentLanguage = newLanguage;
        if (newTranslations) {
            this.translations = newTranslations;
        }
        
        // Update global variables
        window.currentLanguage = newLanguage;
        window.translations = this.translations;
        
        // Update all translations on the page
        this.updateAllTranslations();
        
        // Trigger custom event for other components
        $(document).trigger('translationsUpdated', {
            language: newLanguage,
            translations: this.translations
        });
    }
    
    updateAllTranslations() {
        console.log('🌐 Updating all translations...');
        
        // Update text content
        this.updateTextElements();
        
        // Update placeholders
        this.updatePlaceholders();
        
        // Update titles and tooltips
        this.updateTitles();
        
        // Update form labels
        this.updateLabels();
        
        // Update button text
        this.updateButtons();
    }
    
    updateTextElements() {
        $('[data-translate]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate');
            const translation = this.getTranslation(key);
            
            if (translation) {
                // Handle different element types
                if ($element.is('input[type="submit"], input[type="button"], button')) {
                    if ($element.find('span[data-translate]').length === 0) {
                        $element.text(translation);
                    }
                } else if (!$element.is('input, select, textarea')) {
                    $element.text(translation);
                }
            }
        });
    }
    
    updatePlaceholders() {
        $('[data-translate-placeholder]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate-placeholder');
            const translation = this.getTranslation(key);
            
            if (translation) {
                $element.attr('placeholder', translation);
            }
        });
        
        // Also handle regular data-translate on input elements
        $('input[data-translate], textarea[data-translate]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate');
            const translation = this.getTranslation(key);
            
            if (translation && ($element.is('input[type="text"], input[type="email"], input[type="search"], textarea'))) {
                $element.attr('placeholder', translation);
            }
        });
    }
    
    updateTitles() {
        $('[data-translate-title]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate-title');
            const translation = this.getTranslation(key);
            
            if (translation) {
                $element.attr('title', translation);
            }
        });
    }
    
    updateLabels() {
        $('label[data-translate]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate');
            const translation = this.getTranslation(key);
            
            if (translation) {
                $element.text(translation);
            }
        });
    }
    
    updateButtons() {
        $('button[data-translate] span, input[data-translate]').each((index, element) => {
            const $element = $(element);
            const key = $element.data('translate');
            const translation = this.getTranslation(key);
            
            if (translation) {
                if ($element.is('span')) {
                    $element.text(translation);
                } else if ($element.is('input[type="submit"], input[type="button"]')) {
                    $element.val(translation);
                }
            }
        });
    }
    
    getTranslation(key) {
        // Try current translations first
        if (this.translations && this.translations[key]) {
            return this.translations[key];
        }
        
        // Try fallback translations
        if (this.fallbackTranslations[this.currentLanguage] && this.fallbackTranslations[this.currentLanguage][key]) {
            return this.fallbackTranslations[this.currentLanguage][key];
        }
        
        // Try English fallback
        if (this.currentLanguage !== 'en' && this.fallbackTranslations['en'] && this.fallbackTranslations['en'][key]) {
            return this.fallbackTranslations['en'][key];
        }
        
        return null;
    }
    
    // Public methods
    setLanguage(language) {
        this.currentLanguage = language;
        window.currentLanguage = language;
    }
    
    setTranslations(translations) {
        this.translations = translations;
        window.translations = translations;
    }
    
    translate(key) {
        return this.getTranslation(key) || key;
    }
    
    // Utility method for dynamic content
    translateElement(element, key) {
        const $element = $(element);
        const translation = this.getTranslation(key);
        
        if (translation) {
            if ($element.is('input[type="text"], input[type="email"], textarea')) {
                $element.attr('placeholder', translation);
            } else {
                $element.text(translation);
            }
        }
    }
}

// Initialize translation manager when DOM is ready
$(document).ready(function() {
    window.translationManager = new TranslationManager();
    
    // Expose global translation function
    window.translate = function(key) {
        return window.translationManager ? window.translationManager.translate(key) : key;
    };
    
    // Expose update function
    window.updateTranslations = function() {
        if (window.translationManager) {
            window.translationManager.updateAllTranslations();
        }
    };
    
    console.log('🌐 Translation system initialized');
});
