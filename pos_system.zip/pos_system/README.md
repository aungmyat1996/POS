# BitsTech POS System

A modern Point of Sale (POS) system for computer stores, built with PHP, MySQL, and Bootstrap 5. This system helps you manage sales, inventory, customers, and more.

## Features

- **Dashboard**: Get an overview of daily sales, products, and quick access to key functions
- **Sale Management**: Easily create and manage sales with a user-friendly interface
- **Product Management**: Add, edit, delete, and search products
- **Customer Management**: Track customer information and purchase history
- **Inventory Control**: Monitor stock levels and get low stock alerts
- **Order History**: View and search past orders
- **Reports**: Generate sales reports by date range
- **User Management**: Create users with different roles and permissions
- **Multi-language Support**: Currently supports English and Myanmar languages

## Requirements

- PHP 8.0 or higher
- MySQL 5.7 or higher
- Web server (Apache, Nginx, etc.)
- Modern web browser
- XAMPP, WAMP, MAMP or similar local development environment

## Installation

1. Clone or download this repository to your web server directory
   ```
   git clone https://github.com/yourusername/pos_system.git
   ```

2. Create a MySQL database for the application
   
3. Visit the installation page in your web browser
   ```
   http://localhost/pos_system/install.php
   ```

4. Follow the on-screen instructions to complete the installation:
   - Confirm database settings
   - Create admin account
   - Complete the installation

5. After installation, you can log in with the admin account you created

## Usage

1. **Dashboard**: View key metrics and quick access to functions
2. **New Sale**: Create a new sale by adding products to cart and checking out
3. **Products**: Manage your product catalog 
4. **Customers**: Add and manage customer information
5. **Orders**: View past orders and their details
6. **Reports**: Generate sales reports for any date range
7. **Settings**: Configure system settings, tax rates, and more

## Default Login Credentials

During installation, you'll create an admin account. If you skip that step, the default login is:

- Username: admin
- Password: adminpass

**IMPORTANT**: Change the default password immediately after first login for security!

## Screenshots

(Screenshots will be added soon)

## Support

For support, bug reports, or feature requests, please create an issue in this repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Credits

- Bootstrap 5 for the UI framework
- Bootstrap Icons for the icon set
- Chart.js for the dashboard charts 

# POS System Database လမ်းညွှန်

## Database လုပ်ဆောင်ချက်များ

### ၁။ Data ထည့်သွင်းခြင်း (INSERT)

#### ၁.၁ ဝယ်ယူသူအသစ်ထည့်သွင်းခြင်း
```sql
INSERT INTO customers (customer_name, phone, email, address) 
VALUES ('ဦးမောင်မောင်', '+95 9123456789', 'mgmg@gmail.com', 'ရန်ကုန်၊ လှိုင်မြို့နယ်');
```

#### ၁.၂ ကုန်ပစ္စည်းအသစ်ထည့်သွင်းခြင်း
```sql
INSERT INTO products (
    product_name, 
    category_id, 
    supplier_id, 
    sku, 
    description, 
    unit_price, 
    stock_quantity, 
    reorder_level, 
    cost_price, 
    barcode
) VALUES (
    'Acer Laptop',
    1,
    1,
    'LAP-ACER-001',
    'Acer Aspire 3 Laptop',
    500000,
    10,
    5,
    450000,
    'ACER001'
);
```

### ၂။ Data ကြည့်ရှုခြင်း (SELECT)

#### ၂.၁ ဝယ်ယူသူများစာရင်းကြည့်ခြင်း
```sql
-- ဝယ်ယူသူအားလုံးကြည့်ခြင်း
SELECT * FROM customers;

-- ရန်ကုန်မှဝယ်ယူသူများကိုသာကြည့်ခြင်း
SELECT * FROM customers WHERE address LIKE '%ရန်ကုန်%';

-- ဝယ်ယူသူအမည်နှင့် ဖုန်းနံပါတ်သာကြည့်ခြင်း
SELECT customer_name, phone FROM customers;
```

#### ၂.၂ ကုန်ပစ္စည်းများကြည့်ခြင်း
```sql
-- ကုန်ပစ္စည်းအားလုံးကြည့်ခြင်း
SELECT * FROM products;

-- လက်ကျန်နည်းနေသောကုန်ပစ္စည်းများကြည့်ခြင်း
SELECT * FROM products WHERE stock_quantity <= reorder_level;

-- အမျိုးအစားအလိုက်ကြည့်ခြင်း
SELECT p.*, c.category_name 
FROM products p 
JOIN categories c ON p.category_id = c.category_id 
WHERE c.category_name = 'Laptops';
```

### ၃။ Data ပြင်ဆင်ခြင်း (UPDATE)

#### ၃.၁ ဝယ်ယူသူအချက်အလက်ပြင်ဆင်ခြင်း
```sql
-- ဖုန်းနံပါတ်ပြောင်းလဲခြင်း
UPDATE customers 
SET phone = '+95 9987654321' 
WHERE customer_name = 'ဦးမောင်မောင်';

-- လိပ်စာပြောင်းလဲခြင်း
UPDATE customers 
SET address = 'ရန်ကုန်၊ မရမ်းကုန်းမြို့နယ်' 
WHERE customer_id = 1;
```

#### ၃.၂ ကုန်ပစ္စည်းအချက်အလက်ပြင်ဆင်ခြင်း
```sql
-- စျေးနှုန်းပြောင်းလဲခြင်း
UPDATE products 
SET unit_price = 550000 
WHERE product_name = 'Acer Laptop';

-- လက်ကျန်အရေအတွက်ပြောင်းလဲခြင်း
UPDATE products 
SET stock_quantity = stock_quantity - 1 
WHERE product_id = 1;
```

### ၄။ Data ဖျက်ခြင်း (DELETE)

#### ၄.၁ ဝယ်ယူသူဖျက်ခြင်း
```sql
-- ဝယ်ယူသူတစ်ယောက်ဖျက်ခြင်း
DELETE FROM customers 
WHERE customer_id = 1;

-- မှားယွင်းထည့်သွင်းထားသောဝယ်ယူသူများဖျက်ခြင်း
DELETE FROM customers 
WHERE email IS NULL;
```

#### ၄.၂ ကုန်ပစ္စည်းဖျက်ခြင်း
```sql
-- ကုန်ပစ္စည်းတစ်ခုဖျက်ခြင်း
DELETE FROM products 
WHERE product_id = 1;

-- ရောင်းကုန်ရပ်ဆိုင်းထားသောကုန်ပစ္စည်းများဖျက်ခြင်း
DELETE FROM products 
WHERE status = 'inactive';
```

### ၅။ အသုံးဝင်သော Query များ

#### ၅.၁ အရောင်းအများဆုံးကုန်ပစ္စည်းများ
```sql
SELECT 
    p.product_name,
    COUNT(oi.order_item_id) as total_sales,
    SUM(oi.quantity) as total_quantity
FROM products p
JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_id
ORDER BY total_sales DESC
LIMIT 10;
```

#### ၅.၂ ဝယ်ယူသူအများဆုံးဝယ်ယူသူများ
```sql
SELECT 
    c.customer_name,
    COUNT(o.order_id) as total_orders,
    SUM(o.total_amount) as total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id
ORDER BY total_spent DESC
LIMIT 10;
```

#### ၅.၃ လက်ကျန်နည်းနေသောကုန်ပစ္စည်းများ
```sql
SELECT 
    product_name,
    stock_quantity,
    reorder_level
FROM products
WHERE stock_quantity <= reorder_level
ORDER BY stock_quantity ASC;
```

### ၆။ အခြားလုပ်ဆောင်ချက်များ

#### ၆.၁ အရောင်းပြေစာထုတ်ခြင်း
```sql
SELECT 
    o.order_id,
    c.customer_name,
    p.product_name,
    oi.quantity,
    oi.unit_price,
    oi.subtotal
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.order_id = 1;
```

#### ၆.၂ နေ့စဉ်အရောင်းစာရင်း
```sql
SELECT 
    DATE(o.order_date) as sale_date,
    COUNT(o.order_id) as total_orders,
    SUM(o.total_amount) as total_sales
FROM orders o
GROUP BY DATE(o.order_date)
ORDER BY sale_date DESC;
```

## မှတ်ချက်များ

၁။ Query များရိုက်ထည့်ရာတွင် အထက်ပါ နမူနာများအတိုင်း အသုံးပြုနိုင်ပါသည်။

၂။ MySQL Command Line အသုံးပြုပုံ
```bash
# MySQL သို့ဝင်ရောက်ခြင်း
mysql -u root

# Database ရွေးချယ်ခြင်း
USE pos_system;

# Query ရိုက်ထည့်ခြင်း
SELECT * FROM customers;
```

၃။ လုံခြုံရေးဆိုင်ရာသတိပြုရန်များ
- အရေးကြီးသော Query များမပြုလုပ်မီ data backup ယူထားခြင်း
- DELETE, UPDATE များပြုလုပ်ရာတွင် WHERE condition ကိုသေချာစစ်ဆေးခြင်း
- အသုံးပြုသူအခွင့်အရေးများကိုလိုအပ်သလောက်သာခွင့်ပြုခြင်း

၄။ အကြံပြုချက်များ
- Query များကို file ထဲတွင်သိမ်းဆည်းထားခြင်း
- အရေးကြီးသော Query များကို comment ရေးထားခြင်း
- Regular backup ပြုလုပ်ထားခြင်း 

# Command Prompt မှ MySQL အသုံးပြုပုံ

## ၁။ Command Prompt ဖွင့်နည်း
1. Windows Key + R နှိပ်ပါ
2. `cmd` လို့ရိုက်ပြီး Enter ခေါက်ပါ (သို့) Start Menu မှာ Command Prompt လို့ရှာပြီးဖွင့်ပါ

## ၂။ MySQL Directory သို့သွားရန်
```bash
cd C:\xampp\mysql\bin
```

## ၃။ MySQL သို့ဝင်ရောက်ခြင်း

### ၃.၁ Password မလိုအပ်ပါက
```bash
mysql -u root
```

### ၃.၂ Password လိုအပ်ပါက
```bash
mysql -u root -p
Enter password: ******
```

## ၄။ အခြားအသုံးဝင်သော Commands များ

### ၄.၁ Database များကြည့်ခြင်း
```sql
SHOW DATABASES;
```

### ၄.၂ Database ရွေးချယ်ခြင်း
```sql
USE pos_system;
```

### ၄.၃ Tables များကြည့်ခြင်း
```sql
SHOW TABLES;
```

### ၄.၄ Table ၏ဖွဲ့စည်းပုံကြည့်ခြင်း
```sql
DESCRIBE customers;
```

## ၅။ SQL File များ Import/Export လုပ်ခြင်း

### ၅.၁ SQL File Import လုပ်ခြင်း
```bash
# Command Prompt မှ
mysql -u root pos_system < C:\xampp\htdocs\pos_system\sql\schema.sql

# MySQL Shell ထဲမှ
source C:/xampp/htdocs/pos_system/sql/schema.sql
```

### ၅.၂ Database Backup (Export) လုပ်ခြင်း
```bash
mysqldump -u root pos_system > C:\xampp\htdocs\pos_system\backup\backup.sql
```

## ၆။ အခြားသိကောင်းစရာများ

### ၆.၁ MySQL Service စတင်ခြင်း/ရပ်ဆိုင်းခြင်း
```bash
# Service စတင်ခြင်း
net start mysql

# Service ရပ်ဆိုင်းခြင်း
net stop mysql
```

### ၆.၂ MySQL မှထွက်ခြင်း
```sql
exit;
# (သို့)
quit;
```

### ၆.၃ Screen ရှင်းလင်းခြင်း
```bash
# Command Prompt မှာ
cls

# MySQL Shell ထဲမှာ
system cls
```

## ၇။ အမှားများဖြစ်ပါက

### ၇.၁ MySQL Command မမှန်ပါက
- `;` (semicolon) ထည့်ထားခြင်း ရှိ/မရှိ စစ်ပါ
- Command အရေးအသား မှန်/မမှန် စစ်ပါ
- MySQL Shell ထဲရောက်မှ SQL Query များရိုက်ပါ

### ၇.၂ Access Denied ဖြစ်ပါက
- Username နှင့် Password မှန်/မမှန် စစ်ပါ
- XAMPP Control Panel မှ MySQL running ဖြစ်မဖြစ်စစ်ပါ
- MySQL Service running ဖြစ်မဖြစ်စစ်ပါ

### ၇.၃ File Permission ပြဿနာဖြစ်ပါက
- Command Prompt ကို Administrator အနေနဲ့ဖွင့်ပါ
- File path မှန်/မမှန် စစ်ပါ
- Folder permission စစ်ပါ

## ၈။ အကြံပြုချက်များ
- Command များကို text file ထဲသိမ်းထားပါ
- အရေးကြီးသော Query များကို backup လုပ်ထားပါ
- Password ပါသော command များကို file ထဲမသိမ်းပါနှင့်
- Regular backup ပြုလုပ်ထားပါ 