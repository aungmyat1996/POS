<?php
require_once 'config/db.php';

try {
    // Disable foreign key checks temporarily
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

    // Clear existing data
    $pdo->exec('TRUNCATE TABLE products');
    $pdo->exec('TRUNCATE TABLE categories');

    // Enable foreign key checks
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');

    echo "Data cleared successfully!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 