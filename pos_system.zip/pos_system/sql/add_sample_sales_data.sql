-- =============================================================
--  SAMPLE SALES DATA FOR TESTING
--  Add realistic sales records with various customers, dates, amounts
-- =============================================================

USE pos_system;

-- Add more customers for realistic sales data
INSERT IGNORE INTO customers (customer_name, phone, email, address) VALUES
('Ma Hnin Thuzar', '+95 9777888999', 'hnin@gmail.com', 'Yangon'),
('Ko Aung Naing', '+95 9888999000', 'aung@gmail.com', 'Mandalay'),
('Daw Moe Moe', '+95 9999000111', 'moe@gmail.com', 'Yangon'),
('U Than Htun', '+95 9000111222', 'than@gmail.com', 'Naypyidaw'),
('Ma Ei Ei', '+95 9111222333', 'eiei@gmail.com', 'Yangon'),
('Ko Kyaw Soe', '+95 9222333444', 'kyaw@gmail.com', 'Mandalay'),
('Daw Thida', '+95 9333444555', 'thida@gmail.com', 'Yangon'),
('U Win Maung', '+95 9444555666', 'win@gmail.com', 'Bagan'),
('Ma Nwe Nwe', '+95 9555666777', 'nwe@gmail.com', 'Yangon'),
('Ko Htet Aung', '+95 9666777888', 'htet@gmail.com', 'Mandalay');

-- Add more products for sales
INSERT IGNORE INTO products (product_name, category_id, supplier_id, sku, description, unit_price, discount, stock_quantity, reorder_level, cost_price, barcode) VALUES
('Dell Inspiron 15', 1, 1, 'LAP-DELL-001', '15.6" i5 / 8GB / 512GB SSD', 649.99, 10, 18, 5, 520.00, 'DELL001'),
('HP Pavilion 14', 1, 2, 'LAP-HP-001', '14" Ryzen 7 / 16GB / 512GB', 729.99, 5, 14, 4, 584.00, 'HP001'),
('MacBook Air M2', 1, 3, 'LAP-MAC-001', '13.6" M2 / 8GB / 256GB', 1199.99, 0, 8, 3, 960.00, 'MAC001'),
('Gaming Mouse RGB', 5, 1, 'GAM-MOU-001', 'RGB Gaming Mouse 12000 DPI', 49.99, 15, 25, 8, 35.00, 'GMOU001'),
('Mechanical Keyboard', 5, 2, 'GAM-KEY-001', 'RGB Mechanical Gaming Keyboard', 89.99, 20, 20, 6, 65.00, 'GKEY001'),
('Webcam HD 1080p', 3, 3, 'WEB-CAM-001', 'Full HD Webcam with Microphone', 39.99, 0, 30, 10, 28.00, 'WEB001'),
('USB-C Hub', 3, 1, 'HUB-USB-001', '7-in-1 USB-C Hub with HDMI', 29.99, 10, 35, 12, 20.00, 'HUB001'),
('Wireless Headphones', 5, 2, 'HEAD-WIR-001', 'Bluetooth 5.0 Noise Cancelling', 79.99, 25, 22, 7, 55.00, 'HEAD001');

-- Sample Orders with realistic dates (last 30 days)
INSERT INTO orders (customer_id, user_id, order_date, total_amount, payment_method, payment_status, order_status) VALUES
-- Recent sales (last 7 days)
(1, 1, DATE_SUB(NOW(), INTERVAL 1 DAY), 1249.98, 'card', 'completed', 'completed'),
(2, 2, DATE_SUB(NOW(), INTERVAL 1 DAY), 89.99, 'cash', 'completed', 'completed'),
(3, 1, DATE_SUB(NOW(), INTERVAL 2 DAY), 649.99, 'mobile_payment', 'completed', 'completed'),
(4, 2, DATE_SUB(NOW(), INTERVAL 2 DAY), 169.97, 'cash', 'completed', 'completed'),
(5, 1, DATE_SUB(NOW(), INTERVAL 3 DAY), 729.99, 'card', 'completed', 'completed'),
(6, 2, DATE_SUB(NOW(), INTERVAL 3 DAY), 119.98, 'cash', 'completed', 'completed'),
(7, 1, DATE_SUB(NOW(), INTERVAL 4 DAY), 39.99, 'mobile_payment', 'completed', 'completed'),
(8, 2, DATE_SUB(NOW(), INTERVAL 5 DAY), 1199.99, 'card', 'completed', 'completed'),
(9, 1, DATE_SUB(NOW(), INTERVAL 6 DAY), 259.97, 'cash', 'completed', 'completed'),
(10, 2, DATE_SUB(NOW(), INTERVAL 7 DAY), 449.99, 'card', 'completed', 'completed'),

-- Older sales (8-30 days ago)
(1, 1, DATE_SUB(NOW(), INTERVAL 10 DAY), 89.99, 'cash', 'completed', 'completed'),
(3, 2, DATE_SUB(NOW(), INTERVAL 12 DAY), 649.99, 'card', 'completed', 'completed'),
(5, 1, DATE_SUB(NOW(), INTERVAL 15 DAY), 199.98, 'mobile_payment', 'completed', 'completed'),
(7, 2, DATE_SUB(NOW(), INTERVAL 18 DAY), 1199.99, 'card', 'completed', 'completed'),
(9, 1, DATE_SUB(NOW(), INTERVAL 20 DAY), 79.99, 'cash', 'completed', 'completed'),
(2, 2, DATE_SUB(NOW(), INTERVAL 22 DAY), 729.99, 'card', 'completed', 'completed'),
(4, 1, DATE_SUB(NOW(), INTERVAL 25 DAY), 149.99, 'cash', 'completed', 'completed'),
(6, 2, DATE_SUB(NOW(), INTERVAL 28 DAY), 499.99, 'mobile_payment', 'completed', 'completed'),

-- Some pending and cancelled orders for variety
(8, 1, DATE_SUB(NOW(), INTERVAL 1 HOUR), 299.99, 'card', 'pending', 'pending'),
(10, 2, DATE_SUB(NOW(), INTERVAL 3 HOUR), 89.99, 'cash', 'failed', 'cancelled');

-- Get the order IDs for order items
SET @order1 = (SELECT order_id FROM orders WHERE total_amount = 1249.98 AND DATE(order_date) = DATE_SUB(CURDATE(), INTERVAL 1 DAY) LIMIT 1);
SET @order2 = (SELECT order_id FROM orders WHERE total_amount = 89.99 AND DATE(order_date) = DATE_SUB(CURDATE(), INTERVAL 1 DAY) LIMIT 1);
SET @order3 = (SELECT order_id FROM orders WHERE total_amount = 649.99 AND DATE(order_date) = DATE_SUB(CURDATE(), INTERVAL 2 DAY) LIMIT 1);

-- Order Items for recent sales
INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES
-- Order 1: MacBook + Gaming Mouse
(@order1, 6, 1, 1199.99, 1199.99),
(@order1, 7, 1, 49.99, 49.99),

-- Order 2: Mechanical Keyboard
(@order2, 8, 1, 89.99, 89.99),

-- Order 3: Dell Laptop
(@order3, 4, 1, 649.99, 649.99);

-- Add invoice numbers to orders
UPDATE orders SET 
    invoice_number = CONCAT('INV-', YEAR(order_date), MONTH(order_date), '-', LPAD(order_id, 6, '0'))
WHERE invoice_number IS NULL OR invoice_number = '';

-- Mirror completed orders to sales table
INSERT INTO sales (order_id, customer_id, user_id, sale_date, total_amount, payment_method, payment_status, status)
SELECT order_id, customer_id, user_id, order_date, total_amount, payment_method, payment_status, 'completed'
FROM orders 
WHERE order_status = 'completed' 
AND order_id NOT IN (SELECT DISTINCT order_id FROM sales WHERE order_id IS NOT NULL);

-- Add sale items for completed sales
INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, discount)
SELECT s.sale_id, oi.product_id, oi.quantity, oi.unit_price, 
       COALESCE(p.discount, 0) as discount
FROM sales s
JOIN order_items oi ON s.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE s.sale_id NOT IN (SELECT DISTINCT sale_id FROM sale_items);

-- Update customer purchase totals
UPDATE customers c SET 
    total_purchases = (
        SELECT COALESCE(SUM(o.total_amount), 0) 
        FROM orders o 
        WHERE o.customer_id = c.customer_id 
        AND o.order_status = 'completed'
    ),
    last_purchase_date = (
        SELECT MAX(o.order_date) 
        FROM orders o 
        WHERE o.customer_id = c.customer_id 
        AND o.order_status = 'completed'
    );

-- Add some payment records
INSERT INTO payments (order_id, amount, payment_method, payment_status, transaction_id, payment_date)
SELECT order_id, total_amount, payment_method, payment_status, 
       CONCAT('TXN-', order_id, '-', UNIX_TIMESTAMP(order_date)), order_date
FROM orders 
WHERE order_status = 'completed'
AND order_id NOT IN (SELECT DISTINCT order_id FROM payments WHERE order_id IS NOT NULL);

-- Update product stock based on sales
UPDATE products p SET 
    stock_quantity = stock_quantity - (
        SELECT COALESCE(SUM(oi.quantity), 0)
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        WHERE oi.product_id = p.product_id
        AND o.order_status = 'completed'
        AND o.order_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    )
WHERE p.product_id IN (
    SELECT DISTINCT oi.product_id 
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.order_status = 'completed'
    AND o.order_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
);

-- Ensure no negative stock
UPDATE products SET stock_quantity = 0 WHERE stock_quantity < 0;

-- Set some products to low stock for testing
UPDATE products SET stock_quantity = 2 WHERE product_id IN (1, 2, 6);
UPDATE products SET stock_quantity = 0 WHERE product_id IN (3);

COMMIT;

-- Display summary
SELECT 'Sample Sales Data Added Successfully!' as Status;
SELECT COUNT(*) as 'Total Orders' FROM orders;
SELECT COUNT(*) as 'Completed Orders' FROM orders WHERE order_status = 'completed';
SELECT COUNT(*) as 'Sales Records' FROM sales;
SELECT COUNT(*) as 'Customers with Purchases' FROM customers WHERE total_purchases > 0;
