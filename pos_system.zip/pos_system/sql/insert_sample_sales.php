<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'config/db.php';

try {
    echo "Adding sample sales data...\n";

    // Add more customers
    $customers = [
        ['Ma Hnin Thuzar', '+95 9777888999', 'hnin@gmail.com', 'Yangon'],
        ['Ko Aung Naing', '+95 9888999000', 'aung@gmail.com', 'Mandalay'],
        ['Daw Moe Moe', '+95 9999000111', 'moe@gmail.com', 'Yangon'],
        ['U Than Htun', '+95 9000111222', 'than@gmail.com', 'Naypyidaw'],
        ['Ma Ei Ei', '+95 9111222333', 'eiei@gmail.com', 'Yangon'],
        ['Ko Kyaw Soe', '+95 9222333444', 'kyaw@gmail.com', 'Mandalay'],
        ['Daw Thida', '+95 9333444555', 'thida@gmail.com', 'Yangon'],
        ['U Win Maung', '+95 9444555666', 'win@gmail.com', 'Bagan']
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO customers (customer_name, phone, email, address) VALUES (?, ?, ?, ?)");
    foreach ($customers as $customer) {
        $stmt->execute($customer);
    }
    echo "Customers added.\n";

    // Add more products
    $products = [
        ['Dell Inspiron 15', 1, 1, 'LAP-DELL-001', '15.6" i5 / 8GB / 512GB SSD', 649.99, 10, 18, 5, 520.00, 'DELL001'],
        ['HP Pavilion 14', 1, 2, 'LAP-HP-001', '14" Ryzen 7 / 16GB / 512GB', 729.99, 5, 14, 4, 584.00, 'HP001'],
        ['MacBook Air M2', 1, 3, 'LAP-MAC-001', '13.6" M2 / 8GB / 256GB', 1199.99, 0, 8, 3, 960.00, 'MAC001'],
        ['Gaming Mouse RGB', 5, 1, 'GAM-MOU-001', 'RGB Gaming Mouse 12000 DPI', 49.99, 15, 25, 8, 35.00, 'GMOU001'],
        ['Mechanical Keyboard', 5, 2, 'GAM-KEY-001', 'RGB Mechanical Gaming Keyboard', 89.99, 20, 20, 6, 65.00, 'GKEY001'],
        ['Webcam HD 1080p', 3, 3, 'WEB-CAM-001', 'Full HD Webcam with Microphone', 39.99, 0, 30, 10, 28.00, 'WEB001'],
        ['USB-C Hub', 3, 1, 'HUB-USB-001', '7-in-1 USB-C Hub with HDMI', 29.99, 10, 35, 12, 20.00, 'HUB001'],
        ['Wireless Headphones', 5, 2, 'HEAD-WIR-001', 'Bluetooth 5.0 Noise Cancelling', 79.99, 25, 22, 7, 55.00, 'HEAD001']
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO products (product_name, category_id, supplier_id, sku, description, unit_price, discount, stock_quantity, reorder_level, cost_price, barcode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($products as $product) {
        $stmt->execute($product);
    }
    echo "Products added.\n";

    // Add sample orders with realistic dates
    $orders = [
        // Recent sales (last 7 days)
        [1, 1, date('Y-m-d H:i:s', strtotime('-1 day')), 1249.98, 'card', 'completed', 'completed'],
        [2, 2, date('Y-m-d H:i:s', strtotime('-1 day')), 89.99, 'cash', 'completed', 'completed'],
        [3, 1, date('Y-m-d H:i:s', strtotime('-2 days')), 649.99, 'mobile_payment', 'completed', 'completed'],
        [4, 2, date('Y-m-d H:i:s', strtotime('-2 days')), 169.97, 'cash', 'completed', 'completed'],
        [5, 1, date('Y-m-d H:i:s', strtotime('-3 days')), 729.99, 'card', 'completed', 'completed'],
        [6, 2, date('Y-m-d H:i:s', strtotime('-3 days')), 119.98, 'cash', 'completed', 'completed'],
        [7, 1, date('Y-m-d H:i:s', strtotime('-4 days')), 39.99, 'mobile_payment', 'completed', 'completed'],
        [8, 2, date('Y-m-d H:i:s', strtotime('-5 days')), 1199.99, 'card', 'completed', 'completed'],
        [9, 1, date('Y-m-d H:i:s', strtotime('-6 days')), 259.97, 'cash', 'completed', 'completed'],
        [10, 2, date('Y-m-d H:i:s', strtotime('-7 days')), 449.99, 'card', 'completed', 'completed'],

        // Older sales
        [1, 1, date('Y-m-d H:i:s', strtotime('-10 days')), 89.99, 'cash', 'completed', 'completed'],
        [3, 2, date('Y-m-d H:i:s', strtotime('-12 days')), 649.99, 'card', 'completed', 'completed'],
        [5, 1, date('Y-m-d H:i:s', strtotime('-15 days')), 199.98, 'mobile_payment', 'completed', 'completed'],
        [7, 2, date('Y-m-d H:i:s', strtotime('-18 days')), 1199.99, 'card', 'completed', 'completed'],
        [9, 1, date('Y-m-d H:i:s', strtotime('-20 days')), 79.99, 'cash', 'completed', 'completed'],

        // Some pending orders
        [8, 1, date('Y-m-d H:i:s', strtotime('-1 hour')), 299.99, 'card', 'pending', 'pending'],
        [10, 2, date('Y-m-d H:i:s', strtotime('-3 hours')), 89.99, 'cash', 'failed', 'cancelled']
    ];

    $stmt = $pdo->prepare("INSERT INTO orders (customer_id, user_id, order_date, total_amount, payment_method, payment_status, order_status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    foreach ($orders as $order) {
        $stmt->execute($order);
    }
    echo "Orders added.\n";

    // Add invoice_number column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE orders ADD COLUMN invoice_number VARCHAR(50) AFTER order_id");
        echo "Invoice number column added.\n";
    } catch (PDOException $e) {
        // Column already exists, that's fine
    }

    // Add invoice numbers
    $pdo->exec("UPDATE orders SET invoice_number = CONCAT('INV-', YEAR(order_date), LPAD(MONTH(order_date), 2, '0'), '-', LPAD(order_id, 6, '0')) WHERE invoice_number IS NULL OR invoice_number = ''");
    echo "Invoice numbers updated.\n";

    // Get some order IDs for order items
    $stmt = $pdo->query("SELECT order_id, total_amount FROM orders WHERE order_status = 'completed' ORDER BY order_date DESC LIMIT 10");
    $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Add order items for some orders
    $order_items = [
        [$recent_orders[0]['order_id'], 6, 1, 1199.99, 1199.99], // MacBook
        [$recent_orders[0]['order_id'], 7, 1, 49.99, 49.99],     // Gaming Mouse
        [$recent_orders[1]['order_id'], 8, 1, 89.99, 89.99],     // Keyboard
        [$recent_orders[2]['order_id'], 4, 1, 649.99, 649.99],   // Dell Laptop
        [$recent_orders[3]['order_id'], 9, 2, 79.99, 159.98],    // Headphones x2
        [$recent_orders[4]['order_id'], 5, 1, 729.99, 729.99],   // HP Laptop
        [$recent_orders[5]['order_id'], 10, 3, 39.99, 119.97],   // Webcam x3
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)");
    foreach ($order_items as $item) {
        $stmt->execute($item);
    }
    echo "Order items added.\n";

    // Mirror completed orders to sales table
    $pdo->exec("
        INSERT IGNORE INTO sales (order_id, customer_id, user_id, sale_date, total_amount, payment_method, payment_status, status)
        SELECT order_id, customer_id, user_id, order_date, total_amount, payment_method, payment_status, 'completed'
        FROM orders
        WHERE order_status = 'completed'
    ");
    echo "Sales records created.\n";

    // Update customer totals
    $pdo->exec("
        UPDATE customers c SET
            total_purchases = (
                SELECT COALESCE(SUM(o.total_amount), 0)
                FROM orders o
                WHERE o.customer_id = c.customer_id
                AND o.order_status = 'completed'
            ),
            last_purchase_date = (
                SELECT MAX(o.order_date)
                FROM orders o
                WHERE o.customer_id = c.customer_id
                AND o.order_status = 'completed'
            )
    ");
    echo "Customer totals updated.\n";

    // Set some products to low stock
    $pdo->exec("UPDATE products SET stock_quantity = 2 WHERE product_id IN (1, 2, 6)");
    $pdo->exec("UPDATE products SET stock_quantity = 0 WHERE product_id IN (3)");
    echo "Stock levels adjusted.\n";

    // Display summary
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM orders");
    $total_orders = $stmt->fetchColumn();

    $stmt = $pdo->query("SELECT COUNT(*) as completed FROM orders WHERE order_status = 'completed'");
    $completed_orders = $stmt->fetchColumn();

    $stmt = $pdo->query("SELECT COUNT(*) as sales FROM sales");
    $sales_records = $stmt->fetchColumn();

    echo "\n=== SUMMARY ===\n";
    echo "Total Orders: $total_orders\n";
    echo "Completed Orders: $completed_orders\n";
    echo "Sales Records: $sales_records\n";
    echo "Sample sales data added successfully!\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
