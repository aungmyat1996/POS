<?php
define('BASEPATH', __DIR__ . '/');
require_once BASEPATH . 'config/config.php';

try {
    // Create database connection
    $pdo = new PDO(
        "mysql:host=" . DB_HOST,
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Connected to MySQL successfully.\n";

    // Read and execute init.sql
    $init_sql = file_get_contents(__DIR__ . '/sql/init.sql');
    if ($init_sql === false) {
        throw new Exception("Could not read init.sql file");
    }

    // Split and execute each statement
    $statements = array_filter(
        array_map(
            'trim',
            explode(';', $init_sql)
        ),
        'strlen'
    );

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            echo "Executed statement successfully.\n";
        } catch (PDOException $e) {
            echo "Error executing statement: " . $e->getMessage() . "\n";
            echo "Statement was: " . $statement . "\n";
        }
    }

    // Read and execute schema.sql for sample data
    $schema_sql = file_get_contents(__DIR__ . '/sql/schema.sql');
    if ($schema_sql === false) {
        throw new Exception("Could not read schema.sql file");
    }

    // Extract only the INSERT statements
    preg_match_all("/INSERT INTO.*?;/s", $schema_sql, $matches);
    $insert_statements = $matches[0];

    foreach ($insert_statements as $statement) {
        try {
            $pdo->exec($statement);
            echo "Inserted sample data successfully.\n";
        } catch (PDOException $e) {
            echo "Error inserting sample data: " . $e->getMessage() . "\n";
            echo "Statement was: " . $statement . "\n";
        }
    }

    // Verify products table structure
    $result = $pdo->query("DESCRIBE products");
    $columns = $result->fetchAll(PDO::FETCH_COLUMN);
    echo "\nProducts table columns:\n";
    print_r($columns);

    echo "\nDatabase initialization completed successfully!\n";

} catch (PDOException $e) {
    die("Database initialization failed: " . $e->getMessage() . "\n");
}
?> 