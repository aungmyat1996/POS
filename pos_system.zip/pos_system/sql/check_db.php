<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';

try {
    // Check database connection
    echo "Database Connection Status:\n";
    echo "------------------------\n";
    echo "Connected to database: " . DB_NAME . "\n";
    echo "Host: " . DB_HOST . "\n\n";

    // Check if tables exist and have data
    $tables = [
        'products' => "SELECT COUNT(*) FROM products",
        'orders' => "SELECT COUNT(*) FROM orders",
        'customers' => "SELECT COUNT(*) FROM customers"
    ];

    echo "Table Status:\n";
    echo "-------------\n";
    foreach ($tables as $table => $query) {
        try {
            // Check if table exists
            $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
            $exists = $stmt->rowCount() > 0;
            echo "$table table exists: " . ($exists ? "Yes" : "No") . "\n";
            
            if ($exists) {
                // Count records
                $stmt = $pdo->query($query);
                $count = $stmt->fetchColumn();
                echo "Total records in $table: $count\n";
                
                // Show table structure
                $stmt = $pdo->query("DESCRIBE $table");
                echo "Table structure:\n";
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "  - {$row['Field']} ({$row['Type']})\n";
                }
            }
            echo "\n";
        } catch (PDOException $e) {
            echo "Error checking $table: " . $e->getMessage() . "\n\n";
        }
    }

} catch (PDOException $e) {
    echo "Connection Error: " . $e->getMessage() . "\n";
    echo "Error Code: " . $e->getCode() . "\n";
} 