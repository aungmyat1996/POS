<?php
require_once __DIR__ . '/config/config.php';
require_once BASEPATH . 'config/db.php';

header('Content-Type: application/json');

try {
    // Get the latest order ID for the current user
    $stmt = $pdo->prepare("
        SELECT order_id 
        FROM orders 
        WHERE user_id = ? 
        ORDER BY order_date DESC 
        LIMIT 1
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode(['success' => true, 'order_id' => $result['order_id']]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No recent order found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
} 