<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';

try {
    // Check if database exists
    $stmt = $pdo->query("SELECT DATABASE()");
    $db_name = $stmt->fetchColumn();
    echo "Current database: " . $db_name . "\n\n";

    // Check if tables exist
    $tables = ['products', 'orders', 'customers'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        $exists = $stmt->rowCount() > 0;
        echo "Table '$table' exists: " . ($exists ? "Yes" : "No") . "\n";
    }
    echo "\n";

    // Check products table
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM products WHERE stock_quantity <= 5 AND stock_quantity > 0");
    $low_stock_count = $stmt->fetchColumn();
    echo "Low stock items count: " . $low_stock_count . "\n";

    // Check today's sales
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders WHERE DATE(order_date) = CURDATE() AND order_status = 'completed'");
    $today_sales_count = $stmt->fetchColumn();
    echo "Today's sales count: " . $today_sales_count . "\n";

    // Check today's customers
    $stmt = $pdo->query("SELECT COUNT(DISTINCT customer_id) as count FROM orders WHERE DATE(order_date) = CURDATE() AND order_status = 'completed' AND customer_id IS NOT NULL");
    $today_customers_count = $stmt->fetchColumn();
    echo "Today's customers count: " . $today_customers_count . "\n";

    // Check sample data
    echo "\nSample products with low stock:\n";
    $stmt = $pdo->query("SELECT product_id, product_name, stock_quantity FROM products WHERE stock_quantity <= 5 AND stock_quantity > 0 LIMIT 5");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
    }

    echo "\nSample today's orders:\n";
    $stmt = $pdo->query("SELECT order_id, order_date, total_amount, order_status FROM orders WHERE DATE(order_date) = CURDATE() LIMIT 5");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
    }

    echo "\nSample today's customers:\n";
    $stmt = $pdo->query("SELECT DISTINCT c.customer_id, c.customer_name FROM customers c JOIN orders o ON c.customer_id = o.customer_id WHERE DATE(o.order_date) = CURDATE() AND o.order_status = 'completed' LIMIT 5");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Error code: " . $e->getCode() . "\n";
} 