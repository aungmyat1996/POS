-- =============================================================
--  BitsTech POS System – FULL INSTALLATION SCRIPT (schema + data)
--  Import this file in one run (phpMyAdmin ▸ Import, MySQL-CLI ▸ mysql < pos_system_full.sql, etc.).
--  It contains:
--     • Database creation
--     • All tables / views (discount column already included)
--     • Core seed data (settings, admin user, categories, suppliers …)
--     • Rich sample data (products, customers, orders …)
-- =============================================================

/* -------------------------------------------------------------
   1.  CREATE / SELECT DATABASE
---------------------------------------------------------------- */
CREATE DATABASE IF NOT EXISTS `pos_system`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `pos_system`;

/* -------------------------------------------------------------
   2.  CLEAN PREVIOUS INSTALL (drops are safe if fresh install)
---------------------------------------------------------------- */
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notifications, order_items, orders, product_history, products,
    customers, suppliers, categories, users, settings, expenses, expense_categories,
    returns, return_items, logs, purchase_orders, purchase_order_items, payments,
    discounts, archived_orders, archived_order_items, sales, sale_items, product_images;
SET FOREIGN_KEY_CHECKS = 1;

/* -------------------------------------------------------------
   3.  TABLE DEFINITIONS (taken from pos_tables.sql + discount column)
---------------------------------------------------------------- */

-- SETTINGS
CREATE TABLE settings (
    setting_id   INT AUTO_INCREMENT PRIMARY KEY,
    setting_key  VARCHAR(50)  UNIQUE NOT NULL,
    setting_value TEXT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- USERS
CREATE TABLE users (
    user_id    INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50) UNIQUE NOT NULL,
    password   VARCHAR(255)        NOT NULL,
    full_name  VARCHAR(100)        NOT NULL,
    email      VARCHAR(100) UNIQUE NOT NULL,
    role       ENUM('admin','cashier') DEFAULT 'cashier',
    status     ENUM('active','inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_role     (role),
    INDEX idx_status   (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- CATEGORIES
CREATE TABLE categories (
    category_id   INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description   TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SUPPLIERS
CREATE TABLE suppliers (
    supplier_id   INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    contact_name  VARCHAR(100),
    contact_email VARCHAR(100),
    phone         VARCHAR(20),
    address       TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier_name (supplier_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- CUSTOMERS
CREATE TABLE customers (
    customer_id        INT AUTO_INCREMENT PRIMARY KEY,
    customer_name      VARCHAR(100) NOT NULL,
    phone              VARCHAR(20),
    email              VARCHAR(100),
    address            VARCHAR(255),
    total_purchases    DECIMAL(12,2) DEFAULT 0.00,
    last_purchase_date TIMESTAMP NULL,
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_customer_name (customer_name),
    INDEX idx_phone         (phone),
    INDEX idx_email         (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PRODUCTS  (discount column already included)
CREATE TABLE products (
    product_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_name    VARCHAR(255) NOT NULL,
    category_id     INT,
    supplier_id     INT,
    sku             VARCHAR(50) UNIQUE NOT NULL,
    description     TEXT,
    unit_price      DECIMAL(10,2) NOT NULL,
    image           VARCHAR(255) DEFAULT NULL,
    discount        DECIMAL(10,2) DEFAULT 0,          --  << NEW COLUMN
    stock_quantity  INT NOT NULL DEFAULT 0,
    reorder_level   INT NOT NULL DEFAULT 5,
    cost_price      DECIMAL(10,2) NOT NULL,
    barcode         VARCHAR(50) UNIQUE,
    status          ENUM('active','inactive','discontinued') DEFAULT 'active',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL,
    INDEX idx_product_name (product_name),
    INDEX idx_sku         (sku),
    INDEX idx_barcode     (barcode),
    INDEX idx_status      (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ORDERS
CREATE TABLE orders (
    order_id        INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT,
    user_id         INT NOT NULL,
    order_date      DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_amount    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method  ENUM('cash','card','mobile_payment') NOT NULL,
    payment_status  ENUM('pending','completed','failed') DEFAULT 'pending',
    order_status    ENUM('pending','completed','cancelled') DEFAULT 'pending',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL,
    FOREIGN KEY (user_id)    REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ORDER ITEMS
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    product_id    INT NOT NULL,
    quantity      INT NOT NULL,
    unit_price    DECIMAL(10,2) NOT NULL,
    subtotal      DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(order_id)   ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PAYMENTS
CREATE TABLE payments (
    payment_id     INT AUTO_INCREMENT PRIMARY KEY,
    order_id       INT,
    amount         DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash','card','mobile_payment') NOT NULL,
    payment_status ENUM('pending','completed','failed') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    payment_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SALES
CREATE TABLE IF NOT EXISTS sales (
    sale_id      INT AUTO_INCREMENT PRIMARY KEY,
    order_id     INT,
    user_id      INT,
    customer_id  INT,
    sale_date    DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method  ENUM('cash','card','mobile_payment') DEFAULT 'cash',
    payment_status  ENUM('pending','completed','failed') DEFAULT 'completed',
    status       ENUM('pending','completed','cancelled') DEFAULT 'completed',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id)    REFERENCES orders(order_id) ON DELETE SET NULL,
    FOREIGN KEY (user_id)     REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SALE ITEMS
CREATE TABLE IF NOT EXISTS sale_items (
    sale_item_id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id      INT NOT NULL,
    product_id   INT NOT NULL,
    quantity     INT NOT NULL,
    unit_price   DECIMAL(10,2) NOT NULL,
    discount     DECIMAL(10,2) DEFAULT 0,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PRODUCT HISTORY (basic)
CREATE TABLE product_history (
    history_id     INT AUTO_INCREMENT PRIMARY KEY,
    product_id     INT,
    user_id        INT,
    action         ENUM('purchase','sale','adjustment') NOT NULL,
    quantity       INT,
    old_quantity   INT,
    new_quantity   INT,
    reference_id   INT,
    notes          TEXT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (user_id)    REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PRODUCT IMAGES (advanced image management)
CREATE TABLE IF NOT EXISTS product_images (
    image_id       INT AUTO_INCREMENT PRIMARY KEY,
    product_id     INT NOT NULL,
    image_path     VARCHAR(255) NOT NULL,
    image_name     VARCHAR(255) NOT NULL,
    image_type     VARCHAR(50)  DEFAULT 'additional',
    is_primary     TINYINT(1)   DEFAULT 0,
    display_order  INT          DEFAULT 0,
    uploaded_by    INT          DEFAULT NULL,
    uploaded_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    file_size      INT          DEFAULT NULL,
    mime_type      VARCHAR(100) DEFAULT NULL,
    alt_text       VARCHAR(255) DEFAULT NULL,
    status         ENUM('active','inactive','deleted') DEFAULT 'active',
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(user_id)     ON DELETE SET NULL,
    INDEX idx_prod_primary (product_id,is_primary),
    INDEX idx_prod_order   (product_id,display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- NOTIFICATIONS (for alerts, orders, system messages)
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT,
    type            ENUM('low_stock','order','system') DEFAULT 'system',
    message         TEXT NOT NULL,
    is_read         TINYINT(1) DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_type    (type),
    INDEX idx_is_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* -------------------------------------------------------------
   4.  CORE SEED DATA (settings + admin user)
---------------------------------------------------------------- */
INSERT INTO settings (setting_key, setting_value) VALUES
('store_name',        'BitsTech POS'),
('site_name',         'BitsTech'),
('store_address',     'Yangon, Myanmar'),
('store_phone',       '+95 9123456789'),
('store_email',       'info@example.com'),
('currency',          'USD'),
('tax_rate',          '5'),
('timezone',          'Asia/Yangon'),
('language',          'en'),
('low_stock_threshold','5');


-- Insert sample data for users
INSERT INTO users (user_id, username, email, password, role, created_at) VALUES
(1, 'admin', 'admin@laptopsstore.com', '$2a$12$500LFI5QtLyYUAh87rh9EOQWdFPzXUvMWKprbDk17ICPaIKjim25i', 'admin', '2025-05-24 00:00:00'),
(2, 'cashier1', 'cashier1@laptopsstore.com', '$2a$12$6cV7Me1dsfWyxHOuPuBvW.cXg8fnwSUMffLN3pVFOxTGFoejK3YNq', 'cashier', '2025-05-24 00:00:00');

/* -------------------------------------------------------------
   5.  SAMPLE BUSINESS DATA (categories, suppliers, customers, products…)
---------------------------------------------------------------- */
-- CATEGORIES
INSERT INTO categories (category_name, description) VALUES
('Laptops',        'Portable computers'),
('Desktop PCs',    'Pre-built desktop machines'),
('Computer Parts', 'Individual components'),
('Monitors',       'Displays'),
('Gaming Gear',    'Gaming peripherals');

-- SUPPLIERS
INSERT INTO suppliers (supplier_name, contact_name, contact_email, phone, address) VALUES
('Myanmar Computer City', 'U Aung Ko',  'aungko@mcc.com',   '+95 9123456789', 'Yangon'),
('Tech Hub Myanmar',      'Daw Aye Aye','ayeaye@techhub.com','+95 9234567890', 'Mandalay'),
('Digital World',         'Ma Hla Hla', 'hlahla@dw.com',    '+95 9345678901', 'Yangon');

-- CUSTOMERS (sample 5)
INSERT INTO customers (customer_name, phone, email, address) VALUES
('U Myint Aung',   '+95 9111222333', 'myint@gmail.com',   'Yangon'),
('Daw Khin Ma Ma', '+95 9222333444', 'khin@gmail.com',    'Mandalay'),
('Ko Zaw Min',     '+95 9333444555', 'zaw@gmail.com',     'Yangon'),
('Ma Thiri',       '+95 9444555666', 'thiri@gmail.com',   'Yangon'),
('Ko Ye Htut',     '+95 9555666777', 'yehtut@gmail.com',  'Mandalay');

-- PRODUCTS (short sample – add more as needed)
INSERT INTO products (product_name, category_id, supplier_id, sku, description, unit_price, discount, stock_quantity, reorder_level, cost_price, barcode)
VALUES
('Acer Aspire 3', 1, 1, 'LAP-ACER-001', '15.6" Ryzen 5 / 8GB / 256GB', 499.99, 0, 15, 5, 400.00, 'ACER001'),
('Lenovo IdeaPad', 1, 2, 'LAP-LEN-001',  '14" i3 / 8GB / 256GB',        449.99, 5, 12, 4, 360.00, 'LEN001'),
('ASUS 24" Monitor',4, 3,'MON-24-001',  '1080p IPS Monitor',           149.99, 0, 20, 6, 120.00, 'MON001');

/* -------------------------------------------------------------
   6.  SAMPLE TRANSACTIONS (minimal)
---------------------------------------------------------------- */
-- Order
INSERT INTO orders (customer_id, user_id, order_date, total_amount, payment_method, payment_status, order_status)
VALUES (1, 1, NOW(), 699.97, 'cash', 'completed', 'completed');
SET @order_id = LAST_INSERT_ID();

-- Order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal)
VALUES (@order_id, 1,1,499.99,499.99),
       (@order_id, 3,1,149.99,149.99);

-- Payment record
INSERT INTO payments (order_id, amount, payment_method, payment_status, transaction_id)
VALUES (@order_id, 699.97, 'cash', 'completed', CONCAT('TXN-', @order_id));

-- Mirror to sales table
INSERT INTO sales (order_id, customer_id, user_id, sale_date, total_amount, payment_method, payment_status, status)
SELECT order_id, customer_id, user_id, order_date, total_amount, payment_method, payment_status, 'completed'
FROM orders WHERE order_id = @order_id;

-- Product history + stock deduction
UPDATE products SET stock_quantity = stock_quantity - 1 WHERE product_id IN (1,3);
INSERT INTO product_history (product_id, user_id, action, quantity, old_quantity, new_quantity, reference_id, notes)
SELECT p.product_id, 1, 'sale', 1, stock_quantity+1, stock_quantity, @order_id,
       CONCAT('Sold in order #',@order_id) FROM products p WHERE p.product_id IN (1,3);

/* -------------------------------------------------------------
   DONE – re-enable FK checks
---------------------------------------------------------------- */
SET FOREIGN_KEY_CHECKS = 1;

-- Insert default image rows for any product lacking entry
INSERT INTO product_images (product_id,image_path,image_name,image_type,is_primary,display_order)
SELECT p.product_id,
       CONCAT('images/', COALESCE(p.image,'default.jpg')),
       COALESCE(p.image,'default.jpg'),
       'primary',1,1
FROM products p
LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
WHERE pi.product_id IS NULL;

-- --- END OF SCRIPT ---