-- =============================================================
--  EXTRA SAMPLE DATA (20 categories, 50 products) + quick sales view
--  Import AFTER core schema is in place.
-- =============================================================

USE pos_system;

/* -------------------------------------------------------------
   CATEGORIES (20)
---------------------------------------------------------------- */
INSERT INTO categories (category_name, description) VALUES
('Smartphones','Mobile devices'),
('Tablets','Portable tablets'),
('Printers','Inkjet & Laser'),
('Networking','Routers & Switches'),
('Storage','HDD / SSD / Flash'),
('Audio','Speakers & Headphones'),
('Cameras','Digital cameras'),
('Software','OS & Office'),
('Gaming Consoles','PlayStation / Xbox'),
('Wearables','Smart watches'),
('Accessories','Cables & Adapters'),
('Office Furniture','Desks / Chairs'),
('Servers','Rack & Tower'),
('Projectors','Business & Home'),
('Scanners','Flatbed & Sheetfed'),
('Drones','Quadcopters'),
('VR / AR','Virtual reality'),
('Power','UPS & Power banks'),
('Cooling','Fans & Coolers'),
('Motherboards','Desktop boards');

/* -------------------------------------------------------------
   PRODUCTS (50) – spread across categories 1-20, suppliers 1-3
---------------------------------------------------------------- */
INSERT INTO products (product_name, category_id, supplier_id, sku, description, unit_price, discount, stock_quantity, reorder_level, cost_price, barcode)
VALUES
('iPhone 14',               1,1,'PH-APL-001','128GB Midnight',799.00,0,25,5,640,'IPH14'),
('Galaxy S23',              1,2,'PH-SAM-001','256GB Green',749.00,5,20,5,600,'GS23'),
('iPad Air 5',              2,1,'TAB-APL-001','64GB Space Gray',599.00,0,15,3,480,'IPA5'),
('Galaxy Tab S8',           2,2,'TAB-SAM-001','128GB Silver',699.00,10,10,3,560,'GTS8'),
('Brother HL-L2350DW',      3,3,'PRN-BRO-001','Mono Laser Printer',199.00,0,12,2,160,'PRN01'),
('HP DeskJet 2755e',        3,3,'PRN-HP-001','All-in-One Inkjet',99.00,0,18,4,75,'PRN02'),
('TP-Link Archer AX55',     4,2,'NET-TPL-002','AX3000 WiFi 6',129.00,0,22,5,100,'NET02'),
('Netgear GS308',           4,2,'NET-NET-001','8-Port Gigabit Switch',29.00,0,40,10,20,'NET03'),
('Samsung 980 1TB SSD',     5,1,'SSD-SAM-003','NVMe M.2',119.00,0,30,8,90,'SSD1'),
('Seagate 4TB HDD',         5,2,'HDD-SEA-003','3.5" BarraCuda',89.00,0,25,8,70,'HDD4'),
('Sony WH-1000XM5',         6,3,'AUD-SON-001','Noise Cancelling',399.00,15,12,3,310,'AUD1'),
('JBL Flip 6',              6,3,'AUD-JBL-001','Portable Speaker',129.00,0,28,6,100,'AUD2'),
('Canon EOS M50 II',        7,3,'CAM-CAN-001','Mirrorless 24MP',649.00,0,8,2,520,'CAM1'),
('Nikon Z30',               7,3,'CAM-NIK-001','Mirrorless 21MP',709.00,0,6,2,570,'CAM2'),
('Windows 11 Pro License',  8,1,'SW-MIC-001','Digital Key',199.00,0,50,10,0,'SW1'),
('Office 365 1Y',           8,1,'SW-MIC-002','Family 6-user',99.00,0,60,12,0,'SW2'),
('PlayStation 5',           9,1,'CON-SON-001','Disc Edition',499.00,0,7,2,400,'PS5'),
('Xbox Series X',           9,2,'CON-MIC-001','1TB SSD',499.00,0,9,2,400,'XBX'),
('Apple Watch Series 9',    10,1,'WAR-APL-001','GPS 45mm',399.00,0,14,3,320,'AW9'),
('Fitbit Versa 4',          10,3,'WAR-FIT-001','Black/Graphite',229.00,0,18,4,180,'FV4'),
('USB-C to HDMI Cable',     11,2,'CAB-USBC-001','2m 4K',19.99,0,100,20,10,'CAB1'),
('Anker 65W GaN Charger',   11,2,'ACC-ANK-001','2-Port',39.99,0,40,8,28,'ACC1'),
('Ergo Office Chair',       12,3,'FUR-CHA-001','Mesh Back',149.00,0,12,2,110,'CHA1'),
('Standing Desk 120cm',     12,3,'FUR-DES-001','Electric Height',299.00,0,6,2,240,'DES1'),
('Dell PowerEdge T40',      13,1,'SRV-DEL-001','Entry Tower',569.00,0,4,1,450,'SRV1'),
('HPE ProLiant ML30',       13,1,'SRV-HPE-001','Gen10 Plus',949.00,0,3,1,760,'SRV2'),
('Epson Home Cinema 2250',  14,3,'PRO-EPS-001','1080p Projector',899.00,0,5,1,720,'PROJ1'),
('BenQ TH671ST',            14,3,'PRO-BEN-001','1080p Short-Throw',749.00,0,5,1,600,'PROJ2'),
('Fujitsu ScanSnap iX1300', 15,3,'SCN-FUJ-001','Sheet-fed Scanner',279.00,0,8,2,220,'SCN1'),
('DJI Mini 3 Pro',          16,2,'DRN-DJI-001','4K Drone',759.00,0,4,1,620,'DRN1'),
('Meta Quest 3',            17,1,'VR-MET-001','128GB VR Headset',499.00,0,6,1,400,'VR1'),
('APC Back-UPS 850VA',      18,2,'PWR-APC-001','UPS',129.00,0,10,2,95,'UPS1'),
('Sandisk PowerBank 20k',   18,1,'PWR-SAN-001','20,000mAh',39.99,0,30,6,25,'PB1'),
('CoolerMaster Hyper 212',  19,2,'CL-CM-001','CPU Air Cooler',39.99,0,25,5,25,'COOL1'),
('Noctua NF-A12x25',        19,3,'CL-NOC-001','120mm Fan',29.99,0,40,8,18,'COOL2'),
('ASUS TUF Z790',           20,1,'MB-ASU-001','LGA1700 ATX',329.00,0,6,2,260,'MB1'),
('MSI MAG B650',            20,1,'MB-MSI-001','AM5 ATX',259.00,0,8,2,210,'MB2'),
('Google Pixel 8',          1,2,'PH-GGL-001','128GB Obsidian',699.00,0,15,3,560,'PIX8'),
('OnePlus 11',              1,3,'PH-OP-001','256GB Black',649.00,0,14,3,520,'OP11'),
('iPad Pro 11"',           2,1,'TAB-APL-002','128GB Silver',799.00,0,9,2,640,'IPDPRO'),
('Lenovo Tab P12',          2,2,'TAB-LEN-001','256GB',499.00,0,11,3,390,'LENP12'),
('Brother DCP-T226',        3,3,'PRN-BRO-002','Ink Tank AIO',189.00,0,14,3,150,'PRN03'),
('Seagate NVMe FireCuda',   5,2,'SSD-SEA-001','2TB Gen4',249.00,0,8,2,200,'SSD2'),
('Bose QC SE',              6,3,'AUD-BSE-001','ANC Headphones',329.00,0,10,3,260,'AUD3'),
('Canon SELPHY CP1500',     3,3,'PRN-CAN-001','Portable Photo Printer',129.00,0,9,2,100,'PRN04'),
('ZOTAC RTX 4060',          19,2,'GPU-ZOT-001','8GB GDDR6',329.00,0,5,1,280,'GPU1'),
('Corsair RM750e',          18,1,'PWR-COR-001','750W PSU',119.00,0,10,2,90,'PSU1'),
('Apple Mac mini M2',       13,1,'SRV-APL-002','8-core / 256GB',599.00,0,5,1,480,'SRV3'),
('Samsung Odyssey G7',      4,2,'MON-SAM-002','27" QHD 240Hz',599.00,0,7,2,480,'MON2'),
('Logitech MX Keys S',      11,3,'KEY-LOG-001','Wireless Keyboard',109.00,0,30,6,80,'KEY1'),
('SteelSeries Apex Pro',    11,3,'KEY-SS-001','Mechanical Keyboard',199.00,0,15,3,150,'KEY2'),
('Nintendo Switch OLED',    9,1,'CON-NIN-001','White Joy-Con',349.00,0,12,3,280,'NSW'),
('DJI Osmo Pocket 3',       7,2,'CAM-DJI-001','4K Gimbal Camera',519.00,0,6,2,420,'CAM3'),
('Xiaomi Router BE7000',    4,2,'NET-XM-001','WiFi 7 Router',199.00,0,8,2,160,'NET04'),
('Crucial RAM 32GB Kit',    5,1,'RAM-CRU-001','DDR5 5200',129.00,0,25,5,100,'RAM1');

/* -------------------------------------------------------------
   QUICK VIEW  – What did each customer buy? (sales summary)
---------------------------------------------------------------- */
CREATE OR REPLACE VIEW vw_customer_sales_summary AS
SELECT c.customer_id,
       c.customer_name,
       COUNT(o.order_id)             AS orders_total,
       SUM(o.total_amount)           AS amount_spent,
       GROUP_CONCAT(DISTINCT p.product_name SEPARATOR ', ') AS products_bought
FROM customers c
LEFT JOIN orders o   ON c.customer_id = o.customer_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
LEFT JOIN products p ON oi.product_id = p.product_id
GROUP BY c.customer_id,c.customer_name;

-- Set some products to low stock
UPDATE products SET stock_quantity = 3, reorder_level = 5 WHERE product_id IN (1,2,3);

-- Insert a completed sale for today
INSERT INTO sales (order_id, user_id, customer_id, sale_date, total_amount, status)
VALUES (1, 1, 1, NOW(), 10000, 'completed');

-- Insert sale items for that sale
INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, discount)
VALUES (LAST_INSERT_ID(), 1, 2, 5000, 0),
       (LAST_INSERT_ID(), 2, 1, 5000, 0);

-- --- END EXTRA SAMPLE DATA --- 