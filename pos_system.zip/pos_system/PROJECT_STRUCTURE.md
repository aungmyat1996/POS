# 🏗️ POS System - Project Structure

## 📁 **Organized Folder Structure**

```
pos_system/
├── 📂 api/                     # API Endpoints (NEW)
│   ├── index.php              # API Router
│   ├── products.php           # Products API
│   ├── cart.php               # Cart API
│   ├── sales.php              # Sales API
│   ├── dashboard.php          # Dashboard API
│   ├── notifications.php      # Notifications API
│   ├── customers.php          # Customers API
│   ├── search.php             # Search API
│   └── settings.php           # Settings API
│
├── 📂 assets/                  # Static Assets
│   └── images/                # Logo uploads
│       ├── logo_*.png         # System logos
│       └── ...
│
├── 📂 backups/                 # Database Backups
│   ├── pos_system_backup_*.sql      # Manual backups
│   └── pos_system_auto_backup_*.sql # Automatic backups
│
├── 📂 barcode/                 # Barcode Generation
│   └── generate_barcode.php   # Barcode generator
│
├── 📂 cache/                   # Cache Directory (CLEANED)
│   └── (empty - cache files removed)
│
├── 📂 config/                  # Configuration Files
│   ├── config.php             # Main configuration
│   └── db.php                 # Database configuration
│
├── 📂 database/                # Database Setup
│   ├── create_cart_tables.sql # Cart tables
│   ├── setup_cli.php          # CLI setup
│   ├── setup_database.php     # Database setup
│   └── setup_instructions.md  # Setup guide
│
├── 📂 fpdf/                    # PDF Library
│   ├── fpdf.php               # Main FPDF library
│   ├── font/                  # PDF fonts
│   ├── doc/                   # Documentation
│   ├── tutorial/              # Tutorials
│   └── makefont/              # Font tools
│
├── 📂 includes/                # Core Includes
│   ├── auto_backup.php        # Automatic backup system
│   ├── footer.php             # Footer component
│   ├── functions.php          # Core functions
│   ├── get_datetime.php       # DateTime utilities
│   ├── navbar.php             # Navigation bar
│   ├── security_check.php     # Security middleware
│   ├── sidebar.php            # Sidebar component
│   ├── update_currency.php    # Currency updates
│   ├── update_language.php    # Language updates
│   └── update_settings.php    # Settings updates
│
├── 📂 js/                      # JavaScript Files
│   └── auto_backup_monitor.js # Auto backup monitor
│
├── 📂 languages/               # Localization
│   ├── en.php                 # English translations
│   └── mm.php                 # Myanmar translations
│
├── 📂 pages/                   # Main Pages
│   ├── cart.php               # Shopping cart
│   ├── cart_ajax.php          # Cart AJAX handler
│   ├── change_currency.php    # Currency changer
│   ├── change_language.php    # Language changer
│   ├── customer_ajax.php      # Customer AJAX
│   ├── dashboard.php          # Main dashboard
│   ├── dashboard_data.php     # Dashboard data
│   ├── delete_sale.php        # Sale deletion
│   ├── edit_product.php       # Product editor
│   ├── edit_sale.php          # Sale editor
│   ├── fetch_*.php            # Data fetchers
│   ├── get_*.php              # Data getters
│   ├── inventory.php          # Inventory management
│   ├── invoice.php            # Invoice generation
│   ├── login.php              # User login
│   ├── logout.php             # User logout
│   ├── mark_notifications_read.php # Notification handler
│   ├── pos.php                # Point of Sale
│   ├── product_*.php          # Product management
│   ├── products.php           # Products listing
│   ├── profile.php            # User profile
│   ├── reports.php            # Reports & analytics
│   ├── sales.php              # Sales management
│   ├── search_*.php           # Search functions
│   ├── settings.php           # System settings
│   ├── update_cart.php        # Cart updates
│   ├── users.php              # User management
│   └── verify_payment.php     # Payment verification
│
├── 📂 public/                  # Public Assets
│   ├── css/                   # Stylesheets
│   │   ├── login.css          # Login styles
│   │   └── styles.css         # Main styles
│   ├── images/                # Public images
│   │   ├── products/          # Product images
│   │   ├── logo.png           # Default logo
│   │   └── *.jpg/png          # Various images
│   ├── js/                    # Public JavaScript
│   │   ├── cart.js            # Cart functionality
│   │   ├── dashboard.js       # Dashboard scripts
│   │   ├── navbar-functions.js # Navbar functions
│   │   ├── products.js        # Product scripts
│   │   └── scripts.js         # General scripts
│   └── index.php              # Public entry point
│
├── 📂 scripts/                 # Utility Scripts
│   └── init_db.php            # Database initializer
│
├── 📂 sql/                     # SQL Files
│   ├── add_sample_sales_data.sql # Sample data
│   ├── check_*.php            # Database checkers
│   ├── clear_data.php         # Data cleaner
│   ├── get_latest_order.php   # Order utilities
│   ├── initialize_db.php      # DB initializer
│   ├── insert_sample_sales.php # Sample inserter
│   ├── pos_system_full.sql    # Full database
│   └── sample_large_data.sql  # Large sample data
│
├── 📂 storage/                 # Storage Directory (NEW)
│   ├── cache/                 # Cache storage
│   ├── logs/                  # Log files
│   └── uploads/               # File uploads
│
├── 📂 uploads/                 # Legacy Uploads
│   ├── products/              # Product images
│   └── *.png                  # Various uploads
│
├── 📂 utilities/               # Development Utilities (NEW)
│   ├── index.php              # Utilities dashboard
│   ├── datetime_handler.php   # DateTime operations
│   └── format_tester.php      # Format testing
│
├── 📂 vendor/                  # Third-party Libraries
│   ├── PHPMailer/             # Email library
│   ├── html2pdf/              # HTML to PDF
│   └── tcpdf/                 # PDF library
│
├── 📄 cron_backup.php          # Cron job entry point
├── 📄 index.php               # Main entry point
├── 📄 install.php             # Installation script
├── 📄 PROJECT_STRUCTURE.md    # This file
├── 📄 PRODUCT_DETAILS_FEATURES.md # Product features
└── 📄 README.md               # Project documentation
```

## 🗑️ **Removed Files (Cleanup)**

### **Duplicate Files:**
- ❌ `css/login.css` (duplicate of `public/css/login.css`)
- ❌ `css/styles.css` (duplicate of `public/css/styles.css`)
- ❌ `pages/update_currency.php` (moved to `includes/`)
- ❌ `pages/update_language.php` (moved to `includes/`)

### **Test/Debug Files:**
- ❌ `pages/add_test_notification.php` (test file)
- ❌ `pages/fpdf.php` (duplicate functionality)
- ❌ `pages/inventory_backup.php` (old backup)
- ❌ `test_simple_date.php` (moved to `utilities/datetime_handler.php`)
- ❌ `test_date_format.php` (moved to `utilities/format_tester.php`)

### **System Files:**
- ❌ `desktop.ini` (Windows system file)

### **Log Files:**
- ❌ `logs/db_errors.log` (repetitive errors)
- ❌ `logs/error.log` (old errors)

### **Cache Files:**
- ❌ `cache/*.json` (temporary cache files)

## 🔄 **Path Updates Required**

### **API Endpoints:**
```php
// Old direct calls
pages/fetch_products.php

// New API structure
api/index.php?endpoint=products&action=fetch
```

### **Utilities:**
```php
// Old paths
test_simple_date.php
test_date_format.php

// New paths
utilities/datetime_handler.php
utilities/format_tester.php
```

### **Storage:**
```php
// Old paths
logs/error.log
cache/file.json

// New paths
storage/logs/error.log
storage/cache/file.json
```

## 🎯 **Benefits of New Structure**

### **1. Better Organization:**
- ✅ **API Separation**: All API endpoints in dedicated folder
- ✅ **Storage Consolidation**: Logs, cache, uploads in storage/
- ✅ **Utilities Grouping**: Development tools in utilities/
- ✅ **Clean Root**: Fewer files in root directory

### **2. Improved Maintainability:**
- ✅ **Clear Separation**: Frontend, backend, API, utilities
- ✅ **Logical Grouping**: Related files together
- ✅ **Easy Navigation**: Predictable file locations
- ✅ **Scalable Structure**: Easy to add new features

### **3. Development Benefits:**
- ✅ **API Consistency**: Standardized API routing
- ✅ **Debug Tools**: Centralized utilities
- ✅ **Clean Codebase**: Removed duplicates and unused files
- ✅ **Documentation**: Clear structure documentation

## 🚀 **Next Steps**

1. **Update References**: Update any hardcoded paths in code
2. **Test API Routes**: Verify new API structure works
3. **Update Documentation**: Update any external documentation
4. **Configure Logging**: Set up new logging paths
5. **Test Utilities**: Verify utilities dashboard works

## 📝 **Notes**

- **Backward Compatibility**: Old direct page calls still work
- **API Migration**: Gradual migration to new API structure
- **Storage Flexibility**: Easy to change storage locations
- **Development Tools**: Enhanced debugging and testing tools
