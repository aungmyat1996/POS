<?php
// Main entry point for the POS system
session_start();

// Redirect to the main application
header("Location: public/index.php");
exit();
?> 