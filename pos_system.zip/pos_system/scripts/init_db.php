<?php
define('BASEPATH', dirname(__DIR__) . '/');

try {
    // Create database connection
    $pdo = new PDO(
        "mysql:host=localhost",
        "root",
        "",
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS pos_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE pos_system");

    // Create settings table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `settings` (
            `setting_id` int(11) NOT NULL AUTO_INCREMENT,
            `setting_key` varchar(50) NOT NULL,
            `setting_value` text NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`setting_id`),
            UNIQUE KEY `setting_key` (`setting_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Insert default settings if they don't exist
    $defaultSettings = [
        'store_name' => 'BitsTech POS',
        'store_address' => '123 Tech Lane, Yangon, Myanmar',
        'store_phone' => '+969123456789',
        'store_email' => 'bitstech2025@gmail.com',
        'currency' => 'USD',
        'language' => 'en',
        'timezone' => 'Asia/Yangon'
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES (?, ?)");
    foreach ($defaultSettings as $key => $value) {
        $stmt->execute([$key, $value]);
    }

    echo "Database check completed successfully!\n";
} catch (PDOException $e) {
    die("Database check failed: " . $e->getMessage() . "\n");
} 