<?php
/**
 * Settings API Endpoint
 * Handles all settings-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'fetch_translations':
        require_once BASEPATH . 'pages/fetch_translations.php';
        break;
        
    case 'change_language':
        require_once BASEPATH . 'pages/change_language.php';
        break;
        
    case 'change_currency':
        require_once BASEPATH . 'pages/change_currency.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid settings action: ' . $action
        ]);
}
?>
