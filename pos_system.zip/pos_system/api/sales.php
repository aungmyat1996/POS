<?php
/**
 * Sales API Endpoint
 * Handles all sales-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'fetch_history':
        require_once BASEPATH . 'pages/fetch_sales_history.php';
        break;
        
    case 'fetch_totals':
        require_once BASEPATH . 'pages/fetch_sales_totals.php';
        break;
        
    case 'fetch_trend':
        require_once BASEPATH . 'pages/fetch_sales_trend.php';
        break;
        
    case 'delete':
        require_once BASEPATH . 'pages/delete_sale.php';
        break;
        
    case 'fetch_stock_history':
        require_once BASEPATH . 'pages/fetch_stock_history.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid sales action: ' . $action
        ]);
}
?>
