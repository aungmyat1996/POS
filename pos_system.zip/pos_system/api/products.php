<?php
/**
 * Products API Endpoint
 * Handles all product-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'fetch':
        require_once BASEPATH . 'pages/fetch_products.php';
        break;
        
    case 'fetch_single':
        require_once BASEPATH . 'pages/fetch_product.php';
        break;
        
    case 'search':
        require_once BASEPATH . 'pages/search_products.php';
        break;
        
    case 'search_suggestions':
        require_once BASEPATH . 'pages/search_suggestions.php';
        break;
        
    case 'get_category':
        require_once BASEPATH . 'pages/get_product_category.php';
        break;
        
    case 'get_formatted_price':
        require_once BASEPATH . 'pages/get_formatted_price.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid products action: ' . $action
        ]);
}
?>
