<?php
/**
 * Dashboard API Endpoint
 * Handles all dashboard-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'data':
        require_once BASEPATH . 'pages/dashboard_data.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid dashboard action: ' . $action
        ]);
}
?>
