<?php
/**
 * Notifications API Endpoint
 * Handles all notification-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'get':
        require_once BASEPATH . 'pages/get_notifications.php';
        break;
        
    case 'mark_read':
        require_once BASEPATH . 'pages/mark_notifications_read.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid notifications action: ' . $action
        ]);
}
?>
