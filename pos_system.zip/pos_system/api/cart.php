<?php
/**
 * Cart API Endpoint
 * Handles all cart-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'ajax':
        require_once BASEPATH . 'pages/cart_ajax.php';
        break;
        
    case 'update':
        require_once BASEPATH . 'pages/update_cart.php';
        break;
        
    case 'verify_payment':
        require_once BASEPATH . 'pages/verify_payment.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid cart action: ' . $action
        ]);
}
?>
