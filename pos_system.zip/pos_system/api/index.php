<?php
/**
 * API Router for POS System
 * Central endpoint for all API requests
 */

// Set the base path
define('BASEPATH', dirname(__DIR__) . '/');

require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';
require_once BASEPATH . 'includes/security_check.php';

// Set JSON response headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Get request method and endpoint
$method = $_SERVER['REQUEST_METHOD'];
$endpoint = $_GET['endpoint'] ?? '';
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    // Route API requests
    switch ($endpoint) {
        case 'products':
            require_once 'products.php';
            break;
            
        case 'cart':
            require_once 'cart.php';
            break;
            
        case 'sales':
            require_once 'sales.php';
            break;
            
        case 'dashboard':
            require_once 'dashboard.php';
            break;
            
        case 'notifications':
            require_once 'notifications.php';
            break;
            
        case 'customers':
            require_once 'customers.php';
            break;
            
        case 'search':
            require_once 'search.php';
            break;
            
        case 'settings':
            require_once 'settings.php';
            break;
            
        default:
            throw new Exception('Invalid API endpoint: ' . $endpoint);
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'endpoint' => $endpoint,
        'method' => $method
    ]);
}
?>
