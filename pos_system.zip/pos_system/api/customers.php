<?php
/**
 * Customers API Endpoint
 * Handles all customer-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'ajax':
        require_once BASEPATH . 'pages/customer_ajax.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid customers action: ' . $action
        ]);
}
?>
