<?php
/**
 * Search API Endpoint
 * Handles all search-related API requests
 */

if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
}

switch ($action) {
    case 'products':
        require_once BASEPATH . 'pages/search_products.php';
        break;
        
    case 'suggestions':
        require_once BASEPATH . 'pages/search_suggestions.php';
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid search action: ' . $action
        ]);
}
?>
