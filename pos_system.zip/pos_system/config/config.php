<?php
// Define BASEPATH only if not already defined
if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
}

// System configuration
define('DEFAULT_TIMEZONE', 'Asia/Yangon');
define('DEFAULT_LANGUAGE', 'en');
define('DEFAULT_CURRENCY', 'USD');

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'pos_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', BASEPATH . 'logs/error.log'); 