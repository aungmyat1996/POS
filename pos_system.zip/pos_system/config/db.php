<?php
// Load central configuration
require_once __DIR__ . '/config.php';

// Prevent direct access to this file
if (basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access to this file is not allowed.');
}

// Database connection settings
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_PERSISTENT => true,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
];

// Retry logic for database connection
$maxRetries = 3;
$retryDelay = 2; // seconds
$attempt = 0;
$pdo = null;

while ($attempt < $maxRetries) {
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        // Connection successful, break the retry loop
        break;
    } catch (PDOException $e) {
        $attempt++;
        // Log the error
        $errorMessage = sprintf(
            "[%s] Database connection attempt %d/%d failed: %s",
            date('Y-m-d H:i:s'),
            $attempt,
            $maxRetries,
            $e->getMessage()
        );
        error_log($errorMessage, 3, BASEPATH . 'logs/db_errors.log');

        if ($attempt === $maxRetries) {
            http_response_code(500);
            die("Database connection failed. Please try again later.");
        }
        // Wait before retrying
        sleep($retryDelay);
    }
}

// Optional: Set session timezone for consistent date handling
try {
    $pdo->exec("SET time_zone = '+08:00'"); // Adjust based on server timezone
} catch (PDOException $e) {
    error_log("Failed to set timezone: " . $e->getMessage(), 3, BASEPATH . 'logs/db_errors.log');
}
?>