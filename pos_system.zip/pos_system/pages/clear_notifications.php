<?php
/**
 * Clear all notifications for the current user
 */

// Start session first
session_start();

// Set headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// Define base path
if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
}

// Include required files
try {
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'System configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Check authentication
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated. Please login again.'
    ]);
    exit;
}

// Get user language and translations
$language = $_SESSION['language'] ?? 'en';
$translations = [];

try {
    if (function_exists('loadLanguage')) {
        $translations = loadLanguage($language);
    }
} catch (Exception $e) {
    error_log("Error loading translations: " . $e->getMessage());
    // Continue without translations
}

// Log the clear request
error_log("Clear notifications request from user ID: " . $_SESSION['user_id']);

try {
    // Check if PDO connection exists
    if (!isset($pdo) || $pdo === null) {
        throw new Exception('Database connection not available');
    }

    // Mark all notifications as read for the current user
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $result = $stmt->execute([$_SESSION['user_id']]);

    // Get affected rows count
    $affectedRows = $stmt->rowCount();

    if ($result) {
        error_log("Successfully cleared {$affectedRows} notifications for user ID: " . $_SESSION['user_id']);

        echo json_encode([
            'success' => true,
            'message' => $translations['notifications_cleared'] ?? 'All notifications have been marked as read',
            'cleared_count' => $affectedRows
        ]);
    } else {
        error_log("Failed to clear notifications for user ID: " . $_SESSION['user_id']);

        echo json_encode([
            'success' => false,
            'error' => $translations['error_clearing_notifications'] ?? 'Failed to clear notifications'
        ]);
    }

} catch (PDOException $e) {
    error_log("Database error clearing notifications: " . $e->getMessage());

    echo json_encode([
        'success' => false,
        'error' => $translations['error_clearing_notifications'] ?? 'Database error occurred while clearing notifications'
    ]);

} catch (Exception $e) {
    error_log("General error clearing notifications: " . $e->getMessage());

    echo json_encode([
        'success' => false,
        'error' => $translations['error_clearing_notifications'] ?? 'An error occurred while clearing notifications'
    ]);
}
?>
