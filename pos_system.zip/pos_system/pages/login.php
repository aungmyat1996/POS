<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: pos.php");
    exit();
}

// Initialize message variables
$msg = '';
$msgClass = '';

if (isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username != "" && $password != "") {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'] ?? 'N/A';
                header("Location: pos.php");
                exit;
            } else {
                $msg = "Incorrect username or password!";
                $msgClass = "alert-danger";
            }
        } catch (PDOException $e) {
            $msg = "Database error: " . $e->getMessage();
            $msgClass = "alert-danger";
        }
    } else {
        $msg = "Both fields are required!";
        $msgClass = "alert-danger";
    }
}

// Forgot Password Logic
if (isset($_POST['forgot'])) {
    $email = trim($_POST['email']);

    if ($email != "") {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $token = bin2hex(random_bytes(32));
            $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?");
            $stmt->execute([$token, $email]);

            require_once BASEPATH . 'vendor/PHPMailer/src/PHPMailer.php';
            require_once BASEPATH . 'vendor/PHPMailer/src/SMTP.php';
            require_once BASEPATH . 'vendor/PHPMailer/src/Exception.php';

            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mail->SMTPDebug = 2;
                $mail->Debugoutput = function($str, $level) use (&$msg) {
                    $msg .= "Debug: $str<br>";
                };

                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'bitstech2025@gmail.com';
                $mail->Password = 'immc tgsf pxmq mequ';
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                $mail->Port = 465;

                $mail->setFrom('bitstech2025@gmail.com', 'BitsTech POS');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body = "Click <a href='http://localhost/pos_system/pages/reset_password.php?token=$token'>here</a> to reset your password. This link expires in 1 hour.";

                $mail->send();
                $msg = "Password reset link has been sent to your email!";
                $msgClass = "alert-success";
            } catch (Exception $e) {
                $msg = "Failed to send reset email: {$mail->ErrorInfo}";
                $msgClass = "alert-danger";
            }
        } else {
            $msg = "No account found with that email!";
            $msgClass = "alert-danger";
        }
    } else {
        $msg = "Please enter your email!";
        $msgClass = "alert-danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BitsTech POS - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/login.css">
</head>
<body>
    <div class="login-form">
        <div class="text-center mb-4">
            <?php if (file_exists('../public/images/logo.png')): ?>
                <img src="../public/images/logo.png" alt="BitsTech Logo" class="login-logo">
            <?php else: ?>
                <div class="login-logo bg-primary text-white d-flex align-items-center justify-content-center">
                    <i class="fas fa-desktop"></i>
                </div>
            <?php endif; ?>
            <h2>BitsTech POS - Login</h2>
        </div>

        <?php if ($msg != ''): ?>
            <div class="alert <?php echo $msgClass; ?>">
                <?php echo nl2br(htmlspecialchars($msg)); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">
                    <i class="fas fa-user me-2"></i>Username
                </label>
                <input type="text" name="username" id="username" class="form-control" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <button type="submit" name="submit" class="btn btn-primary w-100">
                    <i class="fas fa-sign-in-alt me-2"></i>Login
                </button>
            </div>
            <div class="text-center">
                <a href="#" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
                    <i class="fas fa-question-circle me-1"></i>Forgot Password?
                </a>
            </div>
        </form>

        <!-- Forgot Password Modal -->
        <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="forgotPasswordModalLabel">
                            <i class="fas fa-key me-2"></i>Forgot Password
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope me-2"></i>Email
                                </label>
                                <input type="email" name="email" id="email" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-2"></i>Close
                            </button>
                            <button type="submit" name="forgot" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i>Send Reset Link
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>