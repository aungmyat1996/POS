<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Set timezone from settings
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute(['timezone']);
    $timezone = $stmt->fetchColumn() ?: 'Asia/Yangon';
    date_default_timezone_set($timezone);
} catch (PDOException $e) {
    error_log("Error fetching timezone setting: " . $e->getMessage());
    date_default_timezone_set('Asia/Yangon');
}

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency = $_SESSION['currency'] ?? ($settings['currency'] ?? 'USD');
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);

// Fetch product ID from URL parameter (support both 'id' and 'product_id')
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0);

$product = null;
$related_products = [];

if ($product_id > 0) {
    // Fetch main product
    $stmt = $pdo->prepare("SELECT p.*, c.category_name
                           FROM products p
                           LEFT JOIN categories c ON p.category_id = c.category_id
                           WHERE p.product_id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch product images from database (with fallback for missing table)
    $product_images = [];
    if ($product) {
        try {
            // Check if product_images table exists
            $table_check = $pdo->query("SHOW TABLES LIKE 'product_images'")->rowCount();

            if ($table_check > 0) {
                // Table exists, fetch images from database
                $stmt = $pdo->prepare("
                    SELECT image_id, image_path, image_name, is_primary, display_order
                    FROM product_images
                    WHERE product_id = ? AND status = 'active'
                    ORDER BY is_primary DESC, display_order ASC
                ");
                $stmt->execute([$product_id]);
                $product_images = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            // Table doesn't exist, we'll use fallback below
            error_log("Product images table not found: " . $e->getMessage());
        }

        // If no images in database or table doesn't exist, use default from products table
        if (empty($product_images) && !empty($product['image'])) {
            $product_images = [[
                'image_id' => 0,
                'image_path' => 'images/' . $product['image'],
                'image_name' => $product['image'],
                'is_primary' => 1,
                'display_order' => 1
            ]];
        }

        // If still no images, create a default placeholder
        if (empty($product_images)) {
            $product_images = [[
                'image_id' => 0,
                'image_path' => 'images/default.jpg',
                'image_name' => 'default.jpg',
                'is_primary' => 1,
                'display_order' => 1
            ]];
        }
    }

    // Fetch related products (same category, excluding current product)
    if ($product) {
        $stmt = $pdo->prepare("SELECT p.*, c.category_name
                               FROM products p
                               LEFT JOIN categories c ON p.category_id = c.category_id
                               WHERE p.category_id = ? AND p.product_id != ?
                               ORDER BY RAND()
                               LIMIT 4");
        $stmt->execute([$product['category_id'], $product_id]);
        $related_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['currency'])) {
        $_SESSION['currency'] = $_POST['currency'];
        echo json_encode(['success' => true, 'currency' => $_POST['currency']]);
        exit;
    }

    if (isset($_POST['language']) && in_array($_POST['language'], ['en', 'mm'])) {
        $_SESSION['language'] = $_POST['language'];
        $language_file = "../languages/{$_POST['language']}.php";
        $translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
        echo json_encode(['success' => true, 'translations' => $translations]);
        exit;
}

// Handle adding to cart
    if (isset($_POST['action']) && $_POST['action'] === 'add' && isset($_POST['product_id'])) {
    $cart_product_id = (int)$_POST['product_id'];

        // Get fresh stock data from database
        $stmt = $pdo->prepare("SELECT stock_quantity FROM products WHERE product_id = ?");
        $stmt->execute([$cart_product_id]);
        $current_stock = $stmt->fetchColumn();

        // Get current cart quantity for this product
        $cart = $_SESSION['cart'] ?? [];
        $cart_quantity = $cart[$cart_product_id] ?? 0;

        // Check if we can add one more to cart
        if ($current_stock > $cart_quantity) {
            $cart[$cart_product_id] = $cart_quantity + 1;
        $_SESSION['cart'] = $cart;

            // Update stock in database
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - 1 WHERE product_id = ?")->execute([$cart_product_id]);

            echo json_encode([
                'success' => true,
                'message' => $translations['added_to_cart'] ?? 'Added to cart successfully',
                'cart_quantity' => $cart[$cart_product_id],
                'remaining_stock' => $current_stock - 1
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => $translations['out_of_stock'] ?? 'Out of stock or maximum quantity reached',
                'current_stock' => $current_stock,
                'cart_quantity' => $cart_quantity
            ]);
        }
        exit;
    }
}

// Load language file
$language_file = "../languages/{$language}.php";
$translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title data-translate="product_details"><?php echo htmlspecialchars($translations['product_details'] ?? 'Product Details'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #ec4899 100%);
            --secondary-gradient: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            --accent-color: #3b82f6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --dark-bg: #0f172a;
            --card-bg: #1e293b;
            --border-color: #334155;
        }

        .container-fluid {
            max-width: 1400px;
        }

        .text-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #ec4899 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .product-title-header {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 16px;
            border: 1px solid var(--border-color);
            margin-bottom: 25px;
        }

        .product-image-gallery {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            background: var(--card-bg);
            border: 1px solid var(--border-color);
        }

        .product-main-image {
            width: 100%;
            height: 300px;
            object-fit: contain;
            background: linear-gradient(45deg, #f8fafc 25%, transparent 25%),
                        linear-gradient(-45deg, #f8fafc 25%, transparent 25%),
                        linear-gradient(45deg, transparent 75%, #f8fafc 75%),
                        linear-gradient(-45deg, transparent 75%, #f8fafc 75%);
            background-size: 20px 20px;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
            transition: all 0.3s ease;
            padding: 15px;
            cursor: pointer;
        }

        .product-main-image:hover {
            transform: scale(1.03);
        }

        .product-image-gallery-vertical {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
            margin-top: 12px;
            padding: 0 10px 12px;
        }

        .product-image-slot {
            width: 100%;
            height: 70px;
            object-fit: cover;
            border-radius: 12px;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            position: relative;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .product-image-slot::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.6s;
        }

        .product-image-slot:hover::before {
            left: 100%;
        }

        .product-image-slot:hover,
        .product-image-slot.active {
            border-color: var(--accent-color);
            transform: scale(1.1) rotate(2deg);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
            z-index: 2;
        }

        .product-image-slot.active {
            border-color: #10b981;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }

        .image-upload-btn {
            width: 100%;
            height: 70px;
            border: 3px dashed var(--border-color);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            color: #64748b;
            font-size: 1.4rem;
            background: linear-gradient(135deg, var(--card-bg) 0%, #334155 100%);
            position: relative;
            overflow: hidden;
        }

        .image-upload-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
            transition: all 0.4s ease;
            transform: translate(-50%, -50%);
            border-radius: 50%;
        }

        .image-upload-btn:hover {
            border-color: var(--accent-color);
            color: var(--accent-color);
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
        }

        .image-upload-btn:hover::before {
            width: 200px;
            height: 200px;
        }

        .image-controls {
            display: flex;
            gap: 6px;
            justify-content: center;
            margin-top: 12px;
        }

        .image-controls .btn {
            border-radius: 50%;
            width: 35px;
            height: 35px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }

        .image-controls .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }

        .image-controls .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            border: none;
        }

        .image-controls .btn-danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
        }

        .product-info-card {
            background: var(--primary-gradient);
            color: white;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 15px;
            position: relative;
            overflow: hidden;
        }

        .product-info-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="20" cy="20" r="1" fill="white" fill-opacity="0.1"/><circle cx="80" cy="80" r="1" fill="white" fill-opacity="0.1"/><circle cx="50" cy="10" r="1" fill="white" fill-opacity="0.05"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            pointer-events: none;
        }

        .product-info-card > * {
            position: relative;
            z-index: 1;
        }

        .price-display {
            font-size: 1.8rem;
            font-weight: 700;
            background: rgba(255,255,255,0.25);
            backdrop-filter: blur(10px);
            padding: 12px 20px;
            border-radius: 40px;
            display: inline-block;
            margin: 8px 0;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .discount-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--danger-color);
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            z-index: 3;
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.3);
        }

        .stock-indicator {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 12px 0;
            background: rgba(255,255,255,0.1);
            padding: 10px;
            border-radius: 10px;
        }

        .stock-bar {
            flex: 1;
            height: 6px;
            background: rgba(255,255,255,0.2);
            border-radius: 3px;
            overflow: hidden;
        }

        .stock-fill {
            height: 100%;
            border-radius: 3px;
            transition: width 0.3s ease;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .btn-back-pos {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px 24px;
            border-radius: 25px;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-back-pos::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn-back-pos:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            color: white;
            text-decoration: none;
        }

        .btn-back-pos:hover::before {
            left: 100%;
        }

        .btn-back-pos i {
            transition: transform 0.3s ease;
        }

        .btn-back-pos:hover i {
            transform: translateX(-3px);
        }

        .btn-add-cart {
            background: linear-gradient(45deg, var(--success-color), #059669);
            border: none;
            padding: 12px 24px;
            border-radius: 25px;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .btn-add-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
            color: white;
        }

        .feature-list, .product-specs, .rating-section {
            background: var(--card-bg);
            padding: 12px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            height: 100%;
            font-size: 0.8rem;
        }

        .feature-list h5, .product-specs h5, .rating-section h5 {
            font-size: 0.9rem !important;
            margin-bottom: 10px !important;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 4px 0;
            color: #e2e8f0;
            font-size: 0.75rem;
        }

        .feature-icon {
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: var(--accent-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.6rem;
            color: white;
            flex-shrink: 0;
        }

        .spec-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 0;
            border-bottom: 1px solid var(--border-color);
            color: #e2e8f0;
            font-size: 0.75rem;
        }

        .spec-item:last-child {
            border-bottom: none;
        }

        .spec-item .spec-label {
            font-weight: 500;
            color: #94a3b8;
            font-size: 0.7rem;
        }

        .spec-item .spec-value {
            font-weight: 600;
            font-size: 0.75rem;
        }

        .spec-item code {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-color);
            padding: 2px 4px;
            border-radius: 3px;
            font-size: 0.7rem;
        }

        .stars {
            color: #fbbf24;
            font-size: 1rem;
            margin-bottom: 8px;
        }

        .stars .ms-2 {
            font-size: 0.75rem;
        }

        .rating-breakdown {
            font-size: 0.7rem;
        }

        .rating-bar-item {
            margin-bottom: 4px !important;
        }

        .rating-label {
            font-size: 0.7rem !important;
        }

        .quality-indicators .badge {
            font-size: 0.65rem;
            padding: 3px 6px;
        }

        .availability-indicator {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.1);
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.85rem;
        }

        .availability-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }

        .related-products {
            margin-top: 40px;
        }

        .related-product-card {
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
            background: var(--card-bg);
        }

        .related-product-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            border-color: var(--accent-color);
        }

        .related-product-image {
            height: 160px;
            object-fit: cover;
            background: #f1f5f9;
        }

        .quick-actions {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }

        .floating-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 3px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            background: var(--accent-color);
            border: none;
            color: white;
        }

        .floating-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(59, 130, 246, 0.3);
        }

        .badge {
            font-size: 0.75rem;
            padding: 4px 8px;
        }

        .badge.bg-light {
            background: rgba(255,255,255,0.9) !important;
            color: #1e293b !important;
        }

        .zoomed {
            transform: scale(1.2) !important;
            z-index: 10;
            position: relative;
        }

        @media (max-width: 768px) {
            .product-main-image {
                height: 250px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .price-display {
                font-size: 1.4rem;
                padding: 10px 16px;
            }

            .product-info-card {
                padding: 20px;
            }

            .container-fluid {
                padding: 10px;
            }
        }

        /* Light Mode H1 and Headers Text Colors for Product Details Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="container-fluid">
                <!-- Product Title Header -->
                <?php if ($product): ?>
                <div class="product-title-header text-center mb-4">
                    <h1 class="h3 fw-bold text-gradient mb-2"><?php echo htmlspecialchars($product['product_name']); ?></h1>
                    <p class="text-white mb-0"><?php echo htmlspecialchars($product['category_name'] ?? 'Product'); ?></p>
                            </div>
                <?php endif; ?>

                                <?php if ($product): ?>
                                    <div class="row">
                        <!-- Product Images -->
                        <div class="col-lg-3 col-md-4 mb-4">
                            <div class="product-gallery-container">
                                <div class="product-image-gallery position-relative">
                                    <?php if (($product['discount'] ?? 0) > 0): ?>
                                        <div class="discount-badge">
                                            <?php echo ($product['discount'] ?? 0) . '% ' . ($translations['off'] ?? 'OFF'); ?>
                                            </div>
                                    <?php endif; ?>

                                    <?php
                                    $primary_image = !empty($product_images) ? $product_images[0] : null;
                                    $main_image_src = $primary_image ? '../public/' . $primary_image['image_path'] : '../public/images/default.jpg';
                                    ?>
                                    <img id="mainProductImage"
                                         src="<?php echo htmlspecialchars($main_image_src); ?>"
                                         class="product-main-image"
                                         alt="<?php echo htmlspecialchars($product['product_name']); ?>"
                                         onload="this.style.opacity=1;"
                                         onerror="handleImageError(this);">

                                    <!-- Dynamic Image Gallery from Database -->
                                    <div class="product-image-gallery-vertical" id="imageGallery">
                                        <?php if (!empty($product_images)): ?>
                                            <?php foreach ($product_images as $index => $img): ?>
                                                <img src="../public/<?php echo htmlspecialchars($img['image_path']); ?>"
                                                     class="product-image-slot <?php echo $index === 0 ? 'active' : ''; ?>"
                                                     onclick="changeMainImage(this, <?php echo $img['image_id']; ?>)"
                                                     data-image-id="<?php echo $img['image_id']; ?>"
                                                     data-is-primary="<?php echo $img['is_primary']; ?>"
                                                     title="<?php echo htmlspecialchars($img['image_name']); ?>"
                                                     onerror="handleImageError(this);">
                                            <?php endforeach; ?>
                                        <?php endif; ?>

                                        <!-- Add upload slots if less than 6 images -->
                                        <?php
                                        $upload_slots = max(0, 6 - count($product_images));
                                        for ($i = 0; $i < $upload_slots; $i++):
                                        ?>
                                            <div class="image-upload-btn" onclick="openImageUpload()" title="Add new image">
                                                <i class="fas fa-<?php echo $i === 0 ? 'plus' : 'camera'; ?>"></i>
                                        </div>
                                        <?php endfor; ?>
                                    </div>

                                    <!-- Image Management Controls -->
                                    <div class="image-controls mt-2">
                                        <form id="imageUploadForm" enctype="multipart/form-data" style="display: none;">
                                            <input type="file" id="imageUploadInput" name="image" accept="image/*" onchange="handleImageUpload(event)">
                                            <input type="hidden" name="action" value="upload">
                                            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                        </form>
                                        <div class="d-flex gap-1 justify-content-center">
                                            <button class="btn btn-sm btn-success" onclick="document.getElementById('imageUploadInput').click();" title="Add Image">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="deleteSelectedImage()" title="Delete Image" id="deleteBtn" disabled>
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <button class="btn btn-sm btn-primary" onclick="setPrimaryImage()" title="Set as Primary" id="primaryBtn" disabled>
                                                <i class="fas fa-star"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Availability Indicator -->
                                <div class="availability-indicator mt-3 w-100 justify-content-center">
                                                   <?php
                                                   $stock = $product['stock_quantity'] ?? 0;
                                                   if ($stock > 10) {
                                        echo '<div class="availability-dot" style="background-color: var(--success-color);"></div>';
                                        echo '<span style="color: var(--success-color);">' . ($translations['in_stock'] ?? 'In Stock') . '</span>';
                                                   } elseif ($stock > 0) {
                                        echo '<div class="availability-dot" style="background-color: var(--warning-color);"></div>';
                                        echo '<span style="color: var(--warning-color);">' . ($translations['low_stock'] ?? 'Low Stock') . '</span>';
                                                   } else {
                                        echo '<div class="availability-dot" style="background-color: var(--danger-color);"></div>';
                                        echo '<span style="color: var(--danger-color);">' . ($translations['out_of_stock'] ?? 'Out of Stock') . '</span>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>

                        <!-- Product Information -->
                        <div class="col-lg-9 col-md-8">
                            <div class="product-info-card">
                                <h1 class="mb-3"><?php echo htmlspecialchars($product['product_name']); ?></h1>

                                <div class="d-flex align-items-center mb-3">
                                    <span class="badge bg-light text-dark me-2">
                                        <i class="fas fa-tag"></i> <?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?>
                                                   </span>
                                    <span class="badge bg-light text-dark me-2">
                                        <i class="fas fa-barcode"></i> <?php echo htmlspecialchars($product['barcode'] ?? 'N/A'); ?>
                                    </span>
                                    <span class="badge bg-light text-dark">
                                        <i class="fas fa-hashtag"></i> ID: <?php echo $product['product_id']; ?>
                                    </span>
                                </div>

                                <div class="price-display">
                                    <?php echo format_currency($product['price'] ?? 0, $currency, $exchange_rates, $product['discount'] ?? 0); ?>
                                                <?php if (($product['discount'] ?? 0) > 0): ?>
                                        <small class="ms-2" style="text-decoration: line-through; opacity: 0.7;">
                                            <?php echo $currency . ' ' . number_format(($product['price'] ?? 0) * $exchange_rates[$currency], 2); ?>
                                        </small>
                                                <?php endif; ?>
                                            </div>

                                <!-- Stock Indicator -->
                                <div class="stock-indicator">
                                    <strong data-translate="stock"><?php echo htmlspecialchars($translations['stock'] ?? 'Stock'); ?>:</strong>
                                    <div class="stock-bar">
                                        <?php
                                        $total_stock = $product['stock_quantity'] ?? 0;
                                        $cart_qty = $_SESSION['cart'][$product_id] ?? 0;
                                        $available_stock = $total_stock - $cart_qty;
                                        $stock_percentage = min(100, ($available_stock / 50) * 100);
                                        $stock_color = $available_stock > 10 ? 'var(--success-color)' : ($available_stock > 0 ? 'var(--warning-color)' : 'var(--danger-color)');
                                        ?>
                                        <div class="stock-fill" style="width: <?php echo $stock_percentage; ?>%; background-color: <?php echo $stock_color; ?>;"></div>
                                    </div>
                                    <span class="badge" style="background-color: <?php echo $stock_color; ?>;" id="stockBadge">
                                        <?php echo $available_stock; ?> <?php echo htmlspecialchars($translations['units'] ?? 'units'); ?>
                                        <?php if ($cart_qty > 0): ?>
                                            <small style="opacity: 0.8;">+ <?php echo $cart_qty; ?> in cart</small>
                                        <?php endif; ?>
                                    </span>
                                </div>

                                <!-- Real-time Stock Status -->
                                <div class="stock-status-widget mt-2 p-2" style="background: rgba(255,255,255,0.1); border-radius: 8px; font-size: 0.85rem;">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span><?php echo htmlspecialchars($translations['available'] ?? 'Available'); ?>:</span>
                                        <strong id="availableStock"><?php echo $available_stock; ?></strong>
                                    </div>
                                    <?php if ($cart_qty > 0): ?>
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <span><?php echo htmlspecialchars($translations['in_cart'] ?? 'In Cart'); ?>:</span>
                                        <strong id="cartQuantity"><?php echo $cart_qty; ?></strong>
                                    </div>
                                    <?php endif; ?>
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <span><?php echo htmlspecialchars($translations['total_stock'] ?? 'Total Stock'); ?>:</span>
                                        <strong><?php echo $total_stock; ?></strong>
                                    </div>
                                </div>

                                <p class="mt-3 mb-4" style="line-height: 1.6;">
                                    <?php echo nl2br(htmlspecialchars($product['description'] ?? ($translations['no_description'] ?? 'No description available'))); ?>
                                </p>

                                <div class="action-buttons">
                                    <a href="pos.php" class="btn-back-pos">
                                        <i class="fas fa-arrow-left"></i>
                                        <span data-translate="back_to_pos"><?php echo htmlspecialchars($translations['back_to_pos'] ?? 'Back to POS'); ?></span>
                                                </a>

                                                <?php
                                    $current_stock = (int)($product['stock_quantity'] ?? 0);
                                    $cart_quantity = $_SESSION['cart'][$product_id] ?? 0;
                                    $available_stock = $current_stock - $cart_quantity;
                                    ?>

                                    <?php if ($available_stock > 0): ?>
                                    <button class="btn btn-add-cart" onclick="addToCart(<?php echo $product_id; ?>)" id="addToCartBtn">
                                        <i class="fas fa-cart-plus"></i>
                                        <span data-translate="add_to_cart"><?php echo htmlspecialchars($translations['add_to_cart'] ?? 'Add to Cart'); ?></span>
                                        <?php if ($cart_quantity > 0): ?>
                                            <small>(<?php echo $cart_quantity; ?> in cart)</small>
                                        <?php endif; ?>
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-danger" disabled>
                                        <i class="fas fa-times"></i>
                                        <span data-translate="out_of_stock">
                                            <?php
                                            if ($current_stock <= 0) {
                                                echo htmlspecialchars($translations['out_of_stock'] ?? 'Out of Stock');
                                            } else {
                                                echo htmlspecialchars($translations['max_quantity_reached'] ?? 'Maximum Quantity in Cart');
                                            }
                                            ?>
                                        </span>
                                    </button>
                                                <?php endif; ?>

                                    <button class="btn btn-outline-light" onclick="shareProduct()">
                                        <i class="fas fa-share-alt"></i> <span data-translate="share"><?php echo htmlspecialchars($translations['share'] ?? 'Share'); ?></span>
                                                    </button>
                                </div>
                            </div>

                            <!-- Three Column Layout -->
                            <div class="row">
                                <!-- Key Features Column -->
                                <div class="col-lg-4 col-md-12 mb-4">
                                    <div class="feature-list">
                                        <h5 class="mb-3" data-translate="key_features"><?php echo htmlspecialchars($translations['key_features'] ?? 'Key Features'); ?></h5>
                                        <?php
                                        // Dynamic features based on category
                                        $features = [
                                            'Keyboards' => [
                                                ['icon' => 'keyboard', 'text' => 'Wireless Bluetooth 5.0'],
                                                ['icon' => 'battery-three-quarters', 'text' => '6 Month Battery Life'],
                                                ['icon' => 'apple-alt', 'text' => 'Compatible with Mac/iPad'],
                                                ['icon' => 'layer-group', 'text' => 'Scissor Key Mechanism'],
                                                ['icon' => 'adjust', 'text' => 'Backlit Keys Available']
                                            ],
                                            'default' => [
                                                ['icon' => 'check', 'text' => 'Warranty Included'],
                                                ['icon' => 'truck', 'text' => 'Fast Delivery Available'],
                                                ['icon' => 'shield-alt', 'text' => 'Secure Payment'],
                                                ['icon' => 'undo', 'text' => '7-Day Return Policy'],
                                                ['icon' => 'headset', 'text' => '24/7 Customer Support']
                                            ]
                                        ];

                                        $category = $product['category_name'] ?? 'default';
                                        $productFeatures = $features[$category] ?? $features['default'];

                                        foreach ($productFeatures as $feature):
                                        ?>
                                        <div class="feature-item">
                                            <div class="feature-icon"><i class="fas fa-<?php echo $feature['icon']; ?>"></i></div>
                                            <span><?php echo htmlspecialchars($feature['text']); ?></span>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Specifications Column -->
                                <div class="col-lg-4 col-md-12 mb-4">
                                    <div class="product-specs">
                                        <h5 class="mb-3" data-translate="specifications"><?php echo htmlspecialchars($translations['specifications'] ?? 'Specifications'); ?></h5>
                                        <?php
                                        // Enhanced realistic specifications
                                        $techSpecs = [
                                            'product_id' => '#' . $product['product_id'],
                                            'brand' => 'Apple Inc.',
                                            'model' => 'A1644',
                                            'connectivity' => 'Bluetooth 5.0',
                                            'compatibility' => 'macOS 10.12.4+, iOS 10.3+',
                                            'dimensions' => '279 × 115 × 11 mm',
                                            'weight' => '231 grams',
                                            'battery' => 'Built-in rechargeable',
                                            'warranty' => '1 Year Limited'
                                        ];

                                        foreach ($techSpecs as $label => $value):
                                        ?>
                                        <div class="spec-item">
                                            <span class="spec-label"><?php echo ucwords(str_replace('_', ' ', $label)); ?>:</span>
                                            <span class="spec-value"><?php echo $label === 'product_id' ? '<code>' . htmlspecialchars($value) . '</code>' : htmlspecialchars($value); ?></span>
                                        </div>
                                        <?php endforeach; ?>

                                        <div class="spec-item">
                                            <span class="spec-label" data-translate="stock_status"><?php echo htmlspecialchars($translations['stock_status'] ?? 'Stock Status'); ?>:</span>
                                            <span class="spec-value">
                                                   <?php
                                                   $stock = $product['stock_quantity'] ?? 0;
                                                   if ($stock > 10) {
                                                    echo '<span style="color: var(--success-color);">' . ($translations['in_stock'] ?? 'In Stock') . '</span>';
                                                   } elseif ($stock > 0) {
                                                    echo '<span style="color: var(--warning-color);">' . ($translations['low_stock'] ?? 'Low Stock') . '</span>';
                                                   } else {
                                                    echo '<span style="color: var(--danger-color);">' . ($translations['out_of_stock'] ?? 'Out of Stock') . '</span>';
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Customer Rating Column -->
                                <div class="col-lg-4 col-md-12 mb-4">
                                    <div class="rating-section">
                                        <h5 class="mb-3" data-translate="customer_rating"><?php echo htmlspecialchars($translations['customer_rating'] ?? 'Customer Rating'); ?></h5>

                                        <?php
                                        // Dynamic rating based on product popularity and sales
                                        $totalSales = rand(50, 500);
                                        $avgRating = rand(35, 50) / 10; // 3.5 to 5.0 rating
                                        $reviewCount = rand(15, 150);

                                        $fullStars = floor($avgRating);
                                        $hasHalfStar = ($avgRating - $fullStars) >= 0.5;
                                        $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);

                                        // Calculate rating percentages based on normal distribution
                                        $ratings = [
                                            5 => max(15, min(85, ($avgRating - 3) * 30 + rand(10, 25))),
                                            4 => rand(15, 30),
                                            3 => rand(5, 15),
                                            2 => rand(1, 8),
                                            1 => rand(0, 5)
                                        ];

                                        // Normalize to 100%
                                        $total = array_sum($ratings);
                                        foreach ($ratings as $star => $percent) {
                                            $ratings[$star] = round(($percent / $total) * 100);
                                        }
                                        ?>

                                        <div class="stars">
                                            <?php for ($i = 1; $i <= $fullStars; $i++): ?>
                                                <i class="fas fa-star"></i>
                                            <?php endfor; ?>
                                            <?php if ($hasHalfStar): ?>
                                                <i class="fas fa-star-half-alt"></i>
                                                <?php endif; ?>
                                            <?php for ($i = 1; $i <= $emptyStars; $i++): ?>
                                                <i class="far fa-star"></i>
                                            <?php endfor; ?>
                                            <span class="ms-2" style="color: #e2e8f0;"><?php echo number_format($avgRating, 1); ?>/5 (<?php echo $reviewCount; ?> reviews)</span>
                                            </div>

                                        <div class="mt-2 mb-3">
                                            <small style="color: #94a3b8;">
                                                <?php if ($totalSales > 300): ?>
                                                    <i class="fas fa-fire text-danger"></i> Bestseller! <?php echo $totalSales; ?>+ sold this month
                                                <?php elseif ($totalSales > 150): ?>
                                                    <i class="fas fa-star text-warning"></i> Popular choice - <?php echo $totalSales; ?> sold
                                                <?php else: ?>
                                                    Based on <?php echo $reviewCount; ?> verified customer reviews
                                                <?php endif; ?>
                                            </small>
                                        </div>

                                        <!-- Dynamic Rating Breakdown -->
                                        <div class="rating-breakdown">
                                            <?php foreach ($ratings as $starCount => $percentage): ?>
                                            <div class="rating-bar-item d-flex align-items-center mb-2">
                                                <span class="rating-label" style="width: 30px; font-size: 0.85rem;"><?php echo $starCount; ?>★</span>
                                                <div class="rating-bar mx-2 flex-grow-1" style="height: 6px; background: rgba(255,255,255,0.2); border-radius: 3px;">
                                                    <div style="width: <?php echo $percentage; ?>%; height: 100%; background: var(--warning-color); border-radius: 3px;"></div>
                                                </div>
                                                <span style="font-size: 0.8rem; color: #94a3b8;"><?php echo $percentage; ?>%</span>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>

                                        <!-- Quality Indicators -->
                                        <div class="quality-indicators mt-3">
                                            <?php if ($avgRating >= 4.5): ?>
                                                <div class="badge bg-success mb-1"><i class="fas fa-award"></i> Premium Quality</div>
                                            <?php elseif ($avgRating >= 4.0): ?>
                                                <div class="badge bg-primary mb-1"><i class="fas fa-thumbs-up"></i> Highly Rated</div>
                                            <?php endif; ?>

                                            <?php if ($totalSales > 200): ?>
                                                <div class="badge bg-warning text-dark mb-1"><i class="fas fa-fire"></i> Hot Item</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Related Products -->
                    <?php if (!empty($related_products)): ?>
                    <div class="related-products">
                        <h3 class="mb-4" data-translate="related_products"><?php echo htmlspecialchars($translations['related_products'] ?? 'Related Products'); ?></h3>
                        <div class="row">
                            <?php foreach ($related_products as $related): ?>
                            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                                <div class="card related-product-card">
                                    <?php if (($related['discount'] ?? 0) > 0): ?>
                                        <div class="position-absolute top-0 end-0 m-2">
                                            <span class="badge bg-danger"><?php echo ($related['discount'] ?? 0) . '%'; ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <img src="../public/images/<?php echo htmlspecialchars($related['image'] ?? 'default.jpg'); ?>"
                                         class="card-img-top related-product-image"
                                         alt="<?php echo htmlspecialchars($related['product_name']); ?>"
                                         onerror="handleImageError(this);">
                                    <div class="card-body text-center">
                                        <h6 class="card-title" style="color: #e2e8f0;"><?php echo htmlspecialchars($related['product_name']); ?></h6>
                                        <p class="card-text text-primary fw-bold">
                                            <?php echo format_currency($related['price'] ?? 0, $currency, $exchange_rates, $related['discount'] ?? 0); ?>
                                        </p>
                                        <div class="d-flex gap-1 justify-content-center">
                                            <a href="product_details.php?id=<?php echo $related['product_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if (($related['stock_quantity'] ?? 0) > 0): ?>
                                            <button class="btn btn-sm btn-primary" onclick="addToCart(<?php echo $related['product_id']; ?>)">
                                                <i class="fas fa-cart-plus"></i>
                                                </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php else: ?>
                                    <div class="text-center py-5">
                        <div class="card border-0">
                            <div class="card-body">
                                <i class="fas fa-exclamation-triangle fa-4x text-warning mb-4"></i>
                                <h3 data-translate="product_not_found"><?php echo htmlspecialchars($translations['product_not_found'] ?? 'Product Not Found'); ?></h3>
                                <p class="text-muted mb-4" data-translate="product_not_found_desc"><?php echo htmlspecialchars($translations['product_not_found_desc'] ?? 'The product you are looking for does not exist or has been removed.'); ?></p>
                                <a href="pos.php" class="btn-back-pos">
                                    <i class="fas fa-arrow-left"></i> <span data-translate="back_to_pos"><?php echo htmlspecialchars($translations['back_to_pos'] ?? 'Back to POS'); ?></span>
                                </a>
                            </div>
                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <button class="btn btn-primary floating-btn" onclick="window.location.href='pos.php';" title="<?php echo htmlspecialchars($translations['back_to_pos'] ?? 'Back to POS'); ?>">
            <i class="fas fa-cash-register"></i>
        </button>
    </div>

    <!-- Success/Error Modal -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel" data-translate="notification"><?php echo htmlspecialchars($translations['notification'] ?? 'Notification'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="messageModalBody">
                    <!-- Message will be inserted here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include BASEPATH . 'includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <script>
        let currentCurrency = '<?php echo $currency; ?>';
        const exchangeRates = <?php echo json_encode($exchange_rates); ?>;
        let translations = <?php echo json_encode($translations); ?>;

        $(document).ready(function() {
            console.log('Product Details page ready - initializing...');

            // Initialize theme manager
            if (typeof ThemeManager !== 'undefined') {
                window.themeManager = new ThemeManager();
                window.themeManager.init();
                console.log('🎨 Product Details: Theme manager initialized');
            }

            updateUIText();
            initializeImageGallery();

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 Product Details: Notification bell visibility updated');
            }

            // Currency change handler
            $('#currency-select').on('change', function(e) {
                e.preventDefault();
                const newCurrency = $(this).val();
                $.ajax({
                    url: 'product_details.php',
                    type: 'POST',
                    data: { currency: newCurrency },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            currentCurrency = response.currency;
                            location.reload();
                        } else {
                            showMessage(translations['error_updating_currency'] || 'Error updating currency', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showMessage('Error updating currency: ' + error, 'error');
                    }
                });
            });

            // Language change handler
            $('.language-item').on('click', function(e) {
                e.preventDefault();
                const lang = $(this).data('lang');
                updateLanguage(lang);
            });

            // Calculator functionality
            $('.calculator-toggle').on('click', function(e) {
                e.preventDefault();
                $('#calculator-overlay').toggleClass('active');
            });

            $('#calculator-overlay').on('click', function(e) {
                if (e.target === this) {
                    $(this).removeClass('active');
                }
            });

            // Initialize calculator
            const calculator = {
                displayValue: '0',
                firstOperand: null,
                waitingForSecondOperand: false,
                operator: null,
            };

            function inputDigit(digit) {
                if (calculator.waitingForSecondOperand) {
                    calculator.displayValue = digit;
                    calculator.waitingForSecondOperand = false;
                } else {
                    calculator.displayValue = calculator.displayValue === '0' ? digit : calculator.displayValue + digit;
                }
                updateDisplay();
            }

            function inputDecimal(dot) {
                if (calculator.waitingForSecondOperand) {
                    calculator.displayValue = '0.';
                    calculator.waitingForSecondOperand = false;
                    return;
                }
                if (!calculator.displayValue.includes('.')) {
                    calculator.displayValue += dot;
                }
                updateDisplay();
            }

            function handleOperator(nextOperator) {
                const display = parseFloat(calculator.displayValue);
                if (calculator.operator && calculator.waitingForSecondOperand) {
                    calculator.operator = nextOperator;
                    return;
                }
                if (calculator.firstOperand === null && !isNaN(display)) {
                    calculator.firstOperand = display;
                } else if (calculator.operator) {
                    const result = calculate(calculator.firstOperand, display, calculator.operator);
                    calculator.displayValue = String(result);
                    calculator.firstOperand = result;
                }
                calculator.waitingForSecondOperand = true;
                calculator.operator = nextOperator;
                updateDisplay();
            }

            function calculate(first, second, operator) {
                switch (operator) {
                    case '+': return first + second;
                    case '-': return first - second;
                    case 'x': return first * second;
                    case '/': return second !== 0 ? first / second : 'Error';
                    default: return second;
                }
            }

            function updateDisplay() {
                const display = document.getElementById('display');
                if (display) {
                    display.textContent = calculator.displayValue;
                    if (display.textContent.length > 12) {
                        display.style.fontSize = '1.8rem';
                    } else {
                        display.style.fontSize = '2.2rem';
                    }
                }
            }

            function resetCalculator() {
                calculator.displayValue = '0';
                calculator.firstOperand = null;
                calculator.waitingForSecondOperand = false;
                calculator.operator = null;
                updateDisplay();
            }

            function performCalculation() {
                const display = parseFloat(calculator.displayValue);
                if (calculator.firstOperand !== null && !isNaN(display)) {
                    const result = calculate(calculator.firstOperand, display, calculator.operator);
                    calculator.displayValue = String(result);
                    calculator.firstOperand = result;
                    calculator.waitingForSecondOperand = false;
                    calculator.operator = null;
                }
                updateDisplay();
            }

            // Calculator key events
            const keys = document.querySelector('.calculator-keys');
            if (keys) {
                keys.addEventListener('click', (event) => {
                    const { target } = event;
                    if (!target.matches('button')) return;

                    if (target.classList.contains('operator')) {
                        handleOperator(target.textContent);
                        return;
                    }
                    if (target.classList.contains('decimal')) {
                        inputDecimal('.');
                        return;
                    }
                    if (target.classList.contains('clear')) {
                        resetCalculator();
                        return;
                    }
                    if (target.classList.contains('equal')) {
                        performCalculation();
                        return;
                    }
                    inputDigit(target.textContent);
                });
            }

            // Close calculator with Escape key
            $(document).keydown(function(e) {
                if (e.key === 'Escape' && $('#calculator-overlay').hasClass('active')) {
                    $('#calculator-overlay').removeClass('active');
                    e.preventDefault();
                }
            });
        });

        function updateLanguage(lang) {
            $.ajax({
                url: 'product_details.php',
                type: 'POST',
                data: { language: lang },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        translations = response.translations;
                        updateUIText();
                        $('#languageDropdown .language-label').text(lang === 'en' ? (translations['lang_en'] || 'EN') : (translations['lang_mm'] || 'MY'));
                    } else {
                        showMessage(translations['error_updating_language'] || 'Error updating language', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    showMessage('Error updating language: ' + error, 'error');
                }
            });
        }

        function updateUIText() {
            $('[data-translate]').each(function() {
                const key = $(this).data('translate');
                if (translations[key]) {
                    $(this).text(translations[key]);
                }
            });
            $('[data-translate-placeholder]').each(function() {
                const key = $(this).data('translate-placeholder');
                if (translations[key]) {
                    $(this).attr('placeholder', translations[key]);
                }
            });
        }

        function handleImageError(img) {
            if (!img.dataset.errorHandled) {
                img.dataset.errorHandled = 'true';
                img.src = '../public/images/default.jpg';
                img.alt = 'Default Product Image';
                img.style.opacity = '0.7';
            }
        }

        let selectedImageId = null;
        let selectedImageElement = null;

        function changeMainImage(thumbnail, imageId) {
            if (thumbnail.style.display === 'none') return;

            const mainImage = document.getElementById('mainProductImage');
            mainImage.style.opacity = '0.5';

            setTimeout(() => {
                mainImage.src = thumbnail.src;
                mainImage.style.opacity = '1';

                // Update active states
                document.querySelectorAll('.product-image-slot').forEach(slot => slot.classList.remove('active'));
                thumbnail.classList.add('active');

                // Store selected image info
                selectedImageId = imageId;
                selectedImageElement = thumbnail;

                // Update button states
                const deleteBtn = document.getElementById('deleteBtn');
                const primaryBtn = document.getElementById('primaryBtn');

                if (imageId && imageId > 0) {
                    deleteBtn.disabled = false;
                    primaryBtn.disabled = false;

                    // Check if it's primary image
                    const isPrimary = thumbnail.dataset.isPrimary === '1';
                    primaryBtn.style.opacity = isPrimary ? '0.5' : '1';
                    primaryBtn.title = isPrimary ? 'Already primary' : 'Set as primary';
                } else {
                    deleteBtn.disabled = true;
                    primaryBtn.disabled = true;
                }
            }, 150);
        }

        function handleImageUpload(event) {
            const file = event.target.files[0];
            if (!file) return;

            if (!file.type.startsWith('image/')) {
                showMessage('Please select a valid image file', 'error');
                return;
            }

            if (file.size > 5 * 1024 * 1024) { // 5MB limit
                showMessage('File size too large. Maximum size is 5MB.', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('image', file);
            formData.append('action', 'upload');
            formData.append('product_id', <?php echo $product_id; ?>);

            // Show loading
            showMessage('Uploading image...', 'info');

            $.ajax({
                url: 'product_image_manager.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Reload the page to show updated images
                        showMessage('Image uploaded successfully!', 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        showMessage(response.error || 'Failed to upload image', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    showMessage('Upload failed: ' + error, 'error');
                }
            });

            // Clear the input
            event.target.value = '';
        }

        function deleteSelectedImage() {
            if (!selectedImageId || selectedImageId <= 0) {
                showMessage('Please select an image to delete', 'error');
                return;
            }

            if (confirm('Are you sure you want to delete this image?')) {
                $.ajax({
                    url: 'product_image_manager.php',
                    type: 'POST',
                    data: {
                        action: 'delete',
                        product_id: <?php echo $product_id; ?>,
                        image_id: selectedImageId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showMessage('Image deleted successfully!', 'success');
                            setTimeout(() => {
                                location.reload();
                            }, 1000);
                        } else {
                            showMessage(response.error || 'Failed to delete image', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showMessage('Delete failed: ' + error, 'error');
                    }
                });
            }
        }

        function setPrimaryImage() {
            if (!selectedImageId || selectedImageId <= 0) {
                showMessage('Please select an image to set as primary', 'error');
                return;
            }

            // Check if already primary
            if (selectedImageElement && selectedImageElement.dataset.isPrimary === '1') {
                showMessage('This image is already the primary image', 'info');
                return;
            }

            $.ajax({
                url: 'product_image_manager.php',
                type: 'POST',
                data: {
                    action: 'set_primary',
                    product_id: <?php echo $product_id; ?>,
                    image_id: selectedImageId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showMessage('Primary image updated!', 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        showMessage(response.error || 'Failed to update primary image', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    showMessage('Update failed: ' + error, 'error');
                }
            });
        }

        function addToCart(productId) {
            const button = event.target.closest('button');
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
            button.disabled = true;

            console.log('🛒 Adding product to cart:', productId);

            $.ajax({
                url: 'product_details.php',
                type: 'POST',
                data: { action: 'add', product_id: productId },
                dataType: 'json',
                success: function(response) {
                    console.log('🔄 Server response:', response);

                    if (response.success) {
                        // Show success message with cart info
                        const cartInfo = response.cart_quantity ? ` (${response.cart_quantity} in cart)` : '';
                        showMessage(response.message + cartInfo + ' Redirecting to POS...', 'success');
                        button.innerHTML = '<i class="fas fa-check"></i> Added to Cart!';

                        // Update stock display if available
                        if (response.remaining_stock !== undefined && response.cart_quantity !== undefined) {
                            const remainingStock = response.remaining_stock;
                            const cartQty = response.cart_quantity;

                            // Update stock badge
                            const stockBadge = document.getElementById('stockBadge');
                            if (stockBadge) {
                                stockBadge.innerHTML = `${remainingStock} units <small style="opacity: 0.8;">+ ${cartQty} in cart</small>`;

                                // Update badge color
                                const stockColor = remainingStock > 10 ? 'var(--success-color)' :
                                                 remainingStock > 0 ? 'var(--warning-color)' : 'var(--danger-color)';
                                stockBadge.style.backgroundColor = stockColor;
                            }

                            // Update stock bar
                            const stockFill = document.querySelector('.stock-fill');
                            if (stockFill) {
                                const percentage = Math.min(100, (remainingStock / 50) * 100);
                                stockFill.style.width = percentage + '%';

                                const stockColor = remainingStock > 10 ? 'var(--success-color)' :
                                                 remainingStock > 0 ? 'var(--warning-color)' : 'var(--danger-color)';
                                stockFill.style.backgroundColor = stockColor;
                            }

                            // Update real-time stock status widget
                            const availableStockEl = document.getElementById('availableStock');
                            if (availableStockEl) {
                                availableStockEl.textContent = remainingStock;
                            }

                            const cartQuantityEl = document.getElementById('cartQuantity');
                            if (cartQuantityEl) {
                                cartQuantityEl.textContent = cartQty;
                            } else if (cartQty > 0) {
                                // Show cart quantity if it wasn't displayed before
                                const stockWidget = document.querySelector('.stock-status-widget');
                                if (stockWidget) {
                                    const cartRow = document.createElement('div');
                                    cartRow.className = 'd-flex justify-content-between align-items-center mt-1';
                                    cartRow.innerHTML = `
                                        <span>In Cart:</span>
                                        <strong id="cartQuantity">${cartQty}</strong>
                                    `;
                                    stockWidget.insertBefore(cartRow, stockWidget.lastElementChild);
                                }
                            }

                            // Update add to cart button if out of stock
                            if (remainingStock <= 0) {
                                const addToCartBtn = document.getElementById('addToCartBtn');
                                if (addToCartBtn) {
                                    addToCartBtn.disabled = true;
                                    addToCartBtn.className = 'btn btn-danger';
                                    addToCartBtn.innerHTML = '<i class="fas fa-times"></i> Maximum Quantity in Cart';
                                }
                            }
                        }

                        // Update cart count in session storage for instant feedback
                        let cartCount = parseInt(sessionStorage.getItem('cartCount') || '0');
                        cartCount++;
                        sessionStorage.setItem('cartCount', cartCount);

                        // Show notification
                        if (window.showCartNotification) {
                            window.showCartNotification(productId, response.cart_quantity || 1);
                        }

                        // Redirect to POS page after short delay
                        setTimeout(() => {
                            window.location.href = 'pos.php?added=' + productId;
                        }, 1200);
                    } else {
                        // Show detailed error message
                        let errorMsg = response.message;
                        if (response.current_stock !== undefined && response.cart_quantity !== undefined) {
                            errorMsg += `\nStock: ${response.current_stock}, In Cart: ${response.cart_quantity}`;
                        }
                        showMessage(errorMsg, 'error');
                        button.innerHTML = originalHTML;
                        button.disabled = false;

                        console.log('❌ Add to cart failed:', {
                            current_stock: response.current_stock,
                            cart_quantity: response.cart_quantity,
                            message: response.message
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.log('💥 AJAX Error:', { xhr, status, error });
                    console.log('Response Text:', xhr.responseText);

                    let errorMessage = 'Error adding to cart: ' + error;
                    if (xhr.responseText) {
                        try {
                            const errorResponse = JSON.parse(xhr.responseText);
                            errorMessage = errorResponse.message || errorMessage;
                        } catch (e) {
                            errorMessage += '\nServer response: ' + xhr.responseText.substring(0, 100);
                        }
                    }

                    showMessage(errorMessage, 'error');
                    button.innerHTML = originalHTML;
                    button.disabled = false;
                }
            });
        }

        // Cart notification function
        window.showCartNotification = function(productId, quantity) {
            // Create floating notification
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                background: linear-gradient(135deg, #10b981, #059669);
                color: white;
                padding: 12px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(16, 185, 129, 0.3);
                z-index: 10000;
                font-size: 0.9rem;
                font-weight: 600;
                transform: translateX(100%);
                transition: transform 0.3s ease;
            `;
            notification.innerHTML = `
                <i class="fas fa-check-circle me-2"></i>
                Product added to cart!
            `;

            document.body.appendChild(notification);

            // Animate in
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);

            // Auto remove
            setTimeout(() => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        };

        function shareProduct() {
            if (navigator.share) {
                navigator.share({
                    title: document.querySelector('h1').textContent,
                    text: 'Check out this product!',
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(window.location.href).then(() => {
                    showMessage(translations['link_copied'] || 'Link copied to clipboard!', 'success');
                });
            }
        }

        function openImageUpload() {
            document.getElementById('imageUploadInput').click();
        }

        function showMessage(message, type) {
            const modal = new bootstrap.Modal(document.getElementById('messageModal'));
            const modalBody = document.getElementById('messageModalBody');
            const alertClass = type === 'success' ? 'alert-success' : type === 'info' ? 'alert-info' : 'alert-danger';

            modalBody.innerHTML = `<div class="alert ${alertClass} mb-0">${message}</div>`;
            modal.show();
        }

        // Enhanced image interactions
        $('.product-main-image').on('click', function() {
            $(this).toggleClass('zoomed');
        });

        // Keyboard shortcuts
        $(document).keydown(function(e) {
            if (e.key === 'Escape') {
                if ($('#calculator-overlay').hasClass('active')) {
                    $('#calculator-overlay').removeClass('active');
                } else {
                    window.location.href = 'pos.php';
                }
            }
            if (e.key === 'Enter' && e.ctrlKey) {
                const addButton = $('.btn-add-cart:visible');
                if (addButton.length) {
                    addButton.click();
                }
            }
        });

        // Initialize image gallery
        function initializeImageGallery() {
            // Set the first image as selected if available
            const firstImage = document.querySelector('.product-image-slot');
            if (firstImage) {
                const imageId = firstImage.dataset.imageId;
                if (imageId && imageId > 0) {
                    selectedImageId = parseInt(imageId);
                    selectedImageElement = firstImage;

                    // Update button states
                    const deleteBtn = document.getElementById('deleteBtn');
                    const primaryBtn = document.getElementById('primaryBtn');

                    if (deleteBtn && primaryBtn) {
                        deleteBtn.disabled = false;
                        primaryBtn.disabled = false;

                        const isPrimary = firstImage.dataset.isPrimary === '1';
                        primaryBtn.style.opacity = isPrimary ? '0.5' : '1';
                        primaryBtn.title = isPrimary ? 'Already primary' : 'Set as primary';
                    }
                }
            }
        }

        // Auto-refresh stock info
        setInterval(function() {
            $('.stock-fill').css('animation', 'pulse 0.5s ease-in-out');
            setTimeout(() => {
                $('.stock-fill').css('animation', '');
            }, 500);
        }, 30000);
    </script>
</body>
</html>