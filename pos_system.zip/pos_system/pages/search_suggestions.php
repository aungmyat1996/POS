<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$search_type = isset($_GET['search_type']) ? $_GET['search_type'] : 'product_name';

$results = [];
if (!empty($search_query)) {
    if ($search_type === 'category') {
        $stmt = $pdo->prepare("SELECT category_name FROM categories WHERE category_name LIKE ? LIMIT 5");
        $stmt->execute(["%$search_query%"]);
        $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } else {
        $stmt = $pdo->prepare("SELECT product_name FROM products WHERE product_name LIKE ? LIMIT 5");
        $stmt->execute(["%$search_query%"]);
        $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}

echo json_encode($results);
?>