<?php
session_start();
require_once '../config/db.php';
require_once '../includes/functions.php';

// Load theme settings
$themeSettings = loadThemeSettings($pdo);
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $themeSettings['theme_mode'] ?? 'dark'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theme Test - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/theme.css">
    <style>
        body {
            padding: 20px;
            min-height: 100vh;
        }
        .test-card {
            margin-bottom: 20px;
        }
        .color-box {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            display: inline-block;
            margin: 5px;
            border: 2px solid var(--border-color);
        }
        .debug-info {
            background: var(--sidebar-color);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            font-family: monospace;
            font-size: 12px;
        }

        /* Light Mode H1 and Headers Text Colors for Theme Test Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Theme Test Page</h1>
        <p>This page tests the theme system functionality.</p>

        <!-- Theme Controls -->
        <div class="card test-card">
            <div class="card-header">
                <h5>Theme Controls</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Theme Mode</h6>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="theme_mode" id="light_mode" value="light"
                                   <?php echo ($themeSettings['theme_mode'] ?? 'dark') === 'light' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="light_mode">Light Mode</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="theme_mode" id="dark_mode" value="dark"
                                   <?php echo ($themeSettings['theme_mode'] ?? 'dark') === 'dark' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="dark_mode">Dark Mode</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6>Quick Actions</h6>
                        <button class="btn btn-primary me-2" onclick="testLightMode()">Test Light</button>
                        <button class="btn btn-secondary me-2" onclick="testDarkMode()">Test Dark</button>
                        <button class="btn btn-info me-2" onclick="checkThemeStatus()">Check Status</button>
                        <button class="btn btn-success" onclick="saveToDatabase()">Save to DB</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Color Preview -->
        <div class="card test-card">
            <div class="card-header">
                <h5>Color Preview</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <h6>Primary Colors</h6>
                        <div class="color-box" style="background: var(--primary-color);" title="Primary"></div>
                        <div class="color-box" style="background: var(--secondary-color);" title="Secondary"></div>
                        <div class="color-box" style="background: var(--accent-color);" title="Accent"></div>
                    </div>
                    <div class="col-md-4">
                        <h6>Background Colors</h6>
                        <div class="color-box" style="background: var(--background-color);" title="Background"></div>
                        <div class="color-box" style="background: var(--sidebar-color);" title="Sidebar"></div>
                        <div class="color-box" style="background: var(--text-color);" title="Text"></div>
                    </div>
                    <div class="col-md-4">
                        <h6>Status Colors</h6>
                        <div class="color-box" style="background: var(--success-color);" title="Success"></div>
                        <div class="color-box" style="background: var(--warning-color);" title="Warning"></div>
                        <div class="color-box" style="background: var(--danger-color);" title="Danger"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Component Tests -->
        <div class="card test-card">
            <div class="card-header">
                <h5>Component Tests</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Buttons</h6>
                        <button class="btn btn-primary me-2">Primary</button>
                        <button class="btn btn-secondary me-2">Secondary</button>
                        <button class="btn btn-success me-2">Success</button>
                        <button class="btn btn-warning me-2">Warning</button>
                        <button class="btn btn-danger">Danger</button>
                    </div>
                    <div class="col-md-6">
                        <h6>Form Elements</h6>
                        <input type="text" class="form-control mb-2" placeholder="Text input">
                        <select class="form-select mb-2">
                            <option>Select option</option>
                            <option>Option 1</option>
                            <option>Option 2</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Debug Information -->
        <div class="debug-info">
            <h6>Debug Information</h6>
            <div id="debug-output">
                <p><strong>PHP Theme Settings:</strong></p>
                <pre><?php echo json_encode($themeSettings, JSON_PRETTY_PRINT); ?></pre>
            </div>
        </div>
    </div>

    <!-- Pass PHP theme settings to JavaScript -->
    <script>
    window.phpThemeSettings = <?php echo json_encode($themeSettings); ?>;
    console.log('🎨 PHP Theme Settings loaded:', window.phpThemeSettings);
    </script>

    <script src="../public/js/theme-manager.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    // Test functions
    function testLightMode() {
        console.log('🎨 Testing light mode...');
        document.documentElement.setAttribute('data-theme', 'light');
        document.body.setAttribute('data-theme', 'light');
        document.body.style.backgroundColor = '#f8f9fa';
        document.body.style.color = '#212529';
        document.querySelector('input[name="theme_mode"][value="light"]').checked = true;

        if (window.themeManager) {
            window.themeManager.setThemeMode('light');
        }

        updateDebugInfo();
        console.log('🎨 Light mode applied');
    }

    function testDarkMode() {
        console.log('🎨 Testing dark mode...');
        document.documentElement.setAttribute('data-theme', 'dark');
        document.body.setAttribute('data-theme', 'dark');
        document.body.style.backgroundColor = '#21243A';
        document.body.style.color = '#ffffff';
        document.querySelector('input[name="theme_mode"][value="dark"]').checked = true;

        if (window.themeManager) {
            window.themeManager.setThemeMode('dark');
        }

        updateDebugInfo();
        console.log('🎨 Dark mode applied');
    }

    function checkThemeStatus() {
        console.log('🎨 Theme Status Check:');
        console.log('- HTML data-theme:', document.documentElement.getAttribute('data-theme'));
        console.log('- Body data-theme:', document.body.getAttribute('data-theme'));
        console.log('- Body background:', document.body.style.backgroundColor);
        console.log('- Body color:', document.body.style.color);
        console.log('- Selected radio:', document.querySelector('input[name="theme_mode"]:checked')?.value);
        console.log('- Theme manager:', typeof window.themeManager !== 'undefined' ? 'Available' : 'Not available');
        if (typeof window.themeManager !== 'undefined') {
            console.log('- Current theme:', window.themeManager.currentTheme);
            console.log('- Colors:', window.themeManager.colors);
        }
        updateDebugInfo();
    }

    function updateDebugInfo() {
        const debugOutput = document.getElementById('debug-output');
        const info = {
            htmlDataTheme: document.documentElement.getAttribute('data-theme'),
            bodyDataTheme: document.body.getAttribute('data-theme'),
            bodyBackground: document.body.style.backgroundColor,
            bodyColor: document.body.style.color,
            selectedRadio: document.querySelector('input[name="theme_mode"]:checked')?.value,
            themeManagerAvailable: typeof window.themeManager !== 'undefined',
            currentTheme: window.themeManager?.currentTheme,
            colors: window.themeManager?.colors
        };

        debugOutput.innerHTML = `
            <p><strong>PHP Theme Settings:</strong></p>
            <pre>${JSON.stringify(window.phpThemeSettings, null, 2)}</pre>
            <p><strong>Current Status:</strong></p>
            <pre>${JSON.stringify(info, null, 2)}</pre>
        `;
    }

    function saveToDatabase() {
        console.log('🎨 Saving current theme to database...');
        if (window.themeManager) {
            window.themeManager.saveThemeToDatabase();
            alert('Theme saved to database! Check console for details.');
        } else {
            alert('Theme manager not available!');
        }
    }

    // Setup radio button listeners
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('input[name="theme_mode"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const mode = this.value;
                console.log('🎨 Radio changed to:', mode);

                if (mode === 'light') {
                    testLightMode();
                } else {
                    testDarkMode();
                }
            });
        });

        // Initial debug info
        setTimeout(updateDebugInfo, 1000);
    });
    </script>
</body>
</html>
