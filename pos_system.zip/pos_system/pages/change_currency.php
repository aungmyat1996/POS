<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Set JSON header for AJAX responses
header('Content-Type: application/json');

// Require authentication for this page
requireAuth();

// Ensure the user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    // Check if currency parameter is set and is valid
    if (!isset($_POST['currency'])) {
        echo json_encode(['success' => false, 'message' => 'Currency parameter missing']);
        exit;
    }

    $currency = $_POST['currency'];

    if (!in_array($currency, ['USD', 'THB', 'MMK'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid currency']);
        exit;
    }

    $user_id = $_SESSION['user_id'] ?? null;

    // Store the selected currency in session
    $_SESSION['currency'] = $currency;

    // If user is logged in, update their preference in database
    if ($user_id) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET currency_preference = ? WHERE user_id = ?");
            $stmt->execute([$currency, $user_id]);
        } catch (PDOException $e) {
            // If there's no currency_preference column yet, we'll create it
            if (strpos($e->getMessage(), "Unknown column 'currency_preference'") !== false) {
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN currency_preference VARCHAR(10) DEFAULT 'USD'");
                    $stmt = $pdo->prepare("UPDATE users SET currency_preference = ? WHERE user_id = ?");
                    $stmt->execute([$currency, $user_id]);
                } catch (PDOException $e2) {
                    error_log("Error adding currency_preference column: " . $e2->getMessage());
                }
            } else {
                error_log("Error updating currency preference: " . $e->getMessage());
            }
        }
    }

    // Log the action
    if (function_exists('logAction')) {
        logAction($pdo, $user_id, "Changed currency to $currency");
    }

    // Currency symbols and rates
    $currency_symbols = [
        'USD' => '$',
        'THB' => '฿',
        'MMK' => 'Ks'
    ];

    $exchange_rates = [
        'USD' => 1,
        'THB' => 33,
        'MMK' => 2100
    ];

    echo json_encode([
        'success' => true,
        'message' => 'Currency updated successfully',
        'currency' => $currency,
        'symbol' => $currency_symbols[$currency],
        'rate' => $exchange_rates[$currency]
    ]);

} catch (Exception $e) {
    error_log("Currency change error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error occurred']);
}
exit;