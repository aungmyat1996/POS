<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$language = $_SESSION['language'] ?? 'en';
$translations = loadLanguage($language);

try {
    $stmt = $pdo->prepare("SELECT notification_id AS id, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
    $stmt->execute([$_SESSION['user_id']]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $unread_count = 0;
    foreach ($notifications as &$notif) {
        $notif['is_read'] = (bool)$notif['is_read'];
        if (!$notif['is_read']) $unread_count++;
        $notif['created_at'] = date('Y-m-d H:i:s', strtotime($notif['created_at']));
    }

    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'unread_count' => $unread_count,
        'translations' => [
            'no_notifications' => $translations['no_notifications'] ?? 'No notifications available.'
        ]
    ]);
} catch (PDOException $e) {
    error_log("Error fetching notifications: " . $e->getMessage(), 3, BASEPATH . 'logs/db_errors.log');
    echo json_encode(['success' => false, 'error' => $translations['error_fetching_notifications'] ?? 'Error fetching notifications']);
}
?>