<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

header('Content-Type: application/json');

try {
    // Validate session and cart data
    if (!isset($_SESSION)) {
        throw new Exception('Session not initialized');
    }

    $cart = $_SESSION['cart'] ?? [];
    if (!is_array($cart)) {
        throw new Exception('Invalid cart data structure');
    }

    // Validate cart contents
    foreach ($cart as $product_id => $quantity) {
        if (!is_numeric($product_id) || $product_id <= 0) {
            unset($cart[$product_id]);
            continue;
        }
        if (!is_numeric($quantity) || $quantity <= 0) {
            unset($cart[$product_id]);
        }
    }

    // Update session with cleaned cart
    $_SESSION['cart'] = $cart;

    $currency = $_SESSION['currency'] ?? 'USD';
    $exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
    
    if (!isset($exchange_rates[$currency])) {
        throw new Exception('Invalid currency');
    }

    $cart_items = [];
    $subtotal = 0;
    $discount = 0;

    if (!empty($cart)) {
        try {
            // Verify database connection
            if (!isset($pdo) || !($pdo instanceof PDO)) {
                error_log("Database connection not available in cart_ajax.php");
                throw new Exception('Database connection error');
            }

            // Check if products table exists
            $tableCheck = $pdo->query("
                SELECT COUNT(*) 
                FROM information_schema.tables 
                WHERE table_schema = DATABASE() 
                AND table_name = 'products'
            ")->fetchColumn();

            if (!$tableCheck) {
                error_log("Products table does not exist in the database");
                throw new Exception('Products table not found');
            }

            // Get products with detailed error logging
            $placeholders = str_repeat('?,', count($cart) - 1) . '?';
            $product_ids = array_keys($cart);
            
            $query = "SELECT product_id, product_name, unit_price, stock_quantity, COALESCE(discount, 0) as discount 
                     FROM products 
                     WHERE product_id IN ($placeholders)";
            
            error_log("Executing query: " . $query . " with IDs: " . implode(', ', $product_ids));
            
            $stmt = $pdo->prepare($query);
            if ($stmt === false) {
                error_log("Failed to prepare product query: " . print_r($pdo->errorInfo(), true));
                throw new Exception('Failed to prepare product query');
            }

            if (!$stmt->execute($product_ids)) {
                error_log("Failed to execute product query: " . print_r($stmt->errorInfo(), true));
                throw new Exception('Failed to execute product query');
            }

            $cart_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($cart_products === false) {
                error_log("Failed to fetch products: " . print_r($stmt->errorInfo(), true));
                throw new Exception('Failed to fetch products');
            }

            error_log("Found " . count($cart_products) . " products for cart");
            
            foreach ($cart_products as $product) {
                $product_id = $product['product_id'];
                if (isset($cart[$product_id])) {
                    // Validate and sanitize numeric values
                    $quantity = max(0, intval($cart[$product_id]));
                    $base_price = max(0, floatval($product['unit_price']));
                    $item_discount = max(0, min(100, floatval($product['discount'])));
                    
                    // Calculate prices with validation
                    $converted_price = $base_price * $exchange_rates[$currency];
                    $discounted_price = $converted_price * (1 - ($item_discount / 100));
                    $item_total = $discounted_price * $quantity;
                    
                    // Build cart item with sanitized data
                    $cart_items[] = [
                        'product_id' => intval($product_id),
                        'product_name' => htmlspecialchars($product['product_name']),
                        'price' => round($converted_price, 2),
                        'discount' => round($item_discount, 2),
                        'quantity' => $quantity,
                        'stock_quantity' => intval($product['stock_quantity']),
                        'total' => round($item_total, 2)
                    ];
                    
                    $subtotal += $item_total;
                    $discount += ($converted_price * $quantity) - $item_total;
                }
            }
        } catch (PDOException $e) {
            error_log("Cart Database Error: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
            throw new Exception('Database error: ' . $e->getMessage());
        }
    }

    // Round final values to prevent floating point issues
    $response = [
        'success' => true,
        'cart_items' => $cart_items,
        'subtotal' => round($subtotal, 2),
        'discount' => round($discount, 2),
        'currency' => $currency
    ];

    error_log("Sending cart response: " . json_encode($response));
    echo json_encode($response);

} catch (Exception $e) {
    error_log("Cart Ajax Error: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
    echo json_encode([
        'success' => false,
        'error' => 'Error processing cart data: ' . $e->getMessage()
    ]);
}
?>