<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Validate product ID
$product_id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($product_id === false || $product_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid product ID']);
    exit();
}

try {
    // Prepare and execute query
    $stmt = $pdo->prepare("
        SELECT product_id, product_name, category_id, description, price,
               stock_quantity, cost_price, supplier_id, discount, barcode,
               image, status
        FROM products
        WHERE product_id = ?
        LIMIT 1
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if product exists
    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
        exit();
    }

    // Set JSON header and output product data
    header('Content-Type: application/json');
    echo json_encode($product);
} catch (PDOException $e) {
    // Log error and return generic message
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
    error_log("Error fetching product for product_id $product_id: " . $e->getMessage());
}
?>