<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
try {
    $stmt = $pdo->query("SELECT SUM(total_amount) FROM sales WHERE DATE(sale_date) = CURDATE()");
    $today_sales_total = $stmt->fetchColumn() ?: 0;
} catch (PDOException $e) {
    $today_sales_total = 0;
    error_log("Error fetching today's sales total: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales
                         FROM sales s
                         WHERE MONTH(s.sale_date) = MONTH(CURDATE()) AND YEAR(s.sale_date) = YEAR(CURDATE())");
    $monthly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $monthly_sales_total = 0;
    error_log("Error fetching monthly sales total: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales
                         FROM sales s
                         WHERE YEAR(s.sale_date) = YEAR(CURDATE())");
    $yearly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $yearly_sales_total = 0;
    error_log("Error fetching yearly sales total: " . $e->getMessage());
}

header('Content-Type: application/json');
echo json_encode([
    'today_sales_total' => $today_sales_total,
    'monthly_sales_total' => $monthly_sales_total,
    'yearly_sales_total' => $yearly_sales_total
]);
?>