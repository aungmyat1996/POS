<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Add getPaymentIcon function
function getPaymentIcon($methodCode) {
    $icons = [
        'CASH' => 'money-bill-wave',
        'KBZPAY' => 'mobile-alt',
        'WAVEPAY' => 'mobile',
        'CARD' => 'credit-card',
        'BANK' => 'university'
    ];
    return $icons[$methodCode] ?? 'money-bill';
}

// Require authentication for this page
requireAuth();

// Set timezone from settings
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'timezone'");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $timezone = $result['setting_value'] ?? 'Asia/Yangon';
    date_default_timezone_set($timezone);
} catch (PDOException $e) {
    error_log("Error fetching timezone setting: " . $e->getMessage());
    date_default_timezone_set('Asia/Yangon');
}

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];
$currency = $_SESSION['currency'] ?? ($settings['currency'] ?? 'USD');
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['currency'])) {
        $_SESSION['currency'] = $_POST['currency'];
        echo json_encode(['success' => true, 'currency' => $_POST['currency']]);
        exit;
    }
    if (isset($_POST['language']) && in_array($_POST['language'], ['en', 'mm'])) {
        $_SESSION['language'] = $_POST['language'];
        $language_file = "../languages/{$_POST['language']}.php";
        $translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
        echo json_encode(['success' => true, 'translations' => $translations]);
        exit;
    }
    if (isset($_POST['reset_all'])) {
        $_SESSION['cart'] = [];
        $_SESSION['customer_info'] = ['name' => '', 'address' => '', 'phone' => ''];
        $_SESSION['tax'] = isset($_POST['tax']) ? floatval($_POST['tax']) : 0;
        $_SESSION['shipping'] = isset($_POST['shipping']) ? floatval($_POST['shipping']) : 0;
        $pdo->query("UPDATE products SET stock_quantity = stock_quantity + 1 WHERE stock_quantity < 100");
        echo json_encode(['success' => true]);
        exit;
    }
    if (isset($_POST['buy_now'])) {
        $customer_info = $_SESSION['customer_info'] ?? ['name' => '', 'address' => '', 'phone' => ''];
        if (empty($customer_info['name']) || empty($customer_info['address']) || empty($customer_info['phone'])) {
            echo json_encode(['success' => false, 'error' => 'Please fill in all customer details']);
            exit;
        } elseif (!empty($_SESSION['cart'])) {
            $stmt = $pdo->prepare("INSERT INTO customers (customer_name, address, phone_no) VALUES (?, ?, ?)");
            $stmt->execute([$customer_info['name'], $customer_info['address'], $customer_info['phone']]);
            $customer_id = $pdo->lastInsertId();

            $cart = $_SESSION['cart'] ?? [];
            $subtotal = 0;
            $discount = 0;
            $placeholders = implode(',', array_fill(0, count(array_keys($cart)), '?'));
            $stmt = $pdo->prepare("SELECT product_id, price, discount FROM products WHERE product_id IN ($placeholders)");
            $stmt->execute(array_keys($cart));
            $cart_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cart_products as $product) {
                $item_discount = $product['discount'] ?? 0;
                $item_total = $product['price'] * $cart[$product['product_id']] * (1 - ($item_discount / 100)) * $exchange_rates[$currency];
                $subtotal += $item_total;
                $discount += ($product['price'] * $cart[$product['product_id']] * ($item_discount / 100)) * $exchange_rates[$currency];
            }
            $tax = isset($_POST['tax']) ? floatval($_POST['tax']) * $exchange_rates[$currency] : 0;
            $shipping = isset($_POST['shipping']) ? floatval($_POST['shipping']) * $exchange_rates[$currency] : 0;
            $total = $subtotal + $tax + $shipping - $discount;

            $invoice_number = 'INV' . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, customer_id, invoice_number, total_amount, status, payment_method, order_date) VALUES (?, ?, ?, ?, 'completed', 'cash', ?)");
            $stmt->execute([$_SESSION['user_id'], $customer_id, $invoice_number, $total, date('Y-m-d H:i:s')]);
            $order_id = $pdo->lastInsertId();

            foreach ($cart_products as $product) {
                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$order_id, $product['product_id'], $cart[$product['product_id']], $product['price'] * $exchange_rates[$currency]]);
            }

            $stmt = $pdo->prepare("INSERT INTO sales (order_id, user_id, customer_id, sale_date, total_amount) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$order_id, $_SESSION['user_id'], $customer_id, date('Y-m-d H:i:s'), $total]);

            $stmt = $pdo->prepare("INSERT INTO logs (user_id, action, created_at) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], 'Sale completed', date('Y-m-d H:i:s')]);

            $_SESSION['cart'] = [];
            $_SESSION['customer_info'] = ['name' => '', 'address' => '', 'phone' => ''];
            $_SESSION['tax'] = 0;
            $_SESSION['shipping'] = 0;

            echo json_encode(['success' => true, 'order_id' => $order_id]);
            exit;
        }
    }
    if (isset($_POST['action']) && isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        $action = $_POST['action'];
        $response = ['success' => false];

        try {
            // Get product stock
            $stmt = $pdo->prepare("SELECT stock_quantity, unit_price, discount FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                throw new Exception('Product not found');
            }

            $stock = $product['stock_quantity'];
        $cart = $_SESSION['cart'] ?? [];
            $current_quantity = isset($cart[$product_id]) ? $cart[$product_id] : 0;

            // Handle different actions
            switch ($action) {
                case 'add':
                    if ($stock > 0) {
                        $cart[$product_id] = $current_quantity + 1;
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - 1 WHERE product_id = ?")->execute([$product_id]);

                        // Calculate totals after adding item
                        $stmt = $pdo->prepare("SELECT unit_price, discount FROM products WHERE product_id = ?");
                        $stmt->execute([$product_id]);
                        $product = $stmt->fetch(PDO::FETCH_ASSOC);

                        $price = floatval($product['unit_price']);
                        $discount = floatval($product['discount'] ?? 0);

                        // Calculate item total with precise decimal handling
                        $item_price = round($price * (1 - ($discount / 100)), 2);
                        $item_total = round($item_price * ($current_quantity + 1), 2);

                        // Calculate cart total
                        $subtotal = 0;
                        foreach ($cart as $pid => $qty) {
                            $stmt = $pdo->prepare("SELECT unit_price, discount FROM products WHERE product_id = ?");
                            $stmt->execute([$pid]);
                            $p = $stmt->fetch(PDO::FETCH_ASSOC);

                            $p_price = floatval($p['unit_price']);
                            $p_discount = floatval($p['discount'] ?? 0);
                            $p_item_price = round($p_price * (1 - ($p_discount / 100)), 2);
                            $p_total = round($p_item_price * $qty, 2);
                            $subtotal = bcadd($subtotal, $p_total, 2);
                        }

                        // Apply currency conversion
                        $subtotal = round($subtotal * $exchange_rates[$currency], 2);

                        // Calculate tax and shipping
                        $tax_rate = isset($_SESSION['tax_rate']) ? floatval($_SESSION['tax_rate']) : 0;
                        $shipping = isset($_SESSION['shipping']) ? floatval($_SESSION['shipping']) : 0;

                        $tax_amount = round(($subtotal * $tax_rate) / 100, 2);
                        $total = round($subtotal + $tax_amount + $shipping, 2);

                        $response['totals'] = [
                            'subtotal' => number_format($subtotal, 2, '.', ''),
                            'tax_amount' => number_format($tax_amount, 2, '.', ''),
                            'shipping' => number_format($shipping, 2, '.', ''),
                            'total' => number_format($total, 2, '.', ''),
                            'items_count' => array_sum($cart)
                        ];

                        $response['success'] = true;
                    } else {
                        throw new Exception('Out of stock');
                    }
                    break;

                case 'plus':
                    if ($stock > 0) {
                        $cart[$product_id] = $current_quantity + 1;
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - 1 WHERE product_id = ?")->execute([$product_id]);
                        $response['success'] = true;
                    } else {
                        throw new Exception('Out of stock');
                    }
                    break;

                case 'minus':
                    if ($current_quantity > 1) {
                        $cart[$product_id] = $current_quantity - 1;
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + 1 WHERE product_id = ?")->execute([$product_id]);
                        $response['success'] = true;
                    } elseif ($current_quantity === 1) {
            unset($cart[$product_id]);
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + 1 WHERE product_id = ?")->execute([$product_id]);

                        // Check if this was the last item in cart
                        if (empty($cart)) {
                            $_SESSION['tax'] = 0;
                            $_SESSION['shipping'] = 0;
                            $_SESSION['tax_rate'] = 0;
                            $response['totals'] = [
                                'subtotal' => '0.00',
                                'tax_amount' => '0.00',
                                'shipping' => '0.00',
                                'total' => '0.00',
                                'items_count' => 0
                            ];
                        }
                        $response['success'] = true;
                    }
                    break;

                case 'remove':
                    if (isset($cart[$product_id])) {
                        $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?")
                            ->execute([$cart[$product_id], $product_id]);
                        unset($cart[$product_id]);
                        $response['success'] = true;
                    }
                    break;
            }

            // Update cart in session
        $_SESSION['cart'] = $cart;

            // Reset session variables if cart is empty
            if (empty($cart)) {
                $_SESSION['tax'] = 0;
                $_SESSION['shipping'] = 0;
                $_SESSION['tax_rate'] = 0;
                $response['totals'] = [
                    'subtotal' => '0.00',
                    'tax_amount' => '0.00',
                    'shipping' => '0.00',
                    'total' => '0.00',
                    'items_count' => 0
                ];
            } else {
                // Calculate totals
                $subtotal = 0;
                $total_items = 0;

                if (!empty($cart)) {
                    $product_ids = array_keys($cart);
                    $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
                    $stmt = $pdo->prepare("SELECT product_id, unit_price, discount FROM products WHERE product_id IN ($placeholders)");
                    $stmt->execute($product_ids);
                    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($products as $prod) {
                        $quantity = $cart[$prod['product_id']];
                        $price = floatval($prod['unit_price']);
                        $discount = floatval($prod['discount'] ?? 0);

                        // Use bcmath for precise decimal calculations
                        $item_price = $price * (1 - ($discount / 100));
                        $item_price = round($item_price, 2); // Round to 2 decimal places
                        $item_total = $item_price * $quantity;
                        $item_total = round($item_total, 2); // Round to 2 decimal places

                        $subtotal = bcadd($subtotal, $item_total, 2); // Use bcadd for precise addition
                        $total_items += $quantity;
                    }
                }

                // Apply currency conversion with precise rounding
                $subtotal = round($subtotal * $exchange_rates[$currency], 2);

                // Calculate tax and total with precise rounding
                $tax_rate = isset($_SESSION['tax_rate']) ? floatval($_SESSION['tax_rate']) : 0;
                $shipping = isset($_SESSION['shipping']) ? floatval($_SESSION['shipping']) : 0;

                $tax_amount = round(($subtotal * $tax_rate) / 100, 2);
                $total = round($subtotal + $tax_amount + $shipping, 2);

                // Add totals to response with exact values
                $response['totals'] = [
                    'subtotal' => number_format($subtotal, 2, '.', ''),
                    'tax_amount' => number_format($tax_amount, 2, '.', ''),
                    'shipping' => number_format($shipping, 2, '.', ''),
                    'total' => number_format($total, 2, '.', ''),
                    'items_count' => $total_items
                ];
            }

        } catch (Exception $e) {
            $response['error'] = $e->getMessage();
        }

        echo json_encode($response);
        exit;
    }
    if (isset($_POST['tax']) || isset($_POST['shipping'])) {
        $_SESSION['tax'] = isset($_POST['tax']) ? floatval($_POST['tax']) * $exchange_rates[$currency] : $_SESSION['tax'];
        $_SESSION['shipping'] = isset($_POST['shipping']) ? floatval($_POST['shipping']) * $exchange_rates[$currency] : $_SESSION['shipping'];
        echo json_encode(['success' => true]);
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'checkout') {
        try {
            // Validate cart is not empty
            if (empty($_SESSION['cart'])) {
                throw new Exception('Cart is empty');
            }

            // Validate customer info
            $customer_info = $_SESSION['customer_info'] ?? null;
            if (!$customer_info || empty($customer_info['name']) || empty($customer_info['phone'])) {
                throw new Exception('Customer information is required');
            }

            // Validate payment method
            if (!isset($_POST['payment_method_id'])) {
                throw new Exception('Payment method is required');
            }

            $payment_method_id = $_POST['payment_method_id'];
            $payment_reference = $_POST['payment_reference'] ?? null;

            // Get payment method details
            $stmt = $pdo->prepare("SELECT method_code, method_name FROM payment_methods WHERE payment_method_id = ?");
            $stmt->execute([$payment_method_id]);
            $payment_method = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$payment_method) {
                throw new Exception('Invalid payment method');
            }

            // Validate payment reference for non-cash payments
            if ($payment_method['method_code'] !== 'CASH' && empty($payment_reference)) {
                throw new Exception('Payment reference is required for ' . $payment_method['method_name']);
            }

            // Start transaction
            $pdo->beginTransaction();

            // Create or update customer
            $stmt = $pdo->prepare("
                INSERT INTO customers (customer_name, phone_no, address)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    address = VALUES(address),
                    updated_at = CURRENT_TIMESTAMP
            ");
            $stmt->execute([
                $customer_info['name'],
                $customer_info['phone'],
                $customer_info['address'] ?? ''
            ]);
            $customer_id = $pdo->lastInsertId();

            // Calculate order totals
            $subtotal = 0;
            $total_discount = 0;
            $cart = $_SESSION['cart'];
            $order_items = [];

            // Get all products in cart
            $product_ids = array_keys($cart);
            $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
            $stmt = $pdo->prepare("SELECT product_id, product_name, unit_price, discount FROM products WHERE product_id IN ($placeholders)");
            $stmt->execute($product_ids);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($products as $product) {
                $quantity = $cart[$product['product_id']];
                $unit_price = floatval($product['unit_price']);
                $discount = floatval($product['discount'] ?? 0);

                // Calculate item total with discount
                $item_price = $unit_price * (1 - ($discount / 100));
                $item_total = $item_price * $quantity;

                $subtotal += $item_total;
                $total_discount += ($unit_price * $quantity * ($discount / 100));

                $order_items[] = [
                    'product_id' => $product['product_id'],
                    'quantity' => $quantity,
                    'unit_price' => $unit_price,
                    'discount' => $discount,
                    'total' => $item_total
                ];
            }

            // Apply currency conversion
            $subtotal = $subtotal * $exchange_rates[$currency];
            $total_discount = $total_discount * $exchange_rates[$currency];

            // Get tax and shipping
            $tax_rate = floatval($_SESSION['tax_rate'] ?? 0);
            $shipping = floatval($_SESSION['shipping'] ?? 0);

            // Calculate final totals
            $tax_amount = ($subtotal * $tax_rate) / 100;
            $total_amount = $subtotal + $tax_amount + $shipping;

            // Generate invoice number
            $invoice_number = 'INV' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);

            // Create order
            $stmt = $pdo->prepare("
                INSERT INTO orders (
                    user_id,
                    customer_id,
                    invoice_number,
                    subtotal,
                    tax_rate,
                    tax_amount,
                    shipping_fee,
                    total_discount,
                    total_amount,
                    payment_method_id,
                    payment_reference,
                    currency,
                    status,
                    order_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', CURRENT_TIMESTAMP)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $customer_id,
                $invoice_number,
                $subtotal,
                $tax_rate,
                $tax_amount,
                $shipping,
                $total_discount,
                $total_amount,
                $payment_method_id,
                $payment_reference,
                $currency
            ]);
            $order_id = $pdo->lastInsertId();

            // Create order items
            $stmt = $pdo->prepare("
                INSERT INTO order_items (
                    order_id,
                    product_id,
                    quantity,
                    unit_price,
                    discount,
                    total
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");

            foreach ($order_items as $item) {
                $stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['quantity'],
                    $item['unit_price'] * $exchange_rates[$currency],
                    $item['discount'],
                    $item['total'] * $exchange_rates[$currency]
                ]);

                // Update stock
                $pdo->prepare("
                    UPDATE products
                    SET stock_quantity = stock_quantity - ?,
                        last_sold_date = CURRENT_TIMESTAMP,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE product_id = ?
                ")->execute([$item['quantity'], $item['product_id']]);
            }

            // Create payment record
            $stmt = $pdo->prepare("
                INSERT INTO payments (
                    order_id,
                    payment_method_id,
                    amount,
                    currency,
                    reference_number,
                    status,
                    payment_date
                ) VALUES (?, ?, ?, ?, ?, 'completed', CURRENT_TIMESTAMP)
            ");
            $stmt->execute([
                $order_id,
                $payment_method_id,
                $total_amount,
                $currency,
                $payment_reference
            ]);

            // Log the transaction
            $stmt = $pdo->prepare("
                INSERT INTO transaction_logs (
                    user_id,
                    action,
                    order_id,
                    amount,
                    details,
                    created_at
                ) VALUES (?, 'sale_completed', ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $order_id,
                $total_amount,
                json_encode([
                    'invoice_number' => $invoice_number,
                    'payment_method' => $payment_method['method_name'],
                    'items_count' => count($order_items)
                ])
            ]);

            // Commit transaction
            $pdo->commit();

            // Clear cart session
            $_SESSION['cart'] = [];
            $_SESSION['customer_info'] = ['name' => '', 'phone' => '', 'address' => ''];
            $_SESSION['tax_rate'] = 0;
            $_SESSION['shipping'] = 0;

            // Return success response
            echo json_encode([
                'success' => true,
                'order_id' => $order_id,
                'invoice_number' => $invoice_number
            ]);

        } catch (Exception $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            echo json_encode([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
        exit;
    }
}

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity <= reorder_level AND stock_quantity > 0");
    $low_stock_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $low_stock_count = 0;
    error_log("Error fetching low stock count: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products");
    $total_products = $stmt->fetchColumn();
} catch (PDOException $e) {
    $total_products = 0;
    error_log("Error fetching total products: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM sale_items si JOIN sales s ON si.sale_id = s.sale_id WHERE s.sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND s.status = 'completed'");
    $today_sales_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $today_sales_count = 0;
    error_log("Error fetching today's sales count: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT COUNT(DISTINCT customer_id) FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND status = 'completed' AND customer_id IS NOT NULL");
    $today_customers_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $today_customers_count = 0;
    error_log("Error fetching today's customers count: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT DISTINCT c.category_name FROM categories c JOIN products p ON p.category_id = c.category_id");
    $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $categories = [];
    error_log("Error fetching categories: " . $e->getMessage());
}

// Fetch real notifications for navbar/modal
if (isset($_SESSION['user_id'])) {
    $notifications = getUserNotifications($pdo, $_SESSION['user_id']);
    $unread_count = getUnreadNotificationsCount($pdo, $_SESSION['user_id']);
} else {
    $notifications = [];
    $unread_count = 0;
}

$_SESSION['customer_info'] = $_SESSION['customer_info'] ?? ['name' => '', 'address' => '', 'phone' => ''];
$_SESSION['tax'] = $_SESSION['tax'] ?? 0;
$_SESSION['shipping'] = $_SESSION['shipping'] ?? 0;

$language_file = "../languages/{$language}.php";
$translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
$store_info = $_SESSION['store_info'] ?? '<i class="fas fa-envelope me-1"></i> bitstech2025@gmail.com <i class="fas fa-phone me-1"></i> +969123456789 <i class="fas fa-map-marker-alt me-1"></i> 123 Tech Lane, Yangon, Myanmar';

// Clear old session data and get fresh from database
unset($_SESSION['system_name']);

// Get system name from database immediately
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_name'");
    $stmt->execute();
    $db_site_name = $stmt->fetchColumn();

    // Update session with database value
    if ($db_site_name) {
        $_SESSION['system_name'] = $db_site_name;
        error_log("POS.php: Updated system_name to: " . $db_site_name);
    } else {
        error_log("POS.php: No site_name found in database");
    }
} catch (PDOException $e) {
    error_log("POS.php: Error fetching site_name: " . $e->getMessage());
}

// Default values for navbar (let navbar.php handle system_name from database)
$logo_path = $_SESSION['logo_path'] ?? '../public/images/logo.png';
// $system_name will be handled by navbar.php from database
$current_page = 'pos';
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title data-translate="title"><?php echo htmlspecialchars($translations['title'] ?? 'Computer Store POS - Home'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <style>
        .loading-spinner { display: none; text-align: center; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #007bff; border-radius: 50%; width: 20px; height: 20px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        /* Add validation animation styles */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }

        .input-error {
            animation: shake 0.5s ease-in-out;
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
            background-color: rgba(220, 53, 69, 0.1) !important;
            width: 300px !important;
            box-sizing: border-box !important;
        }

        .form-control:focus {
            transition: all 0.3s ease;
        }

        .form-label.required::after {
            content: '*';
            color: #dc3545;
            margin-left: 4px;
        }

        .payment-methods {
            background: #1E1E2D;
            border-radius: 12px;
            padding: 20px;
            margin-top: 20px;
            width: 100%;
            max-width: 100%;
        }

        .payment-row {
            display: flex;
            gap: 15px;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .payment-row-center {
            justify-content: center;
            gap: 15px;
        }

        .payment-method-card {
            background: #2B2B40;
            border-radius: 12px;
            padding: 12px;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            border: 2px solid transparent;
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .payment-method-card::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 15px;
            padding: 2px;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            opacity: 0;
            transition: opacity 0.4s ease;
        }

        .payment-method-card:hover::before {
            opacity: 1;
        }

        .payment-method-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .payment-method-card.selected {
            background: linear-gradient(145deg, #2B2B40, #1b1b29);
            border-color: #3699FF;
            box-shadow: 0 0 15px rgba(54, 153, 255, 0.2);
        }

        .payment-method-input {
            display: none;
        }

        .payment-method-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            margin: 0;
            color: #ffffff;
            cursor: pointer;
            width: 100%;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .payment-icon {
            width: 28px;
            height: 28px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.4s ease;
            position: relative;
        }

        .payment-icon::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 6px;
            background: inherit;
            filter: blur(5px);
            opacity: 0;
            transition: opacity 0.4s ease;
            z-index: -1;
        }

        .payment-icon i {
            font-size: 14px;
            color: white;
            transition: transform 0.4s ease;
        }

        .payment-method-card:hover .payment-icon i {
            transform: scale(1.1);
        }

        .payment-method-label span {
            font-size: 0.75rem;
            font-weight: 500;
            color: #a2a3b7;
            transition: all 0.4s ease;
            position: absolute;
            bottom: -16px;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
        }

        .payment-method-card:hover .payment-method-label span {
            color: #ffffff;
        }

        /* Custom gradients for payment icons */
        .payment-method-card[data-method="CASH"] .payment-icon {
            background: linear-gradient(135deg, #2ecc71, #27ae60);
        }

        .payment-method-card[data-method="KBZPAY"] .payment-icon {
            background: linear-gradient(135deg, #3498db, #2980b9);
        }

        .payment-method-card[data-method="WAVEPAY"] .payment-icon {
            background: linear-gradient(135deg, #00bcd4, #0097a7);
        }

        .payment-method-card[data-method="CARD"] .payment-icon {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
        }

        .payment-method-card[data-method="BANK"] .payment-icon {
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
        }

        .payment-method-card.selected .payment-icon {
            transform: scale(1.1);
        }

        #payment_reference_container {
            background: #1E1E2D;
            border-radius: 12px;
            padding: 20px;
            margin-top: 25px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        #payment_reference {
            background: #2B2B40;
            border: 1px solid #3F4254;
            color: #ffffff;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        #payment_reference:focus {
            border-color: #3699FF;
            box-shadow: 0 0 0 2px rgba(54, 153, 255, 0.25);
        }

        #payment_reference::placeholder {
            color: #565674;
        }

        .table {
            font-size: 0.7rem;
            margin-bottom: 0;
        }

        .table > :not(caption) > * > * {
            padding: 0.3rem 0.4rem;
        }

        .table th {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: #a2a3b7;
            background-color: #1E1E2D;
            border-bottom: 1px solid #2B2B40;
            padding: 0.3rem;
        }

        .table td {
            font-size: 0.7rem;
            color: #ffffff;
            border-color: #2B2B40;
            vertical-align: middle;
            padding: 0.3rem;
        }

        /* Light Mode Table Text Colors for POS Page */
        [data-theme="light"] .table,
        [data-theme="light"] .table td {
            color: #ffffff !important;
        }

        [data-theme="light"] .table th {
            color: #212529 !important;
        }

        [data-theme="light"] .table tbody tr:hover td {
            color: #ffffff !important;
        }

        [data-theme="light"] .order-summary .summary-row label,
        [data-theme="light"] .order-summary .summary-row span {
            color: #ffffff !important;
        }

        [data-theme="light"] .order-summary .summary-row .input-group input {
            color: #ffffff !important;
        }

        [data-theme="light"] .order-summary .total-row label,
        [data-theme="light"] .order-summary .total-row span {
            color: #ffffff !important;
        }

        /* Light Mode H1 and Headers Text Colors for POS Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }

        /* Light Mode Order Details and Enter Customer Details Text Colors */
        [data-theme="light"] .order-details h5[data-translate="order_details"],
        [data-theme="light"] .order-details h6[data-translate="enter_customer_details"] {
            color: #000000 !important;
        }

        /* Light Mode Tax and Shipping Input Box Data Colors */
        [data-theme="light"] #tax-input,
        [data-theme="light"] #shipping-input {
            color: #000000 !important;
        }

        /* Light Mode All Products Text Color */
        [data-theme="light"] .products-count {
            color: #ffffff !important;
        }

        /* Light Mode All Products Span Text Color */
        [data-theme="light"] .products-count span[data-translate="all_products"] {
            color: #ffffff !important;
        }

        /* Light Mode Current Order Text Color and Bold */
        [data-theme="light"] h6[data-translate="current_order"] {
            color: #000000 !important;
            font-weight: bold !important;
        }

        /* Dark Mode Current Order Bold */
        [data-theme="dark"] h6[data-translate="current_order"],
        h6[data-translate="current_order"] {
            font-weight: bold !important;
        }

        .btn-action {
            padding: 0.2rem 0.35rem;
            font-size: 0.65rem;
            line-height: 1;
            border-radius: 0.2rem;
            background: transparent;
            border: none;
        }

        .btn-action i {
            font-size: 0.75rem;
            color: #dc3545;
            transition: color 0.3s ease;
        }

        .btn-action:hover i {
            color: #ff4d5f;
        }

        #cart-table {
            border-radius: 6px;
            overflow: hidden;
            border: 1px solid #2B2B40;
        }

        #cart-table tbody tr:hover {
            background-color: rgba(43, 43, 64, 0.5);
        }

        .quantity {
            font-weight: 500;
            color: #3699FF;
            font-size: 0.7rem;
        }

        .custom-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 8px 15px;
            border-radius: 4px;
            font-size: 0.75rem;
            max-width: 250px;
            background: rgba(25, 135, 84, 0.95);
            color: white;
            box-shadow: 0 2px 12px rgba(0,0,0,0.15);
            transform: translateX(150%);
            transition: transform 0.3s ease-in-out;
        }

        .custom-alert.show {
            transform: translateX(0);
        }

        .custom-alert i {
            margin-right: 5px;
            font-size: 0.8rem;
        }

        .product-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 8px 0;
            width: 100%;
        }

        .price-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .original-price {
            font-size: 0.85rem;
            color: #6e7191;
            text-decoration: line-through;
            margin-bottom: 2px;
        }

        .final-price {
            font-size: 1.1rem;
            font-weight: 600;
            color: #3699FF;
        }

        .price {
            font-size: 1.1rem;
            font-weight: 600;
            color: #3699FF;
            margin-right: auto;
        }

        .discount {
            background: #ff4d4f;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
            margin-left: 8px;
        }

        .stock-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 8px;
            font-size: 0.85rem;
            color: #a2a3b7;
        }

        .stock-info span:first-child {
            color: #28a745;
            font-weight: 500;
        }

        .quantity {
            font-weight: 600;
            color: #3699FF;
        }

        .product-card {
            background: #2B2B40;
            border-radius: 8px;
            padding: 6px;
            position: relative;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
            min-height: 135px;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-color: rgba(54, 153, 255, 0.3);
        }

        .product-image {
            width: 100%;
            height: 70px;
            overflow: hidden;
            border-radius: 6px;
            margin-bottom: 5px;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-info h5 {
            font-size: 0.8rem;
            margin: 0 0 4px 0;
            color: #ffffff;
            font-weight: 500;
            line-height: 1.1;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            transform: translateX(120%);
            transition: transform 0.3s ease;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .notification.show {
            transform: translateX(0);
        }

        .notification.success {
            background: linear-gradient(145deg, #28a745, #218838);
        }

        .notification.error {
            background: linear-gradient(145deg, #dc3545, #c82333);
        }

        .cart-item {
            transition: all 0.3s ease;
        }

        .cart-item:hover {
            background: rgba(54, 153, 255, 0.1);
        }

        .btn-quantity {
            width: 28px;
            height: 28px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
            transition: all 0.2s ease;
        }

        .btn-quantity:hover:not(:disabled) {
            background: rgba(54, 153, 255, 0.2);
            transform: translateY(-1px);
        }

        .btn-quantity:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Add these styles */
        #payment_validation_message {
            background-color: rgba(255, 193, 7, 0.1);
            border: 1px solid rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }

        /* Add these styles */
        .custom-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            transform: translateX(120%);
            transition: transform 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            min-width: 300px;
            margin-bottom: 10px;
        }

        .custom-alert.success {
            background: linear-gradient(145deg, #28a745, #218838);
            border-left: 5px solid #1e7e34;
        }

        .custom-alert.error {
            background: linear-gradient(145deg, #dc3545, #c82333);
            border-left: 5px solid #bd2130;
        }

        .custom-alert.show {
            transform: translateX(0);
        }

        .custom-alert i {
            margin-right: 8px;
            font-size: 1.1rem;
        }

        /* Stack multiple alerts */
        .custom-alert + .custom-alert {
            margin-top: 60px;
        }

        #payment_validation_message {
            background: rgba(255, 193, 7, 0.1);
            border: 1px solid rgba(255, 193, 7, 0.2);
            color: #ffc107;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            font-size: 0.9rem;
        }

        #payment_validation_message i {
            margin-right: 8px;
            font-size: 1.1rem;
        }

        .payment-method-card.selected {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(54, 153, 255, 0.3);
        }

        #qr_code_container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        #qr_code_container img {
            max-width: 200px;
            margin: 0 auto;
        }

        .invalid-feedback {
            color: #dc3545;
            font-size: 0.875rem;
            margin-top: 5px;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right calc(0.375em + 0.1875rem) center;
            background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
            width: 300px !important;
            box-sizing: border-box !important;
        }

        .payment-success-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(40, 167, 69, 0.2);
            backdrop-filter: blur(3px);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
        }

        .success-animation {
            animation: successPop 0.5s ease-out;
        }

        .success-animation i {
            font-size: 48px;
            color: #28a745;
            text-shadow: 0 0 20px rgba(40, 167, 69, 0.5);
        }

        @keyframes successPop {
            0% {
                transform: scale(0.5);
                opacity: 0;
            }
            50% {
                transform: scale(1.2);
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        #payment_validation_message.alert-success {
            background: rgba(40, 167, 69, 0.1);
            border-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }

        #verify_payment:disabled {
            cursor: not-allowed;
            opacity: 0.7;
        }

        .payment-method-card.selected {
            border-color: #28a745;
        }

        .payment-method-card.selected .payment-icon {
            transform: scale(1.1);
        }

        /* QR Code Modal Styles */
        .qr-payment-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .qr-payment-modal.show {
            opacity: 1;
        }

        .qr-payment-content {
            background: #1E1E2D;
            padding: 20px;
            border-radius: 12px;
            width: 90%;
            max-width: 320px;
            text-align: center;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.3);
            transform: scale(0.8);
            opacity: 0;
            transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .qr-payment-modal.show .qr-payment-content {
            transform: scale(1);
            opacity: 1;
        }

        .qr-payment-close {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            color: #ffffff;
            font-size: 20px;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.3s;
        }

        .qr-payment-close:hover {
            opacity: 1;
        }

        .qr-code-container {
            background: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin: 15px auto;
            width: fit-content;
            box-shadow: 0 4px 15px rgba(0, 37, 84, 0.1);
        }

        .qr-code-container img {
            max-width: 150px;
            height: auto;
        }

        .qr-amount {
            color: #00267A;
            font-size: 20px;
            font-weight: bold;
            margin: 12px 0;
        }

        .qr-payment-reference {
            margin-top: 15px;
            text-align: left;
        }

        .qr-payment-reference label {
            color: #ffffff;
            display: block;
            margin-bottom: 6px;
            font-size: 0.9rem;
        }

        .qr-payment-reference input {
            width: 100%;
            padding: 10px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            background: #2B2B40;
            color: #ffffff;
            margin-bottom: 6px;
            transition: all 0.3s ease;
        }

        .qr-payment-reference input:focus {
            border-color: #00267A;
            box-shadow: 0 0 0 2px rgba(0, 38, 122, 0.2);
            outline: none;
        }

        .qr-payment-reference .form-text {
            color: #a2a3b7;
            font-size: 11px;
        }

        .verify-payment-btn {
            background: linear-gradient(145deg, #00267A, #0047CC);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            margin-top: 15px;
            transition: all 0.3s;
            font-size: 0.9rem;
        }

        .verify-payment-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 38, 122, 0.3);
        }

        .verify-payment-btn i {
            margin-right: 6px;
        }
    </style>
</head>
<body>
    <!-- Add QR Payment Modal -->
    <div class="qr-payment-modal" id="qrPaymentModal">
        <div class="qr-payment-content">
            <button class="qr-payment-close">&times;</button>
            <h5 class="text-white mb-2">KBZ Pay QR Payment</h5>
            <div class="qr-code-container">
                <img id="qrCodeImage" src="" alt="QR Code">
            </div>
            <div class="text-white mb-1" style="font-size: 0.9rem;">Total Amount:</div>
            <div class="qr-amount" id="qrAmount">MMK 0.00</div>
            <div class="text-muted mb-3" style="font-size: 0.8rem;">Scan with KBZ Pay to complete payment</div>

            <div class="qr-payment-reference">
                <label for="qrPaymentReference">Verification Password</label>
                <input type="text" id="qrPaymentReference" class="form-control"
                       placeholder="Enter verification password">
            </div>

            <button class="verify-payment-btn" id="verifyQrPayment">
                <i class="fas fa-check-circle"></i>Verify Payment
            </button>
        </div>
    </div>

    <?php include '../includes/navbar.php'; ?>

    <!-- Notification Modal -->
    <div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notificationModalLabel" data-translate="notifications"><?php echo htmlspecialchars($translations['notifications'] ?? 'Notifications'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="notificationBody">
                    <?php if (!empty($notifications)): ?>
                        <?php foreach ($notifications as $notification): ?>
                            <p class="mb-1">
                                <?php echo htmlspecialchars($notification['message']); ?><br>
                                <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?></small>
                            </p>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted"><?php echo htmlspecialchars($translations['no_notifications'] ?? 'No notifications'); ?></p>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    <div class="calculator-overlay" id="calculator-overlay">
        <div class="calculator">
            <div class="calculator-display" id="display">0</div>
            <div class="calculator-keys">
                <button class="clear">C</button>
                <button class="operator">(</button>
                <button class="operator">)</button>
                <button class="operator">/</button>
                <button>7</button>
                <button>8</button>
                <button>9</button>
                <button class="operator">x</button>
                <button>4</button>
                <button>5</button>
                <button>6</button>
                <button class="operator">-</button>
                <button>1</button>
                <button>2</button>
                <button>3</button>
                <button class="operator">+</button>
                <button>0</button>
                <button>.</button>
                <button class="equal">=</button>
            </div>
        </div>
    </div>

    <div class="page-content-wrapper">
        <div class="layout-container">
            <div class="main-content">
                <div class="container">
                    <div class="stats-header">
                        <div class="stat-item">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span data-translate="low_stock_items"><?php echo htmlspecialchars($translations['low_stock_items'] ?? 'Low Stock Items'); ?></span>: <?php echo $low_stock_count; ?>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-shopping-cart"></i>
                            <span data-translate="todays_sales_items"><?php echo htmlspecialchars($translations['todays_sales_items'] ?? "Today's Sales Items"); ?></span>: <?php echo $today_sales_count; ?>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-users"></i>
                            <span data-translate="todays_customers"><?php echo htmlspecialchars($translations['todays_customers'] ?? "Today's Customers"); ?></span>: <?php echo $today_customers_count; ?>
                        </div>
                    </div>

                    <div class="search-header-section d-flex align-items-center gap-3 mb-3 p-3" style="background-color: #22243A; border-radius: 10px; margin: -15px -15px 20px -15px;">
                        <div class="products-count flex-shrink-0" style="color: #ffffff; font-weight: 500;">
                            <span data-translate="all_products"><?php echo htmlspecialchars($translations['all_products'] ?? 'All Products'); ?></span> (<?php echo $total_products; ?>)
                        </div>
                        <div class="search-bar d-flex gap-2 flex-grow-1">
                            <select id="category_filter" class="form-select" style="max-width: 200px; background-color: #2D314D; border: 1px solid #404463; color: #E5E7EB;">
                                <option value="" data-translate="all_categories" style="background-color: #2D314D; color: #E5E7EB;"><?php echo htmlspecialchars($translations['all_categories'] ?? 'All Categories'); ?></option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo htmlspecialchars($category); ?>" style="background-color: #2D314D; color: #E5E7EB;"><?php echo htmlspecialchars($category); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" id="search_input" class="form-control flex-grow-1" placeholder="<?php echo htmlspecialchars($translations['search_by_id_name'] ?? 'Search by ID or Name...'); ?>" data-translate-placeholder="search_by_id_name" style="background-color: #2D314D; border: 1px solid #404463; color: #E5E7EB;">
                        </div>
                    </div>

                    <div class="products-section">
                        <h3 data-translate="products_section"><?php echo htmlspecialchars($translations['products_section'] ?? 'BitsTech All Products'); ?></h3>
                        <div class="product-slider" style="max-height: 970px;">
                            <div class="product-grid" id="product_grid">
                                <!-- Products will be loaded dynamically via AJAX -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="right-sidebar">
                <div class="order-details">
                    <h5 data-translate="order_details"><?php echo htmlspecialchars($translations['order_details'] ?? 'Order Details'); ?></h5>

                    <h6 data-translate="enter_customer_details"><?php echo htmlspecialchars($translations['enter_customer_details'] ?? 'Enter Customer Details'); ?></h6>
                    <?php if (isset($validation_error) && $validation_error): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <span data-translate="validation_error"><?php echo htmlspecialchars($translations['validation_error'] ?? 'Please fill in all customer details before proceeding.'); ?></span>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="customer-details">
                        <div class="form-group mb-3">
                            <label for="customer_name" class="form-label required">Customer Name</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo htmlspecialchars($_SESSION['customer_info']['name']); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="phone" class="form-label required">Phone No</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($_SESSION['customer_info']['phone']); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($_SESSION['customer_info']['address']); ?>">
                        </div>
                        <div class="d-flex gap-2 mt-2">
                            <button class="btn btn-update w-50 update-customer"><i class="fas fa-save"></i> <span data-translate="update"><?php echo htmlspecialchars($translations['update'] ?? 'Update'); ?></span></button>
                            <button class="btn btn-clear w-50 clear-customer"><i class="fas fa-eraser"></i> <span data-translate="clear"><?php echo htmlspecialchars($translations['clear'] ?? 'Clear'); ?></span></button>
                        </div>
                    </div>

                    <h6 data-translate="customer_information"><?php echo htmlspecialchars($translations['customer_information'] ?? 'Customer Information'); ?></h6>
                    <div class="customer-info" id="customer-info-display">
                        <?php if (!empty($_SESSION['customer_info']['name']) || !empty($_SESSION['customer_info']['address']) || !empty($_SESSION['customer_info']['phone'])): ?>
                            <?php if ($_SESSION['customer_info']['name']): ?>
                                <p><i class="fas fa-user me-2"></i><strong data-translate="name"><?php echo htmlspecialchars($translations['name'] ?? 'Name'); ?>:</strong> <span id="display-customer-name"><?php echo htmlspecialchars($_SESSION['customer_info']['name']); ?></span></p>
                            <?php endif; ?>
                            <?php if ($_SESSION['customer_info']['address']): ?>
                                <p><i class="fas fa-map-marker-alt me-2"></i><strong data-translate="address"><?php echo htmlspecialchars($translations['address'] ?? 'Address'); ?>:</strong> <span id="display-address"><?php echo htmlspecialchars($_SESSION['customer_info']['address']); ?></span></p>
                            <?php endif; ?>
                            <?php if ($_SESSION['customer_info']['phone']): ?>
                                <p><i class="fas fa-phone me-2"></i><strong data-translate="phone"><?php echo htmlspecialchars($translations['phone'] ?? 'Phone'); ?>:</strong> <span id="display-phone"><?php echo htmlspecialchars($_SESSION['customer_info']['phone']); ?></span></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p data-translate="no_customer_info"><?php echo htmlspecialchars($translations['no_customer_info'] ?? 'No customer information available.'); ?></p>
                        <?php endif; ?>
                    </div>

                    <h6 data-translate="current_order"><?php echo htmlspecialchars($translations['current_order'] ?? 'Current Order'); ?></h6>
                    <div class="loading-spinner"><div class="spinner"></div></div>
                    <div class="table-responsive">
                        <table class="table table-dark table-hover" id="cart-table">
                        <thead>
                            <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Quantity</th>
                                    <th>Discount</th>
                                    <th>Total</th>
                                    <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                                <!-- Cart items will be dynamically added here -->
                        </tbody>
                    </table>
                    </div>

                    <div class="order-summary">
                        <form id="tax-shipping-form">
                            <div class="summary-row">
                                <label data-translate="subtotal"><?php echo htmlspecialchars($translations['subtotal'] ?? 'Subtotal'); ?></label>
                                <span id="subtotal-amount">0.00</span>
                            </div>
                            <div class="summary-row">
                                <label data-translate="tax"><?php echo htmlspecialchars($translations['tax'] ?? 'Tax'); ?></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                                    <input type="number" name="tax" id="tax-input" value="<?php echo htmlspecialchars($_SESSION['tax'] / $exchange_rates[$currency]); ?>" step="0.01" class="form-control" oninput="updateSummary()">
                                </div>
                            </div>
                            <div class="summary-row">
                                <label data-translate="discount"><?php echo htmlspecialchars($translations['discount'] ?? 'Discount'); ?></label>
                                <span id="discount-amount">0.00</span>
                            </div>
                            <div class="summary-row">
                                <label data-translate="shipping"><?php echo htmlspecialchars($translations['shipping'] ?? 'Shipping'); ?></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-truck"></i></span>
                                    <input type="number" name="shipping" id="shipping-input" value="<?php echo htmlspecialchars($_SESSION['shipping'] / $exchange_rates[$currency]); ?>" step="0.01" class="form-control" oninput="updateSummary()">
                                </div>
                            </div>
                            <hr>
                            <div class="summary-row total">
                                <label data-translate="totals"><?php echo htmlspecialchars($translations['totals'] ?? 'Totals'); ?></label>
                                <span id="total-amount">0.00</span>
                            </div>
                        </form>
                    </div>

                    <!-- Payment Methods -->
                    <div class="payment-methods mt-4">
                        <h6 class="text-white mb-3">Payment Method</h6>
                        <!-- First row with 3 payment methods -->
                        <div class="payment-row mb-3">
                            <div class="payment-method-card" data-method="CASH">
                                <input type="radio" name="payment_method" id="payment_cash" value="CASH" class="payment-method-input" checked>
                                <label for="payment_cash" class="payment-method-label">
                                    <div class="payment-icon" style="background-color: #28a745;">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </div>
                                    <span>Cash</span>
                                </label>
                            </div>
                            <div class="payment-method-card" data-method="KBZPAY">
                                <input type="radio" name="payment_method" id="payment_kbzpay" value="KBZPAY" class="payment-method-input">
                                <label for="payment_kbzpay" class="payment-method-label">
                                    <div class="payment-icon" style="background-color: #1d4589;">
                                        <i class="fas fa-mobile-alt"></i>
                                    </div>
                                    <span>KBZ Pay</span>
                                </label>
                            </div>
                            <div class="payment-method-card" data-method="WAVEPAY">
                                <input type="radio" name="payment_method" id="payment_wavepay" value="WAVEPAY" class="payment-method-input">
                                <label for="payment_wavepay" class="payment-method-label">
                                    <div class="payment-icon" style="background-color: #2596be;">
                                        <i class="fas fa-mobile"></i>
                                    </div>
                                    <span>Wave Pay</span>
                                </label>
                            </div>
                        </div>
                        <!-- Second row with 2 payment methods centered -->
                        <div class="payment-row payment-row-center">
                            <div class="payment-method-card" data-method="CARD">
                                <input type="radio" name="payment_method" id="payment_card" value="CARD" class="payment-method-input">
                                <label for="payment_card" class="payment-method-label">
                                    <div class="payment-icon" style="background-color: #dc3545;">
                                        <i class="fas fa-credit-card"></i>
                                    </div>
                                    <span>Card</span>
                                </label>
                            </div>
                            <div class="payment-method-card" data-method="BANK">
                                <input type="radio" name="payment_method" id="payment_bank" value="BANK" class="payment-method-input">
                                <label for="payment_bank" class="payment-method-label">
                                    <div class="payment-icon" style="background-color: #6610f2;">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <span>Bank</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="action-buttons mt-3 d-flex gap-2">
                        <button class="btn btn-reset w-50 reset-all">
                            <i class="fas fa-sync-alt"></i>
                            <span data-translate="all_reset"><?php echo htmlspecialchars($translations['all_reset'] ?? 'All Reset'); ?></span>
                        </button>
                        <button class="btn btn-buy w-50 buy-now">
                            <i class="fas fa-money-bill-wave"></i>
                            <span data-translate="buy_now"><?php echo htmlspecialchars($translations['buy_now'] ?? 'Buy Now'); ?></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentCurrency = '<?php echo $currency; ?>';
        const exchangeRates = <?php echo json_encode($exchange_rates); ?>;
        const currencySymbols = <?php echo json_encode($currency_symbols); ?>;
        let translations = <?php echo json_encode($translations); ?>;

        $(document).ready(function() {
            console.log('POS page ready - initializing...');

            // Initialize theme manager
            if (typeof ThemeManager !== 'undefined') {
                window.themeManager = new ThemeManager();
                window.themeManager.init();
                console.log('🎨 POS: Theme manager initialized');
            }

            // Initialize tooltips
            const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
            const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

            // Handle details button click
            $(document).on('click', '.details-btn', function() {
                const productId = $(this).data('product-id');
                window.location.href = 'product_details.php?id=' + productId;
            });

            loadProducts();
            updateCartTable();
            updateSummary();
            updateUIText();

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 POS: Notification bell visibility updated');
            }

            // Check if product was just added from product details page
            const urlParams = new URLSearchParams(window.location.search);
            const addedProductId = urlParams.get('added');
            if (addedProductId) {
                // Show success notification
                setTimeout(() => {
                    if (window.showCartNotification) {
                        window.showCartNotification(addedProductId, 1);
                    }
                    // Highlight the product in cart if visible
                    highlightAddedProduct(addedProductId);
                }, 500);

                // Clean URL without refresh
                window.history.replaceState({}, document.title, window.location.pathname);
            }

            $('#search_input').on('input', loadProducts);
            $('#category_filter').on('change', loadProducts);

            $('#currency-select').on('change', function(e) {
                e.preventDefault();
                const newCurrency = $(this).val();
                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: { currency: newCurrency },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            currentCurrency = response.currency;
                            updateCurrencyUI();
                            loadProducts();
                            updateSummary(); // Update summary without refreshing table
                        } else {
                            showCustomAlert(translations['error_updating_currency'] || 'Error updating currency');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error updating currency: ' + error);
                    }
                });
            });

            $('.language-item').on('click', function(e) {
                e.preventDefault();
                const lang = $(this).data('lang');
                updateLanguage(lang);
            });

            function updateLanguage(lang) {
                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: { language: lang },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            translations = response.translations;
                            updateUIText();
                            $('#languageDropdown .language-label').text(lang === 'en' ? (translations['lang_en'] || 'EN') : (translations['lang_mm'] || 'MY'));
                        } else {
                            showCustomAlert(translations['error_updating_language'] || 'Error updating language');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error updating language: ' + error);
                    }
                });
            }

            function updateUIText() {
                $('[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });
                $('[data-translate-placeholder]').each(function() {
                    const key = $(this).data('translate-placeholder');
                    if (translations[key]) {
                        $(this).attr('placeholder', translations[key]);
                    }
                });
                $('#currency-select option').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });
            }

            function updateCurrencyUI() {
                $('#currency-select').val(currentCurrency);
                const tax = parseFloat($('#tax-input').val()) || 0;
                const shipping = parseFloat($('#shipping-input').val()) || 0;
                $('#tax-input').val((tax * exchangeRates[currentCurrency] / exchangeRates[currentCurrency]).toFixed(2));
                $('#shipping-input').val((shipping * exchangeRates[currentCurrency] / exchangeRates[currentCurrency]).toFixed(2));
                updateSummary();
            }

            function loadProducts() {
                const searchQuery = $('#search_input').val();
                const category = $('#category_filter').val();
                $.ajax({
                    url: 'fetch_products.php',
                    type: 'GET',
                    data: { search: searchQuery, category: category },
                    success: function(response) {
                        $('#product_grid').html(response);
                        attachProductEventListeners();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading products:', error);
                        $('#product_grid').html('<p>' + (translations['error_loading_products'] || 'Error loading products. Please try again.') + '</p>');
                    }
                });
            }

            function attachProductEventListeners() {
                $('.add-to-cart').off('click').on('click', function(e) {
                    e.preventDefault();
                    const $btn = $(this);
                    const productId = $btn.data('product-id');
                    const action = $btn.data('action');
                    const stock = parseInt($btn.data('stock'));

                    if (stock > 0) {
                        updateProductStock(productId, 'decrease');
                        $.ajax({
                            url: 'pos.php',
                            type: 'POST',
                            data: { action: action, product_id: productId },
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    updateCartTable();
                                    updateProductUI(productId, response.stock, response.sold);
                                }
                            }
                        });
                    }
                });
            }

            function updateProductStock(productId, action) {
                const $stockNumber = $(`#stock-count-${productId} .stock-number`);
                const $soldNumber = $(`#sold-count-${productId} .sold-number`);
                const $addButton = $(`#add-to-cart-${productId}`);
                const $stockStatus = $(`#stock-status-${productId}`);

                let currentStock = parseInt($stockNumber.text());
                let currentSold = parseInt($soldNumber.text());

                if (action === 'decrease' && currentStock > 0) {
                    currentStock--;
                    currentSold++;
                } else if (action === 'increase') {
                    currentStock++;
                    currentSold--;
                }

                // Update stock number with fade animation
                $stockNumber.fadeOut(100, function() {
                    $(this).text(currentStock).fadeIn(100);
                });

                // Update sold number with fade animation
                $soldNumber.fadeOut(100, function() {
                    $(this).text(currentSold).fadeIn(100);
                });

                // Update stock status and button state
                if (currentStock <= 0) {
                    $stockStatus.removeClass('in-stock').addClass('out-of-stock');
                    $stockStatus.find('.status-text').text('Out of Stock');
                    $stockStatus.find('i').removeClass('fa-check-circle').addClass('fa-times-circle');
                    $addButton.addClass('disabled').prop('disabled', true);
                    } else {
                    $stockStatus.removeClass('out-of-stock').addClass('in-stock');
                    $stockStatus.find('.status-text').text('In Stock');
                    $stockStatus.find('i').removeClass('fa-times-circle').addClass('fa-check-circle');
                    $addButton.removeClass('disabled').prop('disabled', false);
                }

                // Update button data-stock attribute
                $addButton.data('stock', currentStock);
            }

            function updateProductUI(productId, stock, sold) {
                const $productCard = $(`#add-to-cart-${productId}`).closest('.product-card');

                if ($productCard.length) {
                    // Update stock count
                    const $stockNumber = $(`#stock-count-${productId} .stock-number`);
                    if ($stockNumber.length) {
                        $stockNumber.fadeOut(100, function() {
                            $(this).text(stock).fadeIn(100);
                        });
                    }

                    // Update sold count
                    const $soldNumber = $(`#sold-count-${productId} .sold-number`);
                    if ($soldNumber.length) {
                        $soldNumber.fadeOut(100, function() {
                            $(this).text(sold).fadeIn(100);
                        });
                    }

                    // Update stock status and button state
                    const $stockStatus = $(`#stock-status-${productId}`);
                    const $addButton = $(`#add-to-cart-${productId}`);

                    if (stock <= 0) {
                        $stockStatus.removeClass('in-stock').addClass('out-of-stock');
                        $stockStatus.find('.status-text').text('Out of Stock');
                        $stockStatus.find('i').removeClass('fa-check-circle').addClass('fa-times-circle');
                        $addButton.addClass('disabled').prop('disabled', true);
                    } else {
                        $stockStatus.removeClass('out-of-stock').addClass('in-stock');
                        $stockStatus.find('.status-text').text('In Stock');
                        $stockStatus.find('i').removeClass('fa-times-circle').addClass('fa-check-circle');
                        $addButton.removeClass('disabled').prop('disabled', false);
                    }

                    // Subtle highlight animation
                    $productCard.css({
                        'transform': 'scale(1.02)',
                        'transition': 'transform 0.2s ease'
                    });

                    setTimeout(() => {
                        $productCard.css('transform', 'scale(1)');
                    }, 200);
                }
            }

            $('.remove-from-cart').on('click', function(e) {
                e.preventDefault();
                const productId = $(this).data('product-id');
                const action = $(this).data('action');
                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: { action: action, product_id: productId },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            updateCartTable();
                        } else {
                            showCustomAlert(translations['error_removing_cart'] || 'Error removing from cart');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error removing from cart: ' + error);
                    }
                });
            });

            // Initially hide payment methods section
            $('.payment-methods').hide();

            // Customer info update handler
            $('.update-customer').on('click', function(e) {
                e.preventDefault();
                const customerName = $('#customer_name').val().trim();
                const phone = $('#phone').val().trim();
                const address = $('#address').val().trim();

                if (!customerName || !phone) {
                    showCustomAlert('Please fill in required customer details', 'error');
                    return;
                }

                $.ajax({
                    url: 'customer_ajax.php',
                    type: 'POST',
                    data: { update_customer: 1, customer_name: customerName, address: address, phone: phone },
                    dataType: 'json',
                    success: function(data) {
                        if (data.success) {
                            updateCustomerInfo(customerName, address, phone);
                            showCustomAlert('Customer info updated successfully');
                            // Show payment methods after customer info is updated
                            $('.payment-methods').fadeIn();
                        } else {
                            showCustomAlert('Failed to update customer info', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error updating customer info', 'error');
                    }
                });
            });

            // Clear customer info handler
            $('.clear-customer').on('click', function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'customer_ajax.php',
                    type: 'POST',
                    data: { clear_customer: 1 },
                    dataType: 'json',
                    success: function(data) {
                        if (data.success) {
                            $('#customer_name').val('');
                            $('#address').val('');
                            $('#phone').val('');
                            updateCustomerInfo('', '', '');
                            // Hide payment methods when customer info is cleared
                            $('.payment-methods').fadeOut();
                            showCustomAlert('Customer info cleared successfully');
                        } else {
                            showCustomAlert('Error: ' + (data.error || translations['customer_clear_failed'] || 'Failed to clear customer'), 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error clearing customer info', 'error');
                    }
                });
            });

            // Buy Now button click handler
            $('.buy-now').off('click').on('click', function(e) {
                e.preventDefault();

                // Check if cart is empty
                if ($('#cart-table tbody tr').length === 0 || $('#cart-table tbody tr:first').find('td').length === 1) {
                    showCustomAlert('Cart is empty. Please add items before checkout.', 'error');
                    return;
                }

                // Validate customer info
                const customerName = $('#customer_name').val().trim();
                const phone = $('#phone').val().trim();

                if (!customerName || !phone) {
                    showCustomAlert('Please fill in customer details first', 'error');
                    // Scroll to customer info section
                    $('html, body').animate({
                        scrollTop: $('.customer-details').offset().top - 100
                    }, 500);
                    return;
                }

                const paymentMethod = $('input[name="payment_method"]:checked').val();
                if (!paymentMethod) {
                    showCustomAlert('Please select a payment method', 'error');
                    return;
                }

                if (paymentMethod === 'KBZPAY') {
                    showQRPaymentModal();
                    return;
                }

                processBuyNow();
            });

            // Payment method selection handler
            $('.payment-method-card').on('click', function() {
                const method = $(this).data('method');

                // Update radio button and UI
                $(this).find('input[type="radio"]').prop('checked', true);
                $('.payment-method-card').removeClass('selected');
                $(this).addClass('selected');
            });

            // Validation function
            function validateForm() {
                let isValid = true;
                const customerName = $('#customer_name').val().trim();
                const phone = $('#phone').val().trim();
                const paymentMethod = $('input[name="payment_method"]:checked').val();
                const paymentReference = $('#payment_reference').val().trim();

                // Reset previous validation states
                $('.form-control').removeClass('input-error is-invalid');
                $('.invalid-feedback').hide();

                // Validate customer name
                if (!customerName) {
                    $('#customer_name')
                        .addClass('input-error is-invalid')
                        .siblings('.invalid-feedback').show();
                    isValid = false;
                }

                // Validate phone
                if (!phone) {
                    $('#phone')
                        .addClass('input-error is-invalid')
                        .siblings('.invalid-feedback').show();
                    isValid = false;
                }

                // Validate payment reference for non-cash payments
                if (paymentMethod !== 'CASH' && !paymentReference) {
                    $('#payment_reference')
                        .addClass('input-error is-invalid')
                        .siblings('.invalid-feedback').show();
                    isValid = false;
                }

                return isValid;
            }

            // Function to show QR Payment Modal
            function showQRPaymentModal() {
                const totalAmount = $('#total-amount').text();
                const orderData = {
                    amount: totalAmount,
                    timestamp: Date.now(),
                    merchant: 'YOUR_MERCHANT_ID'
                };

                // Generate QR code URL
                const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' +
                    encodeURIComponent(JSON.stringify(orderData));

                // Update QR code and amount in modal
                $('#qrCodeImage').attr('src', qrUrl);
                $('#qrAmount').text(totalAmount);

                // Reset verification password field
                $('#qrPaymentReference').val('');

                // Show modal with animation
                const $modal = $('#qrPaymentModal');
                $modal.css('display', 'flex');
                setTimeout(() => {
                    $modal.addClass('show');
                }, 10);
            }

            // Function to process normal buy now
            function processBuyNow() {
                // Your existing buy now process code
                const customerName = $('#customer_name').val().trim();
                const phone = $('#phone').val().trim();
                const address = $('#address').val().trim();
                const paymentMethod = $('input[name="payment_method"]:checked').val();

                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: {
                        action: 'checkout',
                        payment_method_id: getPaymentMethodId(paymentMethod),
                        customer_name: customerName,
                        phone: phone,
                        address: address,
                        tax: parseFloat($('#tax-input').val()) * exchangeRates[currentCurrency],
                        shipping: parseFloat($('#shipping-input').val()) * exchangeRates[currentCurrency]
                    },
                    success: function(response) {
                        if (response.success) {
                            showCustomAlert('Order completed successfully!', 'success');
                            setTimeout(() => {
                                window.location.href = 'invoice.php?order_id=' + response.order_id;
                            }, 1500);
                        } else {
                            showCustomAlert(response.error || 'Error processing checkout', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Error processing checkout: ' + error, 'error');
                    }
                });
            }

            // Custom alert function with improved visibility
            function showCustomAlert(message, type = 'success') {
                // Remove any existing alerts
                $('.custom-alert').remove();

                const alertDiv = $('<div>').addClass('custom-alert ' + type);
                const icon = type === 'success' ? 'check-circle' : 'exclamation-circle';

                alertDiv.html(`<i class="fas fa-${icon}"></i>${message}`);

                $('body').append(alertDiv);

                setTimeout(() => alertDiv.addClass('show'), 100);
                setTimeout(() => {
                    alertDiv.removeClass('show');
                    setTimeout(() => alertDiv.remove(), 300);
                }, 3000);
            }

            // Unified payment verification handler
            function verifyPayment(reference, method, amount, onSuccess) {
                if (!reference) {
                    showCustomAlert('Please enter the transaction reference number', 'error');
                    return false;
                }

                // Show loading state
                const $button = $(this);
                const originalText = $button.html();
                $button.html('<i class="fas fa-spinner fa-spin me-1"></i> Verifying...').prop('disabled', true);

                // Verify payment using verify_payment.php
                $.ajax({
                    url: 'verify_payment.php',
                    type: 'POST',
                    data: { reference, method, amount },
                    success: function(response) {
                        if (response.success) {
                            showCustomAlert('Payment verified successfully!', 'success');
                            if (typeof onSuccess === 'function') {
                                onSuccess(reference);
                            }
                        } else {
                            showCustomAlert(response.error || 'Invalid verification password', 'error');
                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON || {};
                        showCustomAlert(response.error || 'Error verifying payment', 'error');
                    },
                    complete: function() {
                        $button.html(originalText).prop('disabled', false);
                    }
                });

                return true;
            }

            // Function to process verified payment
            function processVerifiedPayment(reference) {
                const customerName = $('#customer_name').val().trim();
                const phone = $('#phone').val().trim();
                const address = $('#address').val().trim();
                const tax = parseFloat($('#tax-input').val() || 0);
                const shipping = parseFloat($('#shipping-input').val() || 0);

                // Show loading state
                showCustomAlert('Processing payment...', 'info');

                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: {
                        action: 'checkout',
                        payment_method_id: 2, // KBZ Pay ID
                        payment_reference: reference,
                        customer_name: customerName,
                        phone: phone,
                        address: address,
                        tax: tax * exchangeRates[currentCurrency],
                        shipping: shipping * exchangeRates[currentCurrency]
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.order_id) {
                            showCustomAlert('Payment successful! Redirecting...', 'success');

                            // Hide QR modal first
                            const $modal = $('#qrPaymentModal');
                            $modal.removeClass('show');

                            setTimeout(function() {
                                $modal.hide();
                                // Redirect to invoice page
                                window.location.href = 'invoice.php?order_id=' + response.order_id;
                            }, 1000);
                        } else {
                            showCustomAlert(response.error || 'Could not process payment. Please try again.', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showCustomAlert('Network error. Please try again.', 'error');
                    }
                });
            }

            // Handle QR payment verification
            $('#verifyQrPayment').off('click').on('click', function() {
                const reference = $('#qrPaymentReference').val().trim();
                const amount = parseFloat($('#total-amount').text().replace(/[^0-9.-]+/g, ''));
                const $button = $(this);
                const originalText = $button.html();

                if (!reference) {
                    showCustomAlert('Please enter the verification password', 'error');
                    return;
                }

                // Show loading state
                $button.html('<i class="fas fa-spinner fa-spin me-1"></i> Verifying...').prop('disabled', true);

                // Call verify_payment.php
                $.ajax({
                    url: 'verify_payment.php',
                    type: 'POST',
                    data: {
                        reference: reference,
                        method: 'KBZPAY',
                        amount: amount
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showCustomAlert('Payment verified successfully!', 'success');

                            // Add success animation to QR modal
                            const $successOverlay = $('<div class="payment-success-overlay"><div class="success-animation"><i class="fas fa-check-circle"></i></div></div>');
                            $('.qr-payment-content').append($successOverlay);

                            // Get form data
                            const customerName = $('#customer_name').val().trim();
                            const phone = $('#phone').val().trim();
                            const address = $('#address').val().trim();
                            const tax = parseFloat($('#tax-input').val() || 0);
                            const shipping = parseFloat($('#shipping-input').val() || 0);

                            // Process checkout
                            $.ajax({
                                url: 'pos.php',
                                type: 'POST',
                                data: {
                                    action: 'checkout',
                                    payment_method_id: '2', // KBZ Pay ID
                                    payment_reference: reference,
                                    customer_name: customerName,
                                    phone: phone,
                                    address: address,
                                    tax: tax * exchangeRates[currentCurrency],
                                    shipping: shipping * exchangeRates[currentCurrency]
                                },
                                dataType: 'json',
                                success: function(checkoutResponse) {
                                    if (checkoutResponse.success) {
                                        showCustomAlert('Order completed successfully!', 'success');

                                        // Hide QR modal
                                        const $modal = $('#qrPaymentModal');
                                        $modal.removeClass('show');
                                        setTimeout(() => {
                                            $modal.hide();
                                            // Redirect to invoice page
                                            window.location.href = 'invoice.php?order_id=' + checkoutResponse.order_id;
                                        }, 1000);
                                    } else {
                                        showCustomAlert(checkoutResponse.error || 'Error processing checkout', 'error');
                                    }
                                },
                                error: function(xhr, status, error) {
                                    showCustomAlert('Error processing checkout: ' + error, 'error');
                                }
                            });
                        } else {
                            showCustomAlert(response.error || 'Verification failed', 'error');
                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON || {};
                        showCustomAlert(response.error || 'Error verifying payment', 'error');
                    },
                    complete: function() {
                        $button.html(originalText).prop('disabled', false);
                    }
                });
            });

            // Close QR Payment Modal
            $('.qr-payment-close, .qr-payment-modal').off('click').on('click', function(e) {
                if (e.target === this) {
                    const $modal = $('#qrPaymentModal');
                    $modal.removeClass('show');
                    setTimeout(() => {
                        $modal.css('display', 'none');
                    }, 300);
                }
            });

            // Prevent modal close when clicking inside content
            $('.qr-payment-content').off('click').on('click', function(e) {
                e.stopPropagation();
            });

            // Helper function to get payment method ID
            function getPaymentMethodId(methodCode) {
                const paymentMethods = {
                    'CASH': 1,
                    'KBZPAY': 2,
                    'WAVEPAY': 3,
                    'CARD': 4,
                    'BANK': 5
                };
                return paymentMethods[methodCode] || 1; // Default to CASH if not found
            }

            // Payment method selection handling
            $('.payment-method-card').on('click', function() {
                const method = $(this).data('method');
                const $paymentReference = $('#payment_reference_container');
                const $referenceInput = $('#payment_reference');

                // Update radio button and UI
                $(this).find('input[type="radio"]').prop('checked', true);
                $('.payment-method-card').removeClass('selected');
                $(this).addClass('selected');

                // Handle payment reference visibility and placeholder
                if (method === 'CASH') {
                    $paymentReference.addClass('d-none');
                    $referenceInput.val('');
                } else {
                    $paymentReference.removeClass('d-none');
                    $referenceInput.attr('placeholder', `Enter ${method} reference (e.g., ${getExampleFormat(method)})`);

                    // Show validation message with example format
                    $('#payment_validation_message')
                        .removeClass('d-none alert-success')
                        .addClass('alert-warning')
                        .html(`<i class="fas fa-info-circle me-2"></i>Please enter the ${method} reference number. Example format: ${getExampleFormat(method)}`);
                }
            });

            // Helper function to get example reference format
            function getExampleFormat(method) {
                switch (method) {
                    case 'KBZPAY':
                        return 'KBZ1234567890';
                    case 'WAVEPAY':
                        return 'WP12345678A';
                    case 'CARD':
                        return 'CARD123456';
                    case 'BANK':
                        return 'TRX12345678';
                    default:
                        return '';
                }
            }

            // Add input validation for reference numbers
            $('#payment_reference').on('input', function() {
                const method = $('input[name="payment_method"]:checked').val();
                const reference = $(this).val().trim();
                const $validationMessage = $('#payment_validation_message');

                // Define validation patterns
                const patterns = {
                    'KBZPAY': /^KBZ[0-9]{10}$/,
                    'WAVEPAY': /^WP[0-9]{8}[A-Z]$/,
                    'CARD': /^CARD[0-9]{6}$/,
                    'BANK': /^TRX[0-9]{8}$/
                };

                if (reference && patterns[method]) {
                    if (patterns[method].test(reference)) {
                        $(this).removeClass('is-invalid').addClass('is-valid');
                        $validationMessage
                            .removeClass('d-none alert-warning')
                            .addClass('alert-success')
                            .html(`<i class="fas fa-check-circle me-2"></i>Valid ${method} reference format`);
                    } else {
                        $(this).removeClass('is-valid').addClass('is-invalid');
                        $validationMessage
                            .removeClass('d-none alert-success')
                            .addClass('alert-warning')
                            .html(`<i class="fas fa-exclamation-circle me-2"></i>Please follow the format: ${getExampleFormat(method)}`);
                    }
                } else {
                    $(this).removeClass('is-valid is-invalid');
                    $validationMessage.addClass('d-none');
                }
            });

            // Function to generate KBZ Pay QR code
            function generateKBZPayQR() {
                const totalAmount = parseFloat($('#total-amount').text().replace(/[^0-9.-]+/g, ''));
                const orderData = {
                    amount: totalAmount,
                    timestamp: Date.now(),
                    merchant: 'YOUR_MERCHANT_ID'
                };

                // Update QR code display
                $('#qr_amount').text($('#total-amount').text());
                $('#qr_code_image').attr('src', 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' +
                    encodeURIComponent(JSON.stringify(orderData)));

                // Show QR container with animation
                $('#qr_code_container')
                    .removeClass('d-none')
                    .hide()
                    .fadeIn();
            }

            // Verify payment button click handler
            $(document).on('click', '#verify_payment', function() {
                const reference = $('#payment_reference').val().trim();
                const method = $('input[name="payment_method"]:checked').val();
                const amount = parseFloat($('#total-amount').text().replace(/[^0-9.-]+/g, ''));
                const $validationMessage = $('#payment_validation_message');

                if (!reference) {
                    $validationMessage
                        .removeClass('d-none')
                        .html(`<i class="fas fa-exclamation-circle me-2"></i>Please enter the transaction reference number. Example format: ${getExampleFormat(method)}`);
                    return;
                }

                // Show loading state
                const $button = $(this);
                const originalText = $button.html();
                $button.html('<i class="fas fa-spinner fa-spin me-1"></i> Verifying...');
                $button.prop('disabled', true);

                // Verify payment using verify_payment.php
                $.ajax({
                    url: 'verify_payment.php',
                    type: 'POST',
                    data: {
                        reference: reference,
                        method: method,
                        amount: amount
                    },
                    success: function(response) {
                        if (response.success) {
                            $validationMessage
                                .removeClass('d-none alert-warning')
                                .addClass('alert-success')
                                .html(`<i class="fas fa-check-circle me-2"></i>${response.message}`);

                            // Enable the buy now button
                            $('.buy-now').prop('disabled', false);

                            // Show success animation
                            $('#payment_reference_container').append(`
                                <div class="payment-success-overlay">
                                    <div class="success-animation">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            `);

                            setTimeout(() => {
                                $('.payment-success-overlay').fadeOut(function() {
                                    $(this).remove();
                                });
                            }, 2000);
                        } else {
                            $validationMessage
                                .removeClass('d-none')
                                .html(`<i class="fas fa-exclamation-circle me-2"></i>${response.error}`);
                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON || {};
                        $validationMessage
                            .removeClass('d-none')
                            .html(`<i class="fas fa-exclamation-circle me-2"></i>${response.error || 'Error verifying payment'}`);
                    },
                    complete: function() {
                        // Reset button state
                        $button.html(originalText);
                        $button.prop('disabled', false);
                    }
                });
            });

            // Helper function to get example reference format
            function getExampleFormat(method) {
                switch (method) {
                    case 'KBZPAY':
                        return 'KBZ1234567890';
                    case 'WAVEPAY':
                        return 'WP12345678A';
                    case 'CARD':
                        return 'CARD123456';
                    case 'BANK':
                        return 'TRX12345678';
                    default:
                        return '';
                }
            }

            // Add these styles
            const styles = `
            <style>
            .payment-success-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(40, 167, 69, 0.2);
                backdrop-filter: blur(3px);
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 12px;
            }

            .success-animation {
                animation: successPop 0.5s ease-out;
            }

            .success-animation i {
                font-size: 48px;
                color: #28a745;
                text-shadow: 0 0 20px rgba(40, 167, 69, 0.5);
            }

            @keyframes successPop {
                0% {
                    transform: scale(0.5);
                    opacity: 0;
                }
                50% {
                    transform: scale(1.2);
                }
                100% {
                    transform: scale(1);
                    opacity: 1;
                }
            }

            #payment_validation_message.alert-success {
                background: rgba(40, 167, 69, 0.1);
                border-color: rgba(40, 167, 69, 0.2);
                color: #28a745;
            }

            #verify_payment:disabled {
                cursor: not-allowed;
                opacity: 0.7;
            }

            .payment-method-card.selected {
                border-color: #28a745;
            }

            .payment-method-card.selected .payment-icon {
                transform: scale(1.1);
            }
            </style>
            `;

            // Add styles to head
            $('head').append(styles);

            function updateCartTable() {
                $('.loading-spinner').show();

                $.ajax({
                    url: 'cart_ajax.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            let html = '';
                            let subtotal = 0;
                            let totalItems = 0;

                            if (response.cart_items && response.cart_items.length > 0) {
                                response.cart_items.forEach(function(item) {
                                    const priceInCurrency = parseFloat((parseFloat(item.price) * exchangeRates[currentCurrency]).toFixed(2));
                                    const discountAmount = parseFloat((priceInCurrency * (item.discount / 100)).toFixed(2));
                                    const itemTotal = parseFloat(((priceInCurrency - discountAmount) * item.quantity).toFixed(2));

                                    html += `
                                        <tr data-product-id="${item.product_id}" class="cart-item">
                                            <td>${item.product_name}</td>
                                            <td class="text-end">${formatCurrency(priceInCurrency)}</td>
                                            <td class="text-center">${item.stock_quantity}</td>
                                            <td class="text-center">
                                                <div class="quantity-controls d-flex align-items-center justify-content-center gap-2">
                                                    <button class="btn btn-sm btn-quantity minus" data-action="minus" data-product-id="${item.product_id}">
                                                        <i class="fas fa-minus"></i>
                                                    </button>
                                                    <span class="quantity">${item.quantity}</span>
                                                    <button class="btn btn-sm btn-quantity plus" data-action="plus" data-product-id="${item.product_id}" ${item.stock_quantity <= item.quantity ? 'disabled' : ''}>
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </td>
                                            <td class="text-center">${item.discount}%</td>
                                            <td class="text-end item-total" data-total="${itemTotal}">${formatCurrency(itemTotal)}</td>
                                            <td class="text-center">
                                                <button class="btn btn-sm btn-danger remove-item" data-product-id="${item.product_id}">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                        </td>
                                    </tr>
                                `;

                                    subtotal = parseFloat((subtotal + itemTotal).toFixed(2));
                                    totalItems += item.quantity;

                                    // Update sold count in product display
                                    updateProductUI(item.product_id, item.stock_quantity, item.quantity);
                                });
                            } else {
                                html = '<tr><td colspan="7" class="text-center">No items in cart</td></tr>';
                                subtotal = 0;
                                totalItems = 0;
                                $('#tax-input').val('0');
                                $('#shipping-input').val('0');

                                // Reset all sold counts to 0 and update UI
                                $('.product-card').each(function() {
                                    const productId = $(this).find('[data-product-id]').data('product-id');
                                    if (productId) {
                                        const stockQuantity = parseInt($(this).find('.stock-number').text()) || 0;
                                        updateProductUI(productId, stockQuantity, 0);
                                    }
                                });
                            }

                            // Update cart table with animation
                            const $tbody = $('#cart-table tbody');
                            $tbody.fadeOut(200, function() {
                                $(this).html(html).fadeIn(200);

                                // Reattach event handlers
                                attachCartEventHandlers();
                            });

                            // Update summary with animation
                            const tax = parseFloat($('#tax-input').val()) || 0;
                            const shipping = parseFloat($('#shipping-input').val()) || 0;

                            const taxAmount = parseFloat(((subtotal * tax) / 100).toFixed(2));
                            const total = parseFloat((subtotal + taxAmount + shipping).toFixed(2));

                            $('#subtotal-amount').text(formatCurrency(subtotal));
                            $('#tax-amount').text(formatCurrency(taxAmount));
                            $('#shipping-amount').text(formatCurrency(shipping));
                            $('#total-amount').text(formatCurrency(total));

                            // Update cart badge
                            updateCartBadge(totalItems);

                            // If cart is empty, force all summary values to 0
                            if (totalItems === 0) {
                                $('#subtotal-amount').text(formatCurrency(0));
                                $('#tax-amount').text(formatCurrency(0));
                                $('#shipping-amount').text(formatCurrency(0));
                                $('#total-amount').text(formatCurrency(0));
                                $('#discount-amount').text(formatCurrency(0));
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Cart update error:', error);
                        showNotification('Error updating cart', 'error');
                    },
                    complete: function() {
                        $('.loading-spinner').hide();
                    }
                });
            }

            function updateSummaryWithAnimation(subtotal, totalItems) {
                const tax = parseFloat($('#tax-input').val()) || 0;
                const shipping = parseFloat($('#shipping-input').val()) || 0;

                // Ensure precise calculations
                subtotal = parseFloat(subtotal.toFixed(2));
                const taxAmount = parseFloat(((subtotal * tax) / 100).toFixed(2));
                shipping = parseFloat(shipping.toFixed(2));
                const total = parseFloat((subtotal + taxAmount + shipping).toFixed(2));

                // Animate summary updates with precise values
                animateValue('#subtotal-amount', subtotal);
                animateValue('#tax-amount', taxAmount);
                animateValue('#shipping-amount', shipping);
                animateValue('#total-amount', total);
            }

            function animateValue(selector, newValue) {
                const $element = $(selector);
                const startValue = parseFloat($element.text().replace(/[^0-9.-]+/g, '')) || 0;

                $({value: startValue}).animate({value: newValue}, {
                    duration: 500,
                    easing: 'swing',
                    step: function() {
                        // Ensure proper rounding during animation
                        const current = parseFloat(this.value.toFixed(2));
                        $element.text(formatCurrency(current));
                    },
                    complete: function() {
                        // Ensure final value is exactly correct
                        $element.text(formatCurrency(newValue));
                    }
                });
            }

            function attachCartEventHandlers() {
                // Quantity controls
                $('.btn-quantity').off('click').on('click', function() {
                    const $btn = $(this);
                    const productId = $btn.data('product-id');
                    const action = $btn.data('action');
                    const $row = $btn.closest('tr');
                    const currentQuantity = parseInt($row.find('.quantity').text());

                    // If this is the last item and we're reducing quantity
                    if (currentQuantity === 1 && action === 'minus') {
                        // Check if this is the only item in cart
                        const totalRows = $('#cart-table tbody tr').length;
                        if (totalRows === 1) {
                            // Reset all values as cart will be empty
                            setTimeout(() => {
                                $('#subtotal-amount').text(formatCurrency(0));
                                $('#tax-amount').text(formatCurrency(0));
                                $('#shipping-amount').text(formatCurrency(0));
                                $('#total-amount').text(formatCurrency(0));
                                $('#discount-amount').text(formatCurrency(0));
                                $('#tax-input').val('0');
                                $('#shipping-input').val('0');
                            }, 100);
                        }
                    }

                    // Update stock before AJAX call
                    updateProductStock(productId, action === 'plus' ? 'decrease' : 'increase');

                            $.ajax({
                                url: 'pos.php',
                                type: 'POST',
                        data: {
                            action: action,
                            product_id: productId
                        },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        updateCartTable();

                                // If totals are provided in response, update them
                                if (response.totals) {
                                    $('#subtotal-amount').text(formatCurrency(parseFloat(response.totals.subtotal)));
                                    $('#tax-amount').text(formatCurrency(parseFloat(response.totals.tax_amount)));
                                    $('#shipping-amount').text(formatCurrency(parseFloat(response.totals.shipping)));
                                    $('#total-amount').text(formatCurrency(parseFloat(response.totals.total)));
                                }
                            }
                                }
                            });
                        });

                // Remove item
                $('.remove-item').off('click').on('click', function() {
                    const $btn = $(this);
                    const productId = $btn.data('product-id');
                    const quantity = parseInt($btn.closest('tr').find('.quantity').text());
                    const $row = $btn.closest('tr');

                    // Check if this is the last item in cart
                    const totalRows = $('#cart-table tbody tr').length;
                    if (totalRows === 1) {
                        // Reset all values as cart will be empty
                        setTimeout(() => {
                            $('#subtotal-amount').text(formatCurrency(0));
                            $('#tax-amount').text(formatCurrency(0));
                            $('#shipping-amount').text(formatCurrency(0));
                            $('#total-amount').text(formatCurrency(0));
                            $('#discount-amount').text(formatCurrency(0));
                            $('#tax-input').val('0');
                            $('#shipping-input').val('0');
                        }, 100);
                    }

                    // Update stock before removal
                    for(let i = 0; i < quantity; i++) {
                        updateProductStock(productId, 'increase');
                    }

                    // Animate item removal
                    $row.fadeOut(300, function() {
                        updateCartItem(productId, 'remove');
                    });
                });
            }

            function updateCartItem(productId, action) {
                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: {
                        action: action,
                        product_id: productId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            updateCartTable();

                            // Update sold count in product display based on cart quantity
                            const cartQuantity = response.cart_quantity || 0;
                            updateProductUI(productId, response.stock_quantity, cartQuantity);
                        }
                    }
                });
            }

            function showNotification(message, type = 'success') {
                const $notification = $('<div>').addClass('notification').addClass(type).text(message);
                $('body').append($notification);

                setTimeout(() => {
                    $notification.addClass('show');
                    setTimeout(() => {
                        $notification.removeClass('show');
                        setTimeout(() => $notification.remove(), 300);
                    }, 2000);
                }, 100);
            }

            function updateSummary() {
                const tax = parseFloat($('#tax-input').val()) || 0;
                const shipping = parseFloat($('#shipping-input').val()) || 0;
                let subtotal = 0;
                $('#cart-table tbody tr').each(function() {
                    const itemTotal = parseFloat($(this).find('.item-total').data('base-total')) || 0;
                    subtotal += itemTotal;
                });
                const discount = parseFloat($('#discount-amount').text().replace(/[^0-9.-]+/g, '')) || 0;
                $('#subtotal-amount').text(formatCurrency(subtotal));
                $('#tax-input').val((tax * exchangeRates[currentCurrency] / exchangeRates[currentCurrency]).toFixed(2));
                $('#shipping-input').val((shipping * exchangeRates[currentCurrency] / exchangeRates[currentCurrency]).toFixed(2));
                const newTotal = subtotal + (tax * exchangeRates[currentCurrency]) + (shipping * exchangeRates[currentCurrency]) - discount;
                $('#total-amount').text(formatCurrency(newTotal));
            }

            function updateOrderSummary(subtotal, tax, discount, shipping) {
                $('#subtotal-amount').text(formatCurrency(subtotal));
                $('#tax-input').val((tax / exchangeRates[currentCurrency]).toFixed(2));
                $('#discount-amount').text(formatCurrency(discount));
                $('#shipping-input').val((shipping / exchangeRates[currentCurrency]).toFixed(2));
                const total = subtotal + tax + shipping - discount;
                $('#total-amount').text(formatCurrency(total));
            }

            function formatCurrency(amount) {
                // Ensure amount is properly rounded to 2 decimal places
                amount = parseFloat(parseFloat(amount).toFixed(2));
                return currencySymbols[currentCurrency] + ' ' + amount.toFixed(2);
            }

            function updateCustomerInfo(name, address, phone) {
                let html = '';
                if (name || address || phone) {
                    if (name) html += `<p><i class="fas fa-user me-2"></i><strong data-translate="name">${translations['name'] || 'Name'}:</strong> <span id="display-customer-name">${name}</span></p>`;
                    if (address) html += `<p><i class="fas fa-map-marker-alt me-2"></i><strong data-translate="address">${translations['address'] || 'Address'}:</strong> <span id="display-address">${address}</span></p>`;
                    if (phone) html += `<p><i class="fas fa-phone me-2"></i><strong data-translate="phone">${translations['phone'] || 'Phone'}:</strong> <span id="display-phone">${phone}</span></p>`;
                } else {
                    html = '<p data-translate="no_customer_info">' + (translations['no_customer_info'] || 'No customer information available.') + '</p>';
                }
                $('#customer-info-display').html(html);
            }

            const calculator = {
                displayValue: '0',
                firstOperand: null,
                waitingForSecondOperand: false,
                operator: null,
            };

            function inputDigit(digit) {
                if (calculator.waitingForSecondOperand) {
                    calculator.displayValue = digit;
                    calculator.waitingForSecondOperand = false;
                } else {
                    calculator.displayValue = calculator.displayValue === '0' ? digit : calculator.displayValue + digit;
                }
                updateDisplay();
            }

            function inputDecimal(dot) {
                if (calculator.waitingForSecondOperand) {
                    calculator.displayValue = '0.';
                    calculator.waitingForSecondOperand = false;
                    return;
                }
                if (!calculator.displayValue.includes('.')) {
                    calculator.displayValue += dot;
                }
                updateDisplay();
            }

            function handleOperator(nextOperator) {
                const display = parseFloat(calculator.displayValue);
                if (calculator.operator && calculator.waitingForSecondOperand) {
                    calculator.operator = nextOperator;
                    return;
                }
                if (calculator.firstOperand === null && !isNaN(display)) {
                    calculator.firstOperand = display;
                } else if (calculator.operator) {
                    const result = calculate(calculator.firstOperand, display, calculator.operator);
                    calculator.displayValue = String(result);
                    calculator.firstOperand = result;
                }
                calculator.waitingForSecondOperand = true;
                calculator.operator = nextOperator;
                updateDisplay();
            }

            function calculate(first, second, operator) {
                switch (operator) {
                    case '+': return first + second;
                    case '-': return first - second;
                    case 'x': return first * second;
                    case '/': return second !== 0 ? first / second : 'Error';
                    default: return second;
                }
            }

            function updateDisplay() {
                const display = document.getElementById('display');
                display.textContent = calculator.displayValue;
                if (display.textContent.length > 12) {
                    display.style.fontSize = '1.2rem';
                } else {
                    display.style.fontSize = '1.5rem';
                }
            }

            function resetCalculator() {
                calculator.displayValue = '0';
                calculator.firstOperand = null;
                calculator.waitingForSecondOperand = false;
                calculator.operator = null;
                updateDisplay();
            }

            function performCalculation() {
                const display = parseFloat(calculator.displayValue);
                if (calculator.firstOperand !== null && !isNaN(display)) {
                    const result = calculate(calculator.firstOperand, display, calculator.operator);
                    calculator.displayValue = String(result);
                    calculator.firstOperand = result;
                    calculator.waitingForSecondOperand = false;
                    calculator.operator = null;
                }
                updateDisplay();
            }

            const keys = document.querySelector('.calculator-keys');
            keys.addEventListener('click', (event) => {
                const { target } = event;
                if (!target.matches('button')) return;

                if (target.classList.contains('operator')) {
                    handleOperator(target.textContent);
                    return;
                }
                if (target.classList.contains('decimal')) {
                    inputDecimal('.');
                    return;
                }
                if (target.classList.contains('clear')) {
                    resetCalculator();
                    return;
                }
                if (target.classList.contains('equal')) {
                    performCalculation();
                    return;
                }
                inputDigit(target.textContent);
            });

            $('.calculator-toggle').on('click', function(e) {
                e.preventDefault();
                $('#calculator-overlay').toggleClass('active');
            });

            $('#calculator-overlay').on('click', function(e) {
                if (e.target === this) {
                    $(this).removeClass('active');
                }
            });

            // Cart notification function
            window.showCartNotification = function(productId, quantity) {
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 80px;
                    right: 20px;
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    padding: 12px 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(16, 185, 129, 0.3);
                    z-index: 10000;
                    font-size: 0.9rem;
                    font-weight: 600;
                    transform: translateX(100%);
                    transition: transform 0.3s ease;
                `;
                notification.innerHTML = `
                    <i class="fas fa-check-circle me-2"></i>
                    Product added to cart successfully!
                `;

                document.body.appendChild(notification);

                setTimeout(() => {
                    notification.style.transform = 'translateX(0)';
                }, 100);

                setTimeout(() => {
                    notification.style.transform = 'translateX(100%)';
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                    }, 300);
                }, 3000);
            };

            function highlightAddedProduct(productId) {
                // Find and highlight the product row in cart table
                const cartRow = $(`#cart-table tbody tr[data-product-id="${productId}"]`);
                if (cartRow.length) {
                    cartRow.addClass('table-success');
                    cartRow.css('background-color', 'rgba(16, 185, 129, 0.1)');

                    // Animate the row
                    cartRow.css('transform', 'scale(1.02)');
                    setTimeout(() => {
                        cartRow.css('transform', 'scale(1)');
                        cartRow.removeClass('table-success');
                        cartRow.css('background-color', '');
                    }, 2000);

                    // Scroll to cart table if not visible
                    const cartTable = document.getElementById('cart-table');
                    if (cartTable) {
                        cartTable.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                }
            }

            $('#notificationModal').on('show.bs.modal', function () {
                const modalBody = $('#notificationBody');
                if (modalBody.length) {
                    modalBody.css('background', '#2D314D');
                    modalBody.css('color', '#FFFFFF');
                }
            });

            // Handle payment method selection
            $('.payment-method-card').on('click', function() {
                const method = $(this).data('method');
                const $paymentReference = $('#payment_reference_container');
                const $referenceInput = $('#payment_reference');

                // Update radio button
                $(this).find('input[type="radio"]').prop('checked', true);

                // Update UI
                $('.payment-method-card').removeClass('selected');
                $(this).addClass('selected');

                // Handle payment reference visibility
                if (method === 'CASH') {
                    $paymentReference.addClass('d-none');
                    $referenceInput.val('');
                } else {
                    $paymentReference.removeClass('d-none');
                    $referenceInput.attr('placeholder', `Enter ${method} reference number`);
                }
            });

            $('input[name="payment_method"]').on('change', function() {
                const method = $(this).val();
                updatePaymentMethodUI(method);
            });

            function updatePaymentMethodUI(method) {
                // Show/hide reference field based on payment method
                if (method === 'CASH') {
                    $('#payment_reference_container').addClass('d-none');
                    $('#payment_reference').val('');
                } else {
                    $('#payment_reference_container').removeClass('d-none');
                }

                // Update card styles
                $('.payment-method-card').each(function() {
                    const cardMethod = $(this).data('method');
                    if (cardMethod === method) {
                        $(this).addClass('selected');
                        $(this).find('.payment-icon').css('transform', 'scale(1.1)');
                    } else {
                        $(this).removeClass('selected');
                        $(this).find('.payment-icon').css('transform', 'scale(1)');
                    }
                });
            }

            // Initialize with cash payment selected
            updatePaymentMethodUI('CASH');

            // Update notification count
            function updateNotificationCount() {
                $.ajax({
                    url: 'get_notifications.php',
                    type: 'GET',
                    success: function(response) {
                        if (response.count > 0) {
                            $('#notificationBadge').text(response.count).show();
                        } else {
                            $('#notificationBadge').hide();
                        }
                    }
                });
            }

            // Initial notification check
            updateNotificationCount();

            // Check notifications every 30 seconds
            setInterval(updateNotificationCount, 30000);

            // All Reset button handler
            $('.reset-all').on('click', function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'pos.php',
                    type: 'POST',
                    data: { reset_all: 1 },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            // Refresh UI components
                            loadProducts();
                            updateCartTable();
                            $('#customer-info-display').html('<p>No customer information available.</p>');
                            $('#tax-input, #shipping-input').val('0');
                            $('#subtotal-amount, #tax-amount, #shipping-amount, #total-amount, #discount-amount').text(currencySymbols[currentCurrency] + ' 0.00');
                            updateCartBadge(0);
                            showNotification('Cart reset successfully');
                        } else {
                            showNotification('Failed to reset', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showNotification('Error resetting cart', 'error');
                    }
                });
            });
        });
    </script>
    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>