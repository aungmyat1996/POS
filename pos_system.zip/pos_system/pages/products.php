<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Set timezone from settings (similar to pos.php)
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute(['timezone']);
    $timezone = $stmt->fetchColumn() ?: 'Asia/Yangon'; // Default timezone
    date_default_timezone_set($timezone);
} catch (PDOException $e) {
    error_log("Error fetching timezone setting: " . $e->getMessage());
    date_default_timezone_set('Asia/Yangon'); // Fallback timezone
}

// Start session and include required files
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get settings for language and currency (similar to pos.php)
try {
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings_array = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings_array = [];
}

// CSRF token for form security
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize variables
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];
$currency = $_SESSION['currency'] ?? ($settings_array['currency'] ?? 'USD');
$language = $_SESSION['language'] ?? ($settings_array['language'] ?? 'en');
$translations = loadLanguage($language); // Assuming loadLanguage handles fallback

$exchangeRates = [ // You might want to fetch this from settings or a config file
    'USD' => 1,
    'THB' => 33,
    'MMK' => 2100
];
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$category_filter_id = isset($_GET['category']) ? sanitize_input($_GET['category']) : '';
$sort = isset($_GET['sort']) ? sanitize_input($_GET['sort']) : 'product_name_asc';
$stock_filter = isset($_GET['stock_filter']) ? sanitize_input($_GET['stock_filter']) : '';

// Fetch categories for filter dropdown
try {
    $stmt_categories = $pdo->query("SELECT category_id, category_name FROM categories ORDER BY category_name");
    $categories = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
    error_log("Error fetching categories: " . $e->getMessage());
    $categories = [];
}

// Build product query
$query = "SELECT p.*, c.category_name, s.supplier_name
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.category_id
          LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id
          WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND (p.product_name LIKE :search OR p.description LIKE :search OR p.barcode LIKE :search)";
    $params[':search'] = "%$search%";
}

if ($category_filter_id) {
    $query .= " AND p.category_id = :category_filter_id";
    $params[':category_filter_id'] = $category_filter_id;
}

if ($stock_filter === 'low') {
    $query .= " AND p.stock_quantity <= 5 AND p.stock_quantity > 0"; // Assuming low stock is <= 5 but not 0
} elseif ($stock_filter === 'out') {
    $query .= " AND p.stock_quantity = 0";
}

switch ($sort) {
    case 'product_name_asc':
        $query .= " ORDER BY p.product_name ASC";
        break;
    case 'product_name_desc':
        $query .= " ORDER BY p.product_name DESC";
        break;
    case 'price_asc':
        $query .= " ORDER BY p.unit_price ASC";
        break;
    case 'price_desc':
        $query .= " ORDER BY p.unit_price DESC";
        break;
    case 'stock_asc':
        $query .= " ORDER BY p.stock_quantity ASC";
        break;
    case 'stock_desc':
        $query .= " ORDER BY p.stock_quantity DESC";
        break;
    default:
        $query .= " ORDER BY p.product_name ASC";
}

// Fetch products
try {
    $stmt_products = $pdo->prepare($query);
    $stmt_products->execute($params);
    $products = $stmt_products->fetchAll(PDO::FETCH_ASSOC);
    $productCount = count($products);
} catch (PDOException $e) {
    error_log("Error fetching products: " . $e->getMessage());
    $products = [];
    $productCount = 0;
}

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product']) && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $product_id_to_delete = (int)($_POST['product_id'] ?? 0);
    if ($product_id_to_delete > 0) {
        try {
            $stmt_delete = $pdo->prepare("DELETE FROM products WHERE product_id = :product_id");
            $stmt_delete->execute([':product_id' => $product_id_to_delete]);
            logAction($pdo, $_SESSION['user_id'] ?? 0, "Deleted product ID $product_id_to_delete");
            // Redirect to avoid form resubmission and to show success message
            header("Location: products.php?success=" . urlencode($translations['product_deleted_success'] ?? 'Product deleted successfully') . "&search=$search&category=$category_filter_id&sort=$sort&stock_filter=$stock_filter");
        exit;
} catch (PDOException $e) {
        error_log("Error deleting product: " . $e->getMessage());
            $error = $translations['product_delete_failed'] ?? "Failed to delete product.";
        }
    } else {
        $error = $translations['invalid_product_id'] ?? "Invalid product ID for deletion.";
    }
}

// Handle product addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product']) && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $errors = [];

    // Validate and sanitize input
    $product_name = sanitize_input($_POST['product_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $description = sanitize_input($_POST['description'] ?? '');
    $unit_price = (float)($_POST['price'] ?? 0);
    $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
    $cost_price = (float)($_POST['cost_price'] ?? 0);
    $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
    $discount = (float)($_POST['discount'] ?? 0);
    $barcode = sanitize_input($_POST['barcode'] ?? '');
    $status = sanitize_input($_POST['status'] ?? 'active');

    // Basic validation
    if (empty($product_name)) {
        $errors[] = $translations['product_name_required'] ?? 'Product name is required.';
    }
    if ($unit_price <= 0) {
        $errors[] = $translations['price_required'] ?? 'Valid price is required.';
    }
    if ($stock_quantity < 0) {
        $errors[] = $translations['stock_required'] ?? 'Stock quantity cannot be negative.';
    }

    // Handle image upload
    $image = 'default.jpg';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];

        if (!in_array($file_type, $allowed_types)) {
            $errors[] = $translations['invalid_image_type'] ?? "Invalid file type. Only JPG, PNG and GIF are allowed.";
        } else {
            $image = uniqid() . '_' . basename($_FILES['image']['name']);
            $upload_path = "../public/images/" . $image;

            if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $errors[] = $translations['image_upload_failed'] ?? "Failed to upload image.";
                $image = 'default.jpg';
            }
        }
    }

    if (empty($errors)) {
        try {
            $stmt_add = $pdo->prepare("INSERT INTO products (product_name, category_id, description, unit_price, stock_quantity, cost_price, supplier_id, discount, barcode, image, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

            $stmt_add->execute([
                $product_name,
                $category_id ?: null,
                $description,
                $unit_price,
                $stock_quantity,
                $cost_price,
                $supplier_id,
                $discount,
                $barcode,
                $image,
                $status
            ]);

            logAction($pdo, $_SESSION['user_id'] ?? 0, "Added new product: $product_name");
            header("Location: products.php?success=" . urlencode($translations['product_added_success'] ?? 'Product added successfully') . "&search=$search&category=$category_filter_id&sort=$sort&stock_filter=$stock_filter");
            exit;
        } catch (PDOException $e) {
            error_log("Error adding product: " . $e->getMessage());
            $error = $translations['product_add_failed'] ?? "Failed to add product.";
        }
    } else {
        $error = implode(' ', $errors);
    }
}

// Handle product editing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_product']) && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $errors = [];

    // Validate and sanitize input
    $product_id = (int)($_POST['product_id'] ?? 0);
    $product_name = sanitize_input($_POST['product_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $description = sanitize_input($_POST['description'] ?? '');
    $unit_price = (float)($_POST['price'] ?? 0);
    $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
    $cost_price = (float)($_POST['cost_price'] ?? 0);
    $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
    $discount = (float)($_POST['discount'] ?? 0);
    $barcode = sanitize_input($_POST['barcode'] ?? '');
    $status = sanitize_input($_POST['status'] ?? 'active');

    // Basic validation
    if (empty($product_name)) {
        $errors[] = $translations['product_name_required'] ?? 'Product name is required.';
    }
    if ($unit_price <= 0) {
        $errors[] = $translations['price_required'] ?? 'Valid price is required.';
    }
    if ($stock_quantity < 0) {
        $errors[] = $translations['stock_required'] ?? 'Stock quantity cannot be negative.';
    }
    if ($product_id <= 0) {
        $errors[] = $translations['invalid_product_id'] ?? 'Invalid product ID.';
    }

    // Get current product data
    $current_product = null;
    if ($product_id > 0) {
        try {
            $stmt_current = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
            $stmt_current->execute([$product_id]);
            $current_product = $stmt_current->fetch(PDO::FETCH_ASSOC);


        } catch (PDOException $e) {
            error_log("Error fetching current product: " . $e->getMessage());
            $errors[] = $translations['product_fetch_failed'] ?? "Failed to fetch product data.";
        }
          }

    // Handle image upload
    $image = $current_product['image'] ?? 'default.jpg'; // Keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];

        if (!in_array($file_type, $allowed_types)) {
            $errors[] = $translations['invalid_image_type'] ?? "Invalid file type. Only JPG, PNG and GIF are allowed.";
        } else {
            $image = uniqid() . '_' . basename($_FILES['image']['name']);
            $upload_path = "../public/images/" . $image;

            if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $errors[] = $translations['image_upload_failed'] ?? "Failed to upload image.";
                $image = $current_product['image'] ?? 'default.jpg'; // Keep existing image if upload fails
            } else {
                // Delete old image if it's not the default image
                if (isset($current_product['image']) && $current_product['image'] !== 'default.jpg' && file_exists("../public/images/" . $current_product['image'])) {
                    unlink("../public/images/" . $current_product['image']);
                }
            }
        }
    }

    // Check if product exists
    if (!$current_product) {
        $errors[] = $translations['product_not_found'] ?? "Product not found. It may have been deleted.";
    }

    if (empty($errors)) {
        try {
            $stmt_update = $pdo->prepare("UPDATE products SET
                product_name = ?,
                category_id = ?,
                description = ?,
                unit_price = ?,
                stock_quantity = ?,
                cost_price = ?,
                supplier_id = ?,
                discount = ?,
                barcode = ?,
                image = ?,
                status = ?
                WHERE product_id = ?");

            $update_result = $stmt_update->execute([
                $product_name,
                $category_id ?: null,
                $description,
                $unit_price,
                $stock_quantity,
                $cost_price,
                $supplier_id,
                $discount,
                $barcode,
                $image,
                $status,
                $product_id
            ]);

            if ($update_result && $stmt_update->rowCount() > 0) {
                logAction($pdo, $_SESSION['user_id'] ?? 0, "Updated product: $product_name (ID: $product_id)");
                header("Location: products.php?success=" . urlencode($translations['product_updated_success'] ?? 'Product updated successfully') . "&search=$search&category=$category_filter_id&sort=$sort&stock_filter=$stock_filter");
                exit;
            } else {
                $error = $translations['no_changes_made'] ?? "No changes were made to the product.";
            }
        } catch (PDOException $e) {
            error_log("Error updating product: " . $e->getMessage());
            $error = $translations['product_update_failed'] ?? "Failed to update product. Please try again.";
        }
    } else {
        $error = implode(', ', $errors);
    }
}

// Handle add category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category']) && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $category_errors = [];

    // Validate and sanitize input
    $category_name = sanitize_input($_POST['category_name'] ?? '');

    // Basic validation
    if (empty($category_name)) {
        $category_errors[] = $translations['category_name_required'] ?? 'Category name is required.';
    } elseif (strlen($category_name) > 50) {
        $category_errors[] = $translations['category_name_too_long'] ?? 'Category name must be 50 characters or less.';
    }

    // Check if category already exists
    if (empty($category_errors)) {
        try {
            $stmt_check = $pdo->prepare("SELECT category_id FROM categories WHERE category_name = ?");
            $stmt_check->execute([$category_name]);
            if ($stmt_check->fetch()) {
                $category_errors[] = $translations['category_already_exists'] ?? 'Category already exists.';
            }
        } catch (PDOException $e) {
            error_log("Error checking category existence: " . $e->getMessage());
            $category_errors[] = $translations['category_check_failed'] ?? "Failed to check category.";
        }
    }

    if (empty($category_errors)) {
        try {
            $stmt_add_cat = $pdo->prepare("INSERT INTO categories (category_name) VALUES (?)");
            $stmt_add_cat->execute([$category_name]);

            logAction($pdo, $_SESSION['user_id'] ?? 0, "Added new category: $category_name");
            header("Location: products.php?success=" . urlencode($translations['category_added_success'] ?? 'Category added successfully') . "&search=$search&category=$category_filter_id&sort=$sort&stock_filter=$stock_filter");
            exit;
        } catch (PDOException $e) {
            error_log("Error adding category: " . $e->getMessage());
            $error = $translations['category_add_failed'] ?? "Failed to add category.";
        }
    } else {
        $error = implode(', ', $category_errors);
    }
}

// Handle success/error messages
$success_message = isset($_GET['success']) ? sanitize_input($_GET['success']) : '';
$error_message = isset($error) ? $error : (isset($_GET['error']) ? sanitize_input($_GET['error']) : '');

// Get settings for navbar
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Clear old session data and get fresh from database
unset($_SESSION['system_name']);

// Get system name from database immediately
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_name'");
    $stmt->execute();
    $db_site_name = $stmt->fetchColumn();

    // Update session with database value
    if ($db_site_name) {
        $_SESSION['system_name'] = $db_site_name;
        error_log("Products.php: Updated system_name to: " . $db_site_name);
    } else {
        error_log("Products.php: No site_name found in database");
    }
} catch (PDOException $e) {
    error_log("Products.php: Error fetching site_name: " . $e->getMessage());
}

// Default values for navbar (let navbar.php handle system_name from database)
$logo_path = $_SESSION['logo_path'] ?? '../public/images/logo.png';
// $system_name will be handled by navbar.php from database
$current_page = 'products';

// Fetch suppliers for modals
try {
    $stmt_suppliers = $pdo->query("SELECT supplier_id, supplier_name FROM suppliers ORDER BY supplier_name");
    $suppliers = $stmt_suppliers->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching suppliers: " . $e->getMessage());
    $suppliers = [];
}

// For Product Summary section
$total_products_summary = $productCount; // Use the count already fetched

try {
    $stmt_low_stock = $pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= 5"); // Assuming low stock is > 0 and <= 5
    $low_stock_count_summary = $stmt_low_stock->fetchColumn();
} catch (PDOException $e) {
    error_log("Error fetching low stock count: " . $e->getMessage());
    $low_stock_count_summary = 0;
}

try {
    $stmt_out_of_stock = $pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity = 0");
    $out_of_stock_count_summary = $stmt_out_of_stock->fetchColumn();
} catch (PDOException $e) {
    error_log("Error fetching out of stock count: " . $e->getMessage());
    $out_of_stock_count_summary = 0;
}

?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($translations['nav_products'] ?? 'Products'); ?> - <?php echo htmlspecialchars($translations['system_name'] ?? 'BitsTech POS'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <!-- jQuery must be loaded before navbar.php -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <style>
        /* Products Page Specific Styles */
        .search-header-section {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            box-sizing: border-box;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .search-header-section .products-count {
            font-size: 0.9rem;
            color: var(--text-primary);
            flex-shrink: 0;
        }

        .search-header-section .search-bar {
            display: flex;
            align-items: center;
            flex-grow: 1;
            gap: 10px;
            min-width: 300px;
        }

        .search-header-section .search-bar .form-control,
        .search-header-section .search-bar .form-select {
            background: #2D314D;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            padding: 8px 12px;
            font-size: 0.8rem;
            flex-grow: 1;
        }

        .search-header-section .search-bar .form-control {
            min-width: 150px;
        }

        .search-header-section .search-bar .form-select {
            min-width: 150px;
            flex-grow: 0;
            flex-basis: 150px;
        }

        .search-header-section .search-bar .form-control:focus,
        .search-header-section .search-bar .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 5px rgba(249, 115, 22, 0.5);
            background: #2D314D;
            color: var(--text-primary);
        }

        .search-header-section .btn {
            padding: 8px 15px;
            font-size: 0.8rem;
        }

        /* Products section */
        .products-section {
            margin-bottom: 20px;
        }

        .products-section h3 {
            color: var(--text-primary);
            margin-bottom: 15px;
            font-size: 1.1rem;
            font-weight: 500;
        }

        /* Modal styling consistency */
        .modal-content {
            background-color: var(--card-bg);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
        }

        .modal-header {
            background: linear-gradient(90deg, var(--gradient-start), var(--gradient-end));
            color: var(--text-primary);
            border-bottom: 1px solid var(--border-color);
        }

        .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }

        .modal-body {
            background-color: #2D314D;
        }

        .modal-body .form-label {
            color: var(--text-secondary);
        }

        .modal-body .form-control,
        .modal-body .form-select {
            background-color: var(--primary-bg);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .modal-body .form-control:focus,
        .modal-body .form-select:focus {
            border-color: var(--accent);
            background-color: var(--primary-bg);
            box-shadow: 0 0 5px rgba(249, 115, 22, 0.5);
        }

        .modal-footer {
            border-top: 1px solid var(--border-color);
        }

        /* Product images error handling improvement */
        .product-image-thumb {
            transition: opacity 0.3s ease;
        }

        .product-image-thumb[src*="default.jpg"] {
            opacity: 0.7;
        }

        /* Product table styling */
        .table-container {
            max-height: 600px;
            overflow-y: auto;
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            background: var(--card-bg);
        }

        .product-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
        }

        .product-table th,
        .product-table td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .product-table th {
            background: var(--accent);
            color: var(--text-primary);
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .product-table td {
            color: var(--text-secondary);
        }

        .product-table tr:hover td {
            background-color: rgba(255, 255, 255, 0.05);
        }

        .product-table img.product-image-thumb {
            max-width: 40px;
            height: auto;
            max-height: 40px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            object-fit: cover;
            opacity: 0;
            transition: opacity 0.3s ease;
            background: #2D314D;
        }

        .product-image-container {
            width: 40px;
            height: 40px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #2D314D;
            border-radius: 4px;
            overflow: hidden;
        }

        .product-image-container::before {
            content: '\f03e';
            font-family: 'Font Awesome 6 Free';
            font-weight: 400;
            color: var(--text-secondary);
            font-size: 16px;
            position: absolute;
        }

        .product-table .actions {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .product-table .actions .btn {
            padding: 5px 8px;
            font-size: 0.75rem;
        }

        .product-table .btn-details {
            background-color: #17a2b8;
            border: none;
        }

        .product-table .btn-danger {
            background-color: #dc3545;
            border: none;
        }

        .product-table .price-original {
            text-decoration: line-through;
            color: #6c757d;
            font-size: 0.75rem;
            margin-left: 5px;
        }

        .product-table .price-discounted {
            color: #28a745;
            font-weight: bold;
        }

        .stock-low {
            color: #ffc107;
            font-weight: bold;
        }

        .stock-out {
            color: #dc3545;
            font-weight: bold;
        }

        /* Product summary section */
        .product-summary-section {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            margin-top: 30px;
            border: 1px solid var(--border-color);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .product-summary-section h4 {
            color: var(--text-primary);
            margin: 0 0 20px 0;
            font-size: 1.2rem;
            font-weight: 600;
        }

        .summary-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .summary-stats-grid .stat-item {
            background: #2D314D;
            padding: 15px;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .summary-stats-grid .stat-item i {
            font-size: 1.5rem;
            color: var(--accent);
            margin-bottom: 10px;
        }

        .summary-stats-grid .stat-item .label {
            color: var(--text-secondary);
            font-size: 0.8rem;
            margin-bottom: 5px;
        }

        .summary-stats-grid .stat-item .value {
            color: var(--text-primary);
            font-size: 1.3rem;
            font-weight: 600;
        }

        .quick-filters-summary {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .quick-filters-summary .filter-btn {
            background: #2D314D;
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .quick-filters-summary .filter-btn:hover,
        .quick-filters-summary .filter-btn.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
        }

        .quick-filters-summary .filter-btn i {
            font-size: 0.8rem;
        }

        /* Page title consistency */
        .page-title {
            color: var(--text-primary);
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 20px;
        }

        /* Button styling */
        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
            color: #fff;
        }

        .btn-info:hover {
            background-color: #138496;
            border-color: #117a8b;
            color: #fff;
        }

        .btn-info:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5);
        }

        /* Light Mode H1 and Headers Text Colors for Products Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }

        /* Responsive adjustments for products page */
        @media (max-width: 768px) {
            .search-header-section {
                flex-direction: column;
                gap: 10px;
            }

            .search-header-section .search-bar {
                width: 100%;
                flex-direction: column;
                min-width: auto;
            }

            .search-header-section .search-bar .form-control,
            .search-header-section .search-bar .form-select {
                width: 100%;
                margin: 5px 0;
                flex-basis: auto;
            }

            .search-header-section .products-count {
                text-align: center;
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            .product-table .actions {
                flex-direction: column;
                gap: 5px;
            }

            .product-table .actions .btn {
                font-size: 0.7rem;
                padding: 4px 6px;
            }
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="main-content"> <!-- Removed layout-container for full width -->
            <div class="container-fluid"> <!-- Use container-fluid for full width content -->

                <h1 class="page-title" data-translate="product_management"><?php echo htmlspecialchars($translations['product_management'] ?? 'Product Management'); ?></h1>

                <!-- Search and Filter Section -->
                <section class="search-header-section">
                    <span class="products-count">
                        <span id="product-count-number"><?php echo htmlspecialchars($productCount); ?></span> <span data-translate="products_found"><?php echo htmlspecialchars($translations['products_found'] ?? 'products found'); ?></span>
                    </span>
                    <form class="search-bar" method="GET" action="products.php">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo htmlspecialchars($translations['search_products_placeholder'] ?? 'Search products...'); ?>" value="<?php echo htmlspecialchars($search); ?>" data-translate-placeholder="search_products_placeholder">
                        <select name="category" class="form-select" data-translate-title="all_categories_title">
                            <option value="" data-translate="all_categories"><?php echo htmlspecialchars($translations['all_categories'] ?? 'All Categories'); ?></option>
                            <?php foreach ($categories as $cat_item): ?>
                                <option value="<?php echo htmlspecialchars($cat_item['category_id']); ?>" <?php echo $category_filter_id === $cat_item['category_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat_item['category_name']); ?>
                                </option>
                        <?php endforeach; ?>
                            </select>
                        <select name="sort" class="form-select" data-translate-title="sort_by_title">
                            <option value="product_name_asc" <?php echo $sort === 'product_name_asc' ? 'selected' : ''; ?> data-translate="sort_name_asc"><?php echo htmlspecialchars($translations['sort_name_asc'] ?? 'Name A-Z'); ?></option>
                            <option value="product_name_desc" <?php echo $sort === 'product_name_desc' ? 'selected' : ''; ?> data-translate="sort_name_desc"><?php echo htmlspecialchars($translations['sort_name_desc'] ?? 'Name Z-A'); ?></option>
                            <option value="price_asc" <?php echo $sort === 'price_asc' ? 'selected' : ''; ?> data-translate="sort_price_asc"><?php echo htmlspecialchars($translations['sort_price_asc'] ?? 'Price Low-High'); ?></option>
                            <option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?> data-translate="sort_price_desc"><?php echo htmlspecialchars($translations['sort_price_desc'] ?? 'Price High-Low'); ?></option>
                            <option value="stock_asc" <?php echo $sort === 'stock_asc' ? 'selected' : ''; ?> data-translate="sort_stock_asc"><?php echo htmlspecialchars($translations['sort_stock_asc'] ?? 'Stock Low-High'); ?></option>
                            <option value="stock_desc" <?php echo $sort === 'stock_desc' ? 'selected' : ''; ?> data-translate="sort_stock_desc"><?php echo htmlspecialchars($translations['sort_stock_desc'] ?? 'Stock High-Low'); ?></option>
                            </select>
                        <button type="submit" class="btn btn-primary" data-translate="search_btn"><?php echo htmlspecialchars($translations['search'] ?? 'Search'); ?></button>
                    </form>
                    <?php if (isAdmin()): // Assuming isAdmin() function checks user role ?>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="#addCategoryModal" class="btn btn-info btn-sm" data-bs-toggle="modal" data-translate="add_category_btn" title="<?php echo htmlspecialchars($translations['add_category_tooltip'] ?? 'Add New Category'); ?>">
                                <i class="fas fa-tags me-1"></i> <?php echo htmlspecialchars($translations['add_category'] ?? 'Add Category'); ?>
                            </a>
                            <a href="#addProductModal" class="btn btn-success btn-sm" data-bs-toggle="modal" data-translate="add_product_btn" title="<?php echo htmlspecialchars($translations['add_product_tooltip'] ?? 'Add New Product'); ?>">
                               <i class="fas fa-plus me-1"></i> <?php echo htmlspecialchars($translations['add_product'] ?? 'Add Product'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </section>

                <!-- Success/Error Messages -->
                <?php if ($success_message): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($success_message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                <?php endif; ?>
                <?php if ($error_message): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($error_message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <!-- Products Table -->
                <section class="products-section">
                    <h3 data-translate="products_list_title"><?php echo htmlspecialchars($translations['products_list'] ?? 'Products List'); ?></h3>
                    <div class="table-container">
                        <?php if (empty($products)): ?>
                            <p class="text-center p-3" data-translate="no_products_found"><?php echo htmlspecialchars($translations['no_products'] ?? 'No products found matching your criteria.'); ?></p>
                        <?php else: ?>
                            <table class="product-table">
                            <thead>
                                <tr>
                                        <th data-translate="table_id"><?php echo htmlspecialchars($translations['id'] ?? 'ID'); ?></th>
                                        <th data-translate="table_product_name"><?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?></th>
                                        <th data-translate="table_category"><?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?></th>
                                        <th data-translate="table_description"><?php echo htmlspecialchars($translations['description'] ?? 'Description'); ?></th>
                                        <th data-translate="table_price"><?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?></th>
                                        <th data-translate="table_stock"><?php echo htmlspecialchars($translations['stock'] ?? 'Stock'); ?></th>
                                        <th data-translate="table_cost_price"><?php echo htmlspecialchars($translations['cost_price'] ?? 'Cost Price'); ?></th>
                                        <th data-translate="table_supplier"><?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?></th>
                                        <th data-translate="table_discount"><?php echo htmlspecialchars($translations['discount'] ?? 'Discount (%)'); ?></th>
                                        <th data-translate="table_barcode"><?php echo htmlspecialchars($translations['barcode'] ?? 'Barcode'); ?></th>
                                        <th data-translate="table_status"><?php echo htmlspecialchars($translations['status'] ?? 'Status'); ?></th>
                                        <th data-translate="table_image"><?php echo htmlspecialchars($translations['image'] ?? 'Image'); ?></th>
                                        <th data-translate="table_actions"><?php echo htmlspecialchars($translations['actions'] ?? 'Actions'); ?></th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td><?php echo (int)$product['product_id']; ?></td>
                                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['category_name'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars(mb_strimwidth($product['description'] ?? 'N/A', 0, 50, "...")); ?></td>
                                        <td data-base-price="<?php echo (float)($product['unit_price'] ?? 0); ?>">
                                            <?php
                                            $original_price = (float)($product['unit_price'] ?? 0);
                                            $discount_percentage = (float)($product['discount'] ?? 0);
                                            $discounted_price = $original_price * (1 - ($discount_percentage / 100));
                                            echo $currency_symbols[$currency] . ' ' . number_format($discounted_price * $exchange_rates[$currency], 2); // Display discounted price
                                            if ($discount_percentage > 0) {
                                                echo ' <span class="price-original">' . $currency_symbols[$currency] . ' ' . number_format($original_price * $exchange_rates[$currency], 2) . '</span>';
                                            }
                                            ?>
                                        </td>
                                        <td class="<?php echo ($product['stock_quantity'] == 0) ? 'stock-out' : (($product['stock_quantity'] <= 5) ? 'stock-low' : ''); ?>">
                                            <?php echo (int)$product['stock_quantity']; ?>
                                        </td>
                                            <td data-base-cost="<?php echo (float)($product['cost_price'] ?? 0); ?>"><?php echo $currency_symbols[$currency] . ' ' . number_format((float)$product['cost_price'] * $exchange_rates[$currency], 0); ?></td>
                                            <td><?php echo htmlspecialchars($product['supplier_name'] ?? 'N/A'); ?></td>
                                        <td data-base-discount="<?php echo (float)($product['discount'] ?? 0); ?>"><?php echo number_format((float)($product['discount'] ?? 0), 2); ?>%</td>
                                            <td><?php echo htmlspecialchars($product['barcode']); ?></td>
                                        <td>
                                           <span class="badge bg-<?php echo ($product['status'] === 'active') ? 'success' : 'secondary'; ?>">
                                                <?php echo htmlspecialchars($translations[$product['status']] ?? ucfirst($product['status'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="product-image-container">
                                                <img src="../public/images/<?php echo htmlspecialchars(!empty($product['image']) && $product['image'] !== 'default.jpg' ? $product['image'] : 'default.png'); ?>"
                                                     alt="<?php echo htmlspecialchars($product['product_name']); ?>"
                                                     class="product-image-thumb"
                                                     loading="lazy"
                                                     onload="this.style.opacity='1';"
                                                     onerror="handleImageError(this);">
                                            </div>
                                        </td>
                                            <td class="actions">
                                                <?php if (isAdmin()): ?>
                                                <a href="#editProductModal" class="btn btn-sm btn-details" data-bs-toggle="modal" data-product='<?php echo htmlspecialchars(json_encode($product), ENT_QUOTES, 'UTF-8'); ?>' title="<?php echo htmlspecialchars($translations['edit_tooltip'] ?? 'Edit Product'); ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                <form method="POST" action="products.php" style="display:inline;" onsubmit="return confirm('<?php echo htmlspecialchars($translations['confirm_delete_product'] ?? 'Are you sure you want to delete this product?'); ?>');">
                                                        <input type="hidden" name="product_id" value="<?php echo (int)$product['product_id']; ?>">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                     <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                                                    <input type="hidden" name="category" value="<?php echo htmlspecialchars($category_filter_id); ?>">
                                                    <input type="hidden" name="sort" value="<?php echo htmlspecialchars($sort); ?>">
                                                    <input type="hidden" name="stock_filter" value="<?php echo htmlspecialchars($stock_filter); ?>">
                                                    <button type="submit" name="delete_product" class="btn btn-sm btn-danger" title="<?php echo htmlspecialchars($translations['delete_tooltip'] ?? 'Delete Product'); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                <button class="btn btn-sm btn-info view-product-details" data-product-id="<?php echo (int)$product['product_id']; ?>" title="<?php echo htmlspecialchars($translations['view_details_tooltip'] ?? 'View Details'); ?>">
                                                        <i class="fas fa-info-circle"></i>
                                                    </button>
                                                <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                </div>
                </section>

                <!-- Product Summary Section -->
                <section class="product-summary-section">
                    <h4 data-translate="product_summary_title"><?php echo htmlspecialchars($translations['product_summary'] ?? 'Product Summary'); ?></h4>
                    <div class="summary-stats-grid">
                        <div class="stat-item">
                            <i class="fas fa-boxes"></i> <!-- Changed icon -->
                            <span class="label" data-translate="total_products_label"><?php echo htmlspecialchars($translations['total_products'] ?? 'Total Products'); ?></span>
                            <span class="value" id="summary_total_products"><?php echo $total_products_summary; ?></span>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-exclamation-circle"></i> <!-- Changed icon -->
                            <span class="label" data-translate="low_stock_label"><?php echo htmlspecialchars($translations['low_stock_alert'] ?? 'Low Stock Items'); ?></span>
                            <span class="value" id="summary_low_stock"><?php echo $low_stock_count_summary; ?></span>
                        </div>
                         <div class="stat-item">
                            <i class="fas fa-ban"></i> <!-- Icon for out of stock -->
                            <span class="label" data-translate="out_of_stock_label"><?php echo htmlspecialchars($translations['out_of_stock_items'] ?? 'Out of Stock Items'); ?></span>
                            <span class="value" id="summary_out_of_stock"><?php echo $out_of_stock_count_summary; ?></span>
                        </div>
            </div>
                    <div class="quick-filters-summary">
                        <button class="filter-btn <?php echo empty($stock_filter) ? 'active' : ''; ?>" data-filter="all" data-translate="filter_all">
                           <i class="fas fa-list"></i> <?php echo htmlspecialchars($translations['all'] ?? 'All'); ?>
                        </button>
                        <button class="filter-btn <?php echo $stock_filter === 'low' ? 'active' : ''; ?>" data-filter="low_stock" data-translate="filter_low_stock">
                           <i class="fas fa-battery-quarter"></i> <?php echo htmlspecialchars($translations['low_stock'] ?? 'Low Stock'); ?>
                        </button>
                        <button class="filter-btn <?php echo $stock_filter === 'out' ? 'active' : ''; ?>" data-filter="out_of_stock" data-translate="filter_out_of_stock">
                           <i class="fas fa-battery-empty"></i> <?php echo htmlspecialchars($translations['out_of_stock'] ?? 'Out of Stock'); ?>
                        </button>
        </div>
                </section>

            </div> <!-- End container-fluid -->
        </div> <!-- End main-content -->
    </div> <!-- End page-content-wrapper -->

        <!-- Footer -->
    <?php include BASEPATH . 'includes/footer.php'; // Shared footer ?>

    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCategoryModalLabel" data-translate="add_category_title"><?php echo htmlspecialchars($translations['add_category'] ?? 'Add New Category'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="products.php" id="addCategoryForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="category_name" class="form-label" data-translate="category_name_label"><?php echo htmlspecialchars($translations['category_name'] ?? 'Category Name'); ?></label>
                            <input type="text" name="category_name" id="category_name" class="form-control" required maxlength="50"
                                   placeholder="<?php echo htmlspecialchars($translations['category_name_placeholder'] ?? 'Enter category name'); ?>"
                                   data-translate-placeholder="category_name_placeholder">
                            <div class="form-text" data-translate="category_name_help"><?php echo htmlspecialchars($translations['category_name_help'] ?? 'Maximum 50 characters'); ?></div>
                        </div>
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close_btn"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
                        <button type="submit" name="add_category" class="btn btn-info" data-translate="add_category_submit_btn"><?php echo htmlspecialchars($translations['add_category'] ?? 'Add Category'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg"> <!-- Larger modal -->
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="addProductModalLabel" data-translate="add_product_title"><?php echo htmlspecialchars($translations['add_product'] ?? 'Add New Product'); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                <form method="POST" action="products.php" enctype="multipart/form-data" id="addProductForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="add_product_name" class="form-label" data-translate="product_name_label"><?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?></label>
                                <input type="text" name="product_name" id="add_product_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="add_category_id" class="form-label" data-translate="category_label"><?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?></label>
                                <select name="category_id" id="add_category_id" class="form-select">
                                    <option value="" data-translate="select_category_option"><?php echo htmlspecialchars($translations['select_category'] ?? 'Select Category'); ?></option>
                                    <?php foreach ($categories as $cat_item): ?>
                                        <option value="<?php echo htmlspecialchars($cat_item['category_id']); ?>"><?php echo htmlspecialchars($cat_item['category_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            </div>
                            <div class="mb-3">
                            <label for="add_description" class="form-label" data-translate="description_label"><?php echo htmlspecialchars($translations['description'] ?? 'Description'); ?></label>
                            <textarea name="description" id="add_description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="add_price" class="form-label" data-translate="price_label_usd"><?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?> (USD)</label>
                                <input type="number" name="price" id="add_price" class="form-control" step="0.01" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="add_cost_price" class="form-label" data-translate="cost_price_label_usd"><?php echo htmlspecialchars($translations['cost_price'] ?? 'Cost Price'); ?> (USD)</label>
                                <input type="number" name="cost_price" id="add_cost_price" class="form-control" step="0.01" value="0.00">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="add_stock_quantity" class="form-label" data-translate="stock_label"><?php echo htmlspecialchars($translations['stock'] ?? 'Stock Quantity'); ?></label>
                                <input type="number" name="stock_quantity" id="add_stock_quantity" class="form-control" required min="0">
                            </div>
                        </div>
                        <div class="row">
                             <div class="col-md-6 mb-3">
                                <label for="add_supplier_id" class="form-label" data-translate="supplier_label"><?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?></label>
                                <select name="supplier_id" id="add_supplier_id" class="form-select">
                                    <option value="" data-translate="select_supplier_option"><?php echo htmlspecialchars($translations['select_supplier'] ?? 'Select Supplier'); ?></option>
                                    <?php foreach ($suppliers as $sup_item): ?>
                                        <option value="<?php echo htmlspecialchars($sup_item['supplier_id']); ?>"><?php echo htmlspecialchars($sup_item['supplier_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="add_discount" class="form-label" data-translate="discount_label_percent"><?php echo htmlspecialchars($translations['discount'] ?? 'Discount (%)'); ?></label>
                                <input type="number" name="discount" id="add_discount" class="form-control" step="0.01" value="0.00" min="0" max="100">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="add_barcode" class="form-label" data-translate="barcode_label"><?php echo htmlspecialchars($translations['barcode'] ?? 'Barcode'); ?></label>
                                <input type="text" name="barcode" id="add_barcode" class="form-control" value="<?php echo generate_barcode(); // Assuming function exists ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="add_status" class="form-label" data-translate="status_label"><?php echo htmlspecialchars($translations['status'] ?? 'Status'); ?></label>
                                <select name="status" id="add_status" class="form-select">
                                    <option value="active" data-translate="status_active"><?php echo htmlspecialchars($translations['active'] ?? 'Active'); ?></option>
                                    <option value="inactive" data-translate="status_inactive"><?php echo htmlspecialchars($translations['inactive'] ?? 'Inactive'); ?></option>
                                </select>
                            </div>
                            </div>
                            <div class="mb-3">
                            <label for="add_image" class="form-label" data-translate="image_label"><?php echo htmlspecialchars($translations['image'] ?? 'Product Image'); ?></label>
                            <input type="file" name="image" id="add_image" class="form-control" accept="image/*">
                            </div>
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close_btn"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
                        <button type="submit" name="add_product" class="btn btn-primary" data-translate="add_product_submit_btn"><?php echo htmlspecialchars($translations['add_product'] ?? 'Add Product'); ?></button>
                    </div>
                </form>
                </div>
            </div>
        </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg"> <!-- Larger modal -->
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="editProductModalLabel" data-translate="edit_product_title"><?php echo htmlspecialchars($translations['edit_product'] ?? 'Edit Product'); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                <form method="POST" action="products.php" enctype="multipart/form-data" id="editProductForm">
                    <div class="modal-body">
                        <input type="hidden" name="product_id" id="edit_product_id">
                         <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_product_name" class="form-label" data-translate="product_name_label"><?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?></label>
                            <input type="text" name="product_name" id="edit_product_name" class="form-control" required>
                    </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_category_id" class="form-label" data-translate="category_label"><?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?></label>
                                <select name="category_id" id="edit_category_id" class="form-select">
                                    <option value="" data-translate="select_category_option"><?php echo htmlspecialchars($translations['select_category'] ?? 'Select Category'); ?></option>
                                    <?php foreach ($categories as $cat_item): ?>
                                        <option value="<?php echo htmlspecialchars($cat_item['category_id']); ?>"><?php echo htmlspecialchars($cat_item['category_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                </div>
            </div>
                        <div class="mb-3">
                            <label for="edit_description" class="form-label" data-translate="description_label"><?php echo htmlspecialchars($translations['description'] ?? 'Description'); ?></label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>
                         <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="edit_price" class="form-label" data-translate="price_label_usd"><?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?> (USD)</label>
                            <input type="number" name="price" id="edit_price" class="form-control" step="0.01" required>
        </div>
                             <div class="col-md-4 mb-3">
                                <label for="edit_cost_price" class="form-label" data-translate="cost_price_label_usd"><?php echo htmlspecialchars($translations['cost_price'] ?? 'Cost Price'); ?> (USD)</label>
                                <input type="number" name="cost_price" id="edit_cost_price" class="form-control" step="0.01">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_stock_quantity" class="form-label" data-translate="stock_label"><?php echo htmlspecialchars($translations['stock'] ?? 'Stock Quantity'); ?></label>
                                <input type="number" name="stock_quantity" id="edit_stock_quantity" class="form-control" required min="0">
                    </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_supplier_id" class="form-label" data-translate="supplier_label"><?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?></label>
                                <select name="supplier_id" id="edit_supplier_id" class="form-select">
                                    <option value="" data-translate="select_supplier_option"><?php echo htmlspecialchars($translations['select_supplier'] ?? 'Select Supplier'); ?></option>
                                    <?php foreach ($suppliers as $sup_item): ?>
                                        <option value="<?php echo htmlspecialchars($sup_item['supplier_id']); ?>"><?php echo htmlspecialchars($sup_item['supplier_name']); ?></option>
                        <?php endforeach; ?>
                            </select>
                    </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_discount" class="form-label" data-translate="discount_label_percent"><?php echo htmlspecialchars($translations['discount'] ?? 'Discount (%)'); ?></label>
                            <input type="number" name="discount" id="edit_discount" class="form-control" step="0.01" min="0" max="100">
                    </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_barcode" class="form-label" data-translate="barcode_label"><?php echo htmlspecialchars($translations['barcode'] ?? 'Barcode'); ?></label>
                            <input type="text" name="barcode" id="edit_barcode" class="form-control">
                </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_status" class="form-label" data-translate="status_label"><?php echo htmlspecialchars($translations['status'] ?? 'Status'); ?></label>
                                <select name="status" id="edit_status" class="form-select">
                                    <option value="active" data-translate="status_active"><?php echo htmlspecialchars($translations['active'] ?? 'Active'); ?></option>
                                    <option value="inactive" data-translate="status_inactive"><?php echo htmlspecialchars($translations['inactive'] ?? 'Inactive'); ?></option>
                            </select>
                            </div>
            </div>
                        <div class="mb-3">
                            <label for="edit_image" class="form-label" data-translate="image_label_current"><?php echo htmlspecialchars($translations['image'] ?? 'Product Image'); ?> (<span data-translate="leave_blank_note"><?php echo htmlspecialchars($translations['image_note'] ?? 'Leave blank to keep current'); ?></span>)</label>
                            <input type="file" name="image" id="edit_image" class="form-control" accept="image/*">
                            <img id="edit_current_image_preview" src="#" alt="<?php echo htmlspecialchars($translations['current_image_alt'] ?? 'Current Image'); ?>" style="max-width: 100px; margin-top: 10px; display: none;">
        </div>
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close_btn"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
                        <button type="submit" name="edit_product" class="btn btn-primary" data-translate="save_changes_btn"><?php echo htmlspecialchars($translations['save_changes'] ?? 'Save Changes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- View Product Details Modal (Example - if not using a separate page) -->
    <div class="modal fade" id="viewProductDetailsModal" tabindex="-1" aria-labelledby="viewProductDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewProductDetailsModalLabel" data-translate="product_details_title">Product Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="viewProductDetailsBody">
                    <!-- Product details will be loaded here by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close_btn">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Global variables for navbar integration
    window.translations = <?php echo json_encode($translations); ?>;
    window.currentCurrency = '<?php echo $currency; ?>';
    window.currentLanguage = '<?php echo $language; ?>';
    window.currencySymbols = <?php echo json_encode($currency_symbols); ?>;
    window.exchangeRates = <?php echo json_encode($exchange_rates); ?>;

    // Global update functions for navbar
    window.updatePageForNewCurrency = function(newCurrency, response) {
        window.currentCurrency = newCurrency;
        // Update all price/cost/discount UI in-place
        $('.product-table tbody tr').each(function() {
            // Price
            const $priceTd = $(this).find('td[data-base-price]');
            const basePrice = parseFloat($priceTd.data('base-price'));
            const discount = parseFloat($(this).find('td[data-base-discount]').data('base-discount')) || 0;
            if (!isNaN(basePrice)) {
                let discountedPrice = basePrice * (1 - (discount / 100));
                $priceTd.html(currencySymbols[newCurrency] + ' ' + (discountedPrice * exchangeRates[newCurrency]).toFixed(2) +
                    (discount > 0 ? ' <span class="price-original">' + currencySymbols[newCurrency] + ' ' + (basePrice * exchangeRates[newCurrency]).toFixed(2) + '</span>' : ''));
            }
            // Cost
            const $costTd = $(this).find('td[data-base-cost]');
            const baseCost = parseFloat($costTd.data('base-cost'));
            if (!isNaN(baseCost)) {
                $costTd.text(currencySymbols[newCurrency] + ' ' + (baseCost * exchangeRates[newCurrency]).toFixed(0));
            }
            // Discount
            const $discountTd = $(this).find('td[data-base-discount]');
            if (!isNaN(discount)) {
                $discountTd.text(discount.toFixed(2) + '%');
            }
        });
        updateUIText();
    };

    window.updatePageForNewLanguage = function(newLanguage, translationsObj) {
        window.currentLanguage = newLanguage;
        if (translationsObj) {
            window.translations = translationsObj;
        }
        updateUIText();
    };

    // updateUIText for all [data-translate] elements
    function updateUIText() {
        console.log('Updating UI text with translations:', translations);

        // Update text content
        $('[data-translate]').each(function() {
            const key = $(this).data('translate');
            if (translations[key]) {
                $(this).text(translations[key]);
                console.log('Updated text for key:', key, 'to:', translations[key]);
            }
        });

        // Update placeholders
        $('[data-translate-placeholder]').each(function() {
            const key = $(this).data('translate-placeholder');
            if (translations[key]) {
                $(this).attr('placeholder', translations[key]);
                console.log('Updated placeholder for key:', key, 'to:', translations[key]);
            }
        });

        // Update titles
        $('[data-translate-title]').each(function() {
            const key = $(this).data('translate-title');
            if (translations[key]) {
                $(this).attr('title', translations[key]);
                console.log('Updated title for key:', key, 'to:', translations[key]);
            }
        });

        // Update select options
        $('option[data-translate]').each(function() {
            const key = $(this).data('translate');
            if (translations[key]) {
                $(this).text(translations[key]);
                console.log('Updated option for key:', key, 'to:', translations[key]);
            }
        });

        // Update page title
        if (translations['product_management']) {
            document.title = translations['nav_products'] + ' - ' + (translations['system_name'] || 'BitsTech POS');
        }

        console.log('UI text update completed');
    }

    // Forced UI text update function
    function updateUITextForced() {
        console.log('=== FORCED UI UPDATE START ===');
        console.log('Current translations object:', window.translations);
        console.log('Current language:', window.currentLanguage);

        if (!window.translations || typeof window.translations !== 'object') {
            console.error('Translations object is invalid!');
            return;
        }

        // Force update all text elements
        $('[data-translate]').each(function() {
            const $element = $(this);
            const key = $element.data('translate');
            if (key && window.translations[key]) {
                const newText = window.translations[key];
                $element.text(newText);
                console.log('FORCED UPDATE - Key:', key, 'Old:', $element.text(), 'New:', newText);
            }
        });

        // Force update placeholders
        $('[data-translate-placeholder]').each(function() {
            const $element = $(this);
            const key = $element.data('translate-placeholder');
            if (key && window.translations[key]) {
                const newPlaceholder = window.translations[key];
                $element.attr('placeholder', newPlaceholder);
                console.log('FORCED UPDATE PLACEHOLDER - Key:', key, 'New:', newPlaceholder);
            }
        });

        // Force update titles
        $('[data-translate-title]').each(function() {
            const $element = $(this);
            const key = $element.data('translate-title');
            if (key && window.translations[key]) {
                const newTitle = window.translations[key];
                $element.attr('title', newTitle);
                console.log('FORCED UPDATE TITLE - Key:', key, 'New:', newTitle);
            }
        });

        // Force update select options
        $('option[data-translate]').each(function() {
            const $element = $(this);
            const key = $element.data('translate');
            if (key && window.translations[key]) {
                const newText = window.translations[key];
                $element.text(newText);
                console.log('FORCED UPDATE OPTION - Key:', key, 'New:', newText);
            }
        });

        // Force update specific elements by ID/class
        const specificUpdates = {
            '.page-title': 'product_management',
            'span[data-translate="products_found"]': 'products_found',
            'h3[data-translate="products_list_title"]': 'products_list',
            'h4[data-translate="product_summary_title"]': 'product_summary'
        };

        Object.keys(specificUpdates).forEach(selector => {
            const key = specificUpdates[selector];
            if (window.translations[key]) {
                $(selector).text(window.translations[key]);
                console.log('FORCED SPECIFIC UPDATE - Selector:', selector, 'Key:', key, 'Text:', window.translations[key]);
            }
        });

        // Update page title
        if (window.translations['nav_products'] && window.translations['system_name']) {
            document.title = window.translations['nav_products'] + ' - ' + window.translations['system_name'];
            console.log('FORCED UPDATE PAGE TITLE:', document.title);
        }

        console.log('=== FORCED UI UPDATE COMPLETE ===');
    }

    // Ultimate force update function - directly targets specific elements
    function forceUpdateAllElements() {
        console.log('🔄 FORCE UPDATE ALL ELEMENTS START');
        console.log('📚 Available translations:', window.translations);

        if (!window.translations) {
            console.error('❌ No translations available!');
            return;
        }

        // Direct element updates with specific selectors
        const updates = [
            // Page title
            { selector: 'h1.page-title', key: 'product_management', type: 'text' },
            { selector: '.page-title[data-translate="product_management"]', key: 'product_management', type: 'text' },

            // Products count
            { selector: 'span[data-translate="products_found"]', key: 'products_found', type: 'text' },

            // Search placeholder
            { selector: 'input[name="search"]', key: 'search_products_placeholder', type: 'placeholder' },

            // All Categories option
            { selector: 'option[data-translate="all_categories"]', key: 'all_categories', type: 'text' },

            // Table headers
            { selector: 'th[data-translate="table_id"]', key: 'id', type: 'text' },
            { selector: 'th[data-translate="table_product_name"]', key: 'product_name', type: 'text' },
            { selector: 'th[data-translate="table_category"]', key: 'category', type: 'text' },
            { selector: 'th[data-translate="table_description"]', key: 'description', type: 'text' },
            { selector: 'th[data-translate="table_price"]', key: 'price', type: 'text' },
            { selector: 'th[data-translate="table_stock"]', key: 'stock', type: 'text' },
            { selector: 'th[data-translate="table_cost_price"]', key: 'cost_price', type: 'text' },
            { selector: 'th[data-translate="table_supplier"]', key: 'supplier', type: 'text' },
            { selector: 'th[data-translate="table_discount"]', key: 'discount', type: 'text' },
            { selector: 'th[data-translate="table_barcode"]', key: 'barcode', type: 'text' },
            { selector: 'th[data-translate="table_status"]', key: 'status', type: 'text' },
            { selector: 'th[data-translate="table_image"]', key: 'image', type: 'text' },
            { selector: 'th[data-translate="table_actions"]', key: 'actions', type: 'text' },

            // Section titles
            { selector: 'h3[data-translate="products_list_title"]', key: 'products_list', type: 'text' },
            { selector: 'h4[data-translate="product_summary_title"]', key: 'product_summary', type: 'text' },

            // Buttons and labels
            { selector: 'button[data-translate="search_btn"]', key: 'search', type: 'text' },
            { selector: 'button[data-translate="filter_all"]', key: 'all', type: 'text' },
            { selector: 'button[data-translate="filter_low_stock"]', key: 'low_stock', type: 'text' },
            { selector: 'button[data-translate="filter_out_of_stock"]', key: 'out_of_stock', type: 'text' },

            // Sort options
            { selector: 'option[data-translate="sort_name_asc"]', key: 'sort_name_asc', type: 'text' },
            { selector: 'option[data-translate="sort_name_desc"]', key: 'sort_name_desc', type: 'text' },
            { selector: 'option[data-translate="sort_price_asc"]', key: 'sort_price_asc', type: 'text' },
            { selector: 'option[data-translate="sort_price_desc"]', key: 'sort_price_desc', type: 'text' },
            { selector: 'option[data-translate="sort_stock_asc"]', key: 'sort_stock_asc', type: 'text' },
            { selector: 'option[data-translate="sort_stock_desc"]', key: 'sort_stock_desc', type: 'text' }
        ];

        let updateCount = 0;
        updates.forEach(update => {
            const elements = $(update.selector);
            if (elements.length > 0 && window.translations[update.key]) {
                const newValue = window.translations[update.key];

                elements.each(function() {
                    if (update.type === 'text') {
                        $(this).text(newValue);
                    } else if (update.type === 'placeholder') {
                        $(this).attr('placeholder', newValue);
                    }
                });

                console.log(`✅ Updated ${elements.length} element(s) for "${update.key}": "${newValue}"`);
                updateCount++;
            } else if (elements.length === 0) {
                console.log(`⚠️ No elements found for selector: ${update.selector}`);
            } else {
                console.log(`⚠️ No translation found for key: ${update.key}`);
            }
        });

        // Update page title
        if (window.translations['nav_products']) {
            document.title = window.translations['nav_products'] + ' - ' + (window.translations['system_name'] || 'BitsTech POS');
            console.log('✅ Updated page title:', document.title);
            updateCount++;
        }

        console.log(`🎯 FORCE UPDATE COMPLETE: ${updateCount} updates applied`);
    }

    // Dynamic search function without page refresh
    function initializeDynamicSearch() {
        let searchTimeout;
        const $searchInput = $('input[name="search"]');
        const $categorySelect = $('select[name="category"]');
        const $sortSelect = $('select[name="sort"]');

        // Search input with debounce
        $searchInput.on('input', function() {
            clearTimeout(searchTimeout);
            const searchTerm = $(this).val();

            searchTimeout = setTimeout(function() {
                performDynamicSearch();
            }, 500); // 500ms delay
        });

        // Category filter change
        $categorySelect.on('change', function() {
            performDynamicSearch();
        });

        // Sort change
        $sortSelect.on('change', function() {
            performDynamicSearch();
        });

        // Stock filter buttons - Dynamic without page refresh
        $('.filter-btn').on('click', function(e) {
            e.preventDefault();

            console.log('🔘 Filter button clicked:', $(this).data('filter'));

            // Remove active class from all buttons
            $('.filter-btn').removeClass('active');
            // Add active class to clicked button
            $(this).addClass('active');

            // Perform dynamic search
            performDynamicSearch();
        });
    }

    // Perform dynamic search with AJAX
    function performDynamicSearch() {
        const searchData = {
            search: $('input[name="search"]').val(),
            category: $('select[name="category"]').val(),
            sort: $('select[name="sort"]').val(),
            stock_filter: $('.filter-btn.active').data('filter') || '',
            ajax_search: 1
        };

        console.log('🔍 Performing dynamic search:', searchData);

        // Show loading state
        showSearchLoading();

        $.ajax({
            url: 'products.php',
            method: 'GET',
            data: searchData,
            dataType: 'json',
            success: function(response) {
                console.log('✅ Search response:', response);

                if (response.success) {
                    updateProductTable(response.products);
                    updateProductSummary(response.summary);
                    updateProductsCount(response.total_count);
                } else {
                    console.error('❌ Search failed:', response.message);
                }

                hideSearchLoading();
            },
            error: function(xhr, status, error) {
                console.error('❌ Search AJAX error:', error);
                hideSearchLoading();
            }
        });
    }

    // Show search loading state
    function showSearchLoading() {
        $('.table-container').addClass('loading');
        $('.table-container').append('<div class="search-loading"><i class="fas fa-spinner fa-spin"></i> Searching...</div>');
    }

    // Hide search loading state
    function hideSearchLoading() {
        $('.table-container').removeClass('loading');
        $('.search-loading').remove();
    }

    // Update product table with new data
    function updateProductTable(products) {
        console.log('📊 Updating product table with', products.length, 'products');

        const $tbody = $('.product-table tbody');
        $tbody.empty();

        if (products.length === 0) {
            $tbody.append(`
                <tr>
                    <td colspan="13" class="text-center p-4">
                        <i class="fas fa-search"></i>
                        ${window.translations['no_products'] || 'No products found matching your criteria.'}
                    </td>
                </tr>
            `);
            return;
        }

        products.forEach(product => {
            const row = createProductRow(product);
            $tbody.append(row);
        });

        console.log('✅ Product table updated successfully');
    }

    // Create product row HTML
    function createProductRow(product) {
        const currencySymbol = window.currencySymbols[window.currentCurrency] || '$';
        const exchangeRate = window.exchangeRates[window.currentCurrency] || 1;

        // Calculate prices
        const originalPrice = parseFloat(product.unit_price || 0);
        const discountPercentage = parseFloat(product.discount || 0);
        const discountedPrice = originalPrice * (1 - (discountPercentage / 100));
        const costPrice = parseFloat(product.cost_price || 0);

        // Stock status classes
        let stockClass = '';
        if (product.stock_quantity == 0) stockClass = 'stock-out';
        else if (product.stock_quantity <= 5) stockClass = 'stock-low';

        // Status badge
        const statusClass = product.status === 'active' ? 'bg-success' : 'bg-secondary';
        const statusText = window.translations[product.status] || product.status;

        // Image
        const imageSrc = product.image && product.image !== 'default.jpg'
            ? `../public/images/${product.image}`
            : '../public/images/default.png';

        return `
            <tr>
                <td>${product.product_id}</td>
                <td>${product.product_name}</td>
                <td>${product.category_name || 'N/A'}</td>
                <td>${(product.description || 'N/A').substring(0, 50)}${product.description && product.description.length > 50 ? '...' : ''}</td>
                <td data-base-price="${originalPrice}">
                    ${currencySymbol} ${(discountedPrice * exchangeRate).toFixed(2)}
                    ${discountPercentage > 0 ? `<span class="price-original">${currencySymbol} ${(originalPrice * exchangeRate).toFixed(2)}</span>` : ''}
                </td>
                <td class="${stockClass}">${product.stock_quantity}</td>
                <td data-base-cost="${costPrice}">${currencySymbol} ${(costPrice * exchangeRate).toFixed(0)}</td>
                <td>${product.supplier_name || 'N/A'}</td>
                <td data-base-discount="${discountPercentage}">${discountPercentage.toFixed(2)}%</td>
                <td>${product.barcode || ''}</td>
                <td>
                    <span class="badge ${statusClass}">${statusText}</span>
                </td>
                <td>
                    <div class="product-image-container">
                        <img src="${imageSrc}" alt="${product.product_name}" class="product-image-thumb" loading="lazy" onerror="handleImageError(this);">
                    </div>
                </td>
                <td class="actions">
                    ${createActionButtons(product)}
                </td>
            </tr>
        `;
    }

    // Create action buttons based on user permissions
    function createActionButtons(product) {
        // Check if user is admin (you might need to pass this from PHP)
        const isAdmin = <?php echo json_encode(isAdmin()); ?>;

        if (isAdmin) {
            return `
                <a href="#editProductModal" class="btn btn-sm btn-details" data-bs-toggle="modal"
                   data-product='${JSON.stringify(product).replace(/'/g, "&#39;")}'
                   title="${window.translations['edit_tooltip'] || 'Edit Product'}">
                    <i class="fas fa-edit"></i>
                </a>
                <form method="POST" action="products.php" style="display:inline;"
                      onsubmit="return confirm('${window.translations['confirm_delete_product'] || 'Are you sure you want to delete this product?'}');">
                    <input type="hidden" name="product_id" value="${product.product_id}">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <button type="submit" name="delete_product" class="btn btn-sm btn-danger"
                            title="${window.translations['delete_tooltip'] || 'Delete Product'}">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            `;
        } else {
            return `
                <button class="btn btn-sm btn-info view-product-details" data-product-id="${product.product_id}"
                        title="${window.translations['view_details_tooltip'] || 'View Details'}">
                    <i class="fas fa-info-circle"></i>
                </button>
            `;
        }
    }

    // Update product summary
    function updateProductSummary(summary) {
        console.log('📈 Updating product summary:', summary);

        if (summary) {
            $('#summary_total_products').text(summary.total_products || 0);
            $('#summary_low_stock').text(summary.low_stock_count || 0);
            $('#summary_out_of_stock').text(summary.out_of_stock_count || 0);
        }
    }

    // Update products count
    function updateProductsCount(count) {
        console.log('🔢 Updating products count:', count);

        const countText = window.currentLanguage === 'mm'
            ? `${count} ${window.translations['products_found'] || 'ပစ္စည်းများ တွေ့ရှိသည်'}`
            : `${count} products found`;

        $('.products-count, span[data-translate="products_found"]').text(countText);
    }

    $(document).ready(function() {
        console.log('Products page ready - initializing...');

        // Initialize theme manager
        if (typeof ThemeManager !== 'undefined') {
            window.themeManager = new ThemeManager();
            window.themeManager.init();
            console.log('🎨 Products: Theme manager initialized');
        }

        // Set initial body class based on current language
        if (window.currentLanguage === 'mm') {
            $('body').addClass('myanmar-lang').attr('data-lang', 'mm');
        } else {
            $('body').removeClass('myanmar-lang').attr('data-lang', 'en');
        }

        // Wait for navbar to be fully loaded, then initialize functions
        setTimeout(function() {
            // Force re-initialize navbar functions for products page
            initializeProductsNavbarFunctions();
            console.log('Products page navbar functions initialized');
        }, 500);

        updateUIText(); // Apply translations on page load

        // Initialize dynamic search
        initializeDynamicSearch();

        // Add active class to current stock filter button if a filter is applied via URL
        const currentStockFilter = new URLSearchParams(window.location.search).get('stock_filter');
        if (currentStockFilter) {
            document.querySelectorAll('.quick-filters-summary .filter-btn').forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.filter === currentStockFilter || (currentStockFilter === 'low' && btn.dataset.filter === 'low_stock') || (currentStockFilter === 'out' && btn.dataset.filter === 'out_of_stock')) {
                    btn.classList.add('active');
                }
            });
        } else {
             const allFilterButton = document.querySelector('.quick-filters-summary .filter-btn[data-filter="all"]');
             if(allFilterButton) allFilterButton.classList.add('active');
        }

        // Edit product modal handler
        $('[data-bs-toggle="modal"][data-bs-target="#editProductModal"]').on('click', function() {
            const productData = JSON.parse($(this).attr('data-product'));
            populateEditForm(productData);

            // Show current image if exists
            if (productData.image && productData.image !== 'default.jpg') {
                $('#edit_current_image_preview').attr('src', '../public/images/' + productData.image).show();
            } else {
                $('#edit_current_image_preview').hide();
            }
        });

        // Quick filter buttons - Now handled by dynamic search in initializeDynamicSearch()
        // Old page refresh logic removed for better UX

        // View product details handler (for non-admin users)
        $('.view-product-details').on('click', function() {
            const productId = $(this).data('product-id');
            // You can implement product details view here
            console.log('View product details for ID:', productId);
        });
    });

    function showMessage(message, type) {
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const alert = $(`
            <div class="alert ${alertClass} alert-dismissible fade show position-fixed"
                 style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);

        $('body').append(alert);

        setTimeout(() => {
            alert.fadeOut(() => alert.remove());
        }, 5000);
    }

    function populateEditForm(productData) {
        document.getElementById('edit_product_name').value = productData.product_name;
        document.getElementById('edit_category_id').value = productData.category_id || '';
        document.getElementById('edit_description').value = productData.description || '';
        document.getElementById('edit_price').value = productData.unit_price;
        document.getElementById('edit_stock_quantity').value = productData.stock_quantity;
        document.getElementById('edit_cost_price').value = productData.cost_price;
        document.getElementById('edit_supplier_id').value = productData.supplier_id || '';
        document.getElementById('edit_discount').value = productData.discount;
        document.getElementById('edit_barcode').value = productData.barcode || '';
        document.getElementById('edit_status').value = productData.status;
        document.getElementById('edit_product_id').value = productData.product_id;
    }

    // Custom alert function for products page
    function showCustomAlert(message, type = 'success') {
        $('.custom-alert').remove();
        const alertDiv = $('<div>').addClass('custom-alert ' + type);
        const icon = type === 'success' ? 'check-circle' : 'exclamation-circle';
        alertDiv.html(`<i class="fas fa-${icon}"></i>${message}`);
        $('body').append(alertDiv);
        setTimeout(() => alertDiv.addClass('show'), 100);
        setTimeout(() => {
            alertDiv.removeClass('show');
            setTimeout(() => alertDiv.remove(), 300);
        }, 3000);
    }

    // Products page specific navbar functions
    function initializeProductsNavbarFunctions() {
        console.log('Initializing products page navbar functions...');

        // Remove any existing event handlers to prevent duplicates
        $(document).off('click', '.calculator-toggle, #calculator-btn');
        $(document).off('click', '.language-item');
        $(document).off('change', '#currency-select');

        // Calculator toggle
        $(document).on('click', '.calculator-toggle, #calculator-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Calculator clicked on products page!');

            const overlay = $('#calculator-overlay');
            if (overlay.length) {
                overlay.toggleClass('active');
                console.log('Calculator overlay active:', overlay.hasClass('active'));

                // Visual feedback
                $(this).addClass('clicked');
                setTimeout(() => $(this).removeClass('clicked'), 200);
            } else {
                console.error('Calculator overlay not found!');
            }
        });

        // Language switcher - Debug version
        console.log('Setting up language switcher...');
        console.log('Language button found:', $('.language-btn').length);
        console.log('Language items found:', $('.language-item').length);
        console.log('Language menu found:', $('.language-menu').length);

        // Remove any existing handlers first
        $(document).off('click', '.language-item');
        $(document).off('click', '.language-btn');

        // Add language button click handler to show dropdown
        $(document).on('click', '.language-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Language button clicked!');

            const menu = $('.language-menu');
            if (menu.hasClass('show')) {
                menu.removeClass('show');
                console.log('Language menu hidden');
            } else {
                menu.addClass('show');
                console.log('Language menu shown');
            }
        });

        // Simple and reliable language switcher
        $(document).on('click', '.language-item', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const newLanguage = $(this).data('lang');
            console.log('🌐 Language switch requested:', newLanguage);

            if (!newLanguage) {
                console.error('❌ No language data found!');
                return;
            }

            // Show loading state
            const $languageBtn = $('.language-label');
            const originalText = $languageBtn.text();
            $languageBtn.text('...');

            // AJAX request
            $.ajax({
                url: 'update_language.php',
                method: 'POST',
                data: {
                    language: newLanguage,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                timeout: 10000,
                success: function(response) {
                    console.log('✅ AJAX Success:', response);

                    if (response && response.success && response.translations) {
                        // Update global state
                        window.currentLanguage = newLanguage;
                        window.translations = response.translations;

                        console.log('📝 Translations loaded:', Object.keys(response.translations).length, 'keys');

                        // Update body class for Myanmar font
                        if (newLanguage === 'mm') {
                            $('body').addClass('myanmar-lang').attr('data-lang', 'mm');
                        } else {
                            $('body').removeClass('myanmar-lang').attr('data-lang', 'en');
                        }

                        // Update language button
                        $languageBtn.text(newLanguage === 'en' ? 'EN' : 'MM');

                        // Force update all UI elements immediately
                        forceUpdateAllElements();

                        // Hide dropdown
                        $('.language-menu').removeClass('show');

                        // Success message
                        showCustomAlert('✅ Language updated!', 'success');

                        console.log('🎉 Language switch completed successfully!');
                    } else {
                        console.error('❌ Invalid response:', response);
                        $languageBtn.text(originalText);
                        alert('Failed to update language');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('❌ AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    $languageBtn.text(originalText);
                    alert('Network error. Please try again.');
                }
            });
        });

        // Close language menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.language-toggle').length) {
                $('.language-menu').removeClass('show');
            }
        });

        console.log('Language switcher setup complete');

        // Currency change handler - Dynamic update
        $(document).on('change', '#currency-select', function() {
            console.log('Currency changed on products page:', $(this).val());

            const newCurrency = $(this).val();
            const $select = $(this);

            // Add loading state
            $select.prop('disabled', true);

            $.ajax({
                url: 'update_currency.php',
                method: 'POST',
                data: {
                    currency: newCurrency,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        console.log('Currency updated successfully! Updating UI...');

                        // Update global variables
                        window.currentCurrency = newCurrency;
                        if (response.exchange_rates) {
                            window.exchangeRates = response.exchange_rates;
                        }
                        if (response.currency_symbols) {
                            window.currencySymbols = response.currency_symbols;
                        }

                        // Update page content with new currency
                        if (typeof updatePageForNewCurrency === 'function') {
                            updatePageForNewCurrency(newCurrency, response);
                        }

                        // Show success message
                        showCustomAlert('Currency updated successfully!', 'success');

                        console.log('Currency UI updated successfully!');
                    } else {
                        console.error('Currency update failed:', response.message);
                        alert('Failed to update currency: ' + (response.message || 'Unknown error'));
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Currency update error:', error);
                    alert('Error updating currency: ' + error);
                },
                complete: function() {
                    // Re-enable select
                    $select.prop('disabled', false);
                }
            });
        });

        console.log('Products page navbar functions initialized successfully!');

        // Initialize notification bell visibility immediately
        if (typeof window.updateNotificationBellVisibility === 'function') {
            window.updateNotificationBellVisibility();
            console.log('🔔 Products: Notification bell visibility updated');
        }
    }

    console.log('Products page JavaScript loaded successfully');
    </script>
    <script>
    // Global image error handler for <img ... onerror="handleImageError(this);">
    function handleImageError(img) {
        if (!img.src.includes('default.png')) {
            img.src = '../public/images/default.png'; // Use default.png instead of default.jpg
        } else {
            img.style.display = 'none';
            if (img.parentElement) img.parentElement.style.background = '#2D314D';
        }
        img.style.opacity = '1';
    }
    </script>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Place this just before </body> -->
    <script src="../public/js/navbar-functions.js"></script>
</body>
</html>