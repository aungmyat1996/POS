<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get settings
try {
    $stmt_settings_dashboard = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings_array_dashboard = $stmt_settings_dashboard->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $settings_array_dashboard = [];
}

$language = $_SESSION['language'] ?? ($settings_array_dashboard['language'] ?? 'en');
$translations = loadLanguage($language);
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];
$currency = $_SESSION['currency'] ?? ($settings_array_dashboard['currency'] ?? 'USD');

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= reorder_level");
    $low_stock_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $low_stock_count = 0;
}
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products");
    $total_products = $stmt->fetchColumn();
} catch (PDOException $e) {
    $total_products = 0;
}
try {
    $stmt = $pdo->query("SELECT COUNT(DISTINCT customer_id) FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND status = 'completed' AND customer_id IS NOT NULL");
    $today_customers_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $today_customers_count = 0;
}
try {
    $stmt = $pdo->query("SELECT SUM(total_amount) FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    $today_sales_total = $stmt->fetchColumn() ?: 0;
} catch (PDOException $e) {
    $today_sales_total = 0;
}
try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales FROM sales s WHERE MONTH(s.sale_date) = MONTH(CURDATE()) AND YEAR(s.sale_date) = YEAR(CURDATE())");
    $monthly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $monthly_sales_total = 0;
}
try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales FROM sales s WHERE YEAR(s.sale_date) = YEAR(CURDATE())");
    $yearly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $yearly_sales_total = 0;
}
try {
    $stmt = $pdo->query("SELECT s.sale_id, s.order_id, c.customer_name AS customer_name, s.total_amount, s.sale_date FROM sales s LEFT JOIN customers c ON s.customer_id = c.customer_id ORDER BY s.sale_date DESC LIMIT 5");
    $recent_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $recent_sales = [];
}
$selected_date = $_POST['sale_date'] ?? date('Y-m-d');
try {
    $stmt = $pdo->prepare("SELECT s.sale_id, c.customer_name AS customer_name, s.total_amount, s.sale_date FROM sales s LEFT JOIN customers c ON s.customer_id = c.customer_id WHERE DATE(s.sale_date) = ? ORDER BY s.sale_date DESC");
    $stmt->execute([$selected_date]);
    $customer_sales_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $customer_sales_history = [];
}
try {
    $stmt = $pdo->query("SELECT category_name, COUNT(*) as count FROM products JOIN categories ON products.category_id = categories.category_id GROUP BY category_name");
    $category_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $category_distribution = [];
}
try {
    $stmt = $pdo->query("SELECT p.product_name, SUM(oi.quantity) as total_sold FROM order_items oi JOIN products p ON oi.product_id = p.product_id JOIN orders o ON oi.order_id = o.order_id GROUP BY p.product_id, p.product_name ORDER BY total_sold DESC LIMIT 5");
    $top_selling_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $top_selling_products = [];
}
$sales_trend = [];
$today = new DateTime();
for ($i = 6; $i >= 0; $i--) {
    $date = clone $today;
    $date->modify("-$i days");
    try {
        $stmt = $pdo->prepare("SELECT SUM(total_amount) as total FROM sales WHERE DATE(sale_date) = ?");
        $stmt->execute([$date->format('Y-m-d')]);
        $sales_trend[$date->format('Y-m-d')] = $stmt->fetchColumn() ?: 0;
    } catch (PDOException $e) {
        $sales_trend[$date->format('Y-m-d')] = 0;
    }
}
try {
    $stmt = $pdo->query("SELECT product_name, stock_quantity FROM products WHERE stock_quantity <= 5 LIMIT 5");
    $low_stock_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $low_stock_products = [];
}
try {
    $stmt = $pdo->query("SELECT l.action, u.username AS user, l.created_at AS timestamp FROM logs l JOIN users u ON l.user_id = u.user_id ORDER BY l.created_at DESC LIMIT 5");
    $activity_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $activity_logs = [];
}
header('Content-Type: application/json');
echo json_encode([
    'total_products' => $total_products,
    'low_stock_count' => $low_stock_count,
    'today_customers_count' => $today_customers_count,
    'today_sales_total' => $today_sales_total,
    'monthly_sales_total' => $monthly_sales_total,
    'yearly_sales_total' => $yearly_sales_total,
    'customer_sales_history' => $customer_sales_history,
    'category_distribution' => $category_distribution,
    'top_selling_products' => $top_selling_products,
    'sales_trend' => $sales_trend,
    'low_stock_products' => $low_stock_products,
    'recent_sales' => $recent_sales,
    'activity_logs' => $activity_logs,
    'currency' => $currency,
    'language' => $language,
    'exchange_rates' => $exchange_rates,
    'currency_symbols' => $currency_symbols
]); 