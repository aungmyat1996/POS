<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
// Check if this file is accessed directly
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    die('Direct access to this file is not allowed.');
}

// Ensure user is logged in
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    header("Location: products.php?error=Invalid CSRF token");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    
    // Validate and sanitize input
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $product_name = filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_STRING);
    $category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $stock_quantity = filter_input(INPUT_POST, 'stock_quantity', FILTER_VALIDATE_INT);
    $cost_price = filter_input(INPUT_POST, 'cost_price', FILTER_VALIDATE_FLOAT);
    $supplier_id = filter_input(INPUT_POST, 'supplier_id', FILTER_VALIDATE_INT);
    $discount = filter_input(INPUT_POST, 'discount', FILTER_VALIDATE_FLOAT);
    $barcode = filter_input(INPUT_POST, 'barcode', FILTER_SANITIZE_STRING);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

    // Get current product data
    try {
        $stmt = $pdo->prepare("SELECT image FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $current_product = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching current product: " . $e->getMessage());
        header("Location: products.php?error=Failed to fetch product data");
        exit();
    }

    // Handle image upload
    $image = $current_product['image']; // Keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $errors[] = "Invalid file type. Only JPG, PNG and GIF are allowed.";
        } else {
            $image = uniqid() . '_' . basename($_FILES['image']['name']);
            $upload_path = "../public/images/" . $image;
            
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $errors[] = "Failed to upload image.";
                $image = $current_product['image']; // Keep existing image if upload fails
            } else {
                // Delete old image if it's not the default image
                if ($current_product['image'] !== 'default.jpg' && file_exists("../public/images/" . $current_product['image'])) {
                    unlink("../public/images/" . $current_product['image']);
                }
            }
        }
    }

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE products SET 
                product_name = ?, 
                category_id = ?, 
                description = ?, 
                price = ?, 
                stock_quantity = ?, 
                cost_price = ?, 
                supplier_id = ?, 
                discount = ?, 
                barcode = ?, 
                image = ?, 
                status = ?, 
                updated_at = NOW() 
                WHERE product_id = ?");
            
            $stmt->execute([
                $product_name,
                $category_id,
                $description,
                $price,
                $stock_quantity,
                $cost_price,
                $supplier_id,
                $discount,
                $barcode,
                $image,
                $status,
                $product_id
            ]);

            header("Location: products.php?success=Product updated successfully");
            exit();
        } catch (PDOException $e) {
            error_log("Error updating product: " . $e->getMessage());
            header("Location: products.php?error=Failed to update product");
            exit();
        }
    } else {
        $_SESSION['errors'] = $errors;
        header("Location: products.php");
        exit();
    }
}

// If not POST request, redirect to products page
header("Location: products.php");
exit();
?>