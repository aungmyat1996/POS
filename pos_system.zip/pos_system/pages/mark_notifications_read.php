<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    try {
        // Get user language for translations
        $language = $_SESSION['language'] ?? 'en';
        $translations = [];

        try {
            if (function_exists('loadLanguage')) {
                $translations = loadLanguage($language);
            }
        } catch (Exception $e) {
            error_log("Error loading translations: " . $e->getMessage());
        }

        // Log the request
        error_log("Mark notifications as read request from user ID: " . $_SESSION['user_id']);

        if (markNotificationsAsRead($pdo, $_SESSION['user_id'])) {
            echo json_encode([
                'success' => true,
                'message' => $translations['notifications_cleared'] ?? 'All notifications have been marked as read'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => $translations['error_clearing_notifications'] ?? 'Failed to mark notifications as read'
            ]);
        }
    } catch (Exception $e) {
        error_log("Error marking notifications as read: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => 'An error occurred while clearing notifications'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request or user not logged in'
    ]);
}
?>