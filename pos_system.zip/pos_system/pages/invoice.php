<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Default values (let navbar.php handle system_name from database)
$logo_path = isset($_SESSION['logo_path']) ? $_SESSION['logo_path'] : '../public/images/logo.png';
// $system_name will be handled by navbar.php from database

// Currency handling
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency = isset($_SESSION['currency']) ? $_SESSION['currency'] : 'USD';

// Fetch cart, customer info, tax, and shipping from session
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$customer_info = $_SESSION['customer_info'] ?? ['name' => '', 'address' => '', 'phone' => ''];
$tax = isset($_SESSION['tax']) ? floatval($_SESSION['tax']) : 0;
$shipping = isset($_SESSION['shipping']) ? floatval($_SESSION['shipping']) : 0;

// Calculate totals
$cart_items = [];
$subtotal = 0;
$discount = 0;

if (!empty($cart)) {
    $placeholders = implode(',', array_fill(0, count(array_keys($cart)), '?'));
    $stmt = $pdo->prepare("SELECT product_id, product_name, price, discount FROM products WHERE product_id IN ($placeholders)");
    $stmt->execute(array_keys($cart));
    $cart_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cart_products as $product) {
        $item_discount = $product['discount'] ?? 0;
        $item_total = $product['price'] * ($cart[$product['product_id']] ?? 1) * (1 - ($item_discount / 100));
        $cart_items[] = [
            'product_id' => $product['product_id'],
            'product_name' => $product['product_name'],
            'price' => $product['price'],
            'discount' => $item_discount,
            'quantity' => $cart[$product['product_id']] ?? 1,
            'total' => $item_total
        ];
        $subtotal += $item_total;
        $discount += ($product['price'] * ($cart[$product['product_id']] ?? 1) * ($item_discount / 100));
    }
}

$total = $subtotal + $tax + $shipping - $discount;

// Save the sale to the database (simplified example)
$invoice_id = 'INV-' . time(); // Unique invoice ID
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_invoice'])) {
    $stmt = $pdo->prepare("INSERT INTO sales (invoice_id, user_id, customer_name, total_amount, sale_date) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$invoice_id, $user_id, $customer_info['name'], $total]);

    $order_id = $pdo->lastInsertId();
    foreach ($cart_items as $item) {
        $stmt = $pdo->prepare("INSERT INTO orders (order_id, product_id, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$order_id, $item['product_id'], $item['quantity'], $item['price'], $item['total']]);
    }

    // Clear session data after saving
    $_SESSION['cart'] = [];
    $_SESSION['customer_info'] = ['name' => '', 'address' => '', 'phone' => ''];
    $_SESSION['tax'] = 0;
    $_SESSION['shipping'] = 0;

    header("Location: invoice.php?success=1&invoice_id=" . $invoice_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>BitsTech POS - Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <style>
        :root {
            --primary-bg: #1A1D2E;
            --card-bg: #21243A;
            --text-primary: #FFFFFF;
            --text-secondary: #D1D5DB;
            --accent: <?php echo $theme_color; ?>;
            --border-color: #2D314D;
            --gradient-start: #F97316;
            --gradient-end: #FF4D4F;
            --sidebar-width: 80px;
            --navbar-height: 60px;
        }

        body {
            background: var(--primary-bg);
            font-family: 'Inter', sans-serif;
            color: var(--text-secondary);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        .left-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--card-bg);
            border-right: 1px solid var(--border-color);
            padding-top: 20px;
            z-index: 1000;
            box-sizing: border-box;
        }

        .left-sidebar .logo-container {
            text-align: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .left-sidebar .logo-container img {
            max-width: 100%;
            height: auto;
        }

        .left-sidebar .system-name {
            text-align: center;
            margin-top: 5px;
            color: var(--text-primary);
            font-size: 0.8rem;
            font-weight: 500;
        }

        .left-sidebar .nav-link {
            color: var(--text-secondary);
            padding: 15px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.3s ease;
            position: relative;
        }

        .left-sidebar .nav-link:hover,
        .left-sidebar .nav-link.active {
            color: var(--accent);
            background: #2D314D;
        }

        .left-sidebar .nav-link i {
            font-size: 0.9rem;
        }

        .left-sidebar .nav-link .nav-label {
            display: none;
        }

        .left-sidebar .nav-link:hover::after {
            content: attr(data-label);
            position: absolute;
            left: 90px;
            background: #2D314D;
            color: var(--text-primary);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9rem;
            white-space: nowrap;
            z-index: 1000;
        }

        .navbar-top {
            background: var(--card-bg);
            border-bottom: 1px solid var(--border-color);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: var(--sidebar-width);
            right: 0;
            height: var(--navbar-height);
            z-index: 1000;
            box-sizing: border-box;
        }

        .navbar-top .nav-left {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .navbar-top .nav-right {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-left: -20px;
        }

        .navbar-top .nav-link {
            color: var(--text-primary);
            font-weight: 500;
            display: flex;
            align-items: center;
            font-size: 0.8rem;
            cursor: pointer;
        }

        .navbar-top .nav-link:hover {
            color: var(--accent);
        }

        .navbar-top .nav-link i {
            margin-right: 5px;
        }

        .navbar-top .datetime {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .main-content {
            margin-top: var(--navbar-height);
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
            padding: 20px;
            box-sizing: border-box;
        }

        .invoice-container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            color: var(--text-primary);
            max-width: 800px;
            margin: 0 auto;
        }

        .invoice-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .invoice-header img {
            max-width: 150px;
            margin-bottom: 10px;
        }

        .invoice-header .invoice-id-date {
            text-align: left;
            font-size: 0.9rem;
        }

        .invoice-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .invoice-details div {
            font-size: 0.8rem;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .invoice-table th,
        .invoice-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .invoice-table th {
            background: var(--accent);
            color: var(--text-primary);
        }

        .invoice-summary {
            text-align: right;
            font-size: 0.9rem;
        }

        .invoice-summary .summary-row {
            margin-bottom: 10px;
        }

        .invoice-summary .total {
            font-size: 1.2rem;
            font-weight: bold;
            color: #28a745;
        }

        .invoice-actions {
            text-align: center;
            margin-top: 20px;
        }

        .invoice-actions .btn {
            font-size: 0.9rem;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .invoice-actions .btn-save {
            background: #28a745;
            border: none;
        }

        .invoice-actions .btn-save:hover {
            background: #218838;
        }

        .invoice-actions .btn-print {
            background: var(--accent);
            border: none;
        }

        .invoice-actions .btn-print:hover {
            background: #e55b0a;
        }

        .alert-success {
            background: #28a745;
            color: var(--text-primary);
            text-align: center;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .invoice-details {
                flex-direction: column;
                gap: 15px;
            }
            .invoice-table th,
            .invoice-table td {
                font-size: 0.7rem;
                padding: 8px;
            }
            .invoice-summary {
                font-size: 0.8rem;
            }
            .invoice-summary .total {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="left-sidebar">
        <div class="logo-container">
            <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="Logo" onerror="this.src='../public/images/default-logo.png';">
            <div class="system-name"><?php echo htmlspecialchars($system_name); ?></div>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="home.php" data-label="Home"><i class="fas fa-home"></i><span class="nav-label">Home</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php" data-label="Dashboard"><i class="fas fa-tachometer-alt"></i><span class="nav-label">Dashboard</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="products.php" data-label="Products"><i class="fas fa-box"></i><span class="nav-label">Products</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="sales.php" data-label="Sales"><i class="fas fa-shopping-cart"></i><span class="nav-label">Sales</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="reports.php" data-label="Reports"><i class="fas fa-chart-line"></i><span class="nav-label">Reports</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inventory.php" data-label="Inventory"><i class="fas fa-warehouse"></i><span class="nav-label">Inventory</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="users.php" data-label="Users"><i class="fas fa-users"></i><span class="nav-label">Users</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="settings.php" data-label="Settings"><i class="fas fa-cog"></i><span class="nav-label">Settings</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php" data-label="Logout"><i class="fas fa-sign-out-alt"></i><span class="nav-label">Logout</span></a>
            </li>
        </ul>
    </div>

    <nav class="navbar-top">
        <div class="nav-left">
            <span class="datetime">
                <?php
                $currentDateTime = new DateTime("now", new DateTimeZone('+0800'));
                echo $currentDateTime->format('l, F j, Y, h:i A T');
                ?>
            </span>
        </div>
        <div class="nav-right">
            <a class="nav-link" href="profile.php">
                <i class="fas fa-user"></i> <?php echo htmlspecialchars($user['username'] ?? 'User'); ?>
            </a>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
                <div class="alert-success">
                    Invoice saved successfully! Invoice ID: <?php echo htmlspecialchars($_GET['invoice_id']); ?>
                </div>
            <?php endif; ?>

            <div class="invoice-container">
                <div class="invoice-header">
                    <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="Logo" onerror="this.src='../public/images/default-logo.png';">
                    <div class="invoice-id-date">
                        <p>Invoice ID: <?php echo $invoice_id; ?></p>
                        <p>Date: <?php echo date('Y-m-d H:i:s'); ?></p>
                    </div>
                </div>

                <div class="invoice-details">
                    <div>
                        <p><strong>Sold By:</strong></p>
                        <p><?php echo htmlspecialchars($system_name); ?></p>
                        <p>Username: <?php echo htmlspecialchars($user['username'] ?? 'Unknown'); ?></p>
                    </div>
                    <div>
                        <p><strong>Billed To:</strong></p>
                        <p>Name: <?php echo htmlspecialchars($customer_info['name'] ?? 'N/A'); ?></p>
                        <p>Address: <?php echo htmlspecialchars($customer_info['address'] ?? 'N/A'); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($customer_info['phone'] ?? 'N/A'); ?></p>
                    </div>
                </div>

                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($cart_items)): ?>
                            <tr>
                                <td colspan="4" class="text-center">No items in the invoice.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($cart_items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo format_currency($item['price'], $currency, $exchange_rates, $item['discount']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td><?php echo format_currency($item['total'], $currency, $exchange_rates); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="invoice-summary">
                    <div class="summary-row">Subtotal: <?php echo format_currency($subtotal, $currency, $exchange_rates); ?></div>
                    <div class="summary-row">Tax: <?php echo format_currency($tax, $currency, $exchange_rates); ?></div>
                    <div class="summary-row">Discount: <?php echo format_currency($discount, $currency, $exchange_rates); ?></div>
                    <div class="summary-row">Shipping: <?php echo format_currency($shipping, $currency, $exchange_rates); ?></div>
                    <div class="summary-row total">Total: <?php echo format_currency($total, $currency, $exchange_rates); ?></div>
                </div>

                <div class="invoice-actions">
                    <form method="POST">
                        <button type="submit" name="save_invoice" class="btn btn-save"><i class="fas fa-save"></i> Save Invoice</button>
                        <button type="button" class="btn btn-print" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>