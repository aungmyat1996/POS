<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

requireAuth();

// Set timezone
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute(['timezone']);
    $timezone = $stmt->fetchColumn() ?: 'Asia/Yangon';
    date_default_timezone_set($timezone);
} catch (PDOException $e) {
    error_log("Error fetching timezone setting: " . $e->getMessage());
    date_default_timezone_set('Asia/Yangon');
}

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values
$currency = $_SESSION['currency'] ?? ($settings['currency'] ?? 'USD');
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');

// Currency symbols and exchange rates
$currency_symbols = [
    'USD' => '$',
    'THB' => '฿',
    'MMK' => 'Ks'
];

$exchange_rates = [
    'USD' => 1,
    'THB' => 33,
    'MMK' => 2100
];

// Load language file
$language_file = "../languages/{$language}.php";
$translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {
            case 'get_products':
                $products = getProducts($pdo);
                echo json_encode(['success' => true, 'data' => $products]);
                break;

            case 'get_categories':
                $categories = getCategories($pdo);
                echo json_encode(['success' => true, 'data' => $categories]);
                break;

            case 'get_suppliers':
                $suppliers = getSuppliers($pdo);
                echo json_encode(['success' => true, 'data' => $suppliers]);
                break;

            case 'add_product':
                validateProductData($_POST);
                $product_id = addProduct($pdo, $_POST);
                echo json_encode(['success' => true, 'message' => 'Product added successfully', 'product_id' => $product_id]);
                break;

            case 'update_product':
                validateProductData($_POST);
                updateProduct($pdo, $_POST);
                echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
                break;

            case 'delete_product':
                if (!isset($_POST['product_id'])) {
                    throw new Exception('Product ID is required');
                }
                deleteProduct($pdo, $_POST['product_id']);
                echo json_encode(['success' => true, 'message' => 'Product deleted successfully']);
                break;

            case 'update_stock':
                if (!isset($_POST['product_id']) || !isset($_POST['quantity'])) {
                    throw new Exception('Product ID and quantity are required');
                }
                updateStock($pdo, $_POST['product_id'], $_POST['quantity']);
                echo json_encode(['success' => true, 'message' => 'Stock updated successfully']);
                break;

            case 'add_category':
                if (!isset($_POST['category_name']) || trim($_POST['category_name']) === '') {
                    throw new Exception('Category name is required');
                }
                $category_id = addCategory($pdo, $_POST['category_name']);
                echo json_encode(['success' => true, 'message' => 'Category added successfully', 'category_id' => $category_id]);
                break;

            case 'delete_category':
                if (!isset($_POST['category_id'])) {
                    throw new Exception('Category ID is required');
                }
                deleteCategory($pdo, $_POST['category_id']);
                echo json_encode(['success' => true, 'message' => 'Category deleted successfully']);
                break;

            case 'add_supplier':
                if (!isset($_POST['supplier_name']) || trim($_POST['supplier_name']) === '') {
                    throw new Exception('Supplier name is required');
                }
                $supplier_id = addSupplier($pdo, $_POST);
                echo json_encode(['success' => true, 'message' => 'Supplier added successfully', 'supplier_id' => $supplier_id]);
                break;

            case 'delete_supplier':
                if (!isset($_POST['supplier_id'])) {
                    throw new Exception('Supplier ID is required');
                }
                deleteSupplier($pdo, $_POST['supplier_id']);
                echo json_encode(['success' => true, 'message' => 'Supplier deleted successfully']);
                break;

            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Helper Functions
function validateProductData($data) {
    $required_fields = ['product_name', 'category_id', 'sku', 'unit_price', 'stock_quantity', 'reorder_level'];
    foreach ($required_fields as $field) {
        if (!isset($data[$field]) || trim($data[$field]) === '') {
            throw new Exception("$field is required");
        }
    }

    if (!is_numeric($data['unit_price']) || $data['unit_price'] < 0) {
        throw new Exception('Invalid unit price');
    }

    if (!is_numeric($data['stock_quantity']) || $data['stock_quantity'] < 0) {
        throw new Exception('Invalid quantity');
    }

    if (!is_numeric($data['reorder_level']) || $data['reorder_level'] < 0) {
        throw new Exception('Invalid reorder level');
    }
}

function getProducts($pdo) {
    $stmt = $pdo->query("
        SELECT
            p.*,
            c.category_name,
            s.supplier_name,
            CASE
                WHEN p.stock_quantity <= 5 AND p.stock_quantity > 0 THEN 'low'
                WHEN p.stock_quantity = 0 THEN 'out'
                ELSE 'good'
            END as stock_status
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id
        ORDER BY p.product_name
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCategories($pdo) {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY category_name");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getSuppliers($pdo) {
    $stmt = $pdo->query("SELECT * FROM suppliers ORDER BY supplier_name");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function addProduct($pdo, $data) {
    $stmt = $pdo->prepare("
        INSERT INTO products (
            product_name, category_id, supplier_id, sku,
            description, unit_price, stock_quantity,
            reorder_level, created_at, updated_at
        ) VALUES (
            :product_name, :category_id, :supplier_id, :sku,
            :description, :unit_price, :stock_quantity,
            :reorder_level, NOW(), NOW()
        )
    ");

    $stmt->execute([
        'product_name' => $data['product_name'],
        'category_id' => $data['category_id'],
        'supplier_id' => $data['supplier_id'] ?? null,
        'sku' => $data['sku'],
        'description' => $data['description'] ?? null,
        'unit_price' => $data['unit_price'],
        'stock_quantity' => $data['stock_quantity'],
        'reorder_level' => $data['reorder_level']
    ]);

    return $pdo->lastInsertId();
}

function updateProduct($pdo, $data) {
    if (!isset($data['product_id'])) {
        throw new Exception('Product ID is required');
    }

    $stmt = $pdo->prepare("
        UPDATE products SET
            product_name = :product_name,
            category_id = :category_id,
            supplier_id = :supplier_id,
            sku = :sku,
            description = :description,
            unit_price = :unit_price,
            stock_quantity = :stock_quantity,
            reorder_level = :reorder_level,
            updated_at = NOW()
        WHERE product_id = :product_id
    ");

    $stmt->execute([
        'product_id' => $data['product_id'],
        'product_name' => $data['product_name'],
        'category_id' => $data['category_id'],
        'supplier_id' => $data['supplier_id'] ?? null,
        'sku' => $data['sku'],
        'description' => $data['description'] ?? null,
        'unit_price' => $data['unit_price'],
        'stock_quantity' => $data['stock_quantity'],
        'reorder_level' => $data['reorder_level']
    ]);
}

function deleteProduct($pdo, $product_id) {
    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
}

function updateStock($pdo, $product_id, $quantity) {
    $stmt = $pdo->prepare("
        UPDATE products
        SET stock_quantity = stock_quantity + :quantity,
            updated_at = NOW()
        WHERE product_id = :product_id
    ");
    $stmt->execute(['product_id' => $product_id, 'quantity' => $quantity]);
}

function addCategory($pdo, $category_name) {
    $stmt = $pdo->prepare("
        INSERT INTO categories (category_name, created_at, updated_at)
        VALUES (:category_name, NOW(), NOW())
    ");
    $stmt->execute(['category_name' => $category_name]);
    return $pdo->lastInsertId();
}

function deleteCategory($pdo, $category_id) {
    // Check if category is used by any products
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        throw new Exception("Cannot delete category. It is being used by {$count} product(s).");
    }

    $stmt = $pdo->prepare("DELETE FROM categories WHERE category_id = ?");
    $stmt->execute([$category_id]);
}

function addSupplier($pdo, $data) {
    $stmt = $pdo->prepare("
        INSERT INTO suppliers (
            supplier_name, contact_person, phone, email,
            address, created_at, updated_at
        ) VALUES (
            :supplier_name, :contact_person, :phone, :email,
            :address, NOW(), NOW()
        )
    ");

    $stmt->execute([
        'supplier_name' => $data['supplier_name'],
        'contact_person' => $data['contact_person'] ?? null,
        'phone' => $data['phone'] ?? null,
        'email' => $data['email'] ?? null,
        'address' => $data['address'] ?? null
    ]);

    return $pdo->lastInsertId();
}

function deleteSupplier($pdo, $supplier_id) {
    // Check if supplier is used by any products
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE supplier_id = ?");
    $stmt->execute([$supplier_id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        throw new Exception("Cannot delete supplier. It is being used by {$count} product(s).");
    }

    $stmt = $pdo->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
    $stmt->execute([$supplier_id]);
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($translations['inventory'] ?? 'Inventory Management'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <style>
        :root {
            --primary-dark: #0a0e1a;
            --secondary-dark: #1a1f2e;
            --accent-dark: #2d3748;
            --accent-purple: #667eea;
            --accent-blue: #4299e1;
            --accent-green: #48bb78;
            --accent-orange: #ed8936;
            --accent-red: #f56565;
            --text-light: #ffffff;
            --text-gray: rgba(255,255,255,0.8);
            --text-muted: rgba(255,255,255,0.6);
            --border-color: rgba(255,255,255,0.1);
            --glass-bg: rgba(255,255,255,0.05);
            --glass-border: rgba(255,255,255,0.1);
            --shadow-light: 0 4px 20px rgba(0,0,0,0.1);
            --shadow-medium: 0 8px 32px rgba(0,0,0,0.2);
            --shadow-heavy: 0 20px 60px rgba(0,0,0,0.4);
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-success: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            --gradient-warning: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
            --gradient-danger: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            --gradient-info: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
        }

        body {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #1a202c 100%);
            color: var(--text-light);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Modern Glassmorphism Effect */
        .glass-effect {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-medium);
        }

        .inventory-container {
            padding: 1rem;
            min-height: 100vh;
            max-width: 1200px;
            margin: 0 auto;
        }

        .content-frame {
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.5rem;
            margin: 1rem 0;
            box-shadow: var(--shadow-medium);
            position: relative;
            overflow: hidden;
        }

        .content-frame::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        }

        .inventory-header {
            background: var(--gradient-primary);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-medium);
            border: 1px solid rgba(255,255,255,0.1);
        }

        .inventory-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.05)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.03)"/><circle cx="20" cy="80" r="0.5" fill="rgba(255,255,255,0.03)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
            pointer-events: none;
        }

        .inventory-header h1 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            position: relative;
            z-index: 1;
            text-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        .inventory-header h1 i {
            background: rgba(255,255,255,0.2);
            padding: 0.5rem;
            border-radius: 10px;
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,255,255,0.1);
            font-size: 1.25rem;
        }

        .inventory-header p {
            font-size: 0.95rem;
            color: var(--text-gray);
            max-width: 600px;
            margin-bottom: 0;
            position: relative;
            z-index: 1;
            line-height: 1.5;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-template-rows: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
            align-items: stretch;
        }

        /* 2x2 Grid Layout */
        .stats-container .stat-card:nth-child(1) {
            grid-column: 1;
            grid-row: 1;
        }

        .stats-container .stat-card:nth-child(2) {
            grid-column: 2;
            grid-row: 1;
        }

        .stats-container .stat-card:nth-child(3) {
            grid-column: 1;
            grid-row: 2;
        }

        .stats-container .stat-card:nth-child(4) {
            grid-column: 2;
            grid-row: 2;
        }

        .stats-container-bottom {
            display: none; /* Hide this as we're using grid layout */
        }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 1.25rem;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-light);
            position: relative;
            overflow: hidden;
            cursor: pointer;
            min-height: 100px;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .stat-card:hover::before {
            opacity: 1;
        }

        .stat-card.products-card {
            border-top: 3px solid var(--accent-blue);
        }

        .stat-card.products-card .stat-icon {
            background: var(--gradient-info);
        }

        .stat-card.low-stock-card {
            border-top: 3px solid var(--accent-orange);
        }

        .stat-card.low-stock-card .stat-icon {
            background: var(--gradient-warning);
        }

        .stat-card.categories-card {
            border-top: 3px solid var(--accent-purple);
        }

        .stat-card.categories-card .stat-icon {
            background: var(--gradient-primary);
        }

        .stat-card.value-card {
            border-top: 3px solid var(--accent-green);
        }

        .stat-card.value-card .stat-icon {
            background: var(--gradient-success);
        }

        .stat-card:hover {
            transform: translateY(-4px) scale(1.01);
            box-shadow: var(--shadow-medium);
            border-color: rgba(255,255,255,0.15);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            font-size: 1.25rem;
            color: #ffffff;
            box-shadow: var(--shadow-light);
            position: relative;
            z-index: 1;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .stat-card:hover .stat-icon {
            transform: scale(1.05) rotate(3deg);
            box-shadow: var(--shadow-medium);
        }

        .stat-info {
            flex: 1;
            position: relative;
            z-index: 1;
        }

        .stat-info h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.25rem 0;
            color: var(--text-light);
            line-height: 1.1;
            letter-spacing: -0.01em;
        }

        .stat-info p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            line-height: 1.2;
        }

        .action-buttons {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        .btn-inventory {
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: none;
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            box-shadow: var(--shadow-light);
            text-transform: none;
            letter-spacing: 0.01em;
        }

        .btn-inventory::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn-inventory:hover::before {
            left: 100%;
        }

        .btn-inventory:hover {
            transform: translateY(-2px) scale(1.02);
            box-shadow: var(--shadow-medium);
        }

        .btn-inventory i {
            font-size: 1rem;
            transition: transform 0.3s ease;
        }

        .btn-inventory:hover i {
            transform: scale(1.1);
        }

        .btn-add-product {
            background: var(--gradient-success);
            color: var(--text-light);
            border: 1px solid rgba(72, 187, 120, 0.3);
        }

        .btn-manage-categories {
            background: var(--gradient-primary);
            color: var(--text-light);
            border: 1px solid rgba(102, 126, 234, 0.3);
        }

        .btn-export {
            background: var(--gradient-info);
            color: var(--text-light);
            border: 1px solid rgba(66, 153, 225, 0.3);
        }

        .table-section {
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            margin: 1rem 0;
            box-shadow: var(--shadow-medium);
            position: relative;
            overflow: hidden;
        }

        .table-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        }

        .table-responsive {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow-light);
            margin: 1rem 0;
            background: var(--secondary-dark);
            border: 1px solid var(--glass-border);
            position: relative;
        }

        .table-responsive::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--gradient-primary);
            border-radius: 12px 12px 0 0;
        }

        /* New Table Container */
        .table-container {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 0;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* New Inventory Table */
        .inventory-table {
            width: 100%;
            table-layout: fixed;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 0.85rem;
            background: transparent;
            margin: 0;
        }

        /* New Table Header Styles */
        .inventory-table thead th {
            background: linear-gradient(135deg, var(--secondary-dark) 0%, var(--accent-dark) 100%);
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.75rem;
            padding: 1rem 0.75rem;
            border: none;
            vertical-align: middle;
            white-space: nowrap;
            text-align: center;
            height: 48px;
            border-bottom: 2px solid var(--accent-purple);
        }

        .inventory-table thead th:first-child {
            border-radius: 12px 0 0 0;
            text-align: left;
        }

        .inventory-table thead th:last-child {
            border-radius: 0 12px 0 0;
        }

        /* New Table Body Styles */
        .inventory-table tbody td {
            background: rgba(255, 255, 255, 0.02);
            color: var(--text-light);
            padding: 0.75rem;
            border: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            vertical-align: middle;
            transition: all 0.3s ease;
            font-size: 0.8rem;
            line-height: 1.4;
            height: 42px;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .inventory-table tbody td:first-child {
            text-align: left;
            font-weight: 500;
        }

        /* Column Specific Styles - Using colgroup widths */
        .inventory-table .col-product-name {
            text-align: left;
            padding-left: 1rem;
            font-weight: 500;
        }

        .inventory-table .col-category,
        .inventory-table .col-sku,
        .inventory-table .col-price,
        .inventory-table .col-stock,
        .inventory-table .col-supplier,
        .inventory-table .col-actions {
            text-align: center;
        }

        /* Row Hover Effects */
        .inventory-table tbody tr:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: translateX(8px) translateY(-2px);
            box-shadow: var(--shadow-light);
        }

        .inventory-table tbody tr:hover td {
            background: rgba(255, 255, 255, 0.08);
        }

        /* Custom Select Dropdown Styling */
        .custom-select {
            background: rgba(83, 52, 131, 0.2) !important;
            border: 1px solid rgba(83, 52, 131, 0.4) !important;
            color: white !important;
        }

        .custom-select option {
            background: rgba(33, 37, 58, 0.95) !important;
            color: white !important;
            padding: 8px 12px !important;
            border: none !important;
        }

        .custom-select option:hover {
            background: rgba(83, 52, 131, 0.8) !important;
            color: white !important;
        }

        .custom-select option:checked {
            background: rgba(83, 52, 131, 0.9) !important;
            color: white !important;
        }

        .custom-select option:selected {
            background: rgba(83, 52, 131, 0.9) !important;
            color: white !important;
        }

        /* Focus state for better visibility */
        .custom-select:focus {
            outline: none !important;
            border-color: rgba(83, 52, 131, 0.8) !important;
            box-shadow: 0 0 0 2px rgba(83, 52, 131, 0.3) !important;
        }

        /* Export Button Hover Effects */
        .export-btn:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
            transition: all 0.3s ease !important;
        }

        .export-options-popup .swal2-html-container {
            padding: 20px !important;
        }

        .sku-code {
            font-family: 'Courier New', monospace;
            font-size: 0.75rem;
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-light);
            padding: 4px 8px;
            border-radius: 4px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .table tbody tr {
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }

        .table tbody tr::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: transparent;
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: rgba(255, 255, 255, 0.08) !important;
            transform: translateX(8px) translateY(-2px);
            box-shadow: var(--shadow-light);
        }

        .table tbody tr:hover::before {
            background: var(--gradient-primary);
        }

        .table tbody tr:hover td {
            background: rgba(255, 255, 255, 0.08) !important;
            color: var(--text-light) !important;
        }

        .btn-group {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            gap: 4px !important;
            width: 100% !important;
        }

        .btn-group .btn {
            padding: 0.375rem !important;
            font-size: 0.75rem !important;
            border-radius: 8px !important;
            min-width: 28px !important;
            height: 28px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            border: none !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            position: relative !important;
            overflow: hidden !important;
            backdrop-filter: blur(8px) !important;
            -webkit-backdrop-filter: blur(8px) !important;
        }

        .btn-group .btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: all 0.3s ease;
        }

        .btn-group .btn:hover::before {
            width: 100px;
            height: 100px;
        }

        .btn-group .btn i {
            font-size: 0.7rem !important;
            position: relative;
            z-index: 1;
        }

        .btn-group .btn-primary {
            background: var(--gradient-info) !important;
            box-shadow: var(--shadow-light) !important;
            border: 1px solid rgba(66, 153, 225, 0.3) !important;
        }

        .btn-group .btn-primary:hover {
            transform: translateY(-2px) scale(1.05) !important;
            box-shadow: var(--shadow-medium) !important;
        }

        .btn-group .btn-success {
            background: var(--gradient-success) !important;
            box-shadow: var(--shadow-light) !important;
            border: 1px solid rgba(72, 187, 120, 0.3) !important;
        }

        .btn-group .btn-success:hover {
            transform: translateY(-2px) scale(1.05) !important;
            box-shadow: var(--shadow-medium) !important;
        }

        .btn-group .btn-danger {
            background: var(--gradient-danger) !important;
            box-shadow: var(--shadow-light) !important;
            border: 1px solid rgba(245, 101, 101, 0.3) !important;
        }

        .btn-group .btn-danger:hover {
            transform: translateY(-2px) scale(1.05) !important;
            box-shadow: var(--shadow-medium) !important;
        }

        /* DataTable Controls Styling */
        .dataTables_wrapper {
            color: var(--text-light) !important;
        }

        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            color: var(--text-light) !important;
            margin-bottom: 15px;
        }

        .dataTables_wrapper .dataTables_length label,
        .dataTables_wrapper .dataTables_filter label {
            color: var(--text-light) !important;
            font-weight: 500;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dataTables_wrapper .dataTables_length select {
            background: rgba(255, 255, 255, 0.1) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-radius: 8px !important;
            color: var(--text-light) !important;
            padding: 8px 12px !important;
            margin: 0 8px !important;
            transition: all 0.3s ease !important;
            min-width: 70px !important;
        }

        .dataTables_wrapper .dataTables_length select:focus {
            outline: none !important;
            border-color: var(--accent-purple) !important;
            box-shadow: 0 0 0 2px rgba(83, 52, 131, 0.3) !important;
        }

        .dataTables_wrapper .dataTables_length select option {
            background: var(--secondary-dark) !important;
            color: var(--text-light) !important;
            padding: 8px 12px !important;
            border: none !important;
        }

        .dataTables_wrapper .dataTables_length select option:hover {
            background: var(--accent-purple) !important;
            color: var(--text-light) !important;
        }

        .dataTables_wrapper .dataTables_length select option:checked {
            background: var(--accent-purple) !important;
            color: var(--text-light) !important;
        }

        .dataTables_wrapper .dataTables_filter input {
            background: rgba(255, 255, 255, 0.1) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-radius: 12px !important;
            color: var(--text-light) !important;
            padding: 12px 20px !important;
            margin-left: 10px !important;
            width: 300px !important;
            transition: all 0.3s ease !important;
            font-size: 0.9rem !important;
        }

        .dataTables_wrapper .dataTables_filter input:focus {
            outline: none !important;
            border-color: var(--accent-purple) !important;
            box-shadow: 0 0 0 3px rgba(83, 52, 131, 0.3) !important;
            background: rgba(255, 255, 255, 0.15) !important;
        }

        .dataTables_wrapper .dataTables_filter input::placeholder {
            color: rgba(255, 255, 255, 0.5) !important;
        }

        .dataTables_wrapper .dataTables_info {
            color: rgba(255, 255, 255, 0.7) !important;
            font-size: 0.9rem !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            background: rgba(255, 255, 255, 0.08) !important;
            border: 1px solid rgba(255, 255, 255, 0.15) !important;
            color: var(--text-light) !important;
            margin: 0 1px !important;
            border-radius: 6px !important;
            padding: 6px 10px !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            font-size: 0.8rem !important;
            font-weight: 500 !important;
            min-width: 32px !important;
            height: 32px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            backdrop-filter: blur(8px) !important;
            -webkit-backdrop-filter: blur(8px) !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: var(--gradient-primary) !important;
            border-color: var(--accent-purple) !important;
            color: var(--text-light) !important;
            transform: translateY(-1px) scale(1.05) !important;
            box-shadow: 0 4px 12px rgba(83, 52, 131, 0.3) !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--gradient-primary) !important;
            border-color: var(--accent-purple) !important;
            color: var(--text-light) !important;
            box-shadow: 0 2px 8px rgba(83, 52, 131, 0.4) !important;
            font-weight: 600 !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            background: rgba(255, 255, 255, 0.03) !important;
            border-color: rgba(255, 255, 255, 0.08) !important;
            color: rgba(255, 255, 255, 0.3) !important;
            cursor: not-allowed !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
            transform: none !important;
            box-shadow: none !important;
        }

        /* DataTable Header and Footer Spacing - Fixed Layout */
        .dataTables_wrapper .dataTables_length {
            float: left;
            margin-bottom: 15px;
            margin-top: 5px;
            width: 40%;
            margin-left: 20px;
        }

        .dataTables_wrapper .dataTables_filter {
            float: right;
            margin-bottom: 15px;
            margin-top: 5px;
            width: 50%;
            text-align: right;
            margin-right: 20px;
        }

        .dataTables_wrapper .dataTables_info {
            float: left;
            margin-top: 15px;
            margin-bottom: 5px;
            width: 50%;
        }

        .dataTables_wrapper .dataTables_paginate {
            float: right;
            margin-top: 1rem;
            margin-bottom: 0.5rem;
            width: 50%;
            text-align: right;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        /* Clear floats */
        .dataTables_wrapper::after {
            content: "";
            display: table;
            clear: both;
        }

        /* Fixed positioning for controls */
        .dataTables_wrapper .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding: 10px 0;
        }

        .dataTables_wrapper .bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1.5rem;
            padding: 1rem 0;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }

        /* Pagination Container Styling */
        .dataTables_wrapper .dataTables_paginate .pagination {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 2px !important;
            margin: 0 !important;
            padding: 0 !important;
            list-style: none !important;
        }

        .dataTables_wrapper .dataTables_info {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 8px;
            padding: 0.5rem 1rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.8rem !important;
        }

        /* Light Mode Table Text Colors for Inventory Page */
        [data-theme="light"] .inventory-table,
        [data-theme="light"] .inventory-table td {
            color: #ffffff !important;
        }

        [data-theme="light"] .inventory-table th {
            color: #212529 !important;
            background: var(--gradient-primary) !important;
        }

        [data-theme="light"] .inventory-table thead th {
            color: #212529 !important;
            background: var(--gradient-primary) !important;
        }

        [data-theme="light"] .inventory-table tbody td {
            color: #ffffff !important;
        }

        [data-theme="light"] .inventory-table tbody tr:hover td {
            color: #ffffff !important;
        }

        [data-theme="light"] .dataTables_wrapper,
        [data-theme="light"] .dataTables_wrapper .dataTables_length,
        [data-theme="light"] .dataTables_wrapper .dataTables_filter,
        [data-theme="light"] .dataTables_wrapper .dataTables_info,
        [data-theme="light"] .dataTables_wrapper .dataTables_paginate {
            color: #ffffff !important;
        }

        [data-theme="light"] .dataTables_wrapper .dataTables_length label,
        [data-theme="light"] .dataTables_wrapper .dataTables_filter label {
            color: #ffffff !important;
        }

        [data-theme="light"] .dataTables_wrapper .dataTables_length select,
        [data-theme="light"] .dataTables_wrapper .dataTables_filter input {
            color: #ffffff !important;
        }

        [data-theme="light"] .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #ffffff !important;
        }

        [data-theme="light"] .sku-code {
            color: #ffffff !important;
        }

        [data-theme="light"] .btn-group .btn {
            color: #ffffff !important;
        }

        [data-theme="light"] .table,
        [data-theme="light"] .table td {
            color: #ffffff !important;
        }

        [data-theme="light"] .table th {
            color: #212529 !important;
        }

        [data-theme="light"] .table tbody tr:hover td {
            color: #ffffff !important;
        }

        /* Light Mode H1 and Headers Text Colors for Inventory Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }

        /* Modern Mobile Responsive Styles */
        @media (max-width: 767px) {
            .inventory-container {
                padding: 1rem !important;
            }

            .content-frame {
                padding: 1.5rem !important;
                border-radius: 24px !important;
            }

            .inventory-header {
                padding: 2rem !important;
                border-radius: 20px !important;
                margin-bottom: 2rem !important;
            }

            .inventory-header h1 {
                font-size: 2rem !important;
                gap: 0.75rem !important;
            }

            .inventory-header h1 i {
                padding: 0.5rem !important;
                border-radius: 12px !important;
            }

            .inventory-header p {
                font-size: 1rem !important;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr) !important;
                grid-template-rows: repeat(2, 1fr) !important;
                gap: 0.75rem !important;
                margin-bottom: 1.5rem !important;
            }

            .stats-container .stat-card:nth-child(1) {
                grid-column: 1 !important;
                grid-row: 1 !important;
            }

            .stats-container .stat-card:nth-child(2) {
                grid-column: 2 !important;
                grid-row: 1 !important;
            }

            .stats-container .stat-card:nth-child(3) {
                grid-column: 1 !important;
                grid-row: 2 !important;
            }

            .stats-container .stat-card:nth-child(4) {
                grid-column: 2 !important;
                grid-row: 2 !important;
            }

            .stat-card {
                padding: 1.25rem 1rem !important;
                min-height: 120px !important;
                border-radius: 16px !important;
                gap: 1rem !important;
            }

            .stat-icon {
                width: 48px !important;
                height: 48px !important;
                font-size: 1.25rem !important;
                border-radius: 14px !important;
            }

            .stat-info h3 {
                font-size: 1.5rem !important;
                margin-bottom: 0.25rem !important;
            }

            .stat-info p {
                font-size: 0.75rem !important;
            }

            .action-buttons {
                gap: 0.75rem !important;
                margin-bottom: 1.5rem !important;
            }

            .btn-inventory {
                padding: 0.875rem 1.5rem !important;
                border-radius: 14px !important;
                font-size: 0.9rem !important;
            }

            .table-section {
                padding: 1.5rem !important;
                border-radius: 24px !important;
            }
        }

        /* Modern Extra Small Mobile */
        @media (max-width: 575px) {
            .inventory-container {
                padding: 0.75rem !important;
            }

            .content-frame {
                padding: 1rem !important;
                border-radius: 20px !important;
                margin: 1rem 0 !important;
            }

            .inventory-header {
                padding: 1.5rem !important;
                border-radius: 16px !important;
                margin-bottom: 1.5rem !important;
            }

            .inventory-header h1 {
                font-size: 1.75rem !important;
                gap: 0.5rem !important;
            }

            .inventory-header h1 i {
                padding: 0.4rem !important;
                border-radius: 10px !important;
            }

            .inventory-header p {
                font-size: 0.9rem !important;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr) !important;
                grid-template-rows: repeat(2, 1fr) !important;
                gap: 0.5rem !important;
                margin-bottom: 1rem !important;
            }

            .stats-container .stat-card:nth-child(1) {
                grid-column: 1 !important;
                grid-row: 1 !important;
            }

            .stats-container .stat-card:nth-child(2) {
                grid-column: 2 !important;
                grid-row: 1 !important;
            }

            .stats-container .stat-card:nth-child(3) {
                grid-column: 1 !important;
                grid-row: 2 !important;
            }

            .stats-container .stat-card:nth-child(4) {
                grid-column: 2 !important;
                grid-row: 2 !important;
            }

            .stat-card {
                padding: 1rem 0.75rem !important;
                min-height: 100px !important;
                border-radius: 14px !important;
                gap: 0.75rem !important;
            }

            .stat-icon {
                width: 40px !important;
                height: 40px !important;
                font-size: 1.1rem !important;
                border-radius: 12px !important;
            }

            .stat-info h3 {
                font-size: 1.25rem !important;
                margin-bottom: 0.125rem !important;
            }

            .stat-info p {
                font-size: 0.65rem !important;
            }

            .action-buttons {
                gap: 0.5rem !important;
                margin-bottom: 1rem !important;
                flex-direction: column !important;
            }

            .btn-inventory {
                padding: 0.75rem 1.25rem !important;
                border-radius: 12px !important;
                font-size: 0.85rem !important;
                width: 100% !important;
            }

            .table-section {
                padding: 1rem !important;
                border-radius: 20px !important;
                margin: 1rem 0 !important;
            }

            .table-responsive {
                border-radius: 16px !important;
            }
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="inventory-container">
                <div class="content-frame">
                    <!-- Header Section -->
                    <div class="inventory-header" data-aos="fade-up">
                    <h1>
                        <i class="fas fa-boxes"></i>
                        <span data-translate="inventory_management"><?php echo htmlspecialchars($translations['inventory_management'] ?? 'Inventory Management'); ?></span>
                    </h1>
                    <p data-translate="inventory_description"><?php echo htmlspecialchars($translations['inventory_description'] ?? 'Manage your products, track stock levels, and organize your inventory efficiently.'); ?></p>
                </div>

                <!-- Stats Cards -->
                <div class="stats-container" data-aos="fade-up" data-aos-delay="100">
                    <div class="stat-card products-card">
                        <div class="stat-icon products">
                            <i class="fas fa-box"></i>
                        </div>
                        <div class="stat-info">
                            <h3 id="total-products">0</h3>
                            <p data-translate="total_products"><?php echo htmlspecialchars($translations['total_products'] ?? 'Total Products'); ?></p>
                        </div>
                    </div>
                    <div class="stat-card low-stock-card">
                        <div class="stat-icon low-stock">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="stat-info">
                            <h3 id="low-stock-items">0</h3>
                            <p data-translate="low_stock_items"><?php echo htmlspecialchars($translations['low_stock_items'] ?? 'Low Stock Items'); ?></p>
                        </div>
                    </div>
                    <div class="stat-card categories-card">
                        <div class="stat-icon categories">
                            <i class="fas fa-tags"></i>
                        </div>
                        <div class="stat-info">
                            <h3 id="total-categories">0</h3>
                            <p data-translate="categories"><?php echo htmlspecialchars($translations['categories'] ?? 'Categories'); ?></p>
                        </div>
                    </div>
                    <div class="stat-card value-card">
                        <div class="stat-icon value">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-info">
                            <h3 id="total-value">$0.00</h3>
                            <p data-translate="total_value"><?php echo htmlspecialchars($translations['total_value'] ?? 'Total Value'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="action-buttons" data-aos="fade-up" data-aos-delay="300">
                    <button class="btn btn-inventory btn-add-product" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        <i class="fas fa-plus"></i>
                        <span data-translate="add_product"><?php echo htmlspecialchars($translations['add_product'] ?? 'Add Product'); ?></span>
                    </button>
                    <button class="btn btn-inventory btn-manage-categories" data-bs-toggle="modal" data-bs-target="#manageCategoriesModal">
                        <i class="fas fa-tags"></i>
                        <span data-translate="manage_categories"><?php echo htmlspecialchars($translations['manage_categories'] ?? 'Manage Categories'); ?></span>
                    </button>
                    <button class="btn btn-inventory btn-export" onclick="exportInventory()">
                        <i class="fas fa-download"></i>
                        <span data-translate="export"><?php echo htmlspecialchars($translations['export'] ?? 'Export'); ?></span>
                    </button>
                </div>

                </div>

                <!-- Products Table - Rebuilt -->
                <div class="table-section" data-aos="fade-up" data-aos-delay="400">
                    <div class="table-container">
                        <table class="inventory-table" id="productsTable">
                            <colgroup>
                                <col style="width: 20%;">
                                <col style="width: 12%;">
                                <col style="width: 12%;">
                                <col style="width: 12%;">
                                <col style="width: 10%;">
                                <col style="width: 16%;">
                                <col style="width: 18%;">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="col-product-name" data-translate="product_name">
                                        <?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?>
                                    </th>
                                    <th class="col-category" data-translate="category">
                                        <?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?>
                                    </th>
                                    <th class="col-sku" data-translate="sku">
                                        <?php echo htmlspecialchars($translations['sku'] ?? 'SKU'); ?>
                                    </th>
                                    <th class="col-price" data-translate="price">
                                        <?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?>
                                    </th>
                                    <th class="col-stock" data-translate="stock">
                                        <?php echo htmlspecialchars($translations['stock'] ?? 'Stock'); ?>
                                    </th>
                                    <th class="col-supplier" data-translate="supplier">
                                        <?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?>
                                    </th>
                                    <th class="col-actions" data-translate="actions">
                                        <?php echo htmlspecialchars($translations['actions'] ?? 'Actions'); ?>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be loaded via AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="background: var(--secondary-dark); border: 1px solid rgba(255,255,255,0.1);">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <h5 class="modal-title text-white" id="addProductModalLabel" data-translate="add_product">
                        <?php echo htmlspecialchars($translations['add_product'] ?? 'Add Product'); ?>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addProductForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="product_name" class="form-label text-white" data-translate="product_name">
                                        <?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?>
                                    </label>
                                    <input type="text" class="form-control" id="product_name" name="product_name" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="category_id" class="form-label text-white" data-translate="category">
                                        <?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?>
                                    </label>
                                    <select class="form-control custom-select" id="category_id" name="category_id" required
                                            style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                        <option value="">Select Category</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="sku" class="form-label text-white" data-translate="sku">
                                        <?php echo htmlspecialchars($translations['sku'] ?? 'SKU'); ?>
                                    </label>
                                    <input type="text" class="form-control" id="sku" name="sku" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="unit_price" class="form-label text-white" data-translate="price">
                                        <?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?>
                                    </label>
                                    <input type="number" step="0.01" class="form-control" id="unit_price" name="unit_price" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="stock_quantity" class="form-label text-white" data-translate="stock">
                                        <?php echo htmlspecialchars($translations['stock'] ?? 'Stock'); ?>
                                    </label>
                                    <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="reorder_level" class="form-label text-white" data-translate="reorder_level">
                                        <?php echo htmlspecialchars($translations['reorder_level'] ?? 'Reorder Level'); ?>
                                    </label>
                                    <input type="number" class="form-control" id="reorder_level" name="reorder_level" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="supplier_id" class="form-label text-white" data-translate="supplier">
                                <?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?>
                            </label>
                            <select class="form-control custom-select" id="supplier_id" name="supplier_id"
                                    style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                <option value="">Select Supplier (Optional)</option>
                                <option value="add_new" style="background: rgba(83, 52, 131, 0.9); color: #4CAF50; font-weight: bold;">+ Add New Supplier</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label text-white" data-translate="description">
                                <?php echo htmlspecialchars($translations['description'] ?? 'Description'); ?>
                            </label>
                            <textarea class="form-control" id="description" name="description" rows="3"
                                      style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer" style="border-top: 1px solid rgba(255,255,255,0.1);">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="cancel">
                        <?php echo htmlspecialchars($translations['cancel'] ?? 'Cancel'); ?>
                    </button>
                    <button type="button" class="btn btn-success" onclick="saveProduct()" data-translate="save">
                        <?php echo htmlspecialchars($translations['save'] ?? 'Save'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="background: var(--secondary-dark); border: 1px solid rgba(255,255,255,0.1);">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <h5 class="modal-title text-white" id="editProductModalLabel" data-translate="edit_product">
                        <?php echo htmlspecialchars($translations['edit_product'] ?? 'Edit Product'); ?>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editProductForm">
                        <input type="hidden" id="edit_product_id" name="product_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_product_name" class="form-label text-white" data-translate="product_name">
                                        <?php echo htmlspecialchars($translations['product_name'] ?? 'Product Name'); ?>
                                    </label>
                                    <input type="text" class="form-control" id="edit_product_name" name="product_name" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_category_id" class="form-label text-white" data-translate="category">
                                        <?php echo htmlspecialchars($translations['category'] ?? 'Category'); ?>
                                    </label>
                                    <select class="form-control custom-select" id="edit_category_id" name="category_id" required
                                            style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                        <option value="">Select Category</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_sku" class="form-label text-white" data-translate="sku">
                                        <?php echo htmlspecialchars($translations['sku'] ?? 'SKU'); ?>
                                    </label>
                                    <input type="text" class="form-control" id="edit_sku" name="sku" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_unit_price" class="form-label text-white" data-translate="price">
                                        <?php echo htmlspecialchars($translations['price'] ?? 'Price'); ?>
                                    </label>
                                    <input type="number" step="0.01" class="form-control" id="edit_unit_price" name="unit_price" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_stock_quantity" class="form-label text-white" data-translate="stock">
                                        <?php echo htmlspecialchars($translations['stock'] ?? 'Stock'); ?>
                                    </label>
                                    <input type="number" class="form-control" id="edit_stock_quantity" name="stock_quantity" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_reorder_level" class="form-label text-white" data-translate="reorder_level">
                                        <?php echo htmlspecialchars($translations['reorder_level'] ?? 'Reorder Level'); ?>
                                    </label>
                                    <input type="number" class="form-control" id="edit_reorder_level" name="reorder_level" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="edit_supplier_id" class="form-label text-white" data-translate="supplier">
                                <?php echo htmlspecialchars($translations['supplier'] ?? 'Supplier'); ?>
                            </label>
                            <select class="form-control custom-select" id="edit_supplier_id" name="supplier_id"
                                    style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                <option value="">Select Supplier (Optional)</option>
                                <option value="add_new" style="background: rgba(83, 52, 131, 0.9); color: #4CAF50; font-weight: bold;">+ Add New Supplier</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_description" class="form-label text-white" data-translate="description">
                                <?php echo htmlspecialchars($translations['description'] ?? 'Description'); ?>
                            </label>
                            <textarea class="form-control" id="edit_description" name="description" rows="3"
                                      style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer" style="border-top: 1px solid rgba(255,255,255,0.1);">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="cancel">
                        <?php echo htmlspecialchars($translations['cancel'] ?? 'Cancel'); ?>
                    </button>
                    <button type="button" class="btn btn-primary" onclick="updateProduct()" data-translate="update">
                        <?php echo htmlspecialchars($translations['update'] ?? 'Update'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Manage Categories Modal -->
    <div class="modal fade" id="manageCategoriesModal" tabindex="-1" aria-labelledby="manageCategoriesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="background: var(--secondary-dark); border: 1px solid rgba(255,255,255,0.1);">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <h5 class="modal-title text-white" id="manageCategoriesModalLabel" data-translate="manage_categories">
                        <?php echo htmlspecialchars($translations['manage_categories'] ?? 'Manage Categories'); ?>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-white mb-3" data-translate="add_category">Add New Category</h6>
                            <form id="addCategoryForm">
                                <div class="mb-3">
                                    <label for="category_name" class="form-label text-white" data-translate="category_name">Category Name</label>
                                    <input type="text" class="form-control" id="category_name" name="category_name" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                                <button type="button" class="btn btn-success" onclick="addCategory()" data-translate="add">Add</button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-white mb-3" data-translate="existing_categories">Existing Categories</h6>
                            <div id="categoriesList" style="max-height: 300px; overflow-y: auto;">
                                <!-- Categories will be loaded here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Supplier Modal -->
    <div class="modal fade" id="addSupplierModal" tabindex="-1" aria-labelledby="addSupplierModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="background: var(--secondary-dark); border: 1px solid rgba(255,255,255,0.1);">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <h5 class="modal-title text-white" id="addSupplierModalLabel" data-translate="add_supplier">
                        Add New Supplier
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="supplierForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplier_name" class="form-label text-white" data-translate="supplier_name">
                                        Supplier Name *
                                    </label>
                                    <input type="text" class="form-control" id="supplier_name" name="supplier_name" required
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="contact_person" class="form-label text-white" data-translate="contact_person">
                                        Contact Person
                                    </label>
                                    <input type="text" class="form-control" id="contact_person" name="contact_person"
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplier_phone" class="form-label text-white" data-translate="phone">
                                        Phone
                                    </label>
                                    <input type="tel" class="form-control" id="supplier_phone" name="phone"
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplier_email" class="form-label text-white" data-translate="email">
                                        Email
                                    </label>
                                    <input type="email" class="form-control" id="supplier_email" name="email"
                                           style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="supplier_address" class="form-label text-white" data-translate="address">
                                Address
                            </label>
                            <textarea class="form-control" id="supplier_address" name="address" rows="3"
                                      style="background: rgba(83, 52, 131, 0.2); border: 1px solid rgba(83, 52, 131, 0.4); color: white;"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer" style="border-top: 1px solid rgba(255,255,255,0.1);">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="cancel">
                        Cancel
                    </button>
                    <button type="button" class="btn btn-primary" onclick="saveSupplier()" data-translate="save_supplier">
                        Save Supplier
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- Export Libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

    <script src="../public/js/navbar-functions.js"></script>
    <script src="../public/js/theme-manager.js"></script>

    <script>
        // Global variables
        let productsTable;
        let translations = <?php echo json_encode($translations, JSON_UNESCAPED_UNICODE); ?>;
        let currency = '<?php echo $currency; ?>';
        let currencySymbol = '<?php echo $currency_symbols[$currency]; ?>';
        let exchangeRate = <?php echo $exchange_rates[$currency]; ?>;

        $(document).ready(function() {
            console.log('📦 INVENTORY: Starting initialization...');

            // Initialize AOS
            AOS.init({
                duration: 800,
                easing: 'ease-in-out',
                once: true
            });

            // Initialize theme manager if not already initialized by navbar
            if (typeof window.themeManager === 'undefined') {
                console.log('🎨 Inventory: Initializing theme manager...');
                if (typeof ThemeManager !== 'undefined') {
                    window.themeManager = new ThemeManager();
                    console.log('🎨 Inventory: Theme manager initialized successfully');
                } else {
                    console.warn('🎨 Inventory: ThemeManager class not available');
                }
            } else {
                console.log('🎨 Inventory: Theme manager already initialized');
            }

            // Apply theme immediately
            setTimeout(() => {
                if (typeof window.themeManager !== 'undefined') {
                    console.log('🎨 Inventory: Applying theme...');
                    window.themeManager.applyTheme();
                    console.log('🎨 Inventory: Theme applied successfully');
                }
            }, 100);

            // Navbar will auto-initialize from navbar.php

            // Initialize DataTable
            initializeDataTable();

            // Load initial data
            loadProducts();
            loadCategories();
            loadSuppliers();
            updateStats();

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 Inventory: Notification bell visibility updated');
            }

            console.log('✅ INVENTORY: Initialization completed');
        });

        function initializeDataTable() {
            productsTable = $('#productsTable').DataTable({
                responsive: false,
                pageLength: 10,
                order: [[0, 'asc']],
                dom: '<"top"lf>rt<"bottom"ip>',
                language: {
                    search: translations.search || 'Search:',
                    lengthMenu: (translations.show || 'Show') + ' _MENU_ ' + (translations.entries || 'entries'),
                    info: (translations.showing || 'Showing') + ' _START_ ' + (translations.to || 'to') + ' _END_ ' + (translations.of || 'of') + ' _TOTAL_ ' + (translations.entries || 'entries'),
                    infoEmpty: translations.no_entries || 'No entries available',
                    infoFiltered: '(' + (translations.filtered || 'filtered') + ' ' + (translations.from || 'from') + ' _MAX_ ' + (translations.total || 'total') + ' ' + (translations.entries || 'entries') + ')',
                    paginate: {
                        first: translations.first || 'First',
                        last: translations.last || 'Last',
                        next: translations.next || 'Next',
                        previous: translations.previous || 'Previous'
                    },
                    emptyTable: translations.no_data || 'No data available in table'
                },
                columnDefs: [
                    {
                        targets: [0],
                        className: 'col-product-name',
                        orderable: true
                    },
                    {
                        targets: [1],
                        className: 'col-category',
                        orderable: true
                    },
                    {
                        targets: [2],
                        className: 'col-sku',
                        orderable: true
                    },
                    {
                        targets: [3],
                        className: 'col-price',
                        orderable: true
                    },
                    {
                        targets: [4],
                        className: 'col-stock',
                        orderable: true
                    },
                    {
                        targets: [5],
                        className: 'col-supplier',
                        orderable: true
                    },
                    {
                        targets: [6],
                        className: 'col-actions',
                        orderable: false
                    }
                ],
                autoWidth: false,
                scrollX: false,
                processing: false,
                serverSide: false,
                responsive: false,
                columns: [
                    {
                        data: 'product_name',
                        title: translations.product_name || 'Product Name',
                        render: function(data) {
                            return `<span class="text-white fw-bold">${data}</span>`;
                        }
                    },
                    {
                        data: 'category_name',
                        title: translations.category || 'Category',
                        render: function(data) {
                            return data ? `<span class="text-white">${data}</span>` : '<span class="text-muted">N/A</span>';
                        }
                    },
                    {
                        data: 'sku',
                        title: translations.sku || 'SKU',
                        className: 'col-sku text-center',
                        render: function(data) {
                            return `<span class="sku-code">${data}</span>`;
                        }
                    },
                    {
                        data: 'unit_price',
                        title: translations.price || 'Price',
                        className: 'col-price text-center',
                        render: function(data) {
                            const convertedAmount = parseFloat(data) * exchangeRate;
                            const formattedAmount = convertedAmount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                            return `<span class="fw-bold text-success">
                                <span class="currency-wrapper">
                                    <span class="symbol currency-symbol">${currencySymbol}</span>
                                    <span class="amount">${formattedAmount}</span>
                                </span>
                            </span>`;
                        }
                    },
                    {
                        data: 'stock_quantity',
                        title: translations.stock || 'Stock',
                        className: 'col-stock text-center',
                        render: function(data, type, row) {
                            let badgeClass = 'bg-success';
                            if (data <= 5 && data > 0) badgeClass = 'bg-warning';
                            if (data === 0) badgeClass = 'bg-danger';
                            return `<span class="badge ${badgeClass}">${data}</span>`;
                        }
                    },
                    {
                        data: 'supplier_name',
                        title: translations.supplier || 'Supplier',
                        className: 'col-supplier text-center',
                        render: function(data) {
                            return data ? `<span class="text-white text-center d-block">${data}</span>` : '<span class="text-muted text-center d-block">N/A</span>';
                        }
                    },
                    {
                        data: null,
                        title: translations.actions || 'Actions',
                        className: 'col-actions text-center',
                        orderable: false,
                        render: function(data, type, row) {
                            return `
                                <div class="btn-group" role="group">
                                    <button class="btn btn-primary btn-action" onclick="editProduct(${row.product_id})" title="${translations.edit || 'Edit'}">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-success btn-action" onclick="updateStock(${row.product_id})" title="${translations.update_stock || 'Update Stock'}">
                                        <i class="fas fa-boxes"></i>
                                    </button>
                                    <button class="btn btn-danger btn-action" onclick="deleteProduct(${row.product_id})" title="${translations.delete || 'Delete'}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            `;
                        }
                    }
                ]
            });
        }

        function loadProducts() {
            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: { action: 'get_products' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        productsTable.clear().rows.add(response.data).draw();
                        updateStats();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error loading products:', error);
                }
            });
        }

        function loadCategories() {
            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: { action: 'get_categories' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Update categories count
                        $('#total-categories').text(response.data.length);

                        // Populate category dropdowns
                        const categorySelect = $('#category_id');
                        const editCategorySelect = $('#edit_category_id');

                        categorySelect.empty().append('<option value="">Select Category</option>');
                        editCategorySelect.empty().append('<option value="">Select Category</option>');

                        response.data.forEach(function(category) {
                            categorySelect.append(`<option value="${category.category_id}">${category.category_name}</option>`);
                            editCategorySelect.append(`<option value="${category.category_id}">${category.category_name}</option>`);
                        });

                        // Populate categories list in modal
                        const categoriesList = $('#categoriesList');
                        categoriesList.empty();
                        response.data.forEach(function(category) {
                            categoriesList.append(`
                                <div class="d-flex justify-content-between align-items-center mb-2 p-2" style="background: rgba(255,255,255,0.05); border-radius: 8px;">
                                    <span class="text-white">${category.category_name}</span>
                                    <button class="btn btn-sm btn-danger" onclick="deleteCategory(${category.category_id})">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            `);
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error loading categories:', error);
                }
            });
        }

        function loadSuppliers() {
            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: { action: 'get_suppliers' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Populate supplier dropdowns
                        const supplierSelect = $('#supplier_id');
                        const editSupplierSelect = $('#edit_supplier_id');

                        supplierSelect.empty().append('<option value="">Select Supplier (Optional)</option>');
                        supplierSelect.append('<option value="add_new" style="background: rgba(83, 52, 131, 0.9); color: #4CAF50; font-weight: bold;">+ Add New Supplier</option>');

                        editSupplierSelect.empty().append('<option value="">Select Supplier (Optional)</option>');
                        editSupplierSelect.append('<option value="add_new" style="background: rgba(83, 52, 131, 0.9); color: #4CAF50; font-weight: bold;">+ Add New Supplier</option>');

                        response.data.forEach(function(supplier) {
                            supplierSelect.append(`<option value="${supplier.supplier_id}">${supplier.supplier_name}</option>`);
                            editSupplierSelect.append(`<option value="${supplier.supplier_id}">${supplier.supplier_name}</option>`);
                        });
                        console.log('Suppliers loaded:', response.data.length);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error loading suppliers:', error);
                }
            });
        }

        function updateStats() {
            const data = productsTable.data().toArray();

            // Total products
            $('#total-products').text(data.length);

            // Low stock items
            const lowStockItems = data.filter(item => item.stock_quantity <= 5 && item.stock_quantity > 0);
            $('#low-stock-items').text(lowStockItems.length);

            // Total value
            const totalValue = data.reduce((sum, item) => {
                return sum + (parseFloat(item.unit_price) * parseInt(item.stock_quantity));
            }, 0);

            const convertedValue = totalValue * exchangeRate;
            const formattedValue = convertedValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            $('#total-value').html(`
                <span class="currency-wrapper">
                    <span class="symbol currency-symbol">${currencySymbol}</span>
                    <span class="amount">${formattedValue}</span>
                </span>
            `);
        }



        window.updatePageForNewLanguage = function(newLanguage, newTranslations) {
            console.log('🌐 Updating page for new language:', newLanguage);
            console.log('🌐 New translations:', newTranslations);

            // Update global translations
            translations = newTranslations;

            // Update all translatable elements
            $('[data-translate]').each(function() {
                const key = $(this).data('translate');
                if (translations[key]) {
                    $(this).text(translations[key]);
                }
            });

            // Update DataTable language
            if (productsTable) {
                productsTable.destroy();
                initializeDataTable();
                loadProducts();
            }

            console.log('🌐 Language update completed');
        };

        // Action button functions

        function updateStock(productId) {
            console.log('Update stock for product:', productId);

            Swal.fire({
                title: translations.update_stock || 'Update Stock',
                input: 'number',
                inputLabel: translations.enter_quantity || 'Enter quantity to add/remove (use negative for removal)',
                inputPlaceholder: '0',
                background: '#16213e',
                color: '#ffffff',
                confirmButtonColor: '#27ae60',
                cancelButtonColor: '#e74c3c',
                showCancelButton: true,
                confirmButtonText: translations.update || 'Update',
                cancelButtonText: translations.cancel || 'Cancel',
                inputValidator: (value) => {
                    if (!value || isNaN(value)) {
                        return translations.enter_valid_number || 'Please enter a valid number';
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const quantity = parseInt(result.value);

                    $.ajax({
                        url: 'inventory.php',
                        method: 'POST',
                        data: {
                            action: 'update_stock',
                            product_id: productId,
                            quantity: quantity
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    title: translations.success || 'Success',
                                    text: response.message,
                                    icon: 'success',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#27ae60'
                                });
                                loadProducts(); // Reload table data
                            } else {
                                Swal.fire({
                                    title: translations.error || 'Error',
                                    text: response.message,
                                    icon: 'error',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#e74c3c'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                title: translations.error || 'Error',
                                text: translations.update_failed || 'Failed to update stock',
                                icon: 'error',
                                background: '#16213e',
                                color: '#ffffff',
                                confirmButtonColor: '#e74c3c'
                            });
                        }
                    });
                }
            });
        }

        function editProduct(productId) {
            // Get product data from table
            const rowData = productsTable.row($(`button[onclick="editProduct(${productId})"]`).closest('tr')).data();

            if (!rowData) {
                Swal.fire({
                    title: translations.error || 'Error',
                    text: 'Product data not found',
                    icon: 'error',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#e74c3c'
                });
                return;
            }

            // Populate edit form
            $('#edit_product_id').val(productId);
            $('#edit_product_name').val(rowData.product_name);
            $('#edit_sku').val(rowData.sku);
            $('#edit_unit_price').val(rowData.unit_price);
            $('#edit_stock_quantity').val(rowData.stock_quantity);
            $('#edit_reorder_level').val(rowData.reorder_level);
            $('#edit_description').val(rowData.description || '');

            // Load and set categories
            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: { action: 'get_categories' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        const editCategorySelect = $('#edit_category_id');
                        editCategorySelect.empty().append('<option value="">Select Category</option>');
                        response.data.forEach(function(category) {
                            const selected = category.category_id == rowData.category_id ? 'selected' : '';
                            editCategorySelect.append(`<option value="${category.category_id}" ${selected}>${category.category_name}</option>`);
                        });
                    }
                }
            });

            // Load and set suppliers
            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: { action: 'get_suppliers' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        const editSupplierSelect = $('#edit_supplier_id');
                        editSupplierSelect.empty().append('<option value="">Select Supplier (Optional)</option>');
                        response.data.forEach(function(supplier) {
                            const selected = supplier.supplier_id == rowData.supplier_id ? 'selected' : '';
                            editSupplierSelect.append(`<option value="${supplier.supplier_id}" ${selected}>${supplier.supplier_name}</option>`);
                        });
                    }
                }
            });

            // Show modal
            $('#editProductModal').modal('show');
        }

        function deleteProduct(productId) {
            console.log('Delete product:', productId);

            Swal.fire({
                title: translations.confirm_delete || 'Are you sure?',
                text: translations.delete_warning || 'This action cannot be undone!',
                icon: 'warning',
                background: '#16213e',
                color: '#ffffff',
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#6c757d',
                confirmButtonText: translations.delete || 'Delete',
                cancelButtonText: translations.cancel || 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'inventory.php',
                        method: 'POST',
                        data: {
                            action: 'delete_product',
                            product_id: productId
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    title: translations.deleted || 'Deleted!',
                                    text: response.message,
                                    icon: 'success',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#27ae60'
                                });
                                loadProducts(); // Reload table data
                            } else {
                                Swal.fire({
                                    title: translations.error || 'Error',
                                    text: response.message,
                                    icon: 'error',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#e74c3c'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                title: translations.error || 'Error',
                                text: translations.delete_failed || 'Failed to delete product',
                                icon: 'error',
                                background: '#16213e',
                                color: '#ffffff',
                                confirmButtonColor: '#e74c3c'
                            });
                        }
                    });
                }
            });
        }

        function exportInventory() {
            console.log('Export inventory');

            Swal.fire({
                title: translations.export_inventory || 'Export Inventory',
                html: `
                    <div style="text-align: center; color: #ffffff;">
                        <p style="margin-bottom: 20px; color: #ffffff;">Choose export format:</p>
                        <div style="display: flex; flex-direction: column; gap: 10px; max-width: 300px; margin: 0 auto;">
                            <button onclick="exportToExcel()" class="export-btn" style="background: #28a745; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <span>📊</span> Export to Excel (.xlsx)
                            </button>
                            <button onclick="exportToPDF()" class="export-btn" style="background: #dc3545; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <span>📄</span> Export to PDF
                            </button>
                            <button onclick="exportToCSV()" class="export-btn" style="background: #17a2b8; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <span>📋</span> Export to CSV
                            </button>
                            <button onclick="exportAnalytics()" class="export-btn" style="background: #6f42c1; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <span>📈</span> Detailed Analytics
                            </button>
                        </div>
                    </div>
                `,
                icon: 'question',
                background: '#16213e',
                color: '#ffffff',
                showConfirmButton: false,
                showCancelButton: true,
                cancelButtonText: translations.cancel || 'Cancel',
                cancelButtonColor: '#6c757d',
                width: '450px',
                customClass: {
                    popup: 'export-options-popup'
                }
            });
        }

        // Export to Excel function
        function exportToExcel() {
            Swal.close();

            // Show loading
            Swal.fire({
                title: 'Exporting to Excel...',
                text: 'Please wait while we prepare your file',
                icon: 'info',
                background: '#16213e',
                color: '#ffffff',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Get current table data
            const data = productsTable.data().toArray();

            // Prepare data for export
            const exportData = data.map(item => ({
                'Product Name': item.product_name,
                'Category': item.category_name || 'N/A',
                'SKU': item.sku,
                'Price': parseFloat(item.unit_price) * exchangeRate,
                'Stock': item.stock_quantity,
                'Reorder Level': item.reorder_level,
                'Supplier': item.supplier_name || 'N/A',
                'Total Value': (parseFloat(item.unit_price) * exchangeRate) * parseInt(item.stock_quantity)
            }));

            // Create workbook
            const ws = XLSX.utils.json_to_sheet(exportData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Inventory');

            // Generate filename with current date
            const now = new Date();
            const filename = `inventory_${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}.xlsx`;

            // Download file
            XLSX.writeFile(wb, filename);

            // Show success message
            setTimeout(() => {
                Swal.fire({
                    title: 'Export Successful!',
                    text: `File saved as: ${filename}`,
                    icon: 'success',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#28a745'
                });
            }, 1000);
        }

        // Export to PDF function
        function exportToPDF() {
            Swal.close();

            // Show loading
            Swal.fire({
                title: 'Exporting to PDF...',
                text: 'Please wait while we prepare your report',
                icon: 'info',
                background: '#16213e',
                color: '#ffffff',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Get current table data
            const data = productsTable.data().toArray();

            // Create PDF using jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Add title
            doc.setFontSize(20);
            doc.text('Inventory Report', 20, 20);

            // Add date
            doc.setFontSize(12);
            const now = new Date();
            doc.text(`Generated on: ${now.toLocaleDateString()}`, 20, 35);

            // Prepare table data
            const tableData = data.map(item => [
                item.product_name,
                item.category_name || 'N/A',
                item.sku,
                `${currencySymbol}${(parseFloat(item.unit_price) * exchangeRate).toFixed(2)}`,
                item.stock_quantity,
                item.supplier_name || 'N/A'
            ]);

            // Add table
            doc.autoTable({
                head: [['Product Name', 'Category', 'SKU', 'Price', 'Stock', 'Supplier']],
                body: tableData,
                startY: 50,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [83, 52, 131] }
            });

            // Generate filename
            const filename = `inventory_report_${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}.pdf`;

            // Download PDF
            doc.save(filename);

            // Show success message
            setTimeout(() => {
                Swal.fire({
                    title: 'PDF Export Successful!',
                    text: `Report saved as: ${filename}`,
                    icon: 'success',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#dc3545'
                });
            }, 1000);
        }

        // Export to CSV function
        function exportToCSV() {
            Swal.close();

            // Show loading
            Swal.fire({
                title: 'Exporting to CSV...',
                text: 'Please wait while we prepare your file',
                icon: 'info',
                background: '#16213e',
                color: '#ffffff',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Get current table data
            const data = productsTable.data().toArray();

            // Prepare CSV content
            const headers = ['Product Name', 'Category', 'SKU', 'Price', 'Stock', 'Reorder Level', 'Supplier', 'Total Value'];
            const csvContent = [
                headers.join(','),
                ...data.map(item => [
                    `"${item.product_name}"`,
                    `"${item.category_name || 'N/A'}"`,
                    `"${item.sku}"`,
                    (parseFloat(item.unit_price) * exchangeRate).toFixed(2),
                    item.stock_quantity,
                    item.reorder_level,
                    `"${item.supplier_name || 'N/A'}"`,
                    ((parseFloat(item.unit_price) * exchangeRate) * parseInt(item.stock_quantity)).toFixed(2)
                ].join(','))
            ].join('\n');

            // Create and download file
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const now = new Date();
            const filename = `inventory_${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}.csv`;

            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.click();

            // Show success message
            setTimeout(() => {
                Swal.fire({
                    title: 'CSV Export Successful!',
                    text: `File saved as: ${filename}`,
                    icon: 'success',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#17a2b8'
                });
            }, 1000);
        }

        // Export Analytics function
        function exportAnalytics() {
            Swal.close();

            // Show loading
            Swal.fire({
                title: 'Generating Analytics...',
                text: 'Please wait while we prepare your detailed report',
                icon: 'info',
                background: '#16213e',
                color: '#ffffff',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Get current table data
            const data = productsTable.data().toArray();

            // Calculate analytics
            const totalProducts = data.length;
            const totalValue = data.reduce((sum, item) => sum + (parseFloat(item.unit_price) * exchangeRate * parseInt(item.stock_quantity)), 0);
            const lowStockItems = data.filter(item => parseInt(item.stock_quantity) <= 5).length;
            const outOfStockItems = data.filter(item => parseInt(item.stock_quantity) === 0).length;

            // Category analysis
            const categoryStats = {};
            data.forEach(item => {
                const category = item.category_name || 'Uncategorized';
                if (!categoryStats[category]) {
                    categoryStats[category] = { count: 0, value: 0 };
                }
                categoryStats[category].count++;
                categoryStats[category].value += parseFloat(item.unit_price) * exchangeRate * parseInt(item.stock_quantity);
            });

            // Create detailed analytics PDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Title
            doc.setFontSize(24);
            doc.text('Inventory Analytics Report', 20, 25);

            // Date
            doc.setFontSize(12);
            const now = new Date();
            doc.text(`Generated on: ${now.toLocaleDateString()} at ${now.toLocaleTimeString()}`, 20, 40);

            // Summary Statistics
            doc.setFontSize(16);
            doc.text('Summary Statistics', 20, 60);
            doc.setFontSize(12);
            doc.text(`Total Products: ${totalProducts}`, 30, 75);
            doc.text(`Total Inventory Value: ${currencySymbol}${totalValue.toFixed(2)}`, 30, 85);
            doc.text(`Low Stock Items (≤5): ${lowStockItems}`, 30, 95);
            doc.text(`Out of Stock Items: ${outOfStockItems}`, 30, 105);
            doc.text(`Average Product Value: ${currencySymbol}${(totalValue/totalProducts).toFixed(2)}`, 30, 115);

            // Category Breakdown
            doc.setFontSize(16);
            doc.text('Category Breakdown', 20, 135);
            doc.setFontSize(12);
            let yPos = 150;
            Object.entries(categoryStats).forEach(([category, stats]) => {
                doc.text(`${category}: ${stats.count} items, ${currencySymbol}${stats.value.toFixed(2)}`, 30, yPos);
                yPos += 10;
            });

            // Top 10 Most Valuable Items
            const topItems = data
                .map(item => ({
                    name: item.product_name,
                    value: parseFloat(item.unit_price) * exchangeRate * parseInt(item.stock_quantity)
                }))
                .sort((a, b) => b.value - a.value)
                .slice(0, 10);

            doc.addPage();
            doc.setFontSize(16);
            doc.text('Top 10 Most Valuable Items', 20, 25);
            doc.setFontSize(12);
            yPos = 40;
            topItems.forEach((item, index) => {
                doc.text(`${index + 1}. ${item.name}: ${currencySymbol}${item.value.toFixed(2)}`, 30, yPos);
                yPos += 10;
            });

            // Generate filename
            const filename = `inventory_analytics_${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}.pdf`;

            // Download PDF
            doc.save(filename);

            // Show success message
            setTimeout(() => {
                Swal.fire({
                    title: 'Analytics Export Successful!',
                    text: `Detailed report saved as: ${filename}`,
                    icon: 'success',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#6f42c1'
                });
            }, 1000);
        }

        // Modal Functions
        function saveProduct() {
            const formData = new FormData(document.getElementById('addProductForm'));
            formData.append('action', 'add_product');

            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: Object.fromEntries(formData),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: translations.success || 'Success',
                            text: response.message,
                            icon: 'success',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#27ae60'
                        });
                        $('#addProductModal').modal('hide');
                        $('#addProductForm')[0].reset();
                        loadProducts();
                    } else {
                        Swal.fire({
                            title: translations.error || 'Error',
                            text: response.message,
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        title: translations.error || 'Error',
                        text: translations.save_failed || 'Failed to save product',
                        icon: 'error',
                        background: '#16213e',
                        color: '#ffffff',
                        confirmButtonColor: '#e74c3c'
                    });
                }
            });
        }

        function updateProduct() {
            const formData = new FormData(document.getElementById('editProductForm'));
            formData.append('action', 'update_product');

            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: Object.fromEntries(formData),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: translations.success || 'Success',
                            text: response.message,
                            icon: 'success',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#27ae60'
                        });
                        $('#editProductModal').modal('hide');
                        loadProducts();
                    } else {
                        Swal.fire({
                            title: translations.error || 'Error',
                            text: response.message,
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        title: translations.error || 'Error',
                        text: translations.update_failed || 'Failed to update product',
                        icon: 'error',
                        background: '#16213e',
                        color: '#ffffff',
                        confirmButtonColor: '#e74c3c'
                    });
                }
            });
        }

        function addCategory() {
            const categoryName = $('#category_name').val().trim();
            if (!categoryName) {
                Swal.fire({
                    title: translations.error || 'Error',
                    text: translations.enter_category_name || 'Please enter category name',
                    icon: 'error',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#e74c3c'
                });
                return;
            }

            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: {
                    action: 'add_category',
                    category_name: categoryName
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: translations.success || 'Success',
                            text: response.message,
                            icon: 'success',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#27ae60'
                        });
                        $('#category_name').val('');
                        loadCategories();
                    } else {
                        Swal.fire({
                            title: translations.error || 'Error',
                            text: response.message,
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        title: translations.error || 'Error',
                        text: translations.add_category_failed || 'Failed to add category',
                        icon: 'error',
                        background: '#16213e',
                        color: '#ffffff',
                        confirmButtonColor: '#e74c3c'
                    });
                }
            });
        }

        function deleteCategory(categoryId) {
            Swal.fire({
                title: translations.confirm_delete || 'Are you sure?',
                text: translations.delete_category_warning || 'This will delete the category and may affect products!',
                icon: 'warning',
                background: '#16213e',
                color: '#ffffff',
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#6c757d',
                confirmButtonText: translations.delete || 'Delete',
                cancelButtonText: translations.cancel || 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'inventory.php',
                        method: 'POST',
                        data: {
                            action: 'delete_category',
                            category_id: categoryId
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    title: translations.deleted || 'Deleted!',
                                    text: response.message,
                                    icon: 'success',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#27ae60'
                                });
                                loadCategories();
                            } else {
                                Swal.fire({
                                    title: translations.error || 'Error',
                                    text: response.message,
                                    icon: 'error',
                                    background: '#16213e',
                                    color: '#ffffff',
                                    confirmButtonColor: '#e74c3c'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                title: translations.error || 'Error',
                                text: translations.delete_failed || 'Failed to delete category',
                                icon: 'error',
                                background: '#16213e',
                                color: '#ffffff',
                                confirmButtonColor: '#e74c3c'
                            });
                        }
                    });
                }
            });
        }

        // Currency update function for navbar integration
        window.updatePageForNewCurrency = function(newCurrency, response) {
            console.log('💰 INVENTORY: Starting currency update');
            console.log('💰 INVENTORY: New currency:', newCurrency);
            console.log('💰 INVENTORY: Response data:', response);

            try {
                // Validate response
                if (!response || !response.success) {
                    console.error('💰 INVENTORY: Invalid response received');
                    throw new Error('Invalid response');
                }

                // Update global variables
                currency = newCurrency;
                currencySymbol = response.currency_symbol || '$';
                exchangeRate = response.exchange_rate || 1;

                console.log('💰 INVENTORY: Global variables updated:', {
                    currency: currency,
                    currencySymbol: currencySymbol,
                    exchangeRate: exchangeRate
                });

                // Update stats display immediately
                console.log('💰 INVENTORY: Updating stats cards...');
                updateStats();

                // Update table price column if table exists
                if (productsTable) {
                    console.log('💰 INVENTORY: Updating table with new currency...');

                    try {
                        // Get current data
                        const currentData = productsTable.data().toArray();
                        console.log('💰 INVENTORY: Current table data count:', currentData.length);

                        if (currentData.length > 0) {
                            // Clear table and re-add data to trigger re-rendering
                            productsTable.clear();
                            productsTable.rows.add(currentData);
                            productsTable.draw();
                            console.log('💰 INVENTORY: Table redrawn with new currency');
                        } else {
                            // If no data, reload from server
                            console.log('💰 INVENTORY: No data in table, reloading...');
                            loadProducts();
                        }
                    } catch (error) {
                        console.error('💰 INVENTORY: Error updating table:', error);
                        // Fallback: reload products
                        loadProducts();
                    }
                } else {
                    console.log('💰 INVENTORY: Table not initialized, loading products...');
                    loadProducts();
                }

                console.log('✅ INVENTORY: Currency update completed successfully');
                return true; // Indicate success

            } catch (error) {
                console.error('💰 INVENTORY: Error during currency update:', error);
                throw error; // Re-throw to trigger fallback in navbar
            }
        };

        // Language update function for navbar integration
        window.updatePageForNewLanguage = function(newLanguage, newTranslations) {
            console.log('🌐 Inventory: Updating page for new language:', newLanguage);
            console.log('🌐 Inventory: New translations:', newTranslations);

            try {
                // Update global translations
                translations = newTranslations;

                // Update page title
                document.title = translations.inventory_management || 'Inventory Management';

                // Update all translatable elements with data-translate attribute
                $('[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update specific UI elements
                updateUILanguage();

                // Update DataTable with new language
                if (productsTable) {
                    console.log('🌐 Inventory: Updating DataTable language...');

                    // Store current data
                    const currentData = productsTable.data().toArray();

                    // Destroy and recreate table with new language
                    productsTable.destroy();
                    initializeDataTable();

                    // Reload data
                    if (currentData.length > 0) {
                        productsTable.clear().rows.add(currentData).draw();
                    } else {
                        loadProducts();
                    }
                }

                console.log('✅ Inventory: Language update completed successfully');

            } catch (error) {
                console.error('🌐 Inventory: Error during language update:', error);
                throw error; // Re-throw to trigger fallback in navbar
            }
        };

        // Function to update UI language elements
        function updateUILanguage() {
            console.log('🌐 Inventory: Updating UI language elements...');

            // Update page heading
            $('.page-title, #page-title').text(translations.inventory_management || 'Inventory Management');

            // Update stats cards
            $('[data-translate="total_products"]').text(translations.total_products || 'Total Products');
            $('[data-translate="low_stock_items"]').text(translations.low_stock_items || 'Low Stock Items');
            $('[data-translate="categories"]').text(translations.categories || 'Categories');
            $('[data-translate="total_value"]').text(translations.total_value || 'Total Value');

            // Update buttons (text only, keep existing icons)
            $('[data-translate="add_product"]').text(translations.add_product || 'Add Product');
            $('[data-translate="manage_categories"]').text(translations.manage_categories || 'Manage Categories');
            $('[data-translate="export"]').text(translations.export || 'Export');

            // Update search placeholder
            $('#products-table_filter input').attr('placeholder', translations.search || 'Search...');

            // Update modal titles
            $('#addProductModalLabel').text(translations.add_product || 'Add Product');
            $('#editProductModalLabel').text(translations.edit_product || 'Edit Product');
            $('#manageCategoriesModalLabel').text(translations.manage_categories || 'Manage Categories');

            // Update form labels
            $('label[for="product_name"], label[for="edit_product_name"]').text(translations.product_name || 'Product Name');
            $('label[for="sku"], label[for="edit_sku"]').text(translations.sku || 'SKU');
            $('label[for="category_id"], label[for="edit_category_id"]').text(translations.category || 'Category');
            $('label[for="unit_price"], label[for="edit_unit_price"]').text(translations.price || 'Price');
            $('label[for="stock_quantity"], label[for="edit_stock_quantity"]').text(translations.stock_quantity || 'Stock Quantity');
            $('label[for="reorder_level"], label[for="edit_reorder_level"]').text(translations.reorder_level || 'Reorder Level');
            $('label[for="supplier_id"], label[for="edit_supplier_id"]').text(translations.supplier || 'Supplier');
            $('label[for="description"], label[for="edit_description"]').text(translations.description || 'Description');

            // Update form placeholders
            $('#product_name, #edit_product_name').attr('placeholder', translations.enter_product_name || 'Enter product name');
            $('#sku, #edit_sku').attr('placeholder', translations.enter_sku || 'Enter SKU');
            $('#unit_price, #edit_unit_price').attr('placeholder', translations.enter_price || 'Enter price');
            $('#stock_quantity, #edit_stock_quantity').attr('placeholder', translations.enter_quantity || 'Enter quantity');
            $('#reorder_level, #edit_reorder_level').attr('placeholder', translations.enter_reorder_level || 'Enter reorder level');
            $('#description, #edit_description').attr('placeholder', translations.enter_description || 'Enter description (optional)');

            // Update button texts
            $('.btn-save').text(translations.save || 'Save');
            $('.btn-update').text(translations.update || 'Update');
            $('.btn-cancel').text(translations.cancel || 'Cancel');
            $('.btn-close').text(translations.close || 'Close');

            // Update category management
            $('#category_name').attr('placeholder', translations.enter_category_name || 'Enter category name');
            $('#add-category-btn').text(translations.add_category || 'Add Category');

            // Update dropdown options
            $('#category_id option:first, #edit_category_id option:first').text(translations.select_category || 'Select Category');
            $('#supplier_id option:first, #edit_supplier_id option:first').text(translations.select_supplier || 'Select Supplier (Optional)');

            console.log('🌐 Inventory: UI language elements updated');
        }

        // Supplier Management Functions
        function saveSupplier() {
            const supplierData = {
                action: 'add_supplier',
                supplier_name: $('#supplier_name').val(),
                contact_person: $('#contact_person').val(),
                phone: $('#supplier_phone').val(),
                email: $('#supplier_email').val(),
                address: $('#supplier_address').val()
            };

            if (!supplierData.supplier_name.trim()) {
                Swal.fire({
                    title: 'Error',
                    text: 'Supplier name is required',
                    icon: 'error',
                    background: '#16213e',
                    color: '#ffffff',
                    confirmButtonColor: '#e74c3c'
                });
                return;
            }

            $.ajax({
                url: 'inventory.php',
                method: 'POST',
                data: supplierData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#addSupplierModal').modal('hide');
                        $('#supplierForm')[0].reset();

                        Swal.fire({
                            title: 'Success!',
                            text: response.message,
                            icon: 'success',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#28a745'
                        });

                        // Reload suppliers
                        loadSuppliers();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to save supplier',
                        icon: 'error',
                        background: '#16213e',
                        color: '#ffffff',
                        confirmButtonColor: '#e74c3c'
                    });
                }
            });
        }

        // Handle supplier dropdown change
        $(document).on('change', '#supplier_id, #edit_supplier_id', function() {
            if ($(this).val() === 'add_new') {
                $('#addSupplierModal').modal('show');
                $(this).val(''); // Reset dropdown
            }
        });

        // Global function to open update stock modal (called from navbar notifications)
        window.openUpdateStockModal = function(productId) {
            console.log('📦 Opening update stock modal for product:', productId);

            // Find the product in the table
            if (productsTable) {
                const data = productsTable.data().toArray();
                const product = data.find(p => p.product_id == productId);

                if (product) {
                    console.log('📦 Found product:', product.product_name, 'Current stock:', product.stock_quantity);

                    // Use the existing updateStock function which shows SweetAlert modal
                    updateStock(productId);

                    console.log('📦 Update stock modal opened for:', product.product_name);
                } else {
                    console.error('📦 Product not found in table data');

                    // Try to find product by searching through all rows
                    let foundProduct = false;
                    if (productsTable.rows().data().length > 0) {
                        productsTable.rows().data().each(function(rowData) {
                            if (rowData.product_id == productId) {
                                foundProduct = true;
                                updateStock(productId);
                                return false; // Break the loop
                            }
                        });
                    }

                    if (!foundProduct) {
                        // Show error message
                        Swal.fire({
                            title: 'Product Not Found',
                            text: 'The product you are trying to restock was not found. Please refresh the page and try again.',
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                }
            } else {
                console.error('📦 Products table not initialized');

                // Show loading message and retry
                Swal.fire({
                    title: 'Loading...',
                    text: 'Please wait while the inventory data loads.',
                    icon: 'info',
                    background: '#16213e',
                    color: '#ffffff',
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    // Retry after 2 seconds
                    if (productsTable && productsTable.data().count() > 0) {
                        window.openUpdateStockModal(productId);
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'Failed to load inventory data. Please refresh the page.',
                            icon: 'error',
                            background: '#16213e',
                            color: '#ffffff',
                            confirmButtonColor: '#e74c3c'
                        });
                    }
                });
            }
        };

        // Check for URL parameters on page load
        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            const productId = urlParams.get('product_id');
            const action = urlParams.get('action');

            if (productId && action === 'restock') {
                console.log('📦 Restock action detected for product:', productId);

                // Wait for table to load, then open modal
                let attempts = 0;
                const maxAttempts = 10;

                const tryOpenModal = function() {
                    attempts++;
                    console.log('📦 Attempt', attempts, 'to open restock modal');

                    if (productsTable && productsTable.data().count() > 0) {
                        // Table is loaded with data
                        console.log('📦 Table loaded, opening modal for product:', productId);
                        window.openUpdateStockModal(productId);

                        // Clean up URL
                        const newUrl = window.location.pathname;
                        window.history.replaceState({}, document.title, newUrl);
                    } else if (attempts < maxAttempts) {
                        // Try again after 500ms
                        setTimeout(tryOpenModal, 500);
                    } else {
                        console.error('📦 Failed to load table data after', maxAttempts, 'attempts');
                        // Fallback: show alert
                        alert('Product data is still loading. Please try again in a moment.');
                    }
                };

                // Start trying to open modal
                setTimeout(tryOpenModal, 1000);
            }
        });

    </script>
</body>
</html>