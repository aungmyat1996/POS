<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Start session as early as possible
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Require authentication for this page
requireLogin();

// Get settings first to avoid undefined array key warnings for language/currency fallback
try {
    $stmt_settings_dashboard = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings_array_dashboard = $stmt_settings_dashboard->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings for dashboard: " . $e->getMessage());
    $settings_array_dashboard = [];
}

// Determine language
$language = $_SESSION['language'] ?? ($settings_array_dashboard['language'] ?? 'en');

// Load translations using the consistent function
$translations = loadLanguage($language);

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Clear old session data and get fresh from database
unset($_SESSION['system_name']);

// Get system name from database immediately
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_name'");
    $stmt->execute();
    $db_site_name = $stmt->fetchColumn();

    // Update session with database value
    if ($db_site_name) {
        $_SESSION['system_name'] = $db_site_name;
        error_log("Dashboard.php: Updated system_name to: " . $db_site_name);
    } else {
        error_log("Dashboard.php: No site_name found in database");
    }
} catch (PDOException $e) {
    error_log("Dashboard.php: Error fetching site_name: " . $e->getMessage());
}

$logo_path = $_SESSION['logo_path'] ?? '../public/images/logo.png';
// $system_name will be handled by navbar.php from database
$theme_color = $_SESSION['theme_color'] ?? '#F97316';
$font_size = $_SESSION['font_size'] ?? '16px';
$store_info = $_SESSION['store_info'] ?? '<i class="fas fa-envelope me-1"></i> bitstech2025@gmail.com <i class="fas fa-phone me-1"></i> +969123456789 <i class="fas fa-map-marker-alt me-1"></i> 123 Tech Lane, Yangon, Myanmar';

// Use the fetched settings for language and currency fallbacks
// $language = $_SESSION['language'] ?? ($settings_array_dashboard['language'] ?? 'en'); // This is now handled above
// $language_file = "../languages/{$language}.php"; // This is handled by loadLanguage()
// $translations = file_exists($language_file) ? require $language_file : require "../languages/en.php"; // This is now handled above

$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];
$currency = $_SESSION['currency'] ?? ($settings_array_dashboard['currency'] ?? 'USD');

// Set timezone for EEST (Eastern European Summer Time)
date_default_timezone_set('Europe/Bucharest');
$current_datetime = date('l, F d, Y, h:i A T');

// Fetch dashboard data with error handling
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= reorder_level");
    $low_stock_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $low_stock_count = 0;
    error_log("Error fetching low stock count: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM products");
    $total_products = $stmt->fetchColumn();
} catch (PDOException $e) {
    $total_products = 0;
    error_log("Error fetching total products: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT COUNT(DISTINCT customer_id) FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND status = 'completed' AND customer_id IS NOT NULL");
    $today_customers_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $today_customers_count = 0;
    error_log("Error fetching today's customers count: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT SUM(total_amount) FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    $today_sales_total = $stmt->fetchColumn() ?: 0;
} catch (PDOException $e) {
    $today_sales_total = 0;
    error_log("Error fetching today's sales total: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales
                         FROM sales s
                         WHERE MONTH(s.sale_date) = MONTH(CURDATE()) AND YEAR(s.sale_date) = YEAR(CURDATE())");
    $monthly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $monthly_sales_total = 0;
    error_log("Error fetching monthly sales total: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT SUM(s.total_amount) as total_sales
                         FROM sales s
                         WHERE YEAR(s.sale_date) = YEAR(CURDATE())");
    $yearly_sales_total = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $yearly_sales_total = 0;
    error_log("Error fetching yearly sales total: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT s.sale_id, s.order_id, c.customer_name AS customer_name, s.total_amount, s.sale_date
                         FROM sales s
                         LEFT JOIN customers c ON s.customer_id = c.customer_id
                         ORDER BY s.sale_date DESC LIMIT 5");
    $recent_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $recent_sales = [];
    error_log("Error fetching recent sales: " . $e->getMessage());
}

$selected_date = isset($_POST['sale_date']) ? $_POST['sale_date'] : date('Y-m-d');
try {
    $stmt = $pdo->prepare("SELECT s.sale_id, c.customer_name AS customer_name, s.total_amount, s.sale_date
                           FROM sales s
                           LEFT JOIN customers c ON s.customer_id = c.customer_id
                           WHERE DATE(s.sale_date) = ?
                           ORDER BY s.sale_date DESC");
    $stmt->execute([$selected_date]);
    $customer_sales_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $customer_sales_history = [];
    error_log("Error fetching customer sales history: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT category_name, COUNT(*) as count FROM products JOIN categories ON products.category_id = categories.category_id GROUP BY category_name");
    $category_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $category_distribution = [];
    error_log("Error fetching category distribution: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT p.product_name, SUM(oi.quantity) as total_sold
                         FROM order_items oi
                         JOIN products p ON oi.product_id = p.product_id
                         JOIN orders o ON oi.order_id = o.order_id
                         GROUP BY p.product_id, p.product_name
                         ORDER BY total_sold DESC
                         LIMIT 5");
    $top_selling_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $top_selling_products = [];
    error_log("Error fetching top selling products: " . $e->getMessage());
}

$sales_trend = [];
$today = new DateTime();
for ($i = 6; $i >= 0; $i--) {
    $date = clone $today;
    $date->modify("-$i days");
    try {
        $stmt = $pdo->prepare("SELECT SUM(total_amount) as total FROM sales WHERE DATE(sale_date) = ?");
        $stmt->execute([$date->format('Y-m-d')]);
        $sales_trend[$date->format('Y-m-d')] = $stmt->fetchColumn() ?: 0;
    } catch (PDOException $e) {
        $sales_trend[$date->format('Y-m-d')] = 0;
        error_log("Error fetching sales trend for date {$date->format('Y-m-d')}: " . $e->getMessage());
    }
}

try {
    $stmt = $pdo->query("SELECT product_name, stock_quantity FROM products WHERE stock_quantity <= 5 LIMIT 5");
    $low_stock_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $low_stock_products = [];
    error_log("Error fetching low stock products: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SELECT l.action, u.username AS user, l.created_at AS timestamp
                         FROM logs l
                         JOIN users u ON l.user_id = u.user_id
                         ORDER BY l.created_at DESC LIMIT 5");
    $activity_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $activity_logs = [];
    error_log("Error fetching activity logs: " . $e->getMessage());
}

if (isset($_SESSION['user_id'])) {
    $notifications = getUserNotifications($pdo, $_SESSION['user_id']);
    $unread_count = getUnreadNotificationsCount($pdo, $_SESSION['user_id']);
} else {
    $notifications = [];
    $unread_count = 0;
}

// Notify low stock products on dashboard load
if (isset($_SESSION['user_id'])) {
    notifyLowStockProducts($pdo, $_SESSION['user_id']);
}

// Fetch notifications for navbar
if (isset($_SESSION['user_id'])) {
    $nav_notifications = getUserNotifications($pdo, $_SESSION['user_id']);
    $nav_unread_count = getUnreadNotificationsCount($pdo, $_SESSION['user_id']);
} else {
    $nav_notifications = [];
    $nav_unread_count = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sale_date'])) {
    $selected_date = $_POST['sale_date'];
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport slippage="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $translations['dashboard_title'] ?? 'Dashboard - BitsTech POS'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <!-- jQuery must be loaded before navbar.php -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <style>
        .loading-spinner {
            display: none;
            text-align: center;
            padding: 20px;
        }
        .loading-spinner i {
            font-size: 1.5rem;
            color: var(--accent);
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Light Mode Text Colors for Dashboard Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #212529 !important;
        }

        [data-theme="light"] .stat-box .value {
            color: #212529 !important;
        }

        [data-theme="light"] .stat-box .label {
            color: #6c757d !important;
        }

        [data-theme="light"] .dashboard-card h4 {
            color: #212529 !important;
        }

        [data-theme="light"] .insights-table td,
        [data-theme="light"] .recent-sales-table td,
        [data-theme="light"] .recent-orders-table td {
            color: #212529 !important;
        }

        [data-theme="light"] .alert-list li .product-name {
            color: #212529 !important;
        }

        [data-theme="light"] .activity-logs li {
            color: #212529 !important;
        }

        [data-theme="light"] .log-action,
        [data-theme="light"] .log-user,
        [data-theme="light"] .log-timestamp {
            color: #212529 !important;
        }

        /* Light Mode Stats Cards Enhancement */
        [data-theme="light"] .stat-box {
            background: #ffffff !important;
            border: 1px solid #dee2e6 !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
            transition: all 0.3s ease !important;
        }

        [data-theme="light"] .stat-box:hover {
            transform: translateY(-5px) !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
            background: #f8f9fa !important;
        }

        [data-theme="light"] .stat-box i {
            color: #007bff !important;
        }

        [data-theme="light"] .stat-box .value {
            color: #212529 !important;
            font-weight: bold !important;
        }

        [data-theme="light"] .stat-box .label {
            color: #6c757d !important;
            font-weight: 500 !important;
        }

        /* Dark Mode Stats Cards Enhancement */
        [data-theme="dark"] .stat-box {
            background: rgb(33, 36, 58) !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2) !important;
            backdrop-filter: blur(10px) !important;
            transition: all 0.3s ease !important;
        }

        [data-theme="dark"] .stat-box:hover {
            transform: translateY(-5px) !important;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3) !important;
            background: rgba(33, 36, 58, 0.9) !important;
        }

        [data-theme="dark"] .stat-box i {
            color: #ffffff !important;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5) !important;
        }

        [data-theme="dark"] .stat-box .value {
            color: #ffffff !important;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5) !important;
            font-weight: bold !important;
        }

        [data-theme="dark"] .stat-box .label {
            color: #ffffff !important;
            text-shadow: 0 1px 3px rgba(0, 0, 0, 0.5) !important;
            font-weight: 500 !important;
        }

        /* Light Mode Overview Title Color */
        [data-theme="light"] h4[data-translate="overview"] {
            color: #000000 !important;
        }

        /* Light Mode Dashboard Section Titles */
        [data-theme="light"] h4[data-translate="sales_by_period"],
        [data-theme="light"] h4[data-translate="low_stock_alerts"],
        [data-theme="light"] h4[data-translate="recent_sales"],
        [data-theme="light"] h4[data-translate="activity_logs"],
        [data-theme="light"] h4[data-translate="category_distribution"],
        [data-theme="light"] h4[data-translate="top_selling_products"],
        [data-theme="light"] h4[data-translate="sales_trend"] {
            color: #000000 !important;
        }

        /* Dark Mode Dashboard Section Titles */
        [data-theme="dark"] h4[data-translate="category_distribution"],
        [data-theme="dark"] h4[data-translate="sales_trend"],
        [data-theme="dark"] h4[data-translate="top_selling_products"] {
            color: #ffffff !important;
        }

        /* Light Mode Chart Section Titles Override */
        [data-theme="light"] h4[data-translate="category_distribution"],
        [data-theme="light"] h4[data-translate="sales_trend"] {
            color: #212529 !important;
        }

        /* Light Mode Low Stock Alerts Text */
        [data-theme="light"] .alert-list li .product-name {
            color: #212529 !important;
        }

        [data-theme="light"] .alert-list li .stock-quantity {
            color: #dc3545 !important;
        }

        [data-theme="light"] .alert-list li {
            color: #212529 !important;
        }

        /* Light Mode Activity Logs Text */
        [data-theme="light"] .activity-logs li {
            color: #212529 !important;
        }

        [data-theme="light"] .log-action,
        [data-theme="light"] .log-user,
        [data-theme="light"] .log-timestamp {
            color: #212529 !important;
        }

        /* Light Mode Chart Text Colors */
        [data-theme="light"] .chart-container-small canvas,
        [data-theme="light"] #categoryChart,
        [data-theme="light"] #salesTrendChart {
            color: #000000 !important;
        }

        /* Light Mode Table Headers and Data */
        [data-theme="light"] .insights-table th,
        [data-theme="light"] .recent-sales-table th,
        [data-theme="light"] .insights-table td,
        [data-theme="light"] .recent-sales-table td {
            color: #212529 !important;
        }

        /* Light Mode Form Labels */
        [data-theme="light"] .form-label {
            color: #212529 !important;
        }

        /* Light Mode No Data Messages */
        [data-theme="light"] .text-center[data-translate] {
            color: #212529 !important;
        }

        /* Light Mode Dashboard Cards */
        [data-theme="light"] .dashboard-card {
            background: #ffffff !important;
            border: 1px solid #dee2e6 !important;
            color: #212529 !important;
        }

        [data-theme="light"] .dashboard-card .card-body {
            background: #ffffff !important;
            color: #212529 !important;
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="container">
                <div class="dashboard-card">
                    <h4 data-translate="overview"><?php echo $translations['overview'] ?? 'Overview'; ?></h4>
                    <div class="stats-grid">
                        <div class="stat-box">
                            <i class="fas fa-box"></i>
                            <div class="value"><?php echo number_format($total_products, 0, '.', ','); ?></div>
                            <div class="label" data-translate="total_products"><?php echo $translations['total_products'] ?? 'Total Products'; ?></div>
                        </div>
                        <div class="stat-box">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div class="value"><?php echo number_format($low_stock_count, 0, '.', ','); ?></div>
                            <div class="label" data-translate="low_stock_items"><?php echo $translations['low_stock_items'] ?? 'Low Stock Items'; ?></div>
                        </div>
                        <div class="stat-box">
                            <i class="fas fa-shopping-cart"></i>
                            <div class="value"><?php echo number_format($today_customers_count, 0, '.', ','); ?></div>
                            <div class="label" data-translate="todays_customers_count"><?php echo $translations['todays_customers_count'] ?? "Today's Customers Count"; ?></div>
                        </div>
                        <div class="stat-box">
                            <i class="fas fa-dollar-sign"></i>
                            <div class="value" id="today-sales-total"><?php echo $currency_symbols[$currency] . ' ' . number_format($today_sales_total * $exchange_rates[$currency], 0); ?></div>
                            <div class="label" data-translate="today_sales_total"><?php echo $translations['today_sales_total'] ?? "Today's Sales Total"; ?></div>
                        </div>
                        <div class="stat-box">
                            <i class="fas fa-calendar"></i>
                            <div class="value" id="monthly-sales-total"><?php echo $currency_symbols[$currency] . ' ' . number_format($monthly_sales_total * $exchange_rates[$currency], 0); ?></div>
                            <div class="label" data-translate="monthly_sales_total"><?php echo $translations['monthly_sales_total'] ?? 'Monthly Sales Total'; ?></div>
                        </div>
                        <div class="stat-box">
                            <i class="fas fa-year"></i>
                            <div class="value" id="yearly-sales-total"><?php echo $currency_symbols[$currency] . ' ' . number_format($yearly_sales_total * $exchange_rates[$currency], 0); ?></div>
                            <div class="label" data-translate="yearly_sales_total"><?php echo $translations['yearly_sales_total'] ?? 'Yearly Sales Total'; ?></div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card">
                    <h4 data-translate="sales_by_period"><?php echo $translations['sales_by_period'] ?? 'Sales by Period'; ?></h4>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <form method="POST" id="sales-period-form">
                                <label for="sale_date" class="form-label" data-translate="select_date"><?php echo $translations['select_date'] ?? 'Select Date'; ?></label>
                                <input type="date" name="sale_date" id="sale_date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>">
                            </form>
                        </div>
                    </div>
                    <div class="loading-spinner" id="sales-loading">
                        <i class="fas fa-spinner"></i>
                    </div>
                    <div class="table-container" id="sales-history-table">
                        <table class="recent-sales-table">
                            <thead>
                                <tr>
                                    <th data-translate="sale_id"><?php echo $translations['sale_id'] ?? 'Sale ID'; ?></th>
                                    <th data-translate="customer_name"><?php echo $translations['customer_name'] ?? 'Customer Name'; ?></th>
                                    <th data-translate="amount"><?php echo $translations['amount'] ?? 'Amount'; ?></th>
                                    <th data-translate="date"><?php echo $translations['date'] ?? 'Date'; ?></th>
                                    <th data-translate="actions"><?php echo $translations['actions'] ?? 'Actions'; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($customer_sales_history as $sale): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($sale['sale_id']); ?></td>
                                        <td><?php echo htmlspecialchars($sale['customer_name'] ?? 'N/A'); ?></td>
                                        <td class="sale-amount"><?php echo $currency_symbols[$currency] . ' ' . number_format($sale['total_amount'] * $exchange_rates[$currency], 2); ?></td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($sale['sale_date'])); ?></td>
                                        <td>
                                            <button class="btn btn-warning btn-sm" onclick="editSale(<?php echo $sale['sale_id']; ?>)"><span data-translate="edit"><?php echo $translations['edit'] ?? 'Edit'; ?></span></button>
                                            <button class="btn btn-danger btn-sm" onclick="deleteSale(<?php echo $sale['sale_id']; ?>)"><span data-translate="delete"><?php echo $translations['delete'] ?? 'Delete'; ?></span></button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($customer_sales_history)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center" data-translate="no_sales_data"><?php echo $translations['no_sales_data'] ?? 'No sales data for selected date.'; ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="insights-grid">
                    <div class="dashboard-card">
                        <h4 data-translate="category_distribution"><?php echo $translations['category_distribution'] ?? 'Category Distribution'; ?></h4>
                        <div class="chart-container-small">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>

                    <div class="dashboard-card">
                        <h4 data-translate="top_selling_products"><?php echo $translations['top_selling_products'] ?? 'Top Selling Products'; ?></h4>
                        <div class="table-container">
                            <table class="insights-table">
                                <thead>
                                    <tr>
                                        <th data-translate="product"><?php echo $translations['product'] ?? 'Product'; ?></th>
                                        <th data-translate="total_sold"><?php echo $translations['total_sold'] ?? 'Total Sold'; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_selling_products as $product): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                            <td><?php echo number_format($product['total_sold'], 0, '.', ','); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($top_selling_products)): ?>
                                        <tr>
                                            <td colspan="2" class="text-center" data-translate="no_sales_data"><?php echo $translations['no_sales_data'] ?? 'No sales data available.'; ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="dashboard-card">
                        <h4 data-translate="sales_trend"><?php echo $translations['sales_trend'] ?? 'Sales Trend (Last 7 Days)'; ?></h4>
                        <div class="chart-container-small">
                            <canvas id="salesTrendChart"></canvas>
                        </div>
                    </div>

                    <div class="dashboard-card">
                        <h4 data-translate="low_stock_alerts"><?php echo $translations['low_stock_alerts'] ?? 'Low Stock Alerts'; ?></h4>
                        <ul class="alert-list">
                            <?php foreach ($low_stock_products as $product): ?>
                                <li>
                                    <span class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></span>
                                    <span class="stock-quantity"><?php echo number_format($product['stock_quantity'], 0, '.', ','); ?> <span data-translate="units"><?php echo $translations['units'] ?? 'units'; ?></span></span>
                                </li>
                            <?php endforeach; ?>
                            <?php if (empty($low_stock_products)): ?>
                                <li class="text-center" data-translate="no_low_stock"><?php echo $translations['no_low_stock'] ?? 'No low stock items.'; ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <div class="dashboard-card">
                    <h4 data-translate="recent_sales"><?php echo $translations['recent_sales'] ?? 'Recent Sales'; ?></h4>
                    <div class="table-container">
                        <table class="recent-sales-table">
                            <thead>
                                <tr>
                                    <th data-translate="order_id"><?php echo $translations['order_id'] ?? 'Order ID'; ?></th>
                                    <th data-translate="customer"><?php echo $translations['customer'] ?? 'Customer'; ?></th>
                                    <th data-translate="amount"><?php echo $translations['amount'] ?? 'Amount'; ?></th>
                                    <th data-translate="date"><?php echo $translations['date'] ?? 'Date'; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_sales as $sale): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($sale['order_id'] ?? $sale['sale_id']); ?></td>
                                        <td><?php echo htmlspecialchars($sale['customer_name'] ?? 'N/A'); ?></td>
                                        <td class="sale-amount"><?php echo $currency_symbols[$currency] . ' ' . number_format($sale['total_amount'] * $exchange_rates[$currency], 2); ?></td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($sale['sale_date'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($recent_sales)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center" data-translate="no_recent_sales"><?php echo $translations['no_recent_sales'] ?? 'No recent sales available.'; ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="dashboard-card">
                    <h4 data-translate="activity_logs"><?php echo $translations['activity_logs'] ?? 'Activity Logs'; ?></h4>
                    <ul class="activity-logs">
                        <?php foreach ($activity_logs as $log): ?>
                            <li>
                                <span class="log-action">[<?php echo htmlspecialchars($log['action']); ?>]</span>
                                <span class="log-user"><?php echo htmlspecialchars($log['user']); ?></span>
                                <span class="log-timestamp"><?php echo date('M d, Y H:i', strtotime($log['timestamp'])); ?></span>
                            </li>
                        <?php endforeach; ?>
                        <?php if (empty($activity_logs)): ?>
                            <li class="text-center" data-translate="no_logs"><?php echo $translations['no_logs'] ?? 'No activity logs available.'; ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        let currentCurrency = '<?php echo $currency; ?>';
        let currentLanguage = '<?php echo $language; ?>';
        const exchangeRates = <?php echo json_encode($exchange_rates); ?>;
        const currencySymbols = <?php echo json_encode($currency_symbols); ?>;
        let translations = <?php echo json_encode($translations); ?>;
        let csrfToken = '<?php echo $_SESSION['csrf_token']; ?>';
        let salesTrendChart;

        // Function to add comma separators to numbers
        function addCommas(number) {
            const parts = number.toString().split('.');
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            return parts.join('.');
        }

        $(document).ready(function() {
            console.log('Dashboard page ready - initializing...');

            // Initialize theme manager
            if (typeof ThemeManager !== 'undefined') {
                window.themeManager = new ThemeManager();
                window.themeManager.init();
                console.log('🎨 Dashboard: Theme manager initialized');

                // Add theme change listener to update charts
                document.addEventListener('themeChanged', function(event) {
                    console.log('🎨 Dashboard: Theme changed event received:', event.detail.theme);
                    setTimeout(() => {
                        console.log('🎨 Dashboard: Reinitializing charts for theme:', event.detail.theme);
                        initializeCharts();
                    }, 100);
                });
            }

            // Listen for theme changes from navbar toggle
            window.addEventListener('storage', function(e) {
                if (e.key === 'theme_changed' && e.newValue) {
                    try {
                        const data = JSON.parse(e.newValue);
                        console.log('🎨 Dashboard: Detected theme change from navbar:', data.theme);

                        // Apply theme to dashboard page
                        document.documentElement.setAttribute('data-theme', data.theme);
                        document.body.setAttribute('data-theme', data.theme);

                        // Update theme manager if available
                        if (typeof window.themeManager !== 'undefined') {
                            window.themeManager.setThemeMode(data.theme);
                        }

                        // Reinitialize charts with new theme
                        setTimeout(() => {
                            console.log('🎨 Dashboard: Reinitializing charts for navbar theme change:', data.theme);
                            initializeCharts();
                        }, 100);

                        console.log('🎨 Dashboard: Synced with navbar theme change');
                    } catch (error) {
                        console.error('🎨 Dashboard: Error parsing theme change:', error);
                    }
                }
            });

            initializeCharts();
            initializeNavbarFunctionality();

            // AJAX for Sales History
            $('#sale_date').on('change', function() {
                const saleDate = $(this).val();
                $('#sales-loading').show();
                $('#sales-history-table').hide();

                $.ajax({
                    url: 'fetch_sales_history.php',
                    method: 'POST',
                    data: { sale_date: saleDate },
                    dataType: 'html',
                    success: function(data) {
                        $('#sales-history-table').html(data).fadeIn();
                        $('#sales-loading').hide();
                        updateSalesHistoryCurrency();
                        updateSalesHistoryTranslations();
                    },
                    error: function() {
                        $('#sales-history-table').html('<table class="recent-sales-table"><tbody><tr><td colspan="5" class="text-center" data-translate="no_sales_data">' + (translations['no_sales_data'] || 'No sales data for selected date.') + '</td></tr></tbody></table>').fadeIn();
                        $('#sales-loading').hide();
                    }
                });
            });

            window.editSale = function(saleId) {
                window.location.href = 'edit_sale.php?id=' + saleId;
            };

            window.deleteSale = function(saleId) {
                if (confirm(translations['confirm_delete_sale'] || 'Are you sure you want to delete this sale?')) {
                    $.ajax({
                        url: 'delete_sale.php',
                        method: 'POST',
                        data: { sale_id: saleId },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                showCustomAlert(translations['sale_deleted'] || 'Sale deleted successfully.', 'success');
                                $('#sale_date').trigger('change');
                            } else {
                                showCustomAlert('Error: ' + response.message, 'error');
                            }
                        },
                        error: function() {
                            showCustomAlert(translations['error_deleting_sale'] || 'Error deleting sale.', 'error');
                        }
                    });
                }
            };

            // Currency change handler (instant, no reload)
            $('#currency-select').off('change').on('change', function() {
                const newCurrency = $(this).val();
                $.post('update_currency.php', { currency: newCurrency, csrf_token: csrfToken }, function(response) {
                    if (response.success) {
                        currentCurrency = response.currency || newCurrency;
                        fetchDashboardData();
                    } else {
                        showCustomAlert(translations['error_updating_currency'] || 'Error updating currency');
                    }
                }, 'json');
            });

            // Language change handler (instant, no reload)
            $('.language-item').off('click').on('click', function() {
                const lang = $(this).data('lang');
                $.post('update_language.php', { language: lang, csrf_token: csrfToken }, function(response) {
                    if (response.success) {
                        translations = response.translations;
                        currentLanguage = lang;
                        updateUIText();
                        fetchDashboardData();
                        $('.language-label').text(lang === 'en' ? (translations['lang_en'] || 'EN') : (translations['lang_mm'] || 'MY'));
                    } else {
                        showCustomAlert(translations['error_updating_language'] || 'Error updating language');
                    }
                }, 'json');
            });

            // Calculator toggle
            $('.calculator-toggle').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('Calculator toggle clicked');
                $('#calculator-overlay').toggleClass('active');
            });

            // Calculator overlay click outside to close
            $('#calculator-overlay').off('click').on('click', function(e) {
                if (e.target === this) {
                    $(this).removeClass('active');
                }
            });

            initializeCalculator();
            console.log('Navbar functionality initialized successfully');
        });

        function initializeNavbarFunctionality() {
            console.log('Initializing navbar functionality...');

            // Currency change handler
            $('#currency-select').off('change').on('change', function() {
                console.log('Currency change detected:', $(this).val());
                const newCurrency = $(this).val();

                $.ajax({
                    url: 'update_currency.php',
                    method: 'POST',
                    data: {
                        currency: newCurrency,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Currency update response:', response);
                        if (response.success) {
                            window.location.reload();
                        } else {
                            showMessage('Failed to update currency: ' + response.message, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Currency update error:', xhr.responseText, error);
                        showMessage('Error updating currency: ' + error, 'error');
                    }
                });
            });

            // Language change handler
            $('.language-item').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('Language change detected:', $(this).data('lang'));
                const newLanguage = $(this).data('lang');

                $.ajax({
                    url: 'update_language.php',
                    method: 'POST',
                    data: {
                        language: newLanguage,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Language update response:', response);
                        if (response.success) {
                            window.location.reload();
                        } else {
                            showMessage('Failed to update language: ' + response.message, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Language update error:', xhr.responseText, error);
                        showMessage('Error updating language: ' + error, 'error');
                    }
                });
            });

            // Calculator toggle
            $('.calculator-toggle').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('Calculator toggle clicked');
                $('#calculator-overlay').toggleClass('active');
            });

            // Calculator overlay click outside to close
            $('#calculator-overlay').off('click').on('click', function(e) {
                if (e.target === this) {
                    $(this).removeClass('active');
                }
            });

            initializeCalculator();
            console.log('Navbar functionality initialized successfully');
        }

        function initializeCalculator() {
            if (document.querySelector('.calculator-keys')) {
                const calculator = {
                    displayValue: '0',
                    firstOperand: null,
                    waitingForSecondOperand: false,
                    operator: null,
                };

                function inputDigit(digit) {
                    if (calculator.waitingForSecondOperand) {
                        calculator.displayValue = digit;
                        calculator.waitingForSecondOperand = false;
                    } else {
                        calculator.displayValue = calculator.displayValue === '0' ? digit : calculator.displayValue + digit;
                    }
                    updateDisplay();
                }

                function inputDecimal(dot) {
                    if (calculator.waitingForSecondOperand) {
                        calculator.displayValue = '0.';
                        calculator.waitingForSecondOperand = false;
                        return;
                    }
                    if (!calculator.displayValue.includes('.')) {
                        calculator.displayValue += dot;
                    }
                    updateDisplay();
                }

                function handleOperator(nextOperator) {
                    const display = parseFloat(calculator.displayValue);
                    if (calculator.operator && calculator.waitingForSecondOperand) {
                        calculator.operator = nextOperator;
                        return;
                    }
                    if (calculator.firstOperand === null && !isNaN(display)) {
                        calculator.firstOperand = display;
                    } else if (calculator.operator) {
                        const result = calculate(calculator.firstOperand, display, calculator.operator);
                        calculator.displayValue = String(result);
                        calculator.firstOperand = result;
                    }
                    calculator.waitingForSecondOperand = true;
                    calculator.operator = nextOperator;
                    updateDisplay();
                }

                function calculate(first, second, operator) {
                    switch (operator) {
                        case '+': return first + second;
                        case '-': return first - second;
                        case 'x': return first * second;
                        case '/': return second !== 0 ? first / second : 'Error';
                        default: return second;
                    }
                }

                function updateDisplay() {
                    const display = document.getElementById('display');
                    if (display) {
                        display.textContent = calculator.displayValue;
                        if (display.textContent.length > 12) {
                            display.style.fontSize = '1.2rem';
                        } else {
                            display.style.fontSize = '1.5rem';
                        }
                    }
                }

                function resetCalculator() {
                    calculator.displayValue = '0';
                    calculator.firstOperand = null;
                    calculator.waitingForSecondOperand = false;
                    calculator.operator = null;
                    updateDisplay();
                }

                function performCalculation() {
                    const display = parseFloat(calculator.displayValue);
                    if (calculator.firstOperand !== null && !isNaN(display)) {
                        const result = calculate(calculator.firstOperand, display, calculator.operator);
                        calculator.displayValue = String(result);
                        calculator.firstOperand = result;
                        calculator.waitingForSecondOperand = false;
                        calculator.operator = null;
                    }
                    updateDisplay();
                }

                const keys = document.querySelector('.calculator-keys');
                if (keys) {
                    keys.addEventListener('click', (event) => {
                        const { target } = event;
                        if (!target.matches('button')) return;

                        if (target.classList.contains('operator')) {
                            handleOperator(target.textContent);
                            return;
                        }
                        if (target.classList.contains('decimal')) {
                            inputDecimal('.');
                            return;
                        }
                        if (target.classList.contains('clear')) {
                            resetCalculator();
                            return;
                        }
                        if (target.classList.contains('equal')) {
                            performCalculation();
                            return;
                        }
                        inputDigit(target.textContent);
                    });
                }
                console.log('Calculator functionality initialized');
            }
        }

        function initializeCharts() {
            // Get current theme for chart text colors
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            // Light mode = black text, Dark mode = white text
            const chartTextColor = currentTheme === 'light' ? '#000000' : '#ffffff';
            const gridColor = currentTheme === 'light' ? '#E5E7EB' : '#2D314D';

            console.log('Current theme:', currentTheme, 'Chart text color:', chartTextColor);

            // Set Chart.js default colors
            Chart.defaults.color = chartTextColor;
            Chart.defaults.borderColor = gridColor;

            // Initialize Category Distribution Chart
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            const categoryChart = new Chart(categoryCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($category_distribution, 'category_name')); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_column($category_distribution, 'count')); ?>,
                        backgroundColor: [
                            '#F97316', '#FF4D4F', '#17a2b8', '#28a745', '#6c757d',
                            '#dc3545', '#007bff', '#ffc107', '#e83e8c'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                color: chartTextColor,
                                font: { size: 10 }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    let value = context.raw || 0;
                                    return label + ': ' + addCommas(value);
                                }
                            }
                        }
                    }
                }
            });

            // Initialize Sales Trend Chart
            initializeSalesTrendChart();
        }

        function initializeSalesTrendChart() {
            // Get current theme
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            // Light mode = black text, Dark mode = white text
            const chartTextColor = currentTheme === 'light' ? '#000000' : '#ffffff';
            const gridColor = currentTheme === 'light' ? '#E5E7EB' : '#2D314D';

            const salesTrendCtx = document.getElementById('salesTrendChart').getContext('2d');
            salesTrendChart = new Chart(salesTrendCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_keys($sales_trend)); ?>,
                    datasets: [{
                        label: translations['sales_amount'] || 'Sales Amount',
                        data: <?php echo json_encode(array_values($sales_trend)); ?>,
                        borderColor: '#F97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.2)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            ticks: { color: chartTextColor, font: { size: 10 } },
                            grid: { color: gridColor }
                        },
                        y: {
                            ticks: {
                                color: chartTextColor,
                                font: { size: 10 },
                                callback: function(value) {
                                    const converted = value * exchangeRates[currentCurrency];
                                    return currencySymbols[currentCurrency] + ' ' + addCommas(converted.toFixed(0));
                                }
                            },
                            grid: { color: gridColor }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: { color: chartTextColor, font: { size: 10 } }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    let value = context.raw || 0;
                                    const converted = value * exchangeRates[currentCurrency];
                                    return label + ': ' + currencySymbols[currentCurrency] + ' ' + addCommas(converted.toFixed(0));
                                }
                            }
                        }
                    }
                }
            });
        }

        function showMessage(message, type) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            const alert = $(`
                <div class="alert ${alertClass} alert-dismissible fade show position-fixed"
                     style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);

            $('body').append(alert);

            setTimeout(() => {
                alert.fadeOut(() => alert.remove());
            }, 5000);
        }

        function updateSalesHistoryCurrency() {
            $('#sales-history-table .sale-amount').each(function() {
                const baseAmount = parseFloat($(this).text().replace(/[^0-9.-]+/g, '')) || 0;
                const converted = baseAmount * (exchangeRates[currentCurrency] / exchangeRates['USD']);
                $(this).text(currencySymbols[currentCurrency] + ' ' + addCommas(converted.toFixed(2)));
            });
        }

        function updateSalesHistoryTranslations() {
            $('#sales-history-table [data-translate]').each(function() {
                const key = $(this).data('translate');
                if (translations[key]) {
                    $(this).text(translations[key]);
                }
            });
        }

        // Add global update functions for instant navbar changes (no reload)
        window.updatePageForNewCurrency = function(newCurrency, response) {
            if (typeof newCurrency === 'string') {
                currentCurrency = newCurrency;
                // Optionally update exchangeRates/currencySymbols if response provides them
                if (response && response.exchangeRates) {
                    Object.assign(exchangeRates, response.exchangeRates);
                }
                updateSalesHistoryCurrency();
                if (typeof initializeCharts === 'function') {
                    initializeCharts();
                }
                showMessage(translations['currency_updated'] || 'Currency updated!', 'success');
            }
        };
        // Make sure globals are available
        window.translations = translations;
        window.currentLanguage = currentLanguage;
        window.currencySymbols = currencySymbols;

        console.log('Dashboard page loaded - navbar functionality initialized');

        // Initialize notification bell visibility immediately
        if (typeof window.updateNotificationBellVisibility === 'function') {
            window.updateNotificationBellVisibility();
            console.log('🔔 Dashboard: Notification bell visibility updated');
        }

        // Expose dashboard data as JS object
        window.dashboardData = {
            total_products: <?php echo json_encode($total_products); ?>,
            low_stock_count: <?php echo json_encode($low_stock_count); ?>,
            today_customers_count: <?php echo json_encode($today_customers_count); ?>,
            today_sales_total: <?php echo json_encode($today_sales_total); ?>,
            monthly_sales_total: <?php echo json_encode($monthly_sales_total); ?>,
            yearly_sales_total: <?php echo json_encode($yearly_sales_total); ?>,
            customer_sales_history: <?php echo json_encode($customer_sales_history); ?>,
            category_distribution: <?php echo json_encode($category_distribution); ?>,
            top_selling_products: <?php echo json_encode($top_selling_products); ?>,
            sales_trend: <?php echo json_encode($sales_trend); ?>,
            low_stock_products: <?php echo json_encode($low_stock_products); ?>,
            recent_sales: <?php echo json_encode($recent_sales); ?>,
            activity_logs: <?php echo json_encode($activity_logs); ?>,
            currency: '<?php echo $currency; ?>',
            language: '<?php echo $language; ?>',
            exchange_rates: <?php echo json_encode($exchange_rates); ?>,
            currency_symbols: <?php echo json_encode($currency_symbols); ?>
        };

        // Fetch updated dashboard data (AJAX)
        function fetchDashboardData() {
            $.ajax({
                url: 'dashboard_data.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    window.dashboardData = data;
                    updateDashboardUI(data);
                    updateUIText();
                }
            });
        }

        // Update all dashboard UI in-place
        function updateDashboardUI(data) {
            // Stat boxes
            $('.stat-box .value').eq(0).text(data.total_products);
            $('.stat-box .value').eq(1).text(data.low_stock_count);
            $('.stat-box .value').eq(2).text(data.today_customers_count);
            $('#today-sales-total').text(data.currency_symbols[data.currency] + ' ' + addCommas((data.today_sales_total * data.exchange_rates[data.currency]).toFixed(0)));
            $('#monthly-sales-total').text(data.currency_symbols[data.currency] + ' ' + addCommas((data.monthly_sales_total * data.exchange_rates[data.currency]).toFixed(0)));
            $('#yearly-sales-total').text(data.currency_symbols[data.currency] + ' ' + addCommas((data.yearly_sales_total * data.exchange_rates[data.currency]).toFixed(0)));
            // Sales history table
            let salesRows = '';
            if (data.customer_sales_history.length) {
                data.customer_sales_history.forEach(function(sale) {
                    salesRows += `<tr><td>${sale.sale_id}</td><td>${sale.customer_name || 'N/A'}</td><td class="sale-amount">${data.currency_symbols[data.currency]} ${addCommas((sale.total_amount * data.exchange_rates[data.currency]).toFixed(2))}</td><td>${sale.sale_date}</td><td><button class="btn btn-warning btn-sm" onclick="editSale(${sale.sale_id})"><span data-translate="edit">${translations['edit'] || 'Edit'}</span></button> <button class="btn btn-danger btn-sm" onclick="deleteSale(${sale.sale_id})"><span data-translate="delete">${translations['delete'] || 'Delete'}</span></button></td></tr>`;
                });
            } else {
                salesRows = `<tr><td colspan="5" class="text-center" data-translate="no_sales_data">${translations['no_sales_data'] || 'No sales data for selected date.'}</td></tr>`;
            }
            $('#sales-history-table tbody').html(salesRows);
            // Top selling products
            let topRows = '';
            if (data.top_selling_products.length) {
                data.top_selling_products.forEach(function(product) {
                    topRows += `<tr><td>${product.product_name}</td><td>${addCommas(product.total_sold)}</td></tr>`;
                });
            } else {
                topRows = `<tr><td colspan="2" class="text-center" data-translate="no_sales_data">${translations['no_sales_data'] || 'No sales data available.'}</td></tr>`;
            }
            $('.insights-table tbody').html(topRows);
            // Recent sales
            let recentRows = '';
            if (data.recent_sales.length) {
                data.recent_sales.forEach(function(sale) {
                    recentRows += `<tr><td>${sale.order_id || sale.sale_id}</td><td>${sale.customer_name || 'N/A'}</td><td class="sale-amount">${data.currency_symbols[data.currency]} ${addCommas((sale.total_amount * data.exchange_rates[data.currency]).toFixed(2))}</td><td>${sale.sale_date}</td></tr>`;
                });
            } else {
                recentRows = `<tr><td colspan="4" class="text-center" data-translate="no_recent_sales">${translations['no_recent_sales'] || 'No recent sales available.'}</td></tr>`;
            }
            $('.dashboard-card:contains("Recent Sales") .recent-sales-table tbody').html(recentRows);
            // Low stock alerts
            let lowStockList = '';
            if (data.low_stock_products.length) {
                data.low_stock_products.forEach(function(product) {
                    lowStockList += `<li><span class="product-name">${product.product_name}</span> <span class="stock-quantity">${addCommas(product.stock_quantity)} <span data-translate="units">${translations['units'] || 'units'}</span></span></li>`;
                });
            } else {
                lowStockList = `<li class="text-center" data-translate="no_low_stock">${translations['no_low_stock'] || 'No low stock items.'}</li>`;
            }
            $('.dashboard-card:contains("Low Stock Alerts") .alert-list').html(lowStockList);
            // Activity logs
            let logList = '';
            if (data.activity_logs.length) {
                data.activity_logs.forEach(function(log) {
                    logList += `<li><span class="log-action">[${log.action}]</span> <span class="log-user">${log.user}</span> <span class="log-timestamp">${log.timestamp}</span></li>`;
                });
            } else {
                logList = `<li class="text-center" data-translate="no_logs">${translations['no_logs'] || 'No activity logs available.'}</li>`;
            }
            $('.dashboard-card:contains("Activity Logs") .activity-logs').html(logList);
            // Charts
            if (typeof initializeCharts === 'function') initializeCharts();
            if (typeof updateUIText === 'function') updateUIText();
        }

        function updateUIText() {
            // Stat-box and table headers
            $('[data-translate]').each(function() {
                const key = $(this).data('translate');
                if (translations[key]) {
                    $(this).text(translations[key]);
                }
            });
            // Placeholder
            $('[data-translate-placeholder]').each(function() {
                const key = $(this).data('translate-placeholder');
                if (translations[key]) {
                    $(this).attr('placeholder', translations[key]);
                }
            });
            // Currency select options
            $('#currency-select option').each(function() {
                const key = $(this).data('translate');
                if (translations[key]) {
                    $(this).text(translations[key]);
                }
            });
            // Chart labels
            if (window.salesTrendChart) {
                window.salesTrendChart.data.datasets[0].label = translations['sales_amount'] || 'Sales Amount';
                window.salesTrendChart.options.plugins.legend.labels.label = translations['sales_amount'] || 'Sales Amount';
                window.salesTrendChart.update();
            }
            // Add more for other charts if needed
        }
    </script>
    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>