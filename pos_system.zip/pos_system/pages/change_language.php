<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Set JSON header for AJAX responses
header('Content-Type: application/json');

// Require authentication for this page
requireAuth();

// Ensure the user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    // Check if language parameter is set and is valid
    if (!isset($_POST['language'])) {
        echo json_encode(['success' => false, 'message' => 'Language parameter missing']);
        exit;
    }

    $language = $_POST['language'];

    if (!in_array($language, ['en', 'mm'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid language']);
        exit;
    }

    $user_id = $_SESSION['user_id'] ?? null;

    // Store the selected language in session
    $_SESSION['language'] = $language;

    // If user is logged in, update their preference in database
    if ($user_id) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET language_preference = ? WHERE user_id = ?");
            $stmt->execute([$language, $user_id]);
        } catch (PDOException $e) {
            // If there's no language_preference column yet, we'll create it
            if (strpos($e->getMessage(), "Unknown column 'language_preference'") !== false) {
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN language_preference VARCHAR(10) DEFAULT 'en'");
                    $stmt = $pdo->prepare("UPDATE users SET language_preference = ? WHERE user_id = ?");
                    $stmt->execute([$language, $user_id]);
                } catch (PDOException $e2) {
                    error_log("Error adding language_preference column: " . $e2->getMessage());
                }
            } else {
                error_log("Error updating language preference: " . $e->getMessage());
            }
        }
    }

    // Log the action
    if (function_exists('logAction')) {
        logAction($pdo, $user_id, "Changed language to " . ($language === 'en' ? 'English' : 'Myanmar'));
    }

    // Load translations for the new language
    $language_file = "../languages/{$language}.php";
    $translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";

    echo json_encode([
        'success' => true,
        'message' => 'Language updated successfully',
        'language' => $language,
        'language_name' => $language === 'en' ? 'English' : 'မြန်မာ',
        'translations' => $translations
    ]);

} catch (Exception $e) {
    error_log("Language change error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error occurred']);
}
exit;
?>