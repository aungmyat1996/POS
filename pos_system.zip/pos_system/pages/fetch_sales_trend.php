<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
$sales_trend = [];
$today = new DateTime();
for ($i = 6; $i >= 0; $i--) {
    $date = clone $today;
    $date->modify("-$i days");
    try {
        $stmt = $pdo->prepare("SELECT SUM(total_amount) as total FROM sales WHERE DATE(sale_date) = ?");
        $stmt->execute([$date->format('Y-m-d')]);
        $sales_trend[$date->format('Y-m-d')] = $stmt->fetchColumn() ?: 0;
    } catch (PDOException $e) {
        $sales_trend[$date->format('Y-m-d')] = 0;
        error_log("Error fetching sales trend for date {$date->format('Y-m-d')}: " . $e->getMessage());
    }
}

header('Content-Type: application/json');
echo json_encode([
    'labels' => array_keys($sales_trend),
    'values' => array_values($sales_trend)
]);
?>