<?php
/**
 * Get low stock notifications with actual product data
 */
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_SESSION['user_id'])) {
    try {
        // Get user language for translations
        $language = $_SESSION['language'] ?? 'en';
        $translations = [];
        
        try {
            if (function_exists('loadLanguage')) {
                $translations = loadLanguage($language);
            }
        } catch (Exception $e) {
            error_log("Error loading translations: " . $e->getMessage());
        }
        
        // Check if low stock notifications are enabled
        $lowStockEnabled = true;
        try {
            $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'low_stock_notifications'");
            $stmt->execute();
            $value = $stmt->fetchColumn();
            $lowStockEnabled = ($value === 'true' || $value === '1');
        } catch (Exception $e) {
            error_log("Error checking low stock settings: " . $e->getMessage());
        }
        
        if (!$lowStockEnabled) {
            echo json_encode([
                'success' => true,
                'notifications' => [],
                'message' => $translations['low_stock_disabled'] ?? 'Low stock notifications are disabled'
            ]);
            exit;
        }
        
        // Get low stock threshold from settings
        $threshold = 5; // Default threshold
        try {
            $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'low_stock_threshold'");
            $stmt->execute();
            $thresholdValue = $stmt->fetchColumn();
            if ($thresholdValue !== false && is_numeric($thresholdValue)) {
                $threshold = (int)$thresholdValue;
            }
        } catch (Exception $e) {
            error_log("Error getting low stock threshold: " . $e->getMessage());
        }
        
        // Get low stock products
        $stmt = $pdo->prepare("
            SELECT 
                p.product_id,
                p.product_name,
                p.sku,
                p.stock_quantity,
                p.reorder_level,
                p.unit_price,
                c.category_name,
                s.supplier_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.category_id
            LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id
            WHERE p.stock_quantity > 0 AND p.stock_quantity <= ?
            ORDER BY p.stock_quantity ASC
        ");
        $stmt->execute([$threshold]);
        $lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format notifications
        $notifications = [];
        foreach ($lowStockProducts as $product) {
            $notifications[] = [
                'id' => 'low_stock_' . $product['product_id'],
                'type' => 'low_stock',
                'product_id' => $product['product_id'],
                'product_name' => $product['product_name'],
                'sku' => $product['sku'],
                'stock_quantity' => $product['stock_quantity'],
                'reorder_level' => $product['reorder_level'],
                'unit_price' => $product['unit_price'],
                'category_name' => $product['category_name'],
                'supplier_name' => $product['supplier_name'],
                'message' => sprintf(
                    $translations['low_stock_message'] ?? 'Low stock alert: %s has only %d items remaining',
                    $product['product_name'],
                    $product['stock_quantity']
                ),
                'created_at' => date('Y-m-d H:i:s'),
                'is_read' => false
            ];
        }
        
        echo json_encode([
            'success' => true,
            'notifications' => $notifications,
            'count' => count($notifications),
            'threshold' => $threshold,
            'translations' => [
                'low_stock_alert' => $translations['low_stock_alert'] ?? 'Low Stock Alert',
                'items_remaining' => $translations['items_remaining'] ?? 'items remaining',
                'reorder_level' => $translations['reorder_level'] ?? 'Reorder Level',
                'category' => $translations['category'] ?? 'Category',
                'supplier' => $translations['supplier'] ?? 'Supplier',
                'price' => $translations['price'] ?? 'Price',
                'view_product' => $translations['view_product'] ?? 'View Product',
                'restock_now' => $translations['restock_now'] ?? 'Restock Now'
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Error getting low stock notifications: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => 'An error occurred while getting low stock notifications'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request or user not logged in'
    ]);
}
?>
