<?php
// Reports page with enhanced navbar functionality and modern design
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Set timezone from settings
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute(['timezone']);
    $timezone = $stmt->fetchColumn() ?: 'Asia/Yangon';
    date_default_timezone_set($timezone);
} catch (PDOException $e) {
    error_log("Error fetching timezone setting: " . $e->getMessage());
    date_default_timezone_set('Asia/Yangon');
}

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];
$currency = $_SESSION['currency'] ?? ($settings['currency'] ?? 'USD');
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');

// Add at the top of the file after require statements
// Set secure headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');

// Add at the top of the file after require statements
if (!file_exists(BASEPATH . 'cache')) {
    mkdir(BASEPATH . 'cache', 0777, true);
}

// Start output buffering
ob_start();

// Add before the generateReport function
function getCachedReport($report_type, $start_date, $end_date) {
    $cache_key = md5($report_type . $start_date . $end_date);
    $cache_file = BASEPATH . 'cache/' . $cache_key . '.json';

    // Check if cache exists and is less than 5 minutes old
    if (file_exists($cache_file) && (time() - filemtime($cache_file) < 300)) {
        return json_decode(file_get_contents($cache_file), true);
    }

    return false;
}

function cacheReport($report_type, $start_date, $end_date, $data) {
    $cache_key = md5($report_type . $start_date . $end_date);
    $cache_file = BASEPATH . 'cache/' . $cache_key . '.json';

    file_put_contents($cache_file, json_encode($data));
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!isset($_POST['action'])) {
            throw new Exception("No action specified");
        }

        switch ($_POST['action']) {
            case 'generate_report':
                $required_fields = ['report_type', 'start_date', 'end_date', 'format'];
                foreach ($required_fields as $field) {
                    if (!isset($_POST[$field])) {
                        throw new Exception("Missing required field: " . $field);
                    }
                }

                $report_type = $_POST['report_type'];
                $start_date = $_POST['start_date'];
                $end_date = $_POST['end_date'];
                $format = $_POST['format'];

                // Validate dates
                if (!strtotime($start_date) || !strtotime($end_date)) {
                    throw new Exception("Invalid date format");
                }

                if (strtotime($end_date) < strtotime($start_date)) {
                    throw new Exception("End date cannot be earlier than start date");
                }

                $report_data = generateReport($pdo, $report_type, $start_date, $end_date);

                if ($format === 'excel') {
                    header('Content-Type: application/vnd.ms-excel');
                    header('Content-Disposition: attachment; filename="' . $report_type . '_report.xlsx"');
                    exportToExcel($report_data, $report_type);
                } elseif ($format === 'pdf') {
                    header('Content-Type: text/html; charset=utf-8');
                    header('Content-Security-Policy: default-src \'self\'; style-src \'self\' \'unsafe-inline\'; script-src \'self\' \'unsafe-inline\';');
                    exportToPDF($report_data, $report_type);
                } else {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => true, 'data' => $report_data]);
                }
                break;

            case 'get_report_preview':
                header('Content-Type: application/json');
                $report_type = $_POST['report_type'] ?? '';
                $start_date = $_POST['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
                $end_date = $_POST['end_date'] ?? date('Y-m-d');

                $preview_data = getReportPreview($pdo, $report_type, $start_date, $end_date);
                echo json_encode(['success' => true, 'data' => $preview_data]);
                break;

            default:
                throw new Exception("Invalid action: " . $_POST['action']);
        }
    } catch (Exception $e) {
        error_log("Error in AJAX request: " . $e->getMessage());
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Helper Functions
function generateReport($pdo, $report_type, $start_date, $end_date) {
    try {
        // Check cache first
        $cached_data = getCachedReport($report_type, $start_date, $end_date);
        if ($cached_data !== false) {
            return $cached_data;
        }

        error_log("Generating report: " . $report_type);
        error_log("Date range: " . $start_date . " to " . $end_date);

        $data = [];

        switch ($report_type) {
            case 'sales_summary':
                $data = getSalesSummary($pdo, $start_date, $end_date);
                break;

            case 'inventory':
                $data = getInventoryReport($pdo);
                break;

            case 'customer_analysis':
                $data = getCustomerAnalysis($pdo, $start_date, $end_date);
                break;

            case 'staff_performance':
                $data = getStaffPerformance($pdo, $start_date, $end_date);
                break;

            case 'profit_loss':
                $data = getProfitLossReport($pdo, $start_date, $end_date);
                break;

            default:
                throw new Exception("Invalid report type: " . $report_type);
        }

        if (empty($data)) {
            error_log("Warning: No data returned for report: " . $report_type);
        } else {
            // Cache the result
            cacheReport($report_type, $start_date, $end_date, $data);
        }

        return $data;
    } catch (PDOException $e) {
        error_log("Database error while generating report: " . $e->getMessage());
        throw new Exception("Database error occurred while generating the report.");
    } catch (Exception $e) {
        error_log("Error generating report: " . $e->getMessage());
        throw $e;
    }
}

function getSalesSummary($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                DATE(s.sale_date) as date,
                COUNT(s.sale_id) as total_transactions,
                SUM(s.total_amount) as total_revenue,
                AVG(s.total_amount) as average_sale,
                COUNT(DISTINCT s.customer_id) as unique_customers
            FROM sales s
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
            GROUP BY DATE(s.sale_date)
            ORDER BY date DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error generating sales summary: " . $e->getMessage());
        return [];
    }
}

function getInventoryReport($pdo) {
    try {
        $stmt = $pdo->query("
            SELECT
                p.product_id,
                p.product_name,
                p.sku,
                c.category_name,
                p.quantity_in_stock,
                p.reorder_level,
                p.unit_price,
                p.last_restock_date,
                COALESCE(SUM(oi.quantity), 0) as total_sold
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.category_id
            LEFT JOIN order_items oi ON p.product_id = oi.product_id
            GROUP BY p.product_id, p.product_name, p.sku, c.category_name
            ORDER BY p.quantity_in_stock ASC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error generating inventory report: " . $e->getMessage());
        return [];
    }
}

function getCustomerAnalysis($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                c.customer_id,
                c.customer_name,
                COUNT(s.sale_id) as total_purchases,
                SUM(s.total_amount) as total_spent,
                AVG(s.total_amount) as average_purchase,
                MAX(s.sale_date) as last_purchase_date
            FROM customers c
            LEFT JOIN sales s ON c.customer_id = s.customer_id
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
            GROUP BY c.customer_id, c.customer_name
            ORDER BY total_spent DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error generating customer analysis: " . $e->getMessage());
        return [];
    }
}

function getStaffPerformance($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                u.user_id,
                u.username,
                COUNT(s.sale_id) as total_sales,
                SUM(s.total_amount) as total_revenue,
                AVG(s.total_amount) as average_sale,
                COUNT(DISTINCT s.customer_id) as unique_customers
            FROM users u
            LEFT JOIN sales s ON u.user_id = s.user_id
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
            GROUP BY u.user_id, u.username
            ORDER BY total_revenue DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error generating staff performance report: " . $e->getMessage());
        return [];
    }
}

function getProfitLossReport($pdo, $start_date, $end_date) {
    try {
        // Revenue
        $stmt = $pdo->prepare("
            SELECT
                DATE_FORMAT(sale_date, '%Y-%m') as month,
                SUM(total_amount) as revenue,
                COUNT(sale_id) as sales_count
            FROM sales
            WHERE DATE(sale_date) BETWEEN ? AND ?
            GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
            ORDER BY month
        ");
        $stmt->execute([$start_date, $end_date]);
        $revenue_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Expenses
        $stmt = $pdo->prepare("
            SELECT
                DATE_FORMAT(expense_date, '%Y-%m') as month,
                SUM(amount) as expenses,
                COUNT(expense_id) as expense_count
            FROM expenses
            WHERE DATE(expense_date) BETWEEN ? AND ?
            GROUP BY DATE_FORMAT(expense_date, '%Y-%m')
            ORDER BY month
        ");
        $stmt->execute([$start_date, $end_date]);
        $expense_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Combine data
        $report = [];
        foreach ($revenue_data as $revenue) {
            $month = $revenue['month'];
            $expenses = 0;
            foreach ($expense_data as $expense) {
                if ($expense['month'] === $month) {
                    $expenses = $expense['expenses'];
                    break;
                }
            }
            $report[] = [
                'month' => $month,
                'revenue' => $revenue['revenue'],
                'expenses' => $expenses,
                'profit' => $revenue['revenue'] - $expenses,
                'sales_count' => $revenue['sales_count']
            ];
        }

        return $report;
    } catch (PDOException $e) {
        error_log("Error generating profit/loss report: " . $e->getMessage());
        return [];
    }
}

function getReportPreview($pdo, $report_type, $start_date, $end_date) {
    // Get first 5 rows of the report
    $data = generateReport($pdo, $report_type, $start_date, $end_date);
    return array_slice($data, 0, 5);
}

function exportToExcel($data, $report_type) {
    $filename = $report_type . '_report_' . date('Y-m-d') . '.csv';

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');

    // Add headers based on report type
    switch ($report_type) {
        case 'sales_summary':
            fputcsv($output, ['Date', 'Total Transactions', 'Total Revenue', 'Average Sale', 'Unique Customers']);
            break;
        case 'inventory':
            fputcsv($output, ['Product ID', 'Product Name', 'SKU', 'Category', 'Stock', 'Reorder Level', 'Unit Price', 'Last Restock', 'Total Sold']);
            break;
        // Add other report types...
    }

    // Add data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

function formatCurrencyValue($value, $currency_symbols, $currency, $exchange_rates) {
    return $currency_symbols[$currency] . ' ' . number_format($value * $exchange_rates[$currency], 2);
}

function exportToPDF($data, $report_type) {
    try {
        global $currency_symbols, $currency, $exchange_rates;

        if (empty($data)) {
            throw new Exception("No data available for PDF generation");
        }

        // Clean any previous output
        if (ob_get_level()) {
            ob_clean();
        }

        $filename = $report_type . '_report_' . date('Y-m-d') . '.pdf';

        // Generate HTML content with tech theme
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>' . htmlspecialchars($filename) . '</title>
            <style>
                @page {
                    margin: 0;
                }
                body {
                    font-family: "Segoe UI", Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background: #0a1929;
                    color: #ffffff;
                }
                .header-bg {
                    background: linear-gradient(135deg, #0a1929 0%, #1e3a5f 100%);
                    padding: 40px;
                    position: relative;
                    overflow: hidden;
                }
                .header-bg::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: url("data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z\' fill=\'%231e3a5f\' fill-opacity=\'0.1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E");
                    opacity: 0.5;
                }
                .logo-section {
                    display: flex;
                    align-items: center;
                    margin-bottom: 20px;
                }
                .logo-icon {
                    font-size: 40px;
                    margin-right: 20px;
                    color: #00bcd4;
                }
                .company-name {
                    font-size: 24px;
                    font-weight: bold;
                    color: #ffffff;
                }
                .report-title {
                    font-size: 32px;
                    font-weight: bold;
                    margin: 20px 0;
                    color: #00bcd4;
                    text-transform: uppercase;
                }
                .meta-info {
                    display: flex;
                    justify-content: space-between;
                    margin: 20px 0;
                    padding: 15px;
                    background: rgba(255,255,255,0.1);
                    border-radius: 10px;
                }
                .meta-item {
                    text-align: center;
                }
                .meta-label {
                    font-size: 12px;
                    color: #00bcd4;
                    text-transform: uppercase;
                }
                .meta-value {
                    font-size: 16px;
                    color: #ffffff;
                    margin-top: 5px;
                }
                .content-wrapper {
                    padding: 40px;
                    background: #132f4c;
                }
                table {
                    width: 100%;
                    border-collapse: separate;
                    border-spacing: 0;
                    margin: 20px 0;
                    background: #0a1929;
                    border-radius: 10px;
                    overflow: hidden;
                }
                th {
                    background: #1e3a5f;
                    color: #00bcd4;
                    padding: 15px;
                    font-weight: 600;
                    text-transform: uppercase;
                    font-size: 14px;
                    letter-spacing: 0.5px;
                    text-align: left;
                }
                td {
                    padding: 12px 15px;
                    border-bottom: 1px solid #1e3a5f;
                    color: #ffffff;
                }
                tr:last-child td {
                    border-bottom: none;
                }
                .currency-value {
                    color: #00bcd4;
                    font-weight: 600;
                }
                .date-value {
                    color: #4caf50;
                }
                .footer {
                    background: #0a1929;
                    padding: 20px 40px;
                    text-align: center;
                    font-size: 12px;
                    color: rgba(255,255,255,0.7);
                    border-top: 1px solid #1e3a5f;
                }
                .footer-logo {
                    margin-bottom: 10px;
                    color: #00bcd4;
                    font-size: 24px;
                }
                .tech-badge {
                    display: inline-block;
                    padding: 5px 10px;
                    background: rgba(0,188,212,0.1);
                    color: #00bcd4;
                    border-radius: 5px;
                    margin: 5px;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
            <div class="header-bg">
                <div class="logo-section">
                    <div class="logo-icon">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <div class="company-name">
                        BitsTech Computer Store
                    </div>
                </div>
                <div class="report-title">
                    ' . ucwords(str_replace('_', ' ', $report_type)) . ' Report
                </div>
                <div class="meta-info">
                    <div class="meta-item">
                        <div class="meta-label">Generated On</div>
                        <div class="meta-value">' . date('M d, Y H:i:s') . '</div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Currency</div>
                        <div class="meta-value">' . $currency_symbols[$currency] . ' (' . $currency . ')</div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Report Type</div>
                        <div class="meta-value">' . ucwords(str_replace('_', ' ', $report_type)) . '</div>
                    </div>
                </div>
            </div>

            <div class="content-wrapper">
                <table>';

        // Add table headers
        if (!empty($data)) {
            $html .= '<tr>';
            foreach (array_keys($data[0]) as $header) {
                $header_text = ucwords(str_replace('_', ' ', $header));
                $html .= '<th>' . htmlspecialchars($header_text) . '</th>';
            }
            $html .= '</tr>';

            // Add table data
            foreach ($data as $row) {
                $html .= '<tr>';
                foreach ($row as $key => $value) {
                    $formatted_value = $value;
                    $class = '';

                    // Format currency values
                    if (is_numeric($value) && (
                        strpos(strtolower($key), 'amount') !== false ||
                        strpos(strtolower($key), 'price') !== false ||
                        strpos(strtolower($key), 'revenue') !== false ||
                        strpos(strtolower($key), 'total') !== false
                    )) {
                        $formatted_value = formatCurrencyValue($value, $currency_symbols, $currency, $exchange_rates);
                        $class = 'currency-value';
                    }
                    // Format dates
                    elseif (strpos(strtolower($key), 'date') !== false && strtotime($value)) {
                        $formatted_value = date('M d, Y', strtotime($value));
                        $class = 'date-value';
                    }

                    $html .= '<td class="' . $class . '">' . htmlspecialchars($formatted_value) . '</td>';
                }
                $html .= '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="100%" style="text-align: center;">No data available</td></tr>';
        }

        $html .= '</table>
            </div>

            <div class="footer">
                <div class="footer-logo">
                    <i class="fas fa-laptop-code"></i>
                </div>
                <div>
                    <span class="tech-badge"><i class="fas fa-desktop"></i> Hardware</span>
                    <span class="tech-badge"><i class="fas fa-laptop"></i> Laptops</span>
                    <span class="tech-badge"><i class="fas fa-mobile-alt"></i> Accessories</span>
                    <span class="tech-badge"><i class="fas fa-tools"></i> Repairs</span>
                </div>
                <p>Generated by BitsTech Computer Store POS System<br>
                Contact: info@bitstechstore.com | Tel: +1-234-567-8900</p>
            </div>
        </body>
        </html>';

        // Set headers for PDF download
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Create temporary HTML file
        $temp_file = tempnam(sys_get_temp_dir(), 'report_');
        file_put_contents($temp_file . '.html', $html);

        // Convert HTML to PDF using wkhtmltopdf if available
        if (file_exists('C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe')) {
            $cmd = '"C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe"';
            $cmd .= ' --page-size A4';
            $cmd .= ' --margin-top 0';
            $cmd .= ' --margin-right 0';
            $cmd .= ' --margin-bottom 0';
            $cmd .= ' --margin-left 0';
            $cmd .= ' --encoding utf-8';
            $cmd .= ' --enable-local-file-access';
            $cmd .= ' --background';
            $cmd .= ' "' . $temp_file . '.html" "' . $temp_file . '.pdf"';

            exec($cmd);

            if (file_exists($temp_file . '.pdf')) {
                readfile($temp_file . '.pdf');
                unlink($temp_file . '.pdf');
            } else {
                // Fallback to HTML if PDF generation fails
                echo $html;
            }
        } else {
            // Fallback to HTML if wkhtmltopdf is not available
            echo $html;
        }

        // Clean up temporary files
        unlink($temp_file);
        if (file_exists($temp_file . '.html')) {
            unlink($temp_file . '.html');
        }
        exit;

    } catch (Exception $e) {
        error_log("Error exporting to PDF: " . $e->getMessage());
        if (ob_get_level()) {
            ob_clean();
        }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Error generating PDF: ' . $e->getMessage()
        ]);
    }
}

// Additional Helper Functions
function getTopSellingProducts($pdo, $start_date, $end_date, $limit = 10) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                p.product_id,
                p.product_name,
                p.sku,
                c.category_name,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.quantity * oi.price) as total_revenue,
                COUNT(DISTINCT o.order_id) as order_count
            FROM products p
            LEFT JOIN order_items oi ON p.product_id = oi.product_id
            LEFT JOIN orders o ON oi.order_id = o.order_id
            LEFT JOIN categories c ON p.category_id = c.category_id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY p.product_id, p.product_name, p.sku, c.category_name
            ORDER BY total_quantity DESC
            LIMIT ?
        ");
        $stmt->execute([$start_date, $end_date, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting top selling products: " . $e->getMessage());
        return [];
    }
}

function getLowStockProducts($pdo, $threshold = 10) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                p.product_id,
                p.product_name,
                p.sku,
                c.category_name,
                p.quantity_in_stock,
                p.reorder_level,
                p.unit_price,
                p.last_restock_date,
                s.supplier_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.category_id
            LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id
            WHERE p.quantity_in_stock <= ?
            ORDER BY p.quantity_in_stock ASC
        ");
        $stmt->execute([$threshold]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting low stock products: " . $e->getMessage());
        return [];
    }
}

function getPaymentMethodStats($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                o.payment_method,
                COUNT(o.order_id) as transaction_count,
                SUM(s.total_amount) as total_amount,
                AVG(s.total_amount) as average_amount
            FROM orders o
            JOIN sales s ON o.order_id = s.order_id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY o.payment_method
            ORDER BY total_amount DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting payment method stats: " . $e->getMessage());
        return [];
    }
}

function getCategoryPerformance($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                c.category_name,
                COUNT(DISTINCT o.order_id) as order_count,
                SUM(oi.quantity) as total_items_sold,
                SUM(oi.quantity * oi.price) as total_revenue,
                AVG(oi.price) as average_price
            FROM categories c
            LEFT JOIN products p ON c.category_id = p.category_id
            LEFT JOIN order_items oi ON p.product_id = oi.product_id
            LEFT JOIN orders o ON oi.order_id = o.order_id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY c.category_id, c.category_name
            ORDER BY total_revenue DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting category performance: " . $e->getMessage());
        return [];
    }
}

function getHourlySalesDistribution($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                HOUR(s.sale_date) as hour_of_day,
                COUNT(s.sale_id) as transaction_count,
                SUM(s.total_amount) as total_revenue,
                AVG(s.total_amount) as average_sale
            FROM sales s
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
            GROUP BY HOUR(s.sale_date)
            ORDER BY hour_of_day
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting hourly sales distribution: " . $e->getMessage());
        return [];
    }
}

function getCustomerSegmentation($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                CASE
                    WHEN total_spent >= 1000000 THEN 'Premium'
                    WHEN total_spent >= 500000 THEN 'Gold'
                    WHEN total_spent >= 100000 THEN 'Silver'
                    ELSE 'Bronze'
                END as customer_segment,
                COUNT(*) as customer_count,
                AVG(total_spent) as average_spent,
                AVG(purchase_count) as average_purchases
            FROM (
                SELECT
                    c.customer_id,
                    SUM(s.total_amount) as total_spent,
                    COUNT(s.sale_id) as purchase_count
                FROM customers c
                JOIN sales s ON c.customer_id = s.customer_id
                WHERE DATE(s.sale_date) BETWEEN ? AND ?
                GROUP BY c.customer_id
            ) customer_stats
            GROUP BY customer_segment
            ORDER BY average_spent DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting customer segmentation: " . $e->getMessage());
        return [];
    }
}

function getStaffSalesPerformance($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                u.user_id,
                u.username,
                u.email,
                COUNT(s.sale_id) as total_sales,
                SUM(s.total_amount) as total_revenue,
                AVG(s.total_amount) as average_sale,
                COUNT(DISTINCT s.customer_id) as unique_customers,
                MAX(s.sale_date) as last_sale_date
            FROM users u
            LEFT JOIN sales s ON u.user_id = s.user_id
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
                AND u.role = 'staff'
            GROUP BY u.user_id, u.username, u.email
            ORDER BY total_revenue DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting staff sales performance: " . $e->getMessage());
        return [];
    }
}

function getInventoryValuation($pdo) {
    try {
        $stmt = $pdo->query("
            SELECT
                c.category_name,
                COUNT(p.product_id) as product_count,
                SUM(p.quantity_in_stock) as total_stock,
                SUM(p.quantity_in_stock * p.unit_price) as total_value,
                AVG(p.unit_price) as average_price,
                MIN(p.last_restock_date) as oldest_stock
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.category_id
            GROUP BY c.category_id, c.category_name
            ORDER BY total_value DESC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting inventory valuation: " . $e->getMessage());
        return [];
    }
}

function getExpenseBreakdown($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                e.expense_category,
                COUNT(e.expense_id) as transaction_count,
                SUM(e.amount) as total_amount,
                AVG(e.amount) as average_amount,
                MIN(e.expense_date) as first_expense,
                MAX(e.expense_date) as last_expense
            FROM expenses e
            WHERE DATE(e.expense_date) BETWEEN ? AND ?
            GROUP BY e.expense_category
            ORDER BY total_amount DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting expense breakdown: " . $e->getMessage());
        return [];
    }
}

function getRefundAnalysis($pdo, $start_date, $end_date) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                r.refund_reason,
                COUNT(r.refund_id) as refund_count,
                SUM(r.refund_amount) as total_refunded,
                AVG(r.refund_amount) as average_refund,
                COUNT(DISTINCT r.customer_id) as unique_customers
            FROM refunds r
            WHERE DATE(r.refund_date) BETWEEN ? AND ?
            GROUP BY r.refund_reason
            ORDER BY total_refunded DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting refund analysis: " . $e->getMessage());
        return [];
    }
}

// Load language file
$language_file = "../languages/{$language}.php";
$translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-translate="reports"><?php echo htmlspecialchars($translations['reports'] ?? 'Reports'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #1a1a2e;
            --secondary-dark: #16213e;
            --accent-dark: #0f3460;
            --accent-purple: #533483;
            --accent-red: #e94560;
            --text-light: #ffffff;
            --text-gray: rgba(255,255,255,0.7);
            --border-color: #2a2a4a;
            --success-green: #3cba92;
            --card-shadow: 0 10px 30px rgba(0,0,0,0.2);
            --gradient-primary: linear-gradient(135deg, var(--accent-dark) 0%, var(--accent-purple) 100%);
            --gradient-secondary: linear-gradient(135deg, var(--accent-purple) 0%, var(--accent-dark) 100%);
        }

        body {
            background: var(--primary-dark);
            color: var(--text-light);
            font-family: 'Inter', sans-serif;
        }

        /* Light Mode Text Colors */
        [data-theme="light"] body {
            color: #ffffff !important;
        }

        [data-theme="light"] .reports-header h1,
        [data-theme="light"] .reports-header p,
        [data-theme="light"] .current-date,
        [data-theme="light"] .current-time {
            color: #ffffff !important;
        }

        [data-theme="light"] .report-title,
        [data-theme="light"] .report-description,
        [data-theme="light"] .preview-title,
        [data-theme="light"] .form-label {
            color: #ffffff !important;
        }

        [data-theme="light"] .table,
        [data-theme="light"] .table th,
        [data-theme="light"] .table td {
            color: #ffffff !important;
        }

        [data-theme="light"] .text-muted {
            color: rgba(255, 255, 255, 0.8) !important;
        }

        [data-theme="light"] .loading-text,
        [data-theme="light"] .preview-text,
        [data-theme="light"] .preview-note {
            color: #ffffff !important;
        }

        /* Light Mode H1 and Headers Text Colors for Reports Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }

        .reports-container {
            padding: 30px;
            min-height: 100vh;
        }

        .reports-header {
            background: var(--gradient-primary);
            padding: 40px;
            border-radius: 20px;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            transform: translateY(0);
            transition: all 0.3s ease;
        }

        .reports-header:hover {
            transform: translateY(-5px);
        }

        .reports-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .reports-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: var(--text-light);
        }

        .reports-header p {
            font-size: 1.1rem;
            opacity: 0.9;
            max-width: 600px;
        }

        .current-date {
            font-size: 1.8rem;
            font-weight: 600;
            color: var(--text-light);
        }

        .current-time {
            font-size: 1.2rem;
            color: var(--text-gray);
        }

        .report-card {
            background: var(--secondary-dark);
            border-radius: 20px;
            padding: 30px;
            height: 100%;
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .report-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .report-card:hover {
            transform: translateY(-10px);
        }

        .report-card:hover::before {
            transform: scaleX(1);
        }

        .report-icon-wrapper {
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
        }

        .report-icon {
            font-size: 3rem;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.3s ease;
        }

        .report-card:hover .report-icon {
            transform: scale(1.1);
        }

        .report-content {
            position: relative;
            z-index: 1;
        }

        .report-title {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--text-light);
        }

        .report-description {
            color: var(--text-gray);
            font-size: 1rem;
            line-height: 1.6;
        }

        .preview-container {
            background: var(--secondary-dark);
            border-radius: 20px;
            padding: 30px;
            margin-top: 40px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
            animation: slideUp 0.5s ease;
        }

        .preview-title {
            font-size: 1.6rem;
            font-weight: 600;
            margin-bottom: 30px;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .preview-title i {
            color: var(--accent-red);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control, .form-select {
            background: var(--primary-dark);
            border: 1px solid var(--border-color);
            color: var(--text-light);
            padding: 12px 15px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            background: var(--primary-dark);
            border-color: var(--accent-purple);
            box-shadow: 0 0 0 3px rgba(83, 52, 131, 0.2);
            color: var(--text-light);
        }

        .form-label {
            color: var(--text-gray);
            font-weight: 500;
            margin-bottom: 10px;
        }

        .btn-report {
            background: var(--gradient-primary);
            border: none;
            color: var(--text-light);
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-report::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent 0%, rgba(255,255,255,0.1) 100%);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }

        .btn-report:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(83, 52, 131, 0.4);
        }

        .btn-report:hover::before {
            transform: translateX(0);
        }

        .table {
            color: var(--text-light);
            margin-top: 30px;
            border-radius: 10px;
            overflow: hidden;
        }

        .table thead th {
            background: var(--gradient-secondary);
            border: none;
            color: var(--text-light);
            padding: 15px;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            background: var(--primary-dark);
            border-color: var(--border-color);
            padding: 15px;
            vertical-align: middle;
            color: var(--text-light);
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: rgba(83, 52, 131, 0.1);
        }

        .loading-overlay {
            background: rgba(26, 26, 46, 0.9);
            backdrop-filter: blur(5px);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 9999;
        }

        .loading-content {
            text-align: center;
            background: var(--secondary-dark);
            padding: 30px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
            position: relative;
            bottom: -50px;
        }

        .loading-spinner {
            font-size: 40px;
            color: var(--accent-purple);
            animation: spin 2s linear infinite;
            margin-bottom: 15px;
        }

        .loading-spinner i {
            filter: drop-shadow(0 0 10px var(--accent-purple));
        }

        .loading-text {
            color: var(--text-light);
            font-size: 1.1rem;
            margin-top: 15px;
            font-weight: 500;
        }

        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            animation: slideInRight 0.5s ease;
        }

        .alert-success {
            background: var(--success-green);
            color: var(--text-light);
        }

        .alert-danger {
            background: var(--accent-red);
            color: var(--text-light);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100%);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 768px) {
            .reports-container {
                padding: 15px;
            }

            .reports-header {
                padding: 30px;
                margin-bottom: 30px;
            }

            .reports-header h1 {
                font-size: 2rem;
            }

            .report-card {
                padding: 20px;
            }

            .preview-container {
                padding: 20px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--primary-dark);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--accent-purple);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-dark);
        }

        /* Calculator Widget Styling */
        .calculator-widget {
            position: fixed;
            top: 100px;
            right: 20px;
            width: 280px;
            background: var(--secondary-dark);
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            border: 1px solid var(--border-color);
            z-index: 9999;
            overflow: hidden;
        }

        .calculator-header {
            background: var(--gradient-primary);
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: move;
        }

        .calculator-header span {
            color: var(--text-light);
            font-weight: 600;
        }

        .btn-close-calc {
            background: none;
            border: none;
            color: var(--text-light);
            font-size: 20px;
            cursor: pointer;
            padding: 0;
            width: 25px;
            height: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.2s ease;
        }

        .btn-close-calc:hover {
            background: rgba(255,255,255,0.2);
        }

        .calculator-display {
            padding: 20px;
            background: var(--primary-dark);
        }

        .calculator-display input {
            width: 100%;
            background: transparent;
            border: none;
            color: var(--text-light);
            font-size: 24px;
            text-align: right;
            font-weight: 600;
        }

        .calculator-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1px;
            background: var(--border-color);
            padding: 1px;
        }

        .calculator-buttons button {
            background: var(--secondary-dark);
            border: none;
            color: var(--text-light);
            padding: 20px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .calculator-buttons button:hover {
            background: var(--accent-dark);
            transform: scale(0.95);
        }

        .calculator-buttons button.operator {
            background: var(--accent-purple);
        }

        .calculator-buttons button.operator:hover {
            background: var(--accent-red);
        }

        .calculator-buttons button.equals {
            background: var(--accent-red);
            grid-row: span 2;
        }

        .calculator-buttons button.equals:hover {
            background: var(--success-green);
        }

        .calculator-buttons button.zero {
            grid-column: span 2;
        }

        /* Enhanced Table Styling */
        .table-responsive {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            margin: 20px 0;
        }

        .table {
            margin-bottom: 0;
            background: var(--secondary-dark);
            border-collapse: separate;
            border-spacing: 0;
        }

        .table-row-even {
            background: rgba(255, 255, 255, 0.05) !important;
        }

        .table-row-odd {
            background: rgba(255, 255, 255, 0.02) !important;
        }

        .table-row-even:hover,
        .table-row-odd:hover {
            background: rgba(255, 255, 255, 0.1) !important;
            transform: translateY(-1px);
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background: var(--accent-dark) !important;
            color: var(--text-light) !important;
            border: none !important;
            font-weight: 600;
            text-align: center !important;
            padding: 18px 20px !important;
            font-size: 0.95rem;
            letter-spacing: 0.5px;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table td {
            border: none !important;
            color: var(--text-light) !important;
            text-align: center !important;
            padding: 15px 20px !important;
            vertical-align: middle !important;
            font-size: 0.9rem;
            line-height: 1.4;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 200px;
        }

        /* Specific column width adjustments */
        .table th:first-child,
        .table td:first-child {
            min-width: 80px;
            max-width: 100px;
        }

        .table th:nth-child(2),
        .table td:nth-child(2) {
            min-width: 150px;
            max-width: 200px;
            white-space: normal;
            word-wrap: break-word;
        }

        .table th:last-child,
        .table td:last-child {
            min-width: 120px;
            max-width: 150px;
        }

        /* Currency and number formatting */
        .table td.currency {
            font-family: 'Courier New', monospace;
            font-weight: 600;
            color: #10B981 !important;
        }

        .table td.number {
            font-family: 'Courier New', monospace;
            font-weight: 500;
        }

        /* Table container improvements */
        #previewArea {
            max-width: 100%;
            overflow-x: auto;
        }

        #previewArea .table-responsive {
            min-height: 200px;
            max-height: 600px;
            overflow-y: auto;
        }

        /* Scrollbar styling */
        #previewArea .table-responsive::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        #previewArea .table-responsive::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
        }

        #previewArea .table-responsive::-webkit-scrollbar-thumb {
            background: var(--accent-purple);
            border-radius: 4px;
        }

        #previewArea .table-responsive::-webkit-scrollbar-thumb:hover {
            background: var(--accent-red);
        }

        /* Mobile responsive adjustments */
        @media (max-width: 768px) {
            .table th,
            .table td {
                padding: 10px 8px !important;
                font-size: 0.8rem;
                min-width: 60px;
            }

            .table th:nth-child(2),
            .table td:nth-child(2) {
                min-width: 120px;
                max-width: 150px;
            }

            #previewArea .table-responsive {
                max-height: 400px;
            }
        }

        /* Table animation */
        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            transform: scale(1.01);
        }

        /* Loading state for table */
        .table-loading {
            position: relative;
            opacity: 0.6;
            pointer-events: none;
        }

        .table-loading::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(33, 36, 58, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="reports-container">
                <!-- Header Section -->
                <div class="reports-header" data-aos="fade-up">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h1 class="mb-2">
                                <i class="fas fa-chart-bar me-3"></i>
                                <span data-translate="reports"><?php echo htmlspecialchars($translations['reports'] ?? 'Reports'); ?></span>
                            </h1>
                            <p class="mb-0" data-translate="reports_description">
                                <?php echo htmlspecialchars($translations['reports_description'] ?? 'Generate and analyze detailed business reports'); ?>
                            </p>
                        </div>
                        <div class="text-end">
                            <div class="current-date h4 mb-1"><?php echo date('F d, Y'); ?></div>
                            <div class="current-time" id="currentTime"><?php echo date('h:i:s A'); ?></div>
                        </div>
                    </div>
                </div>

                <!-- Report Types Grid -->
                <div class="row g-4">
                    <!-- Sales Summary Report -->
                    <div class="col-md-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="report-card" data-report="sales_summary" onclick="selectReport('sales_summary')">
                            <div class="report-icon-wrapper">
                                <i class="fas fa-chart-line report-icon"></i>
                            </div>
                            <div class="report-content">
                                <div class="report-title" data-translate="sales_summary">
                                    <?php echo htmlspecialchars($translations['sales_summary'] ?? 'Sales Summary'); ?>
                                </div>
                                <div class="report-description" data-translate="sales_summary_desc">
                                    <?php echo htmlspecialchars($translations['sales_summary_desc'] ?? 'Comprehensive overview of sales performance and trends'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Inventory Report -->
                    <div class="col-md-4 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                        <div class="report-card" data-report="inventory" onclick="selectReport('inventory')">
                            <div class="report-icon-wrapper">
                                <i class="fas fa-boxes report-icon"></i>
                            </div>
                            <div class="report-content">
                                <div class="report-title" data-translate="inventory_report">
                                    <?php echo htmlspecialchars($translations['inventory_report'] ?? 'Inventory Report'); ?>
                                </div>
                                <div class="report-description" data-translate="inventory_report_desc">
                                    <?php echo htmlspecialchars($translations['inventory_report_desc'] ?? 'Current stock levels, reorder points, and inventory movement'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Analysis -->
                    <div class="col-md-4 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                        <div class="report-card" data-report="customer_analysis" onclick="selectReport('customer_analysis')">
                            <div class="report-icon-wrapper">
                                <i class="fas fa-users report-icon"></i>
                            </div>
                            <div class="report-content">
                                <div class="report-title" data-translate="customer_analysis">
                                    <?php echo htmlspecialchars($translations['customer_analysis'] ?? 'Customer Analysis'); ?>
                                </div>
                                <div class="report-description" data-translate="customer_analysis_desc">
                                    <?php echo htmlspecialchars($translations['customer_analysis_desc'] ?? 'Customer behavior, loyalty, and purchasing patterns'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Staff Performance -->
                    <div class="col-md-4 col-lg-4" data-aos="fade-up" data-aos-delay="400">
                        <div class="report-card" data-report="staff_performance" onclick="selectReport('staff_performance')">
                            <div class="report-icon-wrapper">
                                <i class="fas fa-user-tie report-icon"></i>
                            </div>
                            <div class="report-content">
                                <div class="report-title" data-translate="staff_performance">
                                    <?php echo htmlspecialchars($translations['staff_performance'] ?? 'Staff Performance'); ?>
                                </div>
                                <div class="report-description" data-translate="staff_performance_desc">
                                    <?php echo htmlspecialchars($translations['staff_performance_desc'] ?? 'Employee sales performance and productivity metrics'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Profit/Loss Report -->
                    <div class="col-md-4 col-lg-4" data-aos="fade-up" data-aos-delay="500">
                        <div class="report-card" data-report="profit_loss" onclick="selectReport('profit_loss')">
                            <div class="report-icon-wrapper">
                                <i class="fas fa-balance-scale report-icon"></i>
                            </div>
                            <div class="report-content">
                                <div class="report-title" data-translate="profit_loss">
                                    <?php echo htmlspecialchars($translations['profit_loss'] ?? 'Profit/Loss Report'); ?>
                                </div>
                                <div class="report-description" data-translate="profit_loss_desc">
                                    <?php echo htmlspecialchars($translations['profit_loss_desc'] ?? 'Financial overview with revenue, expenses, and profit analysis'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Report Generation Form -->
                <div class="preview-container" id="reportForm" style="display: none;" data-aos="fade-up">
                    <div class="preview-title">
                        <i class="fas fa-file-alt"></i>
                        <span id="selectedReportTitle"></span>
                    </div>

                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" data-translate="start_date">
                                    <?php echo htmlspecialchars($translations['start_date'] ?? 'Start Date'); ?>
                                </label>
                                <input type="date" class="form-control" id="startDate"
                                       value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" data-translate="end_date">
                                    <?php echo htmlspecialchars($translations['end_date'] ?? 'End Date'); ?>
                                </label>
                                <input type="date" class="form-control" id="endDate"
                                       value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" data-translate="report_format">
                                    <?php echo htmlspecialchars($translations['report_format'] ?? 'Export Format'); ?>
                                </label>
                                <select class="form-select" id="exportFormat">
                                    <option value="html" data-translate="preview">
                                        <?php echo htmlspecialchars($translations['preview'] ?? 'Preview'); ?>
                                    </option>
                                    <option value="excel" data-translate="excel">
                                        <?php echo htmlspecialchars($translations['excel'] ?? 'Excel'); ?>
                                    </option>
                                    <option value="pdf" data-translate="pdf">
                                        <?php echo htmlspecialchars($translations['pdf'] ?? 'PDF'); ?>
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="text-end mt-4">
                        <button class="btn btn-report" onclick="generateReport()">
                            <i class="fas fa-file-export me-2"></i>
                            <span data-translate="generate_report">
                                <?php echo htmlspecialchars($translations['generate_report'] ?? 'Generate Report'); ?>
                            </span>
                        </button>
                    </div>

                    <!-- Preview Area -->
                    <div id="previewArea" class="mt-4"></div>
                </div>

                <!-- Loading Overlay -->
                <div class="loading-overlay" id="loadingOverlay" style="display: none;">
                    <div class="loading-content">
                        <div class="loading-spinner">
                            <i class="fas fa-cog"></i>
                        </div>
                        <div class="loading-text" data-translate="generating_report">
                            <?php echo htmlspecialchars($translations['generating_report'] ?? 'Generating Report...'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <script>
        let currentReport = '';
        let translations = <?php echo json_encode($translations); ?>;
        let currencySymbol = '<?php echo $currency_symbols[$currency]; ?>';
        let exchangeRate = <?php echo $exchange_rates[$currency]; ?>;

        // Function to update currency values in table
        function updateTableCurrencyValues() {
            console.log('🔄 Updating table currency values...');

            // Check if table exists
            if ($('#previewArea table').length === 0) {
                console.log('⚠️ No table found to update');
                return;
            }

            // Store original data for recalculation
            if (!window.originalTableData) {
                console.log('⚠️ No original data stored');
                return;
            }

            // Update currency cells
            $('#previewArea table tbody tr').each(function(rowIndex) {
                const originalRow = window.originalTableData[rowIndex];
                if (!originalRow) return;

                $(this).find('td.currency').each(function(cellIndex) {
                    const $cell = $(this);
                    const columnKeys = Object.keys(originalRow);

                    // Find the corresponding column key for this cell
                    let columnKey = null;
                    let currentCellIndex = 0;

                    $(this).parent().find('td').each(function(index) {
                        if (this === $cell[0]) {
                            columnKey = columnKeys[index];
                            return false;
                        }
                    });

                    if (columnKey && originalRow[columnKey] !== undefined) {
                        const originalValue = parseFloat(originalRow[columnKey]);
                        if (!isNaN(originalValue)) {
                            // Recalculate with new exchange rate
                            const convertedValue = originalValue * exchangeRate;
                            const formattedValue = currencySymbol + ' ' + convertedValue.toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });

                            // Update cell content and tooltip
                            $cell.html(formattedValue);
                            $cell.attr('title', formattedValue);

                            console.log(`💰 Updated ${columnKey}: ${originalValue} → ${formattedValue}`);
                        }
                    }
                });
            });

            console.log('✅ Currency values updated successfully');
        }

        function startRealTimeClock() {
            setInterval(function() {
                const now = new Date();
                const options = {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                };
                $('#currentTime').text(now.toLocaleTimeString(undefined, options));
            }, 1000);
        }

        function selectReport(reportType) {
            // Remove active class from all cards
            $('.report-card').removeClass('active');
            // Add active class to selected card
            $(`[data-report="${reportType}"]`).addClass('active');

            currentReport = reportType;
            $('#selectedReportTitle').text(translations[reportType] || reportType.replace('_', ' ').toUpperCase());

            // Animate form appearance
            $('#reportForm').slideDown({
                duration: 500,
                easing: 'easeOutCubic',
                complete: function() {
                    // Scroll to form
                    $('html, body').animate({
                        scrollTop: $('#reportForm').offset().top - 100
                    }, 500);
                }
            });

            $('#previewArea').empty();
            getReportPreview();
        }

        function showLoading() {
            $('#loadingOverlay').fadeIn(300);
            $('button, input, select').prop('disabled', true);
        }

        function hideLoading() {
            $('#loadingOverlay').fadeOut(300);
            $('button, input, select').prop('disabled', false);
        }

        function getReportPreview() {
            if (!currentReport) return;

            showLoading();

            $.ajax({
                url: 'reports.php',
                type: 'POST',
                data: {
                    action: 'get_report_preview',
                    report_type: currentReport,
                    start_date: $('#startDate').val(),
                    end_date: $('#endDate').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        displayPreview(response.data);
                    }
                },
                error: function() {
                    const errorMsg = translations['error_getting_preview'] || 'Error getting report preview';
                    showMessage(errorMsg, 'error');
                },
                complete: function() {
                    hideLoading();
                }
            });
        }

        function generateReport() {
            if (!currentReport) {
                const errorMsg = translations['select_report_type'] || 'Please select a report type';
                showMessage(errorMsg, 'error');
                return;
            }

            const format = $('#exportFormat').val();
            const startDate = $('#startDate').val();
            const endDate = $('#endDate').val();

            // Validate dates
            if (!startDate || !endDate) {
                const errorMsg = translations['select_dates'] || 'Please select both start and end dates';
                showMessage(errorMsg, 'error');
                return;
            }

            if (new Date(endDate) < new Date(startDate)) {
                const errorMsg = translations['invalid_date_range'] || 'End date cannot be earlier than start date';
                showMessage(errorMsg, 'error');
                return;
            }

            showLoading();

            if (format === 'pdf') {
                // For PDF, open in new window
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'reports.php';
                form.target = '_blank';

                const addInput = (name, value) => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = name;
                    input.value = value;
                    form.appendChild(input);
                };

                addInput('action', 'generate_report');
                addInput('report_type', currentReport);
                addInput('start_date', startDate);
                addInput('end_date', endDate);
                addInput('format', format);

                document.body.appendChild(form);
                form.submit();
                document.body.removeChild(form);
                hideLoading();

                const successMsg = translations['pdf_opening'] || 'PDF will open in a new window';
                showMessage(successMsg, 'success');
            } else {
                // For other formats, use AJAX
                $.ajax({
                    url: 'reports.php',
                    type: 'POST',
                    data: {
                        action: 'generate_report',
                        report_type: currentReport,
                        start_date: startDate,
                        end_date: endDate,
                        format: format
                    },
                    success: function(response) {
                        try {
                            if (format === 'excel') {
                                // For Excel, trigger download
                                const blob = new Blob([response], { type: 'application/vnd.ms-excel' });
                                const url = window.URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = currentReport + '_report.xlsx';
                                document.body.appendChild(a);
                                a.click();
                                window.URL.revokeObjectURL(url);
                                const successMsg = translations['excel_downloaded'] || 'Excel file downloaded successfully';
                                showMessage(successMsg, 'success');
                            } else {
                                // For preview
                                const data = typeof response === 'string' ? JSON.parse(response) : response;
                                if (data.success) {
                                    displayPreview(data.data);
                                    const successMsg = translations['report_generated'] || 'Report generated successfully';
                                    showMessage(successMsg, 'success');
                                } else {
                                    const errorMsg = data.message || translations['error_generating_report'] || 'Error generating report';
                                    throw new Error(errorMsg);
                                }
                            }
                        } catch (error) {
                            console.error('Error:', error);
                            const errorMsg = error.message || translations['error_processing_response'] || 'Error processing response';
                            showMessage(errorMsg, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', {
                            status: xhr.status,
                            statusText: xhr.statusText,
                            error: error
                        });

                        let errorMessage = translations['network_error'] || 'Network error or server not responding';

                        try {
                            if (xhr.responseText) {
                                const response = JSON.parse(xhr.responseText);
                                errorMessage = response.message || errorMessage;
                            }
                        } catch (e) {
                            console.error('Error parsing error response:', e);
                        }

                        showMessage(errorMessage, 'error');
                    },
                    complete: function() {
                        hideLoading();
                    }
                });
            }
        }

        function displayPreview(data) {
            if (!data || data.length === 0) {
                const noDataText = translations['no_data_available'] || 'No data available for this report';
                $('#previewArea').html('<p class="text-center" style="color: #10B981; font-weight: 600; font-size: 1.1rem; text-shadow: 0 1px 2px rgba(16, 185, 129, 0.3);">📊 ' + noDataText + '</p>');
                window.originalTableData = null; // Clear original data
                return;
            }

            // Store original data for currency conversion
            window.originalTableData = JSON.parse(JSON.stringify(data));
            console.log('💾 Stored original table data for currency conversion');

            let html = '<div class="table-responsive"><table class="table table-hover">';

            // Headers with translation
            html += '<thead><tr>';
            Object.keys(data[0]).forEach(key => {
                let header = key.replace(/_/g, ' ').toUpperCase();

                // Translate headers to Myanmar if available
                const headerTranslations = {
                    'CUSTOMER ID': translations['customer_id'] || 'Customer ID',
                    'CUSTOMER NAME': translations['customer_name'] || 'Customer Name',
                    'TOTAL PURCHASES': translations['total_purchases'] || 'Total Purchases',
                    'TOTAL SPENT': translations['total_spent'] || 'Total Spent',
                    'AVERAGE PURCHASE': translations['average_purchase'] || 'Average Purchase',
                    'LAST PURCHASE DATE': translations['last_purchase_date'] || 'Last Purchase Date',
                    'PRODUCT ID': translations['product_id'] || 'Product ID',
                    'PRODUCT NAME': translations['product_name'] || 'Product Name',
                    'CATEGORY': translations['category'] || 'Category',
                    'STOCK QUANTITY': translations['stock_quantity'] || 'Stock Quantity',
                    'UNIT PRICE': translations['unit_price'] || 'Unit Price',
                    'TOTAL VALUE': translations['total_value'] || 'Total Value',
                    'STAFF ID': translations['staff_id'] || 'Staff ID',
                    'STAFF NAME': translations['staff_name'] || 'Staff Name',
                    'SALES COUNT': translations['sales_count'] || 'Sales Count',
                    'TOTAL SALES': translations['total_sales'] || 'Total Sales',
                    'COMMISSION': translations['commission'] || 'Commission',
                    'DATE': translations['date'] || 'Date',
                    'REVENUE': translations['revenue'] || 'Revenue',
                    'EXPENSES': translations['expenses'] || 'Expenses',
                    'PROFIT': translations['profit'] || 'Profit',
                    'PROFIT MARGIN': translations['profit_margin'] || 'Profit Margin',
                    'USER ID': translations['user_id'] || 'User ID',
                    'USERNAME': translations['username'] || 'Username',
                    'TOTAL REVENUE': translations['total_revenue'] || 'Total Revenue',
                    'AVERAGE SALE': translations['average_sale'] || 'Average Sale',
                    'UNIQUE CUSTOMERS': translations['unique_customers'] || 'Unique Customers'
                };

                header = headerTranslations[header] || header;
                html += `<th>${header}</th>`;
            });
            html += '</tr></thead>';

            // Data rows with enhanced formatting
            html += '<tbody>';
            data.forEach((row, index) => {
                const rowClass = index % 2 === 0 ? 'table-row-even' : 'table-row-odd';
                html += `<tr class="${rowClass}">`;
                Object.entries(row).forEach(([key, value]) => {
                    let cellClass = '';
                    let formattedValue = value;

                    // Format currency values based on column type
                    if (typeof value === 'number' && (
                        key.toLowerCase().includes('spent') ||
                        key.toLowerCase().includes('purchase') ||
                        key.toLowerCase().includes('price') ||
                        key.toLowerCase().includes('value') ||
                        key.toLowerCase().includes('sales') ||
                        key.toLowerCase().includes('commission') ||
                        key.toLowerCase().includes('revenue') ||
                        key.toLowerCase().includes('expenses') ||
                        key.toLowerCase().includes('profit')
                    )) {
                        // Format as currency with proper symbol and exchange rate
                        const convertedValue = value * exchangeRate;
                        formattedValue = currencySymbol + ' ' + convertedValue.toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                        cellClass = 'currency';
                    } else if (typeof value === 'number') {
                        // Format other numbers
                        if (String(value).includes('.')) {
                            formattedValue = parseFloat(value).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });
                        } else {
                            formattedValue = parseInt(value).toLocaleString('en-US');
                        }
                        cellClass = 'number';
                    } else if (typeof value === 'string' && value.length > 20) {
                        // Truncate long text with tooltip
                        formattedValue = `<span title="${value}">${value.substring(0, 20)}...</span>`;
                    }

                    html += `<td class="${cellClass}" title="${value}">${formattedValue}</td>`;
                });
                html += '</tr>';
            });
            html += '</tbody></table></div>';

            // Preview note
            const previewNoteText = translations['preview_note'] || 'This is a preview. Generate the full report to see all data';
            html += '<div class="text-center mt-3">';
            html += '<small style="color: #10B981; font-weight: 600; text-shadow: 0 1px 2px rgba(16, 185, 129, 0.3);">✨ ' + previewNoteText + '</small>';
            html += '</div>';

            $('#previewArea').html(html);
        }

        function showMessage(message, type = 'info') {
            // Remove any existing alerts
            $('.alert').remove();

            const alertClass = type === 'success' ? 'alert-success' :
                             type === 'error' ? 'alert-danger' :
                             'alert-info';

            const icon = type === 'success' ? 'fa-check-circle' :
                        type === 'error' ? 'fa-exclamation-circle' :
                        'fa-info-circle';

            const alert = $(`
                <div class="alert ${alertClass} alert-dismissible fade show"
                     style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                    <i class="fas ${icon} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);

            $('body').append(alert);

            // Auto dismiss after 5 seconds
            setTimeout(() => {
                alert.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }

        // Initialize
        $(document).ready(function() {
            // Initialize translations
            window.translations = <?php echo json_encode($translations); ?>;

            // Initialize AOS
            AOS.init({
                duration: 800,
                once: true
            });

            // Initialize theme manager if not already initialized by navbar
            if (typeof window.themeManager === 'undefined') {
                console.log('🎨 Reports: Initializing theme manager...');
                if (typeof ThemeManager !== 'undefined') {
                    window.themeManager = new ThemeManager();
                    console.log('🎨 Reports: Theme manager initialized successfully');
                } else {
                    console.warn('🎨 Reports: ThemeManager class not available');
                }
            } else {
                console.log('🎨 Reports: Theme manager already initialized');
            }

            // Apply theme from localStorage
            console.log('🎨 Reports: Applying theme from localStorage...');
            const currentTheme = localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Reports: Current theme:', currentTheme);

            // Apply theme attributes immediately
            document.documentElement.setAttribute('data-theme', currentTheme);
            document.body.setAttribute('data-theme', currentTheme);

            console.log('🎨 Reports: Theme applied successfully');

            startRealTimeClock();

            // Initialize navbar functionality
            initializeNavbarFunctionality();

            // Also initialize navbar functions from navbar.php
            if (typeof initializeNavbarFunctions === 'function') {
                initializeNavbarFunctions();
                console.log('✅ Navbar functions initialized');
            } else {
                console.log('⚠️ initializeNavbarFunctions not found');
            }

            // Debug calculator
            console.log('🧮 Calculator overlay exists:', $('#calculator-overlay').length);
            console.log('🧮 Calculator button exists:', $('.calculator-toggle, #calculator-btn').length);

            // Ensure calculator overlay exists
            if ($('#calculator-overlay').length === 0) {
                console.log('🧮 Calculator overlay not found, creating...');
                // Add calculator overlay if it doesn't exist
                const calculatorOverlay = `
                    <div id="calculator-overlay" class="calculator-overlay">
                        <div class="calculator">
                            <div class="calculator-header">
                                <span data-translate="calculator"><?php echo htmlspecialchars($translations['calculator'] ?? 'Calculator'); ?></span>
                                <button class="close-btn" onclick="$('#calculator-overlay').removeClass('active')">&times;</button>
                            </div>
                            <div class="calculator-display">
                                <input type="text" id="calculator-result" readonly value="0">
                            </div>
                            <div class="calculator-buttons">
                                <button class="clear">C</button>
                                <button class="operator">÷</button>
                                <button class="operator">×</button>
                                <button class="backspace">⌫</button>

                                <button class="number">7</button>
                                <button class="number">8</button>
                                <button class="number">9</button>
                                <button class="operator">-</button>

                                <button class="number">4</button>
                                <button class="number">5</button>
                                <button class="number">6</button>
                                <button class="operator">+</button>

                                <button class="number">1</button>
                                <button class="number">2</button>
                                <button class="number">3</button>
                                <button class="equal" rowspan="2">=</button>

                                <button class="number zero">0</button>
                                <button class="decimal">.</button>
                            </div>
                        </div>
                    </div>
                `;
                $('body').append(calculatorOverlay);
                console.log('✅ Calculator overlay created');
            }

            // Manual calculator button click handler
            $(document).on('click', '.calculator-toggle, #calculator-btn', function(e) {
                e.preventDefault();
                console.log('🧮 Calculator button clicked manually!');
                $('#calculator-overlay').toggleClass('active');
            });

            // Calculator functionality
            let calculatorDisplay = '0';
            let calculatorOperator = null;
            let calculatorPreviousValue = null;
            let calculatorWaitingForOperand = false;

            function updateCalculatorDisplay() {
                $('#calculator-result').val(calculatorDisplay);
            }

            function inputCalculatorDigit(digit) {
                if (calculatorWaitingForOperand) {
                    calculatorDisplay = String(digit);
                    calculatorWaitingForOperand = false;
                } else {
                    calculatorDisplay = calculatorDisplay === '0' ? String(digit) : calculatorDisplay + digit;
                }
                updateCalculatorDisplay();
            }

            function inputCalculatorDecimal() {
                if (calculatorWaitingForOperand) {
                    calculatorDisplay = '0.';
                    calculatorWaitingForOperand = false;
                } else if (calculatorDisplay.indexOf('.') === -1) {
                    calculatorDisplay += '.';
                }
                updateCalculatorDisplay();
            }

            function clearCalculator() {
                calculatorDisplay = '0';
                calculatorOperator = null;
                calculatorPreviousValue = null;
                calculatorWaitingForOperand = false;
                updateCalculatorDisplay();
            }

            function performCalculatorOperation() {
                const inputValue = parseFloat(calculatorDisplay);

                if (calculatorPreviousValue === null) {
                    calculatorPreviousValue = inputValue;
                } else if (calculatorOperator) {
                    const currentValue = calculatorPreviousValue || 0;
                    const newValue = {
                        '+': (prev, curr) => prev + curr,
                        '-': (prev, curr) => prev - curr,
                        '×': (prev, curr) => prev * curr,
                        '÷': (prev, curr) => prev / curr,
                    }[calculatorOperator](currentValue, inputValue);

                    calculatorDisplay = String(newValue);
                    calculatorPreviousValue = newValue;
                    updateCalculatorDisplay();
                }

                calculatorWaitingForOperand = true;
            }

            // Calculator button events
            $(document).on('click', '.calculator-buttons .number', function() {
                inputCalculatorDigit($(this).text());
            });

            $(document).on('click', '.calculator-buttons .decimal', function() {
                inputCalculatorDecimal();
            });

            $(document).on('click', '.calculator-buttons .operator', function() {
                const operator = $(this).text();
                if (calculatorOperator && !calculatorWaitingForOperand) {
                    performCalculatorOperation();
                }
                calculatorOperator = operator;
                calculatorPreviousValue = parseFloat(calculatorDisplay);
                calculatorWaitingForOperand = true;
            });

            $(document).on('click', '.calculator-buttons .equal', function() {
                performCalculatorOperation();
                calculatorOperator = null;
                calculatorPreviousValue = null;
                calculatorWaitingForOperand = true;
            });

            $(document).on('click', '.calculator-buttons .clear', function() {
                clearCalculator();
            });

            $(document).on('click', '.calculator-buttons .backspace', function() {
                if (calculatorDisplay.length > 1) {
                    calculatorDisplay = calculatorDisplay.slice(0, -1);
                } else {
                    calculatorDisplay = '0';
                }
                updateCalculatorDisplay();
            });

            // Close calculator on outside click
            $(document).on('click', '#calculator-overlay', function(e) {
                if (e.target === this) {
                    $(this).removeClass('active');
                }
            });

            // Close calculator on escape key
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape' && $('#calculator-overlay').hasClass('active')) {
                    $('#calculator-overlay').removeClass('active');
                }
            });

            console.log('✅ Calculator functionality initialized');

            // Add hover effect to report cards
            $('.report-card').hover(
                function() {
                    $(this).find('.report-icon').addClass('animate__animated animate__rubberBand');
                },
                function() {
                    $(this).find('.report-icon').removeClass('animate__animated animate__rubberBand');
                }
            );

            // Smooth scroll
            $('a[href*="#"]').on('click', function(e) {
                const href = $(this).attr('href');
                if (href && href !== '#' && href.length > 1) {
                    e.preventDefault();
                    const target = $(href);
                    if (target.length) {
                        $('html, body').animate({
                            scrollTop: target.offset().top - 100
                        }, 500, 'easeOutCubic');
                    }
                }
            });

            // Initialize tooltips
            $('[data-bs-toggle="tooltip"]').tooltip();

            // Initialize date pickers with validation
            $('#startDate, #endDate').on('change', function() {
                const startDate = new Date($('#startDate').val());
                const endDate = new Date($('#endDate').val());

                if (endDate < startDate) {
                    showMessage('End date cannot be earlier than start date', 'error');
                    this.value = this.id === 'startDate' ? $('#endDate').val() : $('#startDate').val();
                } else if (currentReport) {
                    getReportPreview();
                }
            });

            // Add animation to buttons
            $('.btn-report').on('mouseenter', function() {
                $(this).addClass('animate__animated animate__pulse');
            }).on('mouseleave', function() {
                $(this).removeClass('animate__animated animate__pulse');
            });

            // Error handling
            window.onerror = function(msg, url, lineNo, columnNo, error) {
                console.error('JavaScript Error:', error);
                showMessage('An unexpected error occurred. Please try again.', 'error');
                hideLoading();
                return false;
            };

            // Network error handling
            $(window).on('offline', function() {
                showMessage('Network connection lost. Please check your internet connection.', 'error');
            });

            // Add custom animations to tables
            $('.table').on('mouseover', 'tr', function() {
                $(this).addClass('animate__animated animate__fadeIn');
            }).on('mouseout', 'tr', function() {
                $(this).removeClass('animate__animated animate__fadeIn');
            });
        });

        // Add custom easing functions
        $.easing.easeOutCubic = function (x, t, b, c, d) {
            return c * ((t = t/d - 1) * t * t + 1) + b;
        };

        // Navbar functionality for Reports page
        function initializeNavbarFunctionality() {
            console.log('🔧 Initializing Reports page navbar functionality...');

            // Use navbar's calculator functionality - no need to override
            console.log('🧮 Using navbar calculator functionality');

            // Language switching
            window.switchLanguage = function(lang) {
                console.log('🌐 Language switched to:', lang, 'on Reports page');

                $.ajax({
                    url: 'update_language.php',
                    method: 'POST',
                    data: {
                        language: lang,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('✅ Language response:', response);
                        if (response.success) {
                            // Update global translations
                            translations = response.translations;

                            // Update all translatable elements
                            updatePageTranslations();

                            // Force update specific elements that might not have data-translate
                            updateSpecificElements();

                            // Update language label in navbar
                            $('.language-label').text(lang === 'en' ? (translations['lang_en'] || 'EN') : (translations['lang_mm'] || 'MM'));

                            console.log('✅ Language updated without refresh');
                        } else {
                            showMessage('Error: ' + response.message, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Language change failed:', xhr.responseText);
                        showMessage('Failed to change language: ' + error, 'error');
                    }
                });
            };

            // Currency switching
            window.switchCurrency = function(currency) {
                console.log('💱 Currency switched to:', currency, 'on Reports page');

                $.ajax({
                    url: 'update_currency.php',
                    method: 'POST',
                    data: {
                        currency: currency,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('✅ Currency response:', response);
                        if (response.success) {
                            // Update global currency variables
                            const symbols = { 'USD': '$', 'THB': '฿', 'MMK': 'Ks' };
                            const rates = { 'USD': 1, 'THB': 33, 'MMK': 2100 };

                            // Update global variables
                            window.currencySymbol = symbols[currency];
                            window.exchangeRate = rates[currency];
                            currencySymbol = symbols[currency];
                            exchangeRate = rates[currency];

                            // Update all currency displays on the page
                            updateCurrencyDisplays(currency, symbols[currency], rates[currency]);

                            // Update table currency values if table exists
                            updateTableCurrencyValues();

                            console.log('✅ Currency updated without refresh');
                        } else {
                            showMessage('Error: ' + response.message, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Currency change failed:', xhr.responseText);
                        showMessage('Failed to change currency: ' + error, 'error');
                    }
                });
            };

            // Update currency displays
            function updateCurrencyDisplays(newCurrency, symbol, rate) {
                console.log('💰 Updating currency displays:', newCurrency, symbol, rate);

                // Update all currency amounts on the page
                $('.currency-amount').each(function() {
                    const baseAmount = $(this).data('base-amount');
                    if (baseAmount) {
                        const convertedAmount = baseAmount * rate;
                        $(this).text(symbol + ' ' + convertedAmount.toLocaleString());
                    }
                });

                // Update currency symbol in forms and displays
                $('.currency-symbol').text(symbol);

                // Update global currency variables
                window.currencySymbol = symbol;
                window.exchangeRate = rate;

                // Update currency select dropdown
                $('#currency-select').val(newCurrency);

                console.log('✅ Currency displays updated to:', newCurrency);
            }

            // Update page translations
            function updatePageTranslations() {
                console.log('🔄 Updating page translations...');

                // Force update specific report card elements
                updateReportCards();

                // Update all elements with data-translate attribute
                $('[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update page title
                if (translations['reports']) {
                    document.title = translations['reports'] + ' - BitsTech POS';
                }

                // Update report titles and descriptions
                $('.report-title[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update form labels
                $('.form-label[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update select options
                $('option[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update button text
                $('button span[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update loading text
                $('.loading-text[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update table headers if preview is visible
                if ($('#previewArea table').length > 0) {
                    $('#previewArea table thead th').each(function(index) {
                        const originalText = $(this).text().trim();
                        const headerTranslations = {
                            'Customer ID': translations['customer_id'] || 'Customer ID',
                            'Customer Name': translations['customer_name'] || 'Customer Name',
                            'Total Purchases': translations['total_purchases'] || 'Total Purchases',
                            'Total Spent': translations['total_spent'] || 'Total Spent',
                            'Average Purchase': translations['average_purchase'] || 'Average Purchase',
                            'Last Purchase Date': translations['last_purchase_date'] || 'Last Purchase Date',
                            'Product ID': translations['product_id'] || 'Product ID',
                            'Product Name': translations['product_name'] || 'Product Name',
                            'Category': translations['category'] || 'Category',
                            'Stock Quantity': translations['stock_quantity'] || 'Stock Quantity',
                            'Unit Price': translations['unit_price'] || 'Unit Price',
                            'Total Value': translations['total_value'] || 'Total Value',
                            'Staff ID': translations['staff_id'] || 'Staff ID',
                            'Staff Name': translations['staff_name'] || 'Staff Name',
                            'Sales Count': translations['sales_count'] || 'Sales Count',
                            'Total Sales': translations['total_sales'] || 'Total Sales',
                            'Commission': translations['commission'] || 'Commission',
                            'Date': translations['date'] || 'Date',
                            'Revenue': translations['revenue'] || 'Revenue',
                            'Expenses': translations['expenses'] || 'Expenses',
                            'Profit': translations['profit'] || 'Profit',
                            'Profit Margin': translations['profit_margin'] || 'Profit Margin',
                            'User ID': translations['user_id'] || 'User ID',
                            'Username': translations['username'] || 'Username',
                            'Total Revenue': translations['total_revenue'] || 'Total Revenue',
                            'Average Sale': translations['average_sale'] || 'Average Sale',
                            'Unique Customers': translations['unique_customers'] || 'Unique Customers',
                            // Myanmar to English reverse mapping
                            'ဖောက်သည် ID': translations['customer_id'] || 'Customer ID',
                            'ဖောက်သည်အမည်': translations['customer_name'] || 'Customer Name',
                            'စုစုပေါင်းဝယ်ယူမှု': translations['total_purchases'] || 'Total Purchases',
                            'စုစုပေါင်းသုံးစွဲမှု': translations['total_spent'] || 'Total Spent',
                            'ပျမ်းမျှဝယ်ယူမှု': translations['average_purchase'] || 'Average Purchase',
                            'နောက်ဆုံးဝယ်ယူသည့်ရက်': translations['last_purchase_date'] || 'Last Purchase Date',
                            'ကုန်ပစ္စည်း ID': translations['product_id'] || 'Product ID',
                            'ကုန်ပစ္စည်းအမည်': translations['product_name'] || 'Product Name',
                            'အမျိုးအစား': translations['category'] || 'Category',
                            'စတော့ပမာဏ': translations['stock_quantity'] || 'Stock Quantity',
                            'တစ်ခုချင်းစျေးနှုန်း': translations['unit_price'] || 'Unit Price',
                            'စုစုပေါင်းတန်ဖိုး': translations['total_value'] || 'Total Value',
                            'ဝန်ထမ်း ID': translations['staff_id'] || 'Staff ID',
                            'ဝန်ထမ်းအမည်': translations['staff_name'] || 'Staff Name',
                            'ရောင်းချမှုအရေအတွက်': translations['sales_count'] || 'Sales Count',
                            'စုစုပေါင်းရောင်းချမှု': translations['total_sales'] || 'Total Sales',
                            'ကော်မရှင်': translations['commission'] || 'Commission',
                            'ရက်စွဲ': translations['date'] || 'Date',
                            'ဝင်ငွေ': translations['revenue'] || 'Revenue',
                            'ကုန်ကျစရိတ်': translations['expenses'] || 'Expenses',
                            'အမြတ်': translations['profit'] || 'Profit',
                            'အမြတ်နှုန်း': translations['profit_margin'] || 'Profit Margin',
                            'အသုံးပြုသူ ID': translations['user_id'] || 'User ID',
                            'အသုံးပြုသူအမည်': translations['username'] || 'Username',
                            'စုစုပေါင်းဝင်ငွေ': translations['total_revenue'] || 'Total Revenue',
                            'ပျမ်းမျှရောင်းချမှု': translations['average_sale'] || 'Average Sale',
                            'ဖောက်သည်အရေအတွက်': translations['unique_customers'] || 'Unique Customers'
                        };

                        if (headerTranslations[originalText]) {
                            $(this).text(headerTranslations[originalText]);
                        }
                    });
                }

                // Update preview note
                const previewNote = $('#previewArea small');
                if (previewNote.length > 0) {
                    const previewNoteText = translations['preview_note'] || 'This is a preview. Generate the full report to see all data';
                    previewNote.html('✨ ' + previewNoteText);
                }

                // Update no data message
                const noDataMsg = $('#previewArea p');
                if (noDataMsg.length > 0 && noDataMsg.text().includes('📊')) {
                    const noDataText = translations['no_data_available'] || 'No data available for this report';
                    noDataMsg.html('📊 ' + noDataText);
                }

                // Update currency values in table
                updateTableCurrencyValues();

                $('.report-description[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                // Update form labels and buttons
                $('.form-label[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                $('.btn[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (translations[key]) {
                        $(this).text(translations[key]);
                    }
                });

                console.log('✅ Page translations updated');
            }

            // Force update report cards
            function updateReportCards() {
                console.log('🔄 Force updating report cards...');

                // Sales Summary Card
                $('.report-card').eq(0).find('h3').text(translations['sales_summary'] || 'Sales Summary');
                $('.report-card').eq(0).find('p').text(translations['sales_summary_desc'] || 'Comprehensive overview of sales performance and trends');

                // Inventory Report Card
                $('.report-card').eq(1).find('h3').text(translations['inventory_report'] || 'Inventory Report');
                $('.report-card').eq(1).find('p').text(translations['inventory_report_desc'] || 'Current stock levels, reorder points, and inventory movement');

                // Customer Analysis Card
                $('.report-card').eq(2).find('h3').text(translations['customer_analysis'] || 'Customer Analysis');
                $('.report-card').eq(2).find('p').text(translations['customer_analysis_desc'] || 'Customer behavior, loyalty, and purchasing patterns');

                // Staff Performance Card
                $('.report-card').eq(3).find('h3').text(translations['staff_performance'] || 'Staff Performance');
                $('.report-card').eq(3).find('p').text(translations['staff_performance_desc'] || 'Employee sales performance and productivity metrics');

                // Profit/Loss Report Card
                $('.report-card').eq(4).find('h3').text(translations['profit_loss'] || 'Profit/Loss Report');
                $('.report-card').eq(4).find('p').text(translations['profit_loss_desc'] || 'Financial overview with revenue, expenses, and profit analysis');

                console.log('✅ Report cards force updated');
            }

            // Update specific elements that might not have data-translate attributes
            function updateSpecificElements() {
                console.log('🔄 Updating specific elements...');

                // Update page description
                $('.page-description').text(translations['reports_description'] || 'Generate and analyze detailed business reports');

                // Update all report card titles and descriptions by index
                const reportCards = $('.report-card');

                if (reportCards.length >= 5) {
                    // Sales Summary
                    $(reportCards[0]).find('h3').text(translations['sales_summary'] || 'Sales Summary');
                    $(reportCards[0]).find('p').text(translations['sales_summary_desc'] || 'Comprehensive overview of sales performance and trends');

                    // Inventory Report
                    $(reportCards[1]).find('h3').text(translations['inventory_report'] || 'Inventory Report');
                    $(reportCards[1]).find('p').text(translations['inventory_report_desc'] || 'Current stock levels, reorder points, and inventory movement');

                    // Customer Analysis
                    $(reportCards[2]).find('h3').text(translations['customer_analysis'] || 'Customer Analysis');
                    $(reportCards[2]).find('p').text(translations['customer_analysis_desc'] || 'Customer behavior, loyalty, and purchasing patterns');

                    // Staff Performance
                    $(reportCards[3]).find('h3').text(translations['staff_performance'] || 'Staff Performance');
                    $(reportCards[3]).find('p').text(translations['staff_performance_desc'] || 'Employee sales performance and productivity metrics');

                    // Profit/Loss Report
                    $(reportCards[4]).find('h3').text(translations['profit_loss'] || 'Profit/Loss Report');
                    $(reportCards[4]).find('p').text(translations['profit_loss_desc'] || 'Financial overview with revenue, expenses, and profit analysis');
                }

                // Update form elements
                $('label[for="start_date"]').text(translations['start_date'] || 'Start Date');
                $('label[for="end_date"]').text(translations['end_date'] || 'End Date');
                $('label[for="report_format"]').text(translations['report_format'] || 'Report Format');

                // Update select options
                $('#report_format option[value="preview"]').text(translations['preview'] || 'Preview');
                $('#report_format option[value="excel"]').text(translations['excel'] || 'Excel');
                $('#report_format option[value="pdf"]').text(translations['pdf'] || 'PDF');

                // Update button text
                $('.btn-primary').text(translations['generate_report'] || 'Generate Report');

                // Update preview section
                $('.preview-title').text(translations['report_preview'] || 'Report Preview');
                $('.preview-text').text(translations['no_data_available'] || 'No data available for this report');
                $('.preview-note').text(translations['preview_note'] || 'This is a preview. Generate the full report to see all data');

                console.log('✅ Specific elements updated');
            }

            console.log('✅ Reports page navbar functionality initialized');

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 Reports: Notification bell visibility updated');
            }

            // Override navbar language handler
            $('.language-item').off('click').on('click', function(e) {
                e.preventDefault();
                const lang = $(this).data('lang');
                console.log('🌐 Language clicked:', lang);
                window.switchLanguage(lang);
            });

            // Override navbar currency handler
            $('#currency-select').off('change').on('change', function() {
                const currency = $(this).val();
                console.log('💱 Currency changed:', currency);
                window.switchCurrency(currency);
            });

            // Don't override calculator - let navbar handle it
            console.log('🧮 Calculator functionality handled by navbar');
        }
    </script>

    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>