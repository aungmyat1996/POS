<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Get current user data
$userId = $_SESSION['user_id'];
try {
    $stmt = $pdo->prepare("
        SELECT
            u.user_id,
            u.username,
            u.email,
            u.role,
            u.status,
            u.profile_image,
            u.created_at,
            u.last_login,
            u.phone,
            u.address,
            COALESCE(
                (SELECT COUNT(*) FROM orders WHERE user_id = u.user_id),
                0
            ) as total_orders,
            COALESCE(
                (SELECT SUM(total_amount) FROM orders WHERE user_id = u.user_id),
                0
            ) as total_sales
        FROM users u
        WHERE u.user_id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Set default values if user data is not found
    if (!$user) {
        $user = [
            'username' => '',
            'email' => '',
            'role' => '',
            'status' => '',
            'profile_image' => '',
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'phone' => '',
            'address' => '',
            'total_orders' => 0,
            'total_sales' => 0.00
        ];
    }

    // Ensure numeric values are properly formatted
    $user['total_orders'] = intval($user['total_orders']);
    $user['total_sales'] = floatval($user['total_sales']);

} catch (PDOException $e) {
    error_log("Error fetching user data: " . $e->getMessage());
    // Set default values if there's an error
    $user = [
        'username' => '',
        'email' => '',
        'role' => '',
        'status' => '',
        'profile_image' => '',
        'created_at' => date('Y-m-d H:i:s'),
        'last_login' => null,
        'phone' => '',
        'address' => '',
        'total_orders' => 0,
        'total_sales' => 0.00
    ];
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {
            case 'update_profile':
                // Validate required fields
                if (empty($_POST['username']) || empty($_POST['email'])) {
                    throw new Exception('Username and email are required');
                }

                // Check if email is already taken by another user
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM users
                    WHERE email = ? AND user_id != ?
                ");
                $stmt->execute([$_POST['email'], $userId]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Email is already taken');
                }

                // Handle profile image upload
                $profileImage = $user['profile_image'];
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                    $maxSize = 5 * 1024 * 1024; // 5MB

                    if (!in_array($_FILES['profile_image']['type'], $allowedTypes)) {
                        throw new Exception('Invalid image type. Only JPG, PNG and GIF are allowed.');
                    }

                    if ($_FILES['profile_image']['size'] > $maxSize) {
                        throw new Exception('Image size too large. Maximum size is 5MB.');
                    }

                    $uploadDir = BASEPATH . 'uploads/profiles/';
                    if (!file_exists($uploadDir)) {
                        mkdir($uploadDir, 0777, true);
                    }

                    $fileName = uniqid('profile_') . '_' . basename($_FILES['profile_image']['name']);
                    $targetPath = $uploadDir . $fileName;

                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetPath)) {
                        // Delete old profile image if exists
                        if ($profileImage && file_exists($uploadDir . $profileImage)) {
                            unlink($uploadDir . $profileImage);
                        }
                        $profileImage = $fileName;
                    } else {
                        throw new Exception('Failed to upload image');
                    }
                }

                // Update user data
                $stmt = $pdo->prepare("
                    UPDATE users
                    SET
                        username = ?,
                        email = ?,
                        phone = ?,
                        address = ?,
                        profile_image = ?,
                        updated_at = NOW()
                    WHERE user_id = ?
                ");
                $stmt->execute([
                    $_POST['username'],
                    $_POST['email'],
                    $_POST['phone'] ?? null,
                    $_POST['address'] ?? null,
                    $profileImage,
                    $userId
                ]);

                echo json_encode([
                    'success' => true,
                    'message' => 'Profile updated successfully'
                ]);
                break;

            case 'change_password':
                // Validate password fields
                if (empty($_POST['current_password']) || empty($_POST['new_password']) || empty($_POST['confirm_password'])) {
                    throw new Exception('All password fields are required');
                }

                if ($_POST['new_password'] !== $_POST['confirm_password']) {
                    throw new Exception('New passwords do not match');
                }

                // Verify current password
                $stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
                $stmt->execute([$userId]);
                $currentHash = $stmt->fetchColumn();

                if (!password_verify($_POST['current_password'], $currentHash)) {
                    throw new Exception('Current password is incorrect');
                }

                // Update password
                $newHash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    UPDATE users
                    SET password = ?, updated_at = NOW()
                    WHERE user_id = ?
                ");
                $stmt->execute([$newHash, $userId]);

                echo json_encode([
                    'success' => true,
                    'message' => 'Password changed successfully'
                ]);
                break;

            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($translations['profile'] ?? 'Profile'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <style>
        :root {
            --primary-bg: #1a1c23;
            --secondary-bg: #24262d;
            --card-bg: #2a2d35;
            --text-primary: #ffffff;
            --text-secondary: rgba(255,255,255,0.7);
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --card-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            --success-gradient: linear-gradient(135deg, #34d399 0%, #3b82f6 100%);
            --danger-gradient: linear-gradient(135deg, #f43f5e 0%, #ec4899 100%);
            --warning-gradient: linear-gradient(135deg, #f59e0b 0%, #f43f5e 100%);
            --info-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }

        body {
            background: var(--primary-bg);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
        }

        .profile-container {
            padding: 2rem;
            min-height: 100vh;
        }

        .page-header {
            background: var(--secondary-bg);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, var(--accent-purple) 0%, var(--accent-pink) 100%);
            opacity: 0.1;
            z-index: 0;
        }

        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .profile-image {
            width: 120px;
            height: 120px;
            border-radius: 1rem;
            object-fit: cover;
            background: var(--card-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: var(--text-secondary);
            overflow: hidden;
            position: relative;
        }

        .profile-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-image:hover .profile-image-overlay {
            opacity: 1;
        }

        .profile-image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            cursor: pointer;
        }

        .profile-info h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .profile-info p {
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 1.5rem;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: var(--success-gradient);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .stat-card p {
            color: var(--text-secondary);
            margin: 0;
            font-size: 0.875rem;
        }

        .profile-content {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 1rem;
        }

        .form-label {
            color: var(--text-secondary);
            font-size: 0.875rem;
            margin-bottom: 0.5rem;
        }

        .form-control {
            background: var(--secondary-bg);
            border: 1px solid rgba(255,255,255,0.1);
            color: var(--text-primary);
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
        }

        .form-control:focus {
            background: var(--secondary-bg);
            border-color: var(--accent-purple);
            color: var(--text-primary);
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.25);
        }

        .btn-save {
            background: var(--accent-purple);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-save:hover {
            background: var(--accent-pink);
            transform: translateY(-2px);
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--primary-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--accent-purple);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-pink);
        }

        /* Light Mode H1 and Headers Text Colors for Profile Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }
    </style>
</head>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="profile-container">
            <!-- Page Header -->
            <div class="page-header" data-aos="fade-down">
                <h1>
                    <i class="fas fa-user-circle"></i>
                    <span data-translate="profile">
                        <?php echo htmlspecialchars($translations['profile'] ?? 'Profile'); ?>
                    </span>
                </h1>
            </div>

            <!-- Profile Header -->
            <div class="profile-header" data-aos="fade-up">
                <div class="profile-image">
                    <?php if (!empty($user['profile_image'])): ?>
                        <img src="../uploads/profiles/<?php echo htmlspecialchars($user['profile_image']); ?>"
                             alt="Profile Image">
                    <?php else: ?>
                        <i class="fas fa-user"></i>
                    <?php endif; ?>
                    <div class="profile-image-overlay" onclick="$('#profileImage').click()">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                <div class="profile-info">
                    <h2><?php echo htmlspecialchars($user['username'] ?? 'User'); ?></h2>
                    <p><i class="fas fa-envelope me-2"></i><?php echo htmlspecialchars($user['email'] ?? 'No email set'); ?></p>
                    <p><i class="fas fa-user-tag me-2"></i><?php echo htmlspecialchars(ucfirst($user['role'] ?? 'user')); ?></p>
                    <p><i class="fas fa-clock me-2"></i>Member since <?php
                        $created_at = !empty($user['created_at']) ? date('M Y', strtotime($user['created_at'])) : 'Unknown';
                        echo $created_at;
                    ?></p>
                </div>
            </div>

            <!-- Profile Stats -->
            <div class="profile-stats" data-aos="fade-up" data-aos-delay="100">
                <div class="stat-card">
                    <h3><?php echo number_format($user['total_orders'] ?? 0); ?></h3>
                    <p data-translate="total_orders">Total Orders</p>
                </div>
                <div class="stat-card">
                    <h3><?php echo number_format($user['total_sales'] ?? 0, 2); ?></h3>
                    <p data-translate="total_sales">Total Sales</p>
                </div>
                <div class="stat-card">
                    <h3><?php
                        $last_login = $user['last_login'] ?? null;
                        echo $last_login && $last_login !== '0000-00-00 00:00:00' ? date('d M Y', strtotime($last_login)) : 'Never';
                    ?></h3>
                    <p data-translate="last_login">Last Login</p>
                </div>
            </div>

            <!-- Profile Content -->
            <div class="row">
                <!-- Personal Information -->
                <div class="col-md-6">
                    <div class="profile-content" data-aos="fade-up" data-aos-delay="200">
                        <h3 data-translate="personal_info">Personal Information</h3>
                        <form id="profileForm" enctype="multipart/form-data">
                            <input type="file" id="profileImage" name="profile_image" accept="image/*" style="display: none;">
                            <div class="mb-3">
                                <label class="form-label" data-translate="username">Username</label>
                                <input type="text" class="form-control" name="username"
                                       value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" data-translate="email">Email</label>
                                <input type="email" class="form-control" name="email"
                                       value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" data-translate="phone">Phone</label>
                                <input type="tel" class="form-control" name="phone"
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label" data-translate="address">Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-save">
                                <i class="fas fa-save"></i>
                                <span data-translate="save_changes">Save Changes</span>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Security Settings -->
                <div class="col-md-6">
                    <div class="profile-content" data-aos="fade-up" data-aos-delay="300">
                        <h3 data-translate="security">Security</h3>
                        <form id="passwordForm">
                            <div class="mb-3">
                                <label class="form-label" data-translate="current_password">Current Password</label>
                                <input type="password" class="form-control" name="current_password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" data-translate="new_password">New Password</label>
                                <input type="password" class="form-control" name="new_password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" data-translate="confirm_password">Confirm New Password</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                            <button type="submit" class="btn btn-save">
                                <i class="fas fa-key"></i>
                                <span data-translate="change_password">Change Password</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true
        });

        // Apply theme from localStorage
        console.log('🎨 Profile: Applying theme from localStorage...');
        const currentTheme = localStorage.getItem('theme_mode') || 'dark';
        console.log('🎨 Profile: Current theme:', currentTheme);

        // Apply theme attributes immediately
        document.documentElement.setAttribute('data-theme', currentTheme);
        document.body.setAttribute('data-theme', currentTheme);

        console.log('🎨 Profile: Theme applied successfully');

        // Initialize notification bell visibility immediately
        if (typeof window.updateNotificationBellVisibility === 'function') {
            window.updateNotificationBellVisibility();
            console.log('🔔 Profile: Notification bell visibility updated');
        }

        // Handle profile image change
        $('#profileImage').on('change', function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('.profile-image img').attr('src', e.target.result);
                };
                reader.readAsDataURL(this.files[0]);
            }
        });

        // Handle profile form submission
        $('#profileForm').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            formData.append('action', 'update_profile');

            const submitBtn = $(this).find('button[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Saving...');
            submitBtn.prop('disabled', true);

            $.ajax({
                url: 'profile.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        showSuccessMessage(response.message);
                        setTimeout(() => window.location.reload(), 1500);
                    } else {
                        showErrorMessage(response.message || 'Failed to update profile');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            });
        });

        // Handle password form submission
        $('#passwordForm').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            formData.append('action', 'change_password');

            const submitBtn = $(this).find('button[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Saving...');
            submitBtn.prop('disabled', true);

            $.ajax({
                url: 'profile.php',
                type: 'POST',
                data: Object.fromEntries(formData),
                success: function(response) {
                    if (response.success) {
                        showSuccessMessage(response.message);
                        $('#passwordForm')[0].reset();
                    } else {
                        showErrorMessage(response.message || 'Failed to change password');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            });
        });

        function showSuccessMessage(message) {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: message,
                timer: 2000,
                showConfirmButton: false
            });
        }

        function showErrorMessage(message) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: message
            });
        }

        function handleAjaxError(xhr, status, error) {
            let errorMessage = 'An error occurred';
            try {
                const response = JSON.parse(xhr.responseText);
                errorMessage = response.message || errorMessage;
            } catch (e) {
                console.error('Error parsing error response:', e);
            }

            showErrorMessage(errorMessage);
        }
    </script>

    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>