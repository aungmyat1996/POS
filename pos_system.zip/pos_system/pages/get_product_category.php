<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
header('Content-Type: application/json');
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

if (empty($search_query)) {
    echo json_encode(['category_id' => '']);
    exit();
}

$where_clause = '';
$params = [];
if (is_numeric($search_query)) {
    $where_clause = "WHERE p.product_id = ?";
    $params[] = $search_query;
} else {
    $where_clause = "WHERE p.product_name LIKE ?";
    $params[] = "%$search_query%";
}

$stmt = $pdo->prepare("SELECT category_id FROM products p $where_clause LIMIT 1");
$stmt->execute($params);
$product = $stmt->fetch();

echo json_encode(['category_id' => $product['category_id'] ?? '']);