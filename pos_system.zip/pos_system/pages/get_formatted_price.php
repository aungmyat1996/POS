<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$price = (float)($_POST['price'] ?? 0);
$currency = sanitize_input($_POST['currency'] ?? 'USD');
$discount = (float)($_POST['discount'] ?? 0);

$exchangeRates = [
    'USD' => 1,
    'THB' => 33,
    'MMK' => 2100
];

echo json_encode([
    'success' => true,
    'formatted' => format_currency($price, $currency, $exchangeRates, $discount)
]);
?>