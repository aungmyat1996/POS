<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
header('Content-Type: application/json');

$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

if (!$product_id) {
    echo json_encode(['html' => '<tr><td colspan="4" class="text-center" data-translate="no_history">No history available</td></tr>']);
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM stock_history WHERE product_id = :id ORDER BY created_at DESC LIMIT 5");
$stmt->execute([':id' => $product_id]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

$html = '';
if (empty($history)) {
    $html = '<tr><td colspan="4" class="text-center" data-translate="no_history">No history available</td></tr>';
} else {
    foreach ($history as $entry) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($entry['created_at']) . '</td>';
        $html .= '<td>' . htmlspecialchars($entry['change_type']) . '</td>';
        $html .= '<td>' . htmlspecialchars($entry['quantity']) . '</td>';
        $html .= '<td>' . htmlspecialchars($entry['reason'] ?? 'N/A') . '</td>';
        $html .= '</tr>';
    }
}

echo json_encode(['html' => $html]);
?>