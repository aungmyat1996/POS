<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication
requireAuth();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$action = $_POST['action'] ?? '';
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid product ID']);
    exit;
}

// Verify product exists and user has permission
try {
    $stmt = $pdo->prepare("SELECT product_id FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Product not found']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}

switch ($action) {
    case 'upload':
        handleImageUpload($pdo, $product_id);
        break;
    case 'delete':
        handleImageDelete($pdo, $product_id);
        break;
    case 'get_images':
        getProductImages($pdo, $product_id);
        break;
    case 'set_primary':
        setPrimaryImage($pdo, $product_id);
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        break;
}

function handleImageUpload($pdo, $product_id) {
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => 'No file uploaded or upload error']);
        return;
    }

    $file = $_FILES['image'];
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = 5 * 1024 * 1024; // 5MB

    // Validate file type
    if (!in_array($file['type'], $allowed_types)) {
        echo json_encode(['success' => false, 'error' => 'Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed.']);
        return;
    }

    // Validate file size
    if ($file['size'] > $max_size) {
        echo json_encode(['success' => false, 'error' => 'File too large. Maximum size is 5MB.']);
        return;
    }

    // Create upload directory if it doesn't exist
    $upload_dir = BASEPATH . 'public/images/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'product_' . $product_id . '_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $filepath = $upload_dir . $filename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        echo json_encode(['success' => false, 'error' => 'Failed to save file']);
        return;
    }

    // Get next display order
    try {
        $stmt = $pdo->prepare("SELECT MAX(display_order) FROM product_images WHERE product_id = ? AND status = 'active'");
        $stmt->execute([$product_id]);
        $max_order = $stmt->fetchColumn() ?: 0;
        $next_order = $max_order + 1;

        // Insert into database
        $stmt = $pdo->prepare("
            INSERT INTO product_images 
            (product_id, image_path, image_name, image_type, is_primary, display_order, uploaded_by, file_size, mime_type, status) 
            VALUES (?, ?, ?, 'additional', 0, ?, ?, ?, ?, 'active')
        ");
        
        $image_path = 'images/products/' . $filename;
        $stmt->execute([
            $product_id,
            $image_path,
            $filename,
            $next_order,
            $_SESSION['user_id'],
            $file['size'],
            $file['type']
        ]);

        $image_id = $pdo->lastInsertId();

        echo json_encode([
            'success' => true,
            'image_id' => $image_id,
            'image_path' => '../public/' . $image_path,
            'filename' => $filename,
            'display_order' => $next_order
        ]);

    } catch (PDOException $e) {
        // Delete uploaded file if database insert fails
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function handleImageDelete($pdo, $product_id) {
    $image_id = isset($_POST['image_id']) ? (int)$_POST['image_id'] : 0;
    
    if ($image_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid image ID']);
        return;
    }

    try {
        // Get image info and verify ownership
        $stmt = $pdo->prepare("
            SELECT image_id, image_path, is_primary 
            FROM product_images 
            WHERE image_id = ? AND product_id = ? AND status = 'active'
        ");
        $stmt->execute([$image_id, $product_id]);
        $image = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$image) {
            echo json_encode(['success' => false, 'error' => 'Image not found']);
            return;
        }

        // Don't allow deletion of primary image if it's the only one
        if ($image['is_primary']) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM product_images WHERE product_id = ? AND status = 'active'");
            $stmt->execute([$product_id]);
            $count = $stmt->fetchColumn();
            
            if ($count <= 1) {
                echo json_encode(['success' => false, 'error' => 'Cannot delete the only image']);
                return;
            }
        }

        // Mark as deleted in database
        $stmt = $pdo->prepare("UPDATE product_images SET status = 'deleted' WHERE image_id = ?");
        $stmt->execute([$image_id]);

        // Delete physical file
        $file_path = BASEPATH . 'public/' . $image['image_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // If deleted image was primary, set another image as primary
        if ($image['is_primary']) {
            $stmt = $pdo->prepare("
                UPDATE product_images 
                SET is_primary = 1 
                WHERE product_id = ? AND status = 'active' 
                ORDER BY display_order ASC 
                LIMIT 1
            ");
            $stmt->execute([$product_id]);
        }

        echo json_encode(['success' => true, 'message' => 'Image deleted successfully']);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function getProductImages($pdo, $product_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT image_id, image_path, image_name, is_primary, display_order 
            FROM product_images 
            WHERE product_id = ? AND status = 'active' 
            ORDER BY is_primary DESC, display_order ASC
        ");
        $stmt->execute([$product_id]);
        $images = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'images' => $images]);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function setPrimaryImage($pdo, $product_id) {
    $image_id = isset($_POST['image_id']) ? (int)$_POST['image_id'] : 0;
    
    if ($image_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid image ID']);
        return;
    }

    try {
        $pdo->beginTransaction();

        // Verify image belongs to product
        $stmt = $pdo->prepare("
            SELECT image_id FROM product_images 
            WHERE image_id = ? AND product_id = ? AND status = 'active'
        ");
        $stmt->execute([$image_id, $product_id]);
        
        if (!$stmt->fetch()) {
            $pdo->rollback();
            echo json_encode(['success' => false, 'error' => 'Image not found']);
            return;
        }

        // Remove primary status from all images of this product
        $stmt = $pdo->prepare("UPDATE product_images SET is_primary = 0 WHERE product_id = ?");
        $stmt->execute([$product_id]);

        // Set new primary image
        $stmt = $pdo->prepare("UPDATE product_images SET is_primary = 1 WHERE image_id = ?");
        $stmt->execute([$image_id]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Primary image updated']);

    } catch (PDOException $e) {
        $pdo->rollback();
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}
?> 