<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check for logged-in user and product ID
if (!isLoggedIn() || !isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access or missing product ID']);
    exit();
}

// Validate product ID
$product_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
if ($product_id === false || $product_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid product ID']);
    exit();
}

try {
    // Fetch product history with user names
    $stmt = $pdo->prepare("
        SELECT ph.history_id, ph.product_id, ph.action, ph.created_at, u.username AS user_name
        FROM product_history ph
        LEFT JOIN users u ON ph.user_id = u.user_id
        WHERE ph.product_id = ?
        ORDER BY ph.created_at DESC
    ");
    $stmt->execute([$product_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set JSON header and output history data
    header('Content-Type: application/json');
    echo json_encode($history);
} catch (PDOException $e) {
    // Log error and return generic message
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
    error_log("Error fetching history for product_id $product_id: " . $e->getMessage());
}
?>