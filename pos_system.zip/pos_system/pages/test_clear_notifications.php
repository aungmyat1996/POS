<?php
/**
 * Test file to debug clear notifications functionality
 */

// Start session first
session_start();

// Set headers
header('Content-Type: application/json');

echo json_encode([
    'test' => 'Clear notifications test',
    'session_id' => session_id(),
    'user_id' => $_SESSION['user_id'] ?? 'NOT SET',
    'session_data' => $_SESSION,
    'request_method' => $_SERVER['REQUEST_METHOD'],
    'current_file' => __FILE__,
    'basepath_defined' => defined('BASEPATH'),
    'timestamp' => date('Y-m-d H:i:s')
]);
?>
