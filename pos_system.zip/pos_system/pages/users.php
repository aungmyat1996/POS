<?php
// This page is DRY: navbar, calculator, notification, language/currency switcher are handled only by navbar.php/shared JS
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Get settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);

// Fetch user statistics
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'");
    $active_users = $stmt->fetchColumn();

    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'inactive'");
    $inactive_users = $stmt->fetchColumn();

    $stmt = $pdo->query("SELECT COUNT(DISTINCT role) FROM users");
    $total_roles = $stmt->fetchColumn();

    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE last_login >= NOW() - INTERVAL 24 HOUR");
    $users_today = $stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("Error fetching user statistics: " . $e->getMessage());
    $active_users = $inactive_users = $total_roles = $users_today = 0;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {
            case 'get_users':
                $stmt = $pdo->query("
                    SELECT
                        u.user_id,
                        u.username,
                        u.email,
                        u.role,
                        u.status,
                        u.last_login,
                        u.created_at,
                        COALESCE(
                            (SELECT COUNT(*) FROM orders WHERE user_id = u.user_id),
                            0
                        ) as total_orders
                    FROM users u
                    ORDER BY u.created_at DESC
                ");
                $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $users]);
                break;

            case 'add_user':
                // Validate required fields
                if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['role'])) {
                    throw new Exception('All fields are required');
                }

                // Check if username or email already exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$_POST['username'], $_POST['email']]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Username or email already exists');
                }

                // Hash password
                $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

                // Insert new user
                $stmt = $pdo->prepare("
                    INSERT INTO users (username, email, password, role, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                ");
                $stmt->execute([
                    $_POST['username'],
                    $_POST['email'],
                    $hashedPassword,
                    $_POST['role'],
                    $_POST['status'] ?? 'active'
                ]);

                echo json_encode([
                    'success' => true,
                    'message' => 'User added successfully'
                ]);
                break;

            case 'update_user':
                // Validate required fields
                if (empty($_POST['user_id']) || empty($_POST['username']) || empty($_POST['email']) || empty($_POST['role'])) {
                    throw new Exception('Required fields are missing');
                }

                // Check if username or email already exists for other users
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM users
                    WHERE (username = ? OR email = ?)
                    AND user_id != ?
                ");
                $stmt->execute([$_POST['username'], $_POST['email'], $_POST['user_id']]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Username or email already exists');
                }

                // Build update query
                $updateFields = [
                    'username = ?',
                    'email = ?',
                    'role = ?',
                    'status = ?',
                    'updated_at = NOW()'
                ];
                $params = [
                    $_POST['username'],
                    $_POST['email'],
                    $_POST['role'],
                    $_POST['status'] ?? 'active'
                ];

                // Add password update if provided
                if (!empty($_POST['password'])) {
                    $updateFields[] = 'password = ?';
                    $params[] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                }

                // Add user_id to params
                $params[] = $_POST['user_id'];

                // Update user
                $stmt = $pdo->prepare("
                    UPDATE users
                    SET " . implode(', ', $updateFields) . "
                    WHERE user_id = ?
                ");
                $stmt->execute($params);

                echo json_encode([
                    'success' => true,
                    'message' => 'User updated successfully'
                ]);
                break;

            case 'delete_user':
                // Validate user_id
                if (empty($_POST['user_id'])) {
                    throw new Exception('User ID is required');
                }

                // Check if user exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
                $stmt->execute([$_POST['user_id']]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception('User not found');
                }

                // Check if user is not the last admin
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM users
                    WHERE role = 'admin'
                    AND user_id != ?
                ");
                $stmt->execute([$_POST['user_id']]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception('Cannot delete the last admin user');
                }

                // Delete user
                $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
                $stmt->execute([$_POST['user_id']]);

                echo json_encode([
                    'success' => true,
                    'message' => 'User deleted successfully'
                ]);
                break;

            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($translations['user_management'] ?? 'User Management'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css">
    <!-- Theme preloader - must load before any content -->
    <script src="../public/js/theme-preloader.js"></script>
    <style>
        :root {
            --primary-bg: #21243A;
            --secondary-bg: #2a2d3a;
            --card-bg: #343748;
            --text-primary: #ffffff;
            --text-secondary: rgba(255,255,255,0.7);
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --card-shadow: 0 8px 25px rgba(0,0,0,0.3);
            --success-gradient: linear-gradient(135deg, #34d399 0%, #3b82f6 100%);
            --danger-gradient: linear-gradient(135deg, #f43f5e 0%, #ec4899 100%);
            --warning-gradient: linear-gradient(135deg, #f59e0b 0%, #f43f5e 100%);
            --info-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }

        body {
            background: var(--primary-bg);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }

        .users-container {
            padding: 2rem;
            min-height: 100vh;
        }

        .page-header {
            background: var(--secondary-bg);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            position: relative;
            overflow: hidden;
            max-width: 1000px;
            margin-left: auto;
            margin-right: auto;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, var(--accent-purple) 0%, var(--accent-pink) 100%);
            opacity: 0.1;
            z-index: 0;
        }

        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 3rem;
            height: 3rem;
            border-radius: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        .stat-icon.active-users {
            background: var(--success-gradient);
        }

        .stat-icon.inactive-users {
            background: var(--danger-gradient);
        }

        .stat-icon.total-roles {
            background: var(--warning-gradient);
        }

        .stat-icon.users-today {
            background: var(--info-gradient);
        }

        .stat-info h3 {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0;
        }

        .stat-info p {
            color: var(--text-secondary);
            margin: 0;
            font-size: 0.875rem;
        }

        .users-table-container {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-top: 2rem;
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255,255,255,0.1);
            max-width: 1000px;
            margin-left: auto;
            margin-right: auto;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .table-header h2 {
            color: var(--text-primary);
            font-weight: 600;
            margin: 0;
            font-size: 1.5rem;
        }

        .btn-add-user {
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-pink));
            color: white;
            border: none;
            padding: 0.6rem 1.2rem;
            border-radius: 0.5rem;
            font-weight: 600;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }

        .btn-add-user:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(139, 92, 246, 0.4);
        }

        .table {
            color: var(--text-primary);
            background: transparent;
            border-radius: 0.75rem;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table th {
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.7rem;
            padding: 0.75rem 0.5rem;
            background: rgba(255,255,255,0.08);
            border: none;
            text-align: center;
            color: var(--text-primary);
        }

        .table td {
            padding: 0.75rem 0.5rem;
            vertical-align: middle;
            border: none;
            text-align: center;
            background: rgba(255,255,255,0.02);
            color: #ffffff !important;
            font-size: 0.85rem;
        }

        .table td * {
            color: #ffffff !important;
        }

        .table .fw-bold {
            color: #ffffff !important;
            font-weight: 600;
        }

        .table .text-secondary {
            color: rgba(255,255,255,0.7) !important;
        }

        .table tbody tr {
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: rgba(255,255,255,0.05);
            transform: translateY(-1px);
        }

        .user-avatar {
            width: 2rem;
            height: 2rem;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            text-transform: uppercase;
            font-size: 0.7rem;
        }

        .user-status {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-active {
            background: rgba(16, 185, 129, 0.2);
            color: #ffffff !important;
            border: 1px solid #10b981;
        }

        .status-inactive {
            background: rgba(239, 68, 68, 0.2);
            color: #ffffff !important;
            border: 1px solid #ef4444;
        }

        .badge {
            color: #ffffff !important;
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-pink)) !important;
            border: none;
            font-weight: 600;
        }

        .btn-action {
            width: 1.5rem;
            height: 1.5rem;
            border-radius: 0.3rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.65rem;
            margin: 0 0.15rem;
        }

        .btn-edit {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }

        .btn-edit:hover {
            background: linear-gradient(135deg, #1d4ed8, #1e40af);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .btn-delete {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.3);
        }

        .btn-delete:hover {
            background: linear-gradient(135deg, #dc2626, #b91c1c);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--primary-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--accent-purple);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-pink);
        }

        /* DataTable Customization */
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            color: var(--text-primary) !important;
        }

        .dataTables_wrapper .dataTables_length label,
        .dataTables_wrapper .dataTables_filter label,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #ffffff !important;
        }

        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            background: var(--secondary-bg);
            color: var(--text-primary);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 0.5rem;
            padding: 0.5rem;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            background: var(--secondary-bg);
            color: var(--text-primary) !important;
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 0.4rem;
            margin: 0 0.15rem;
            padding: 0.4rem 0.6rem;
            font-size: 0.8rem;
            min-width: 2rem;
            height: 2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: var(--accent-purple) !important;
            color: white !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(139, 92, 246, 0.3);
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--accent-purple) !important;
            color: white !important;
            box-shadow: 0 2px 6px rgba(139, 92, 246, 0.4);
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            background: rgba(255,255,255,0.05) !important;
            color: rgba(255,255,255,0.3) !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            margin-top: 1rem;
        }

        /* Modal Customization */
        .modal-content {
            background: var(--card-bg) !important;
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 1rem;
        }

        .modal-header {
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .form-control, .form-select {
            background: var(--secondary-bg) !important;
            border: 1px solid rgba(255,255,255,0.2) !important;
            color: var(--text-primary) !important;
            border-radius: 0.5rem;
        }

        .form-control:focus, .form-select:focus {
            background: var(--secondary-bg) !important;
            border-color: var(--accent-purple) !important;
            box-shadow: 0 0 0 0.2rem rgba(139, 92, 246, 0.25) !important;
        }

        /* Enhanced Responsive Design */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 1.5rem;
            }

            .users-table-container {
                max-width: 900px;
                padding: 1.25rem;
            }

            .table-responsive {
                margin: 0 -0.5rem;
                padding: 0 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .users-container {
                padding: 0.5rem;
            }

            .page-header {
                padding: 1rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .stat-card {
                padding: 1rem;
                min-height: auto;
            }

            .stat-card h3 {
                font-size: 1.5rem;
            }

            .stat-card p {
                font-size: 0.8rem;
            }

            .users-table-container {
                max-width: 100%;
                padding: 1rem;
                margin: 1rem 0;
            }

            .table-header {
                flex-direction: column;
                align-items: stretch;
                gap: 1rem;
            }

            .btn-add-user {
                justify-content: center;
                padding: 0.75rem 1rem;
                font-size: 0.9rem;
            }

            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                margin: 0 -0.5rem;
                padding: 0 0.5rem;
            }

            .dataTables_wrapper .dataTables_filter,
            .dataTables_wrapper .dataTables_length {
                text-align: center;
                margin-bottom: 1rem;
            }

            .dataTables_wrapper .dataTables_filter input {
                width: 100% !important;
                max-width: 300px;
            }

            .dataTables_wrapper .dataTables_paginate {
                justify-content: center;
                flex-wrap: wrap;
                gap: 0.1rem;
            }

            .dataTables_wrapper .dataTables_paginate .paginate_button {
                padding: 0.3rem 0.5rem;
                font-size: 0.7rem;
                min-width: 1.8rem;
                height: 1.8rem;
            }

            .user-avatar {
                width: 35px;
                height: 35px;
                font-size: 0.7rem;
            }

            .btn-action {
                padding: 0.3rem 0.5rem;
                font-size: 0.7rem;
            }

            .badge {
                font-size: 0.6rem;
                padding: 0.2rem 0.4rem;
            }
        }

        @media (max-width: 480px) {
            .page-header h1 {
                font-size: 1.5rem;
            }

            .page-header p {
                font-size: 0.8rem;
            }

            .stats-grid {
                gap: 0.75rem;
            }

            .stat-card {
                padding: 0.75rem;
            }

            .stat-card h3 {
                font-size: 1.25rem;
            }

            .table-responsive {
                font-size: 0.8rem;
            }

            .dataTables_wrapper .dataTables_length select {
                font-size: 0.8rem;
            }

            .dataTables_wrapper .dataTables_info {
                font-size: 0.7rem;
                text-align: center;
            }

            .user-avatar {
                width: 30px;
                height: 30px;
                font-size: 0.6rem;
            }

            .btn-action {
                padding: 0.25rem 0.4rem;
                font-size: 0.65rem;
            }
        }

        /* Table Responsive Enhancements */
        @media (max-width: 768px) {
            #usersTable {
                font-size: 0.85rem;
            }

            #usersTable th,
            #usersTable td {
                padding: 0.5rem 0.25rem;
                vertical-align: middle;
            }

            #usersTable .d-flex {
                flex-direction: column;
                align-items: center !important;
                gap: 0.25rem;
            }

            #usersTable .user-avatar {
                margin-bottom: 0.25rem;
            }
        }

        /* Light Mode H1 and Headers Text Colors for Users Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="users-container">
            <!-- Page Header -->
            <div class="page-header" data-aos="fade-down">
                <h1>
                    <i class="fas fa-users"></i>
                    <span data-translate="user_management">
                        <?php echo htmlspecialchars($translations['user_management'] ?? 'User Management'); ?>
                    </span>
                </h1>
                <p class="text-secondary" data-translate="user_management_desc">
                    <?php echo htmlspecialchars($translations['user_management_desc'] ?? 'Manage system users, roles, and permissions'); ?>
                </p>

                <!-- Statistics Grid -->
                <div class="stats-grid">
                    <!-- Active Users -->
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="stat-icon active-users">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-info">
                            <h3 data-stat-number="<?php echo $active_users; ?>"><?php echo number_format($active_users); ?></h3>
                            <p data-translate="active_users">
                                <?php echo htmlspecialchars($translations['active_users'] ?? 'Active Users'); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Inactive Users -->
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="stat-icon inactive-users">
                            <i class="fas fa-user-times"></i>
                        </div>
                        <div class="stat-info">
                            <h3 data-stat-number="<?php echo $inactive_users; ?>"><?php echo number_format($inactive_users); ?></h3>
                            <p data-translate="inactive_users">
                                <?php echo htmlspecialchars($translations['inactive_users'] ?? 'Inactive Users'); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Total Roles -->
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="stat-icon total-roles">
                            <i class="fas fa-user-tag"></i>
                        </div>
                        <div class="stat-info">
                            <h3 data-stat-number="<?php echo $total_roles; ?>"><?php echo number_format($total_roles); ?></h3>
                            <p data-translate="total_roles">
                                <?php echo htmlspecialchars($translations['total_roles'] ?? 'Total Roles'); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Users Today -->
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="400">
                        <div class="stat-icon users-today">
                            <i class="fas fa-user-clock"></i>
                        </div>
                        <div class="stat-info">
                            <h3 data-stat-number="<?php echo $users_today; ?>"><?php echo number_format($users_today); ?></h3>
                            <p data-translate="users_today">
                                <?php echo htmlspecialchars($translations['users_today'] ?? 'Active Today'); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Users Table Section -->
            <div class="users-table-container" data-aos="fade-up">
                <div class="table-header">
                    <h2 data-translate="user_list">
                        <?php echo htmlspecialchars($translations['user_list'] ?? 'User List'); ?>
                    </h2>
                    <button class="btn-add-user" onclick="showAddUserModal()">
                        <i class="fas fa-plus"></i>
                        <span data-translate="add_user">
                            <?php echo htmlspecialchars($translations['add_user'] ?? 'Add User'); ?>
                        </span>
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table" id="usersTable">
                        <thead>
                            <tr>
                                <th data-translate="user">
                                    <?php echo htmlspecialchars($translations['user'] ?? 'User'); ?>
                                </th>
                                <th data-translate="email">
                                    <?php echo htmlspecialchars($translations['email'] ?? 'Email'); ?>
                                </th>
                                <th data-translate="role">
                                    <?php echo htmlspecialchars($translations['role'] ?? 'Role'); ?>
                                </th>
                                <th data-translate="status">
                                    <?php echo htmlspecialchars($translations['status'] ?? 'Status'); ?>
                                </th>
                                <th data-translate="last_login">
                                    <?php echo htmlspecialchars($translations['last_login'] ?? 'Last Login'); ?>
                                </th>
                                <th data-translate="actions">
                                    <?php echo htmlspecialchars($translations['actions'] ?? 'Actions'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Users will be loaded here dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal fade" id="userModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark text-light">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title" id="userModalTitle">Add User</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <input type="hidden" id="userId">
                        <div class="mb-3">
                            <label class="form-label" data-translate="username">
                                <?php echo htmlspecialchars($translations['username'] ?? 'Username'); ?>
                            </label>
                            <input type="text" class="form-control bg-secondary text-light" id="username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" data-translate="email">
                                <?php echo htmlspecialchars($translations['email'] ?? 'Email'); ?>
                            </label>
                            <input type="email" class="form-control bg-secondary text-light" id="email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" data-translate="password">
                                <?php echo htmlspecialchars($translations['password'] ?? 'Password'); ?>
                            </label>
                            <input type="password" class="form-control bg-secondary text-light" id="password">
                            <small class="text-muted" id="passwordHelp">Leave blank to keep current password</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" data-translate="role">
                                <?php echo htmlspecialchars($translations['role'] ?? 'Role'); ?>
                            </label>
                            <select class="form-select bg-secondary text-light" id="role" required>
                                <option value="admin" data-translate-option="admin">Admin</option>
                                <option value="manager" data-translate-option="manager">Manager</option>
                                <option value="staff" data-translate-option="staff">Staff</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" data-translate="status">
                                <?php echo htmlspecialchars($translations['status'] ?? 'Status'); ?>
                            </label>
                            <select class="form-select bg-secondary text-light" id="status" required>
                                <option value="active" data-translate-option="active">Active</option>
                                <option value="inactive" data-translate-option="inactive">Inactive</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="cancel">
                        <?php echo htmlspecialchars($translations['cancel'] ?? 'Cancel'); ?>
                    </button>
                    <button type="button" class="btn btn-primary" onclick="saveUser()" data-translate="save">
                        <?php echo htmlspecialchars($translations['save'] ?? 'Save'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true
        });

        let usersTable;
        const translations = <?php echo json_encode($translations); ?>;
        let currentLanguage = '<?php echo $language; ?>';

        // Function to get current language settings for DataTable
        function getCurrentLanguage() {
            return currentLanguage === 'mm' ? {
                search: translations.dt_search || "ရှာဖွေရန်:",
                lengthMenu: translations.dt_length_menu || "စာမျက်နှာတစ်ခုတွင် _MENU_ ခု ပြရန်",
                info: translations.dt_info || "စုစုပေါင်း _TOTAL_ ခုမှ _START_ မှ _END_ အထိ ပြသနေသည်",
                infoEmpty: translations.dt_info_empty || "ဒေတာမရှိပါ",
                infoFiltered: translations.dt_info_filtered || "(စုစုပေါင်း _MAX_ ခုမှ စစ်ထုတ်ထားသည်)",
                paginate: {
                    first: translations.dt_first || "ပထမ",
                    last: translations.dt_last || "နောက်ဆုံး",
                    next: translations.dt_next || "နောက်",
                    previous: translations.dt_previous || "ရှေ့"
                },
                emptyTable: translations.dt_empty_table || "ဇယားတွင် ဒေတာမရှိပါ",
                zeroRecords: translations.dt_zero_records || "ကိုက်ညီသော မှတ်တမ်းများ မတွေ့ရှိပါ"
            } : {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries per page",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                infoEmpty: "No data available",
                infoFiltered: "(filtered from _MAX_ total entries)",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                },
                emptyTable: "No data available in table",
                zeroRecords: "No matching records found"
            };
        }

        // Helper functions for table data translation
        function getRoleText(role) {
            if (currentLanguage === 'mm') {
                switch(role) {
                    case 'admin': return 'စီမံခန့်ခွဲသူ';
                    case 'manager': return 'မန်နေဂျာ';
                    case 'staff': return 'ဝန်ထမ်း';
                    default: return role || 'မသိ';
                }
            }
            return role || 'N/A';
        }

        function getStatusText(status) {
            if (currentLanguage === 'mm') {
                switch(status) {
                    case 'active': return 'အသုံးပြုနေသည်';
                    case 'inactive': return 'အသုံးမပြုပါ';
                    default: return status || 'မသိ';
                }
            }
            return status || 'N/A';
        }

        function getNeverText() {
            return currentLanguage === 'mm' ? 'မရှိပါ' : 'Never';
        }

        function getOrdersText() {
            return currentLanguage === 'mm' ? 'အော်ဒါများ' : 'orders';
        }

        // Function to update stats cards
        function updateStatsCards(translations) {
            const statsMappings = {
                'user_management': translations.user_management || 'User Management',
                'user_management_desc': translations.user_management_desc || 'Manage system users, roles, and permissions',
                'active_users': translations.active_users || 'Active Users',
                'inactive_users': translations.inactive_users || 'Inactive Users',
                'total_roles': translations.total_roles || 'Total Roles',
                'users_today': translations.users_today || 'Active Today',
                'user_list': translations.user_list || 'User List',
                'add_user': translations.add_user || 'Add User'
            };

            // Update all elements with data-translate attributes
            $('[data-translate]').each(function() {
                const key = $(this).data('translate');
                if (statsMappings[key]) {
                    $(this).text(statsMappings[key]);
                }
            });

            // Keep numbers in English format always
            $('[data-stat-number]').each(function() {
                const number = $(this).data('stat-number');
                const formattedNumber = number.toLocaleString();
                $(this).text(formattedNumber);
            });
        }

        // Function to update form labels
        function updateFormLabels(translations) {
            const labelMappings = {
                'username': translations.username || 'Username',
                'email': translations.email || 'Email',
                'password': translations.password || 'Password',
                'role': translations.role || 'Role',
                'status': translations.status || 'Status',
                'cancel': translations.cancel || 'Cancel',
                'save': translations.save || 'Save'
            };

            // Update form labels
            $('[data-translate]').each(function() {
                const key = $(this).data('translate');
                if (labelMappings[key]) {
                    $(this).text(labelMappings[key]);
                }
            });
        }

        // Function to update dropdown options
        function updateDropdownOptions() {
            const roleOptions = {
                'admin': currentLanguage === 'mm' ? 'စီမံခန့်ခွဲသူ' : 'Admin',
                'manager': currentLanguage === 'mm' ? 'မန်နေဂျာ' : 'Manager',
                'staff': currentLanguage === 'mm' ? 'ဝန်ထမ်း' : 'Staff'
            };

            const statusOptions = {
                'active': currentLanguage === 'mm' ? 'အသုံးပြုနေသည်' : 'Active',
                'inactive': currentLanguage === 'mm' ? 'အသုံးမပြုပါ' : 'Inactive'
            };

            // Update role dropdown options
            $('#role option').each(function() {
                const value = $(this).val();
                if (roleOptions[value]) {
                    $(this).text(roleOptions[value]);
                }
            });

            // Update status dropdown options
            $('#status option').each(function() {
                const value = $(this).val();
                if (statusOptions[value]) {
                    $(this).text(statusOptions[value]);
                }
            });
        }

        // Function to update pagination info
        function updatePaginationInfo() {
            // DataTable will handle this automatically with getCurrentLanguage() function
            // No manual text replacement needed anymore
        }

        // Function to update table headers
        function updateTableHeaders(newTranslations) {
            const headerMappings = {
                'USER': currentLanguage === 'mm' ? 'အသုံးပြုသူ' : 'USER',
                'EMAIL': currentLanguage === 'mm' ? 'အီးမေးလ်' : 'EMAIL',
                'ROLE': currentLanguage === 'mm' ? 'ရာထူး' : 'ROLE',
                'STATUS': currentLanguage === 'mm' ? 'အခြေအနေ' : 'STATUS',
                'LAST LOGIN': currentLanguage === 'mm' ? 'နောက်ဆုံးဝင်ရောက်မှု' : 'LAST LOGIN',
                'ACTIONS': currentLanguage === 'mm' ? 'လုပ်ဆောင်ချက်များ' : 'ACTIONS'
            };

            // Update table headers
            $('#usersTable thead th').each(function(index) {
                const currentText = $(this).text().trim();
                const headerKeys = Object.keys(headerMappings);

                // Find matching header and update
                for (let key of headerKeys) {
                    if (currentText.includes(key) ||
                        currentText.includes(headerMappings[key]) ||
                        index === 0 && key === 'USER' ||
                        index === 1 && key === 'EMAIL' ||
                        index === 2 && key === 'ROLE' ||
                        index === 3 && key === 'STATUS' ||
                        index === 4 && key === 'LAST LOGIN' ||
                        index === 5 && key === 'ACTIONS') {
                        $(this).text(headerMappings[key]);
                        break;
                    }
                }
            });
        }

        // Function to initialize users table
        function initializeUsersTable() {
            usersTable = $('#usersTable').DataTable({
                ajax: {
                    url: 'users.php',
                    type: 'POST',
                    data: { action: 'get_users' },
                    dataSrc: function(json) {
                        console.log('Received data:', json);
                        return json.data || [];
                    }
                },
                pageLength: 10,
                responsive: true,
                language: getCurrentLanguage(),
                columns: [
                    {
                        data: null,
                        render: function(data) {
                            console.log('Rendering user row:', data);
                            const initials = data.username ? data.username.substring(0, 2).toUpperCase() : 'NA';
                            return `
                                <div class="d-flex align-items-center gap-3">
                                    <div class="user-avatar">${initials}</div>
                                    <div>
                                        <div class="fw-bold">${data.username || ''}</div>
                                        <small class="text-secondary">${data.total_orders || 0} ${getOrdersText()}</small>
                                    </div>
                                </div>
                            `;
                        }
                    },
                    { data: 'email' },
                    {
                        data: 'role',
                        render: function(data) {
                            const roleText = getRoleText(data);
                            return `<span class="badge bg-primary">${roleText}</span>`;
                        }
                    },
                    {
                        data: 'status',
                        render: function(data) {
                            const statusClass = data === 'active' ? 'status-active' : 'status-inactive';
                            const statusText = getStatusText(data);
                            return `<span class="user-status ${statusClass}">${statusText}</span>`;
                        }
                    },
                    {
                        data: 'last_login',
                        render: function(data) {
                            const neverText = getNeverText();
                            return data ? new Date(data).toLocaleString() : neverText;
                        }
                    },
                    {
                        data: null,
                        render: function(data) {
                            return `
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn-action btn-edit" data-id="${data.user_id}">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn-action btn-delete" data-id="${data.user_id}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            `;
                        }
                    }
                ],
                order: [[4, 'desc']],
                drawCallback: function() {
                    // Attach event handlers after table redraw
                    attachActionHandlers();
                }
            });

            // Attach event handlers for edit and delete buttons
            function attachActionHandlers() {
                // Edit button handler
                $('.btn-edit').off('click').on('click', function() {
                    const userId = $(this).data('id');
                    console.log('Edit clicked for user:', userId);
                    editUser(userId);
                });

                // Delete button handler
                $('.btn-delete').off('click').on('click', function() {
                    const userId = $(this).data('id');
                    console.log('Delete clicked for user:', userId);
                    deleteUser(userId);
                });
            }

            // Add Enter key support for forms
            $('#userForm').on('keypress', function(e) {
                if (e.which === 13) { // Enter key
                    e.preventDefault();
                    saveUser();
                }
            });

            // Update pagination info on table draw
            usersTable.on('draw', function() {
                updatePaginationInfo();
            });

            // Add Enter key support for search
            $('.dataTables_filter input').on('keypress', function(e) {
                if (e.which === 13) { // Enter key
                    e.preventDefault();
                    usersTable.search($(this).val()).draw();
                }
            });
        }

        $(document).ready(function() {
            // Apply theme from localStorage
            console.log('🎨 Users: Applying theme from localStorage...');
            const currentTheme = localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Users: Current theme:', currentTheme);

            // Apply theme attributes immediately
            document.documentElement.setAttribute('data-theme', currentTheme);
            document.body.setAttribute('data-theme', currentTheme);

            console.log('🎨 Users: Theme applied successfully');

            // Initialize DataTable
            initializeUsersTable();

            // Initialize stats cards with current language
            updateStatsCards(translations);

            // Initialize dropdown options with current language
            updateDropdownOptions();

            // Initialize pagination info with current language
            updatePaginationInfo();

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 Users: Notification bell visibility updated');
            }
        });

        function showAddUserModal() {
            $('#userId').val('');
            $('#userForm')[0].reset();
            $('#passwordHelp').hide();
            $('#userModalTitle').text(translations.add_user || 'Add User');
            $('#userModal').modal('show');
        }

        function editUser(userId) {
            console.log('Editing user:', userId);
            const data = usersTable.data();
            console.log('All users data:', data);

            // Find user in the DataTable data
            let user = null;
            data.each(function(item) {
                if (item.user_id == userId) {
                    user = item;
                    return false; // Break the loop
                }
            });

            console.log('Found user:', user);

            if (user) {
                // Populate form fields
                $('#userId').val(user.user_id);
                $('#username').val(user.username);
                $('#email').val(user.email);
                $('#role').val(user.role);
                $('#status').val(user.status);
                $('#password').val('');
                $('#passwordHelp').show();

                // Update modal title and show
                $('#userModalTitle').text(translations.edit_user || 'Edit User');
                $('#userModal').modal('show');
            } else {
                showErrorMessage('User not found');
            }
        }

        function saveUser() {
            const userData = {
                action: $('#userId').val() ? 'update_user' : 'add_user',
                user_id: $('#userId').val(),
                username: $('#username').val(),
                email: $('#email').val(),
                password: $('#password').val(),
                role: $('#role').val(),
                status: $('#status').val()
            };

            console.log('Saving user data:', userData);

            // Show loading state
            const saveBtn = $('#userModal .btn-primary');
            const originalText = saveBtn.html();
            saveBtn.html('<i class="fas fa-spinner fa-spin"></i> Saving...');
            saveBtn.prop('disabled', true);

            $.ajax({
                url: 'users.php',
                type: 'POST',
                data: userData,
                success: function(response) {
                    console.log('Save response:', response);
                    if (response.success) {
                        $('#userModal').modal('hide');
                        showSuccessMessage(response.message);
                        usersTable.ajax.reload();
                    } else {
                        showErrorMessage(response.message || 'Failed to save user');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    // Reset button state
                    saveBtn.html(originalText);
                    saveBtn.prop('disabled', false);
                }
            });
        }

        function deleteUser(userId) {
            Swal.fire({
                title: translations.confirm_delete || 'Confirm Delete',
                text: translations.delete_user_confirm || 'Are you sure you want to delete this user?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#3b82f6',
                confirmButtonText: translations.yes_delete || 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'users.php',
                        type: 'POST',
                        data: {
                            action: 'delete_user',
                            user_id: userId
                        },
                        success: function(response) {
                            if (response.success) {
                                showSuccessMessage(response.message);
                                usersTable.ajax.reload();
                            }
                        },
                        error: handleAjaxError
                    });
                }
            });
        }

        function showErrorMessage(message) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: message
            });
        }

        function showSuccessMessage(message) {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: message,
                timer: 2000,
                showConfirmButton: false
            });
        }

        function handleAjaxError(xhr, status, error) {
            let errorMessage = 'An error occurred';
            try {
                const response = JSON.parse(xhr.responseText);
                errorMessage = response.message || errorMessage;
            } catch (e) {
                console.error('Error parsing error response:', e);
            }

            showErrorMessage(errorMessage);
        }

        // Language switching support - prevent page refresh
        window.updatePageForNewLanguage = function(lang, newTranslations) {
            console.log('🌐 Updating users page language to:', lang);

            try {
                // Update current language
                currentLanguage = lang;

                // Update page translations
                Object.assign(translations, newTranslations);

                // Update static text elements
                $('[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    if (newTranslations[key]) {
                        $(this).text(newTranslations[key]);
                    }
                });

                // Update stats cards and page elements
                updateStatsCards(newTranslations);

                // Update table headers specifically
                updateTableHeaders(newTranslations);

                // Update modal elements
                $('#userModalTitle').text(newTranslations.add_user || 'Add User');
                $('#passwordHelp').text(newTranslations.password_help || 'Leave blank to keep current password');

                // Update Add User button text
                $('.btn-add-user span').text(newTranslations.add_user || 'Add User');

                // Update form labels
                updateFormLabels(newTranslations);

                // Update dropdown options
                updateDropdownOptions();

                // Reinitialize DataTable with new language settings
                if (usersTable) {
                    const dtLanguage = getCurrentLanguage();
                    usersTable.destroy();
                    initializeUsersTable();
                }

                // Get new language settings
                const dtLanguage = getCurrentLanguage();

                // Update DataTable language settings dynamically
                if (usersTable && usersTable.settings) {
                    const settings = usersTable.settings()[0];
                    if (settings && settings.oLanguage) {
                        // Update all language properties
                        Object.assign(settings.oLanguage, dtLanguage);

                        // Update search placeholder and label
                        $('.dataTables_filter input').attr('placeholder', dtLanguage.search);
                        $('.dataTables_filter label').contents().filter(function() {
                            return this.nodeType === 3; // Text nodes only
                        }).first().replaceWith(dtLanguage.search + ' ');

                        // Update length menu label
                        $('.dataTables_length label').html(
                            dtLanguage.lengthMenu.replace('_MENU_',
                                $('.dataTables_length select')[0].outerHTML
                            )
                        );

                        // Force redraw to apply all changes and refresh table data
                        usersTable.ajax.reload(null, false);

                        // Update pagination buttons text with more reliable method
                        setTimeout(() => {
                            $('.paginate_button.first').each(function() {
                                if ($(this).text().trim() !== '') {
                                    $(this).text(dtLanguage.paginate.first);
                                }
                            });
                            $('.paginate_button.last').each(function() {
                                if ($(this).text().trim() !== '') {
                                    $(this).text(dtLanguage.paginate.last);
                                }
                            });
                            $('.paginate_button.next').each(function() {
                                if ($(this).text().trim() !== '') {
                                    $(this).text(dtLanguage.paginate.next);
                                }
                            });
                            $('.paginate_button.previous').each(function() {
                                if ($(this).text().trim() !== '') {
                                    $(this).text(dtLanguage.paginate.previous);
                                }
                            });

                            // Update info text
                            $('.dataTables_info').each(function() {
                                const text = $(this).text();
                                if (text.includes('Showing') || text.includes('စုစုပေါင်း')) {
                                    // Force info update by triggering draw
                                    usersTable.draw(false);
                                }
                            });
                        }, 300);
                    }
                }

                console.log('🌐 Users page language updated successfully without refresh');
                return true; // Indicate successful update

            } catch (error) {
                console.error('🌐 Error updating users page language:', error);
                return false; // Indicate failure, will trigger page refresh
            }
        };
    </script>

    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>