<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'User not logged in'
    ]);
    exit;
}

// Check if request is POST and contains JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Validate cart data
    if (isset($data['cart']) && is_array($data['cart'])) {
        // Update stock quantities if needed
        $currentCart = $_SESSION['cart'] ?? [];
        
        // Handle stock update logic
        foreach ($data['cart'] as $productId => $quantity) {
            $oldQuantity = isset($currentCart[$productId]) ? $currentCart[$productId] : 0;
            $quantityDiff = $quantity - $oldQuantity;
            
            if ($quantityDiff != 0) {
                // If quantity increased, decrease stock; if decreased, increase stock
                $stmt = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?");
                $stmt->execute([$quantityDiff, $productId]);
            }
        }
        
        // Update session cart
        $_SESSION['cart'] = $data['cart'];
        
        // Calculate cart count and total
        $cartCount = 0;
        $cartTotal = 0;
        
        if (!empty($_SESSION['cart'])) {
            $placeholders = implode(',', array_fill(0, count(array_keys($_SESSION['cart'])), '?'));
            $stmt = $pdo->prepare("SELECT product_id, price, discount FROM products WHERE product_id IN ($placeholders)");
            $stmt->execute(array_keys($_SESSION['cart']));
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($products as $product) {
                $quantity = $_SESSION['cart'][$product['product_id']];
                $price = $product['price'];
                $discount = $product['discount'] ?? 0;
                $itemTotal = $price * $quantity * (1 - ($discount / 100));
                
                $cartCount += $quantity;
                $cartTotal += $itemTotal;
            }
        }
        
        // Return success response with updated data
        echo json_encode([
            'success' => true,
            'message' => 'Cart updated successfully',
            'cart_count' => $cartCount,
            'cart_total' => number_format($cartTotal, 2)
        ]);
        exit;
    }
}

// If we get here, something went wrong
echo json_encode([
    'success' => false,
    'message' => 'Invalid request'
]);
exit;
?> 