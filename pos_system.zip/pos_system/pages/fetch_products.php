<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    define('BASEPATH', dirname(__DIR__) . '/');
    require_once BASEPATH . 'includes/security_check.php';
    require_once BASEPATH . 'config/db.php';
    require_once BASEPATH . 'includes/functions.php';

    // Require authentication for this page
    requireAuth();

    // Currency handling
    $exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
    $currency_symbols = [
        'USD' => '$',
        'THB' => '฿',
        'MMK' => 'Ks'
    ];
    $currency = $_SESSION['currency'] ?? 'USD';

    // Fetch cart from session
    $cart = $_SESSION['cart'] ?? [];

    // Fetch products with search and category filter
    $search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
    $category = isset($_GET['category']) ? trim($_GET['category']) : '';

    $where_clauses = [];
    $params = [];

    if (!empty($category) && $category !== 'All Categories') {
        $where_clauses[] = "c.category_name = ?";
        $params[] = $category;
    }

    if (!empty($search_query)) {
        if (is_numeric($search_query)) {
            // Search by ID
            $where_clauses[] = "p.product_id = ?";
            $params[] = $search_query;
        } else {
            // Search by Name
            $where_clauses[] = "p.product_name LIKE ?";
            $params[] = "%$search_query%";
        }
    }

    $where_clause = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";

    // Basic query to get products
    $query = "SELECT p.*, c.category_name,
                     CAST(p.unit_price AS DECIMAL(10,2)) as price,
                     CAST(COALESCE(p.discount, 0) AS DECIMAL(10,2)) as discount_percent,
                     (
                         SELECT COUNT(oi.order_item_id) 
                         FROM order_items oi 
                         WHERE oi.product_id = p.product_id
                     ) as total_sold
              FROM products p 
              LEFT JOIN categories c ON p.category_id = c.category_id
              $where_clause";

    $stmt = $pdo->prepare($query);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . print_r($pdo->errorInfo(), true));
    }

    $success = $stmt->execute($params);
    if (!$success) {
        throw new Exception("Failed to execute statement: " . print_r($stmt->errorInfo(), true));
    }

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($products === false) {
        throw new Exception("Failed to fetch results: " . print_r($stmt->errorInfo(), true));
    }

    if (empty($products)) {
        echo '<p data-translate="no_products_found">' . htmlspecialchars('No products found.') . '</p>';
    } else {
        foreach ($products as $product) {
            $product_id = $product['product_id'];
            $stock_quantity = $product['stock_quantity'] ?? 0;
            $discount = $product['discount_percent'] ?? 0;
            $price = $product['price'] ?? 0;

            // Get quantity from session cart
            $cart_quantity = isset($cart[$product_id]) ? $cart[$product_id] : 0;

            // Convert price to selected currency
            $price_in_currency = $price * $exchange_rates[$currency];
            $final_price = $price_in_currency * (1 - ($discount / 100));
            $formatted_price = $currency_symbols[$currency] . ' ' . number_format($final_price, 2);

            $stock_class = $stock_quantity > 0 ? 'in-stock' : 'out-of-stock';
            $stock_icon = $stock_quantity > 0 ? 'check-circle' : 'times-circle';
            $stock_text = $stock_quantity > 0 ? 'In Stock' : 'Out of Stock';
            $disabled = $stock_quantity <= 0 ? 'disabled' : '';

            $output = '<div class="product-card">';
            
            // Product Image
            $output .= '<div class="product-image">';
            $output .= '<img src="' . htmlspecialchars($product['image'] ?? '../public/images/default-product.jpg') . '" alt="' . htmlspecialchars($product['product_name']) . '">';
            $output .= '</div>';
            
            // Product Info
            $output .= '<div class="product-info">';
            $output .= '<h5>' . htmlspecialchars($product['product_name']) . '</h5>';

            // Price and Discount Section
            $output .= '<div class="price-section">';
            if ($discount > 0) {
                $original_price_formatted = $currency_symbols[$currency] . ' ' . number_format($price_in_currency, 2);
                $output .= '<div class="original-price">' . $original_price_formatted . '</div>';
                $output .= '<div class="final-price">' . $formatted_price . '</div>';
                $output .= '<span class="discount-badge">-' . $discount . '%</span>';
            } else {
                $output .= '<div class="price">' . $formatted_price . '</div>';
            }
            $output .= '</div>';

            // Stock Information
            $output .= '<div class="stock-info">';
            $output .= '<div class="stock-status ' . $stock_class . '" id="stock-status-' . $product_id . '">';
            $output .= '<i class="fas fa-' . $stock_icon . '"></i> ';
            $output .= '<span class="status-text">' . $stock_text . '</span>';
            $output .= '</div>';
            $output .= '<div class="stock-quantity" id="stock-count-' . $product_id . '">Stock: <span class="stock-number">' . $stock_quantity . '</span></div>';
            $output .= '<div class="sold-count" id="sold-count-' . $product_id . '">Sold: <span class="sold-number">' . $product['total_sold'] . '</span></div>';
            $output .= '</div>';

            // Action Buttons
            $output .= '<div class="action-buttons-container">';
            
            // Details Button
            $output .= '<button class="btn-action details-btn" ';
            $output .= 'data-product-id="' . $product_id . '" ';
            $output .= 'data-bs-toggle="tooltip" ';
            $output .= 'data-bs-placement="top" ';
            $output .= 'title="View Details">';
            $output .= '<i class="fas fa-info-circle"></i>';
            $output .= '</button>';

            // Add to Cart Button
            $output .= '<button class="btn-action add-to-cart ' . $disabled . '" ';
            $output .= 'id="add-to-cart-' . $product_id . '" ';
            $output .= 'data-product-id="' . $product_id . '" ';
            $output .= 'data-action="add" ';
            $output .= 'data-stock="' . $stock_quantity . '" ';
            $output .= 'data-bs-toggle="tooltip" ';
            $output .= 'data-bs-placement="top" ';
            $output .= 'title="Add to Cart">';
            $output .= '<i class="fas fa-cart-plus"></i>';
            $output .= '</button>';

            $output .= '</div>'; // End action-buttons-container

            $output .= '</div>'; // End product-info
            $output .= '</div>'; // End product-card

            echo $output;
        }
    }
} catch (Exception $e) {
    error_log("Error in fetch_products.php: " . $e->getMessage());
    echo '<div class="alert alert-danger">';
    echo '<strong>Error loading products:</strong><br>';
    echo htmlspecialchars($e->getMessage());
    echo '</div>';
}
?>