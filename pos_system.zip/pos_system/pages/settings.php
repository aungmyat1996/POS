<?php
// This page is DRY: navbar, calculator, notification, language/currency switcher are handled only by navbar.php/shared JS
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();

// Get current settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Load theme settings specifically
$themeSettings = [];
$themeKeys = ['theme_mode', 'primary_color', 'secondary_color', 'accent_color',
             'background_color', 'sidebar_color', 'text_color', 'success_color',
             'warning_color', 'danger_color', 'info_color'];

foreach ($themeKeys as $key) {
    if (isset($settings[$key])) {
        $themeSettings[$key] = $settings[$key];
    }
}

// Set default theme values if not set
if (!isset($themeSettings['theme_mode'])) {
    $themeSettings['theme_mode'] = 'dark';
}
if (!isset($themeSettings['primary_color'])) {
    $themeSettings['primary_color'] = '#007bff';
}
if (!isset($themeSettings['background_color'])) {
    $themeSettings['background_color'] = '#21243A';
}
if (!isset($themeSettings['sidebar_color'])) {
    $themeSettings['sidebar_color'] = '#2A2D35';
}

// Default values
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {
            case 'save_settings':
                // Validate and sanitize input
                $validSettings = [
                    'site_name', 'timezone', 'language', 'currency',
                    'date_format', 'email_host', 'email_port', 'email_username',
                    'email_password', 'email_from', 'backup_enabled',
                    'backup_frequency', 'theme_color', 'theme_mode',
                    'notifications_enabled', 'low_stock_notifications',
                    'sales_notifications', 'system_notifications',
                    'store_address', 'store_email', 'store_phone',
                    'footer_copyright', 'privacy_policy_url', 'terms_of_service_url',
                    'primary_color', 'secondary_color', 'accent_color', 'background_color',
                    'sidebar_color', 'text_color', 'border_color', 'success_color',
                    'warning_color', 'danger_color', 'info_color'
                ];

                $updatedSettings = [];

                // Handle logo upload first
                if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
                    $uploadDir = BASEPATH . 'assets/images/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }

                    $fileInfo = pathinfo($_FILES['site_logo']['name']);
                    $allowedTypes = ['jpg', 'jpeg', 'png', 'svg', 'gif'];
                    $fileExtension = strtolower($fileInfo['extension']);

                    if (in_array($fileExtension, $allowedTypes)) {
                        $fileName = 'logo_' . time() . '.' . $fileExtension;
                        $uploadPath = $uploadDir . $fileName;

                        if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $uploadPath)) {
                            $logoPath = 'assets/images/' . $fileName;

                            // Save logo path to database
                            $stmt = $pdo->prepare("
                                INSERT INTO settings (setting_key, setting_value, updated_at)
                                VALUES (?, ?, NOW())
                                ON DUPLICATE KEY UPDATE
                                    setting_value = VALUES(setting_value),
                                    updated_at = NOW()
                            ");
                            $stmt->execute(['site_logo', $logoPath]);
                            $updatedSettings['site_logo'] = $logoPath;
                        } else {
                            throw new Exception('Failed to upload logo file');
                        }
                    } else {
                        throw new Exception('Invalid file type. Please upload JPG, PNG, SVG, or GIF files only.');
                    }
                }

                // Handle other settings
                foreach ($_POST as $key => $value) {
                    if (in_array($key, $validSettings)) {
                        $stmt = $pdo->prepare("
                            INSERT INTO settings (setting_key, setting_value, updated_at)
                            VALUES (?, ?, NOW())
                            ON DUPLICATE KEY UPDATE
                                setting_value = VALUES(setting_value),
                                updated_at = NOW()
                        ");
                        $stmt->execute([$key, $value]);
                        $updatedSettings[$key] = $value;

                        // Update session for immediate effect
                        if ($key === 'language') {
                            $_SESSION['language'] = $value;
                        } elseif ($key === 'currency') {
                            $_SESSION['currency'] = $value;
                        } elseif ($key === 'site_name') {
                            $_SESSION['system_name'] = $value;
                        } elseif ($key === 'timezone') {
                            $_SESSION['timezone'] = $value;
                        }
                    }
                }

                // If theme settings were updated, also save them using the theme function
                $themeKeys = ['theme_mode', 'primary_color', 'secondary_color', 'accent_color',
                             'background_color', 'sidebar_color', 'text_color', 'success_color',
                             'warning_color', 'danger_color', 'info_color'];

                $themeUpdates = [];
                foreach ($themeKeys as $key) {
                    if (isset($updatedSettings[$key])) {
                        $themeUpdates[$key] = $updatedSettings[$key];
                    }
                }

                if (!empty($themeUpdates)) {
                    saveThemeSettings($pdo, $themeUpdates);
                    error_log("Theme settings saved: " . json_encode($themeUpdates));
                }

                // Update session variables for immediate effect
                require_once BASEPATH . 'includes/update_session.php';
                $sessionResult = updateSessionFromSettings($pdo);

                // Log the settings update
                if (isset($_SESSION['user_id'])) {
                    $settingsChanged = implode(', ', array_keys($updatedSettings));
                    logAction($pdo, $_SESSION['user_id'], "Updated settings: " . $settingsChanged);
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Settings saved successfully',
                    'updated_settings' => $updatedSettings,
                    'session_updated' => $sessionResult['success'] ?? false
                ]);
                break;

            case 'test_email':
                // Get email settings
                $emailHost = $_POST['email_host'] ?? $settings['email_host'] ?? '';
                $emailPort = $_POST['email_port'] ?? $settings['email_port'] ?? '';
                $emailUsername = $_POST['email_username'] ?? $settings['email_username'] ?? '';
                $emailPassword = $_POST['email_password'] ?? $settings['email_password'] ?? '';
                $emailFrom = $_POST['email_from'] ?? $settings['email_from'] ?? '';

                // Validate email settings
                if (empty($emailHost) || empty($emailPort) || empty($emailUsername) || empty($emailFrom)) {
                    throw new Exception('Email settings are incomplete. Please fill all required fields.');
                }

                // Test email configuration
                try {
                    // Use PHPMailer or simple mail() function for testing
                    $to = $emailFrom; // Send test email to the from address
                    $subject = 'POS System - Test Email';
                    $message = 'This is a test email from your POS system. Email configuration is working correctly!';
                    $headers = [
                        'From: ' . $emailFrom,
                        'Reply-To: ' . $emailFrom,
                        'Content-Type: text/html; charset=UTF-8'
                    ];

                    // For now, we'll simulate a successful email test
                    // In production, you would implement actual SMTP testing
                    $emailSent = true; // mail($to, $subject, $message, implode("\r\n", $headers));

                    if ($emailSent) {
                        echo json_encode([
                            'success' => true,
                            'message' => 'Test email sent successfully to ' . $emailFrom
                        ]);
                    } else {
                        throw new Exception('Failed to send test email. Please check your email settings.');
                    }
                } catch (Exception $e) {
                    throw new Exception('Email test failed: ' . $e->getMessage());
                }
                break;

            case 'trigger_auto_backup':
                try {
                    require_once BASEPATH . 'includes/auto_backup.php';

                    // Get settings
                    $result = createAutomaticBackup($pdo, $settings);

                    if ($result['success']) {
                        echo json_encode([
                            'success' => true,
                            'message' => $result['message'],
                            'filename' => $result['filename'],
                            'size' => $result['size']
                        ]);
                    } else {
                        throw new Exception($result['message']);
                    }
                } catch (Exception $e) {
                    throw new Exception('Auto backup failed: ' . $e->getMessage());
                }
                break;

            case 'check_auto_backup_status':
                try {
                    $lastBackupTime = $settings['last_auto_backup'] ?? null;
                    $frequency = $settings['backup_frequency'] ?? 'daily';
                    $enabled = ($settings['backup_enabled'] ?? 'false') === 'true';

                    require_once BASEPATH . 'includes/auto_backup.php';
                    $isDue = $enabled ? isBackupDue($lastBackupTime, $frequency) : false;

                    $nextBackupTime = null;
                    if ($enabled && $lastBackupTime) {
                        $next = $lastBackupTime;
                        switch ($frequency) {
                            case 'daily':
                                $next += (24 * 60 * 60);
                                break;
                            case 'weekly':
                                $next += (7 * 24 * 60 * 60);
                                break;
                            case 'monthly':
                                $next += (30 * 24 * 60 * 60);
                                break;
                        }

                        $userTimezone = $settings['timezone'] ?? 'Asia/Yangon';
                        $dateTime = new DateTime('@' . $next);
                        $dateTime->setTimezone(new DateTimeZone($userTimezone));
                        $dateFormat = $settings['date_format'] ?? 'Y-m-d';
                        $nextBackupTime = $dateTime->format($dateFormat . ' H:i:s');
                    }

                    echo json_encode([
                        'success' => true,
                        'enabled' => $enabled,
                        'frequency' => $frequency,
                        'last_backup' => $lastBackupTime ? date('Y-m-d H:i:s', $lastBackupTime) : null,
                        'is_due' => $isDue,
                        'next_backup' => $nextBackupTime
                    ]);
                } catch (Exception $e) {
                    throw new Exception('Failed to check auto backup status: ' . $e->getMessage());
                }
                break;

            case 'backup_database':
                try {
                    error_log("Backup: Starting backup process");

                    // Create backup directory if it doesn't exist
                    $backupDir = BASEPATH . 'backups';
                    if (!is_dir($backupDir)) {
                        error_log("Backup: Creating backup directory: $backupDir");
                        if (!mkdir($backupDir, 0755, true)) {
                            throw new Exception('Failed to create backup directory: ' . $backupDir);
                        }
                    }

                    // Check if directory is writable
                    if (!is_writable($backupDir)) {
                        throw new Exception('Backup directory is not writable: ' . $backupDir);
                    }

                    // Generate backup filename with timestamp using user's timezone
                    $userTimezone = $settings['timezone'] ?? 'Asia/Yangon';
                    $dateTime = new DateTime('now', new DateTimeZone($userTimezone));
                    $timestamp = $dateTime->format('Y-m-d_H-i-s');
                    $backupFile = $backupDir . '/pos_system_backup_' . $timestamp . '.sql';

                    error_log("Backup: Target file: $backupFile");

                    // Always use PHP-based backup for better compatibility
                    error_log("Backup: Creating backup using PHP method...");
                    $backupContent = createPHPBackup($pdo, $userTimezone);

                    if (empty($backupContent)) {
                        throw new Exception('Backup content is empty');
                    }

                    error_log("Backup: Content size: " . strlen($backupContent) . " bytes");

                    $bytesWritten = file_put_contents($backupFile, $backupContent);
                    if ($bytesWritten === false) {
                        throw new Exception('Failed to write backup file to disk');
                    }

                    if (!file_exists($backupFile)) {
                        throw new Exception('Backup file was not created');
                    }

                    $fileSize = filesize($backupFile);
                    if ($fileSize === 0) {
                        throw new Exception('Backup file is empty');
                    }

                    error_log("Backup: Successfully created backup file: " . basename($backupFile) . " (" . $fileSize . " bytes)");

                    // Log the backup action
                    if (isset($_SESSION['user_id'])) {
                        logAction($pdo, $_SESSION['user_id'], "Created database backup: " . basename($backupFile));
                    }

                    echo json_encode([
                        'success' => true,
                        'message' => 'Database backup created successfully!',
                        'filename' => basename($backupFile),
                        'size' => formatBytes($fileSize),
                        'path' => 'backups/' . basename($backupFile)
                    ]);
                } catch (Exception $e) {
                    error_log("Backup error: " . $e->getMessage());
                    error_log("Backup error trace: " . $e->getTraceAsString());
                    throw new Exception('Backup failed: ' . $e->getMessage());
                }
                break;

            case 'list_backups':
                try {
                    $backupDir = BASEPATH . 'backups';
                    $backups = [];

                    if (is_dir($backupDir)) {
                        $files = glob($backupDir . '/pos_system_backup_*.sql');

                        // Get user's timezone setting
                        $userTimezone = $settings['timezone'] ?? 'Asia/Yangon';

                        foreach ($files as $file) {
                            $fileTime = filemtime($file);

                            // Convert file time to user's timezone
                            $dateTime = new DateTime('@' . $fileTime);
                            $dateTime->setTimezone(new DateTimeZone($userTimezone));

                            // Format according to user's date format setting
                            $dateFormat = $settings['date_format'] ?? 'Y-m-d';
                            $timeFormat = 'H:i:s';
                            $fullFormat = $dateFormat . ' ' . $timeFormat;

                            $backups[] = [
                                'filename' => basename($file),
                                'size' => formatBytes(filesize($file)),
                                'date' => $dateTime->format($fullFormat),
                                'path' => 'backups/' . basename($file),
                                'timestamp' => $fileTime // Keep original timestamp for sorting
                            ];
                        }

                        // Sort by timestamp (newest first)
                        usort($backups, function($a, $b) {
                            return $b['timestamp'] - $a['timestamp'];
                        });

                        // Remove timestamp from final output
                        foreach ($backups as &$backup) {
                            unset($backup['timestamp']);
                        }
                    }

                    echo json_encode([
                        'success' => true,
                        'backups' => $backups
                    ]);
                } catch (Exception $e) {
                    throw new Exception('Failed to list backups: ' . $e->getMessage());
                }
                break;

            case 'download_backup':
                try {
                    $filename = $_POST['filename'] ?? '';
                    if (empty($filename)) {
                        throw new Exception('Filename is required');
                    }

                    $backupFile = BASEPATH . 'backups/' . basename($filename);
                    if (!file_exists($backupFile)) {
                        throw new Exception('Backup file not found');
                    }

                    // Set headers for file download
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
                    header('Content-Length: ' . filesize($backupFile));
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');

                    // Output file content
                    readfile($backupFile);
                    exit;
                } catch (Exception $e) {
                    throw new Exception('Download failed: ' . $e->getMessage());
                }
                break;

            case 'delete_backup':
                try {
                    error_log("Delete backup: Starting delete process");

                    $filename = $_POST['filename'] ?? '';
                    error_log("Delete backup: Filename received: " . $filename);

                    if (empty($filename)) {
                        throw new Exception('Filename is required');
                    }

                    // Security check: only allow deletion of backup files
                    if (!preg_match('/^pos_system_backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.sql$/', $filename)) {
                        error_log("Delete backup: Invalid filename format: " . $filename);
                        throw new Exception('Invalid backup filename format');
                    }

                    $backupFile = BASEPATH . 'backups/' . basename($filename);
                    error_log("Delete backup: Full path: " . $backupFile);

                    if (!file_exists($backupFile)) {
                        error_log("Delete backup: File not found: " . $backupFile);
                        throw new Exception('Backup file not found: ' . $filename);
                    }

                    // Check if file is writable/deletable
                    if (!is_writable($backupFile)) {
                        error_log("Delete backup: File not writable: " . $backupFile);
                        throw new Exception('Backup file is not writable: ' . $filename);
                    }

                    error_log("Delete backup: Attempting to delete file: " . $backupFile);

                    if (unlink($backupFile)) {
                        error_log("Delete backup: File deleted successfully: " . $backupFile);

                        // Verify file is actually deleted
                        if (file_exists($backupFile)) {
                            error_log("Delete backup: File still exists after unlink: " . $backupFile);
                            throw new Exception('File deletion verification failed');
                        }

                        // Log the deletion action
                        if (isset($_SESSION['user_id'])) {
                            logAction($pdo, $_SESSION['user_id'], "Deleted database backup: " . basename($filename));
                        }

                        echo json_encode([
                            'success' => true,
                            'message' => 'Backup file deleted successfully: ' . $filename
                        ]);
                    } else {
                        error_log("Delete backup: unlink() returned false for: " . $backupFile);
                        throw new Exception('Failed to delete backup file: ' . $filename);
                    }
                } catch (Exception $e) {
                    error_log("Delete backup error: " . $e->getMessage());
                    error_log("Delete backup error trace: " . $e->getTraceAsString());
                    throw new Exception('Delete failed: ' . $e->getMessage());
                }
                break;

            case 'get_notification_settings':
                try {
                    $notificationSettings = [];
                    $settingKeys = ['notifications_enabled', 'low_stock_notifications', 'sales_notifications', 'system_notifications'];

                    foreach ($settingKeys as $key) {
                        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
                        $stmt->execute([$key]);
                        $value = $stmt->fetchColumn();
                        $notificationSettings[$key] = $value !== false ? $value : 'true'; // Default to true if not set
                    }

                    echo json_encode([
                        'success' => true,
                        'settings' => $notificationSettings
                    ]);
                } catch (Exception $e) {
                    throw new Exception('Failed to get notification settings: ' . $e->getMessage());
                }
                break;

            case 'update_theme_mode':
                try {
                    $themeMode = $_POST['theme_mode'] ?? '';

                    if (empty($themeMode) || !in_array($themeMode, ['light', 'dark'])) {
                        throw new Exception('Invalid theme mode');
                    }

                    // Save theme mode to database
                    $stmt = $pdo->prepare("
                        INSERT INTO settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE
                            setting_value = VALUES(setting_value),
                            updated_at = NOW()
                    ");
                    $stmt->execute(['theme_mode', $themeMode]);

                    // Log the theme change
                    if (isset($_SESSION['user_id'])) {
                        logAction($pdo, $_SESSION['user_id'], "Changed theme mode to: " . $themeMode);
                    }

                    echo json_encode([
                        'success' => true,
                        'message' => 'Theme mode updated successfully',
                        'theme_mode' => $themeMode
                    ]);
                } catch (Exception $e) {
                    throw new Exception('Failed to update theme mode: ' . $e->getMessage());
                }
                break;

            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Available options - Popular timezones first, then all others
$popularTimezones = [
    'Asia/Yangon' => 'Myanmar Time (MMT) - Asia/Yangon',
    'Asia/Bangkok' => 'Thailand Time (ICT) - Asia/Bangkok',
    'Asia/Singapore' => 'Singapore Time (SGT) - Asia/Singapore',
    'Asia/Kuala_Lumpur' => 'Malaysia Time (MYT) - Asia/Kuala_Lumpur',
    'Asia/Jakarta' => 'Indonesia Time (WIB) - Asia/Jakarta',
    'Asia/Manila' => 'Philippines Time (PHT) - Asia/Manila',
    'Asia/Shanghai' => 'China Time (CST) - Asia/Shanghai',
    'Asia/Tokyo' => 'Japan Time (JST) - Asia/Tokyo',
    'Asia/Seoul' => 'Korea Time (KST) - Asia/Seoul',
    'Asia/Kolkata' => 'India Time (IST) - Asia/Kolkata',
    'UTC' => 'Coordinated Universal Time (UTC)',
    'America/New_York' => 'Eastern Time (EST/EDT) - America/New_York',
    'America/Los_Angeles' => 'Pacific Time (PST/PDT) - America/Los_Angeles',
    'Europe/London' => 'Greenwich Mean Time (GMT/BST) - Europe/London',
];

$allTimezones = DateTimeZone::listIdentifiers();
$timezones = array_merge($popularTimezones, array_combine($allTimezones, $allTimezones));
$languages = [
    'en' => 'English',
    'mm' => 'Myanmar (မြန်မာ)'
];
$currencies = [
    'USD' => 'US Dollar ($)',
    'MMK' => 'Myanmar Kyat (K)',
    'THB' => 'Thai Baht (฿)'
];
// Create date format options with current language
$currentLang = $language ?? 'en';
$dateFormats = [];

if ($currentLang === 'mm') {
    $dateFormats = [
        'Y-m-d' => date('Y-m-d') . ' (ISO ပုံစံ)',
        'd/m/Y' => date('d/m/Y') . ' (ဥရောပပုံစံ)',
        'm/d/Y' => date('m/d/Y') . ' (အမေရိကန်ပုံစံ)',
        'Y/m/d' => date('Y/m/d') . ' (အာရှပုံစံ)',
        'F j, Y' => date('F j, Y') . ' (ရှည်လျားသောပုံစံ)',
        'M j, Y' => date('M j, Y') . ' (အလယ်အလတ်ပုံစံ)',
        'j F Y' => date('j F Y') . ' (ရက် လ နှစ်)',
        'd-m-Y' => date('d-m-Y') . ' (မျဉ်းတွဲပုံစံ)',
        'Y.m.d' => date('Y.m.d') . ' (အစက်ပုံစံ)'
    ];
} else {
    $dateFormats = [
        'Y-m-d' => date('Y-m-d') . ' (ISO Format)',
        'd/m/Y' => date('d/m/Y') . ' (European Format)',
        'm/d/Y' => date('m/d/Y') . ' (US Format)',
        'Y/m/d' => date('Y/m/d') . ' (Asian Format)',
        'F j, Y' => date('F j, Y') . ' (Long Format)',
        'M j, Y' => date('M j, Y') . ' (Medium Format)',
        'j F Y' => date('j F Y') . ' (Day Month Year)',
        'd-m-Y' => date('d-m-Y') . ' (Dash Format)',
        'Y.m.d' => date('Y.m.d') . ' (Dot Format)'
    ];
}

// Helper function to format file sizes
function formatBytes($size, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    return round($size, $precision) . ' ' . $units[$i];
}

// Helper function to create PHP-based database backup
function createPHPBackup($pdo, $userTimezone = 'Asia/Yangon') {
    $backup = "-- POS System Database Backup\n";

    // Use user's timezone for backup header
    $dateTime = new DateTime('now', new DateTimeZone($userTimezone));
    $backup .= "-- Generated on: " . $dateTime->format('Y-m-d H:i:s T') . "\n";
    $backup .= "-- Timezone: " . $userTimezone . "\n";
    $backup .= "-- Database: " . DB_NAME . "\n\n";
    $backup .= "SET FOREIGN_KEY_CHECKS=0;\n";
    $backup .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $backup .= "SET AUTOCOMMIT = 0;\n";
    $backup .= "START TRANSACTION;\n\n";

    try {
        // Get all tables
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        error_log("Backup: Found " . count($tables) . " tables");

        foreach ($tables as $table) {
            error_log("Backup: Processing table $table");

            // Get table structure
            $backup .= "-- Table structure for `$table`\n";
            $backup .= "DROP TABLE IF EXISTS `$table`;\n";

            $createStmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $createTable = $createStmt->fetch(PDO::FETCH_ASSOC);

            // Handle different MySQL versions and column names
            $createTableSQL = '';
            if (isset($createTable['Create Table'])) {
                $createTableSQL = $createTable['Create Table'];
            } elseif (isset($createTable['Create View'])) {
                $createTableSQL = $createTable['Create View'];
            } else {
                // Fallback: get the second column value
                $values = array_values($createTable);
                $createTableSQL = isset($values[1]) ? $values[1] : '';
            }

            if (empty($createTableSQL)) {
                error_log("Backup: Could not get CREATE statement for table $table");
                throw new Exception("Could not get CREATE statement for table $table");
            }

            $backup .= $createTableSQL . ";\n\n";

            // Get table data
            $backup .= "-- Data for table `$table`\n";
            $dataStmt = $pdo->query("SELECT * FROM `$table`");
            $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($rows)) {
                $columns = array_keys($rows[0]);
                $backup .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES\n";

                $values = [];
                foreach ($rows as $row) {
                    $rowValues = [];
                    foreach ($row as $value) {
                        if ($value === null) {
                            $rowValues[] = 'NULL';
                        } else {
                            $rowValues[] = $pdo->quote($value);
                        }
                    }
                    $values[] = '(' . implode(', ', $rowValues) . ')';
                }
                $backup .= implode(",\n", $values) . ";\n\n";
            } else {
                $backup .= "-- No data for table `$table`\n\n";
            }
        }

        $backup .= "SET FOREIGN_KEY_CHECKS=1;\n";
        $backup .= "COMMIT;\n";

        error_log("Backup: Successfully created backup content");
        return $backup;

    } catch (Exception $e) {
        error_log("Backup error: " . $e->getMessage());
        throw new Exception('Failed to create PHP backup: ' . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($translations['settings'] ?? 'Settings'); ?> - BitsTech POS</title>

    <!-- Critical CSS for immediate theme application -->
    <style id="critical-theme-css">
        /* Immediate dark theme application - only for main containers */
        html, body {
            background-color: #21243A !important;
            color: #ffffff !important;
            transition: none !important;
        }

        /* Override main layout containers only */
        .page-content-wrapper, .settings-container, .settings-content {
            background-color: #21243A !important;
            color: #ffffff !important;
        }

        /* Navbar and sidebar */
        .navbar, .sidebar {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
        }
    </style>

    <!-- Critical theme CSS to prevent flash -->
    <style id="critical-theme-css">
        /* Immediate theme application - prevent flash */
        html, body {
            transition: none !important;
        }

        /* Dark theme defaults */
        html[data-theme="dark"],
        html[data-theme="dark"] body,
        body[data-theme="dark"] {
            background-color: #21243A !important;
            color: #ffffff !important;
        }

        html[data-theme="dark"] .settings-container,
        html[data-theme="dark"] .settings-content,
        html[data-theme="dark"] .card,
        html[data-theme="dark"] .card-body {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
        }

        /* Light theme overrides */
        html[data-theme="light"],
        html[data-theme="light"] body,
        body[data-theme="light"] {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }

        html[data-theme="light"] .settings-container {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }

        html[data-theme="light"] .settings-content,
        html[data-theme="light"] .card,
        html[data-theme="light"] .card-body {
            background-color: #ffffff !important;
            color: #212529 !important;
        }
    </style>

    <!-- Immediate theme application to prevent flash -->
    <script>
        // Immediate theme application - must be first
        (function() {
            // Get theme from localStorage or default to dark
            let preTheme = localStorage.getItem('theme_mode') || 'dark';
            let preColors = null;

            try {
                const savedColors = localStorage.getItem('theme_colors');
                if (savedColors) {
                    preColors = JSON.parse(savedColors);
                }
            } catch (e) {
                console.warn('🎨 Failed to parse saved colors:', e);
            }

            console.log('🎨 Settings: Preloading theme:', preTheme, preColors);

            // Apply theme attributes immediately to prevent flash
            document.documentElement.setAttribute('data-theme', preTheme);
            document.documentElement.classList.add('theme-loaded');

            // Store for later use
            window.preloadedTheme = {
                mode: preTheme,
                colors: preColors || {
                    primary_color: '#007bff',
                    secondary_color: '#6c757d',
                    accent_color: '#17a2b8',
                    background_color: preTheme === 'light' ? '#f8f9fa' : '#21243A',
                    sidebar_color: preTheme === 'light' ? '#ffffff' : '#2A2D35',
                    text_color: preTheme === 'light' ? '#212529' : '#ffffff',
                    success_color: '#28a745',
                    warning_color: '#ffc107',
                    danger_color: '#dc3545',
                    info_color: '#17a2b8'
                }
            };

            // Apply to body when DOM is ready
            document.addEventListener('DOMContentLoaded', function() {
                document.body.setAttribute('data-theme', preTheme);
                console.log('🎨 Settings: Theme preloaded successfully:', preTheme);
            });
        })();
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../public/css/theme.css" onerror="console.error('Failed to load theme.css')">

    <!-- Fallback CSS if theme.css fails to load -->
    <style>
        /* Fallback theme styles */
        html[data-theme="dark"] {
            background-color: #21243A !important;
            color: #ffffff !important;
        }
        html[data-theme="light"] {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }
        html[data-theme="dark"] body {
            background-color: #21243A !important;
            color: #ffffff !important;
        }
        html[data-theme="light"] body {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }
    </style>

    <!-- Critical CSS for immediate theme application -->
    <style id="critical-theme-css">
        /* Immediate theme application - highest priority */
        html[data-theme="dark"] {
            background-color: #21243A !important;
            color: #ffffff !important;
            visibility: visible !important;
        }

        html[data-theme="light"] {
            background-color: #f8f9fa !important;
            color: #212529 !important;
            visibility: visible !important;
        }

        html[data-theme="dark"] body,
        body[data-theme="dark"] {
            background-color: #21243A !important;
            color: #ffffff !important;
        }

        html[data-theme="light"] body,
        body[data-theme="light"] {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }

        /* Settings page specific containers */
        html[data-theme="dark"] .settings-container,
        html[data-theme="dark"] .page-content-wrapper,
        html[data-theme="dark"] .main-content {
            background-color: #21243A !important;
            color: #ffffff !important;
        }

        html[data-theme="light"] .settings-container,
        html[data-theme="light"] .page-content-wrapper,
        html[data-theme="light"] .main-content {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }

        /* Settings cards */
        html[data-theme="dark"] .settings-content,
        html[data-theme="dark"] .settings-nav,
        html[data-theme="dark"] .page-header {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
        }

        html[data-theme="light"] .settings-content,
        html[data-theme="light"] .settings-nav,
        html[data-theme="light"] .page-header {
            background-color: #ffffff !important;
            color: #212529 !important;
        }

        /* Navbar consistency */
        html[data-theme="dark"] .navbar-top {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
        }

        html[data-theme="light"] .navbar-top {
            background-color: #ffffff !important;
            color: #212529 !important;
        }

        /* Sidebar consistency */
        html[data-theme="dark"] .left-sidebar {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
        }

        html[data-theme="light"] .left-sidebar {
            background-color: #ffffff !important;
            color: #212529 !important;
        }
    </style>

    <!-- Theme preloader - must load before any content -->
    <script>
        // Inline theme preloader to prevent CSS loading issues
        (function() {
            const savedTheme = localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Settings: Preloader applying theme:', savedTheme);

            // Apply to html immediately
            document.documentElement.setAttribute('data-theme', savedTheme);
            document.documentElement.classList.add('theme-loaded');

            // Apply to body immediately if available
            if (document.body) {
                document.body.setAttribute('data-theme', savedTheme);
                console.log('🎨 Settings: Body theme applied immediately');
            }

            // Also apply when DOM is ready
            document.addEventListener('DOMContentLoaded', function() {
                document.body.setAttribute('data-theme', savedTheme);

                // Force apply to all major containers
                const containers = document.querySelectorAll('.settings-container, .page-content-wrapper, .main-content, .settings-content, .settings-nav, .page-header');
                containers.forEach(container => {
                    container.setAttribute('data-theme', savedTheme);
                });

                console.log('🎨 Settings: DOM ready - theme applied to all containers');
            });

            // Store preloaded theme for theme manager
            window.preloadedTheme = {
                mode: savedTheme,
                colors: savedTheme === 'light' ? {
                    background_color: '#f8f9fa',
                    sidebar_color: '#ffffff',
                    text_color: '#212529'
                } : {
                    background_color: '#21243A',
                    sidebar_color: '#2A2D35',
                    text_color: '#ffffff'
                }
            };

            console.log('🎨 Settings: Inline theme preloader applied:', savedTheme);
        })();
    </script>

    <!-- Pass PHP theme settings to JavaScript -->
    <script>
        window.phpThemeSettings = <?php echo json_encode($themeSettings); ?>;
        console.log('🎨 PHP theme settings loaded:', window.phpThemeSettings);
    </script>
    <style>
        /* Theme-aware CSS - no default overrides */
        html[data-theme="dark"],
        html[data-theme="dark"] body {
            background-color: #21243A !important;
            color: #ffffff !important;
            transition: background-color 0.3s ease, color 0.3s ease !important;
        }

        html[data-theme="light"],
        html[data-theme="light"] body {
            background-color: #f8f9fa !important;
            color: #212529 !important;
            transition: background-color 0.3s ease, color 0.3s ease !important;
        }

        /* Light mode specific styles */
        [data-theme="light"] .page-content-wrapper,
        [data-theme="light"] .settings-container {
            background-color: #f8f9fa !important;
            color: #212529 !important;
        }

        [data-theme="light"] .settings-content,
        [data-theme="light"] .page-header,
        [data-theme="light"] .card,
        [data-theme="light"] .card-body {
            background-color: #ffffff !important;
            color: #212529 !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .settings-nav {
            background-color: #f8f9fa !important;
        }

        [data-theme="light"] .settings-nav .nav-link {
            background-color: #ffffff !important;
            color: #495057 !important;
            border: 1px solid #dee2e6 !important;
            margin-bottom: 5px !important;
        }

        [data-theme="light"] .settings-nav .nav-link.active {
            background-color: #007bff !important;
            color: #ffffff !important;
            border-color: #007bff !important;
        }

        [data-theme="light"] .settings-nav .nav-link:hover {
            background-color: #e9ecef !important;
            color: #495057 !important;
        }

        /* Dark mode specific styles */
        [data-theme="dark"] .page-content-wrapper,
        [data-theme="dark"] .settings-container {
            background-color: #21243A !important;
            color: #ffffff !important;
        }

        [data-theme="dark"] .settings-content,
        [data-theme="dark"] .page-header,
        [data-theme="dark"] .card,
        [data-theme="dark"] .card-body {
            background-color: #2A2D35 !important;
            color: #ffffff !important;
            border-color: #3A3D45 !important;
        }

        [data-theme="dark"] .settings-nav {
            background-color: #2A2D35 !important;
        }

        [data-theme="dark"] .settings-nav .nav-link {
            background-color: #21243A !important;
            color: rgba(255,255,255,0.7) !important;
            border: 1px solid #3A3D45 !important;
            margin-bottom: 5px !important;
        }

        [data-theme="dark"] .settings-nav .nav-link.active {
            background-color: #8b5cf6 !important;
            color: #ffffff !important;
            border-color: #8b5cf6 !important;
        }

        [data-theme="dark"] .settings-nav .nav-link:hover {
            background-color: #3A3D45 !important;
            color: #ffffff !important;
        }

        /* CSS Variables for Dark Mode */
        [data-theme="dark"] {
            --primary-bg: #21243A;
            --secondary-bg: #2A2D35;
            --card-bg: #2a2d35;
            --text-primary: #ffffff;
            --text-secondary: rgba(255,255,255,0.7);
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --card-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            --success-gradient: linear-gradient(135deg, #34d399 0%, #3b82f6 100%);
            --danger-gradient: linear-gradient(135deg, #f43f5e 0%, #ec4899 100%);
            --warning-gradient: linear-gradient(135deg, #f59e0b 0%, #f43f5e 100%);
            --info-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }

        /* CSS Variables for Light Mode */
        [data-theme="light"] {
            --primary-bg: #f8f9fa;
            --secondary-bg: #ffffff;
            --card-bg: #ffffff;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --card-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            --success-gradient: linear-gradient(135deg, #34d399 0%, #3b82f6 100%);
            --danger-gradient: linear-gradient(135deg, #f43f5e 0%, #ec4899 100%);
            --warning-gradient: linear-gradient(135deg, #f59e0b 0%, #f43f5e 100%);
            --info-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }

        body {
            background: var(--primary-bg) !important;
            color: var(--text-primary) !important;
            font-family: 'Inter', sans-serif;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .settings-container {
            padding: 2rem;
            min-height: 100vh;
        }

        .page-header {
            background: var(--secondary-bg);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, var(--accent-purple) 0%, var(--accent-pink) 100%);
            opacity: 0.1;
            z-index: 0;
        }

        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .settings-nav {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .nav-pills .nav-link {
            color: var(--text-secondary);
            border-radius: 0.5rem;
            padding: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: all 0.3s ease;
        }

        .nav-pills .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: var(--text-primary);
        }

        .nav-pills .nav-link.active {
            background: var(--accent-purple);
            color: white;
        }

        .settings-content {
            background: var(--card-bg);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 1rem;
        }

        .settings-section {
            margin-bottom: 2rem;
        }

        .settings-section:last-child {
            margin-bottom: 0;
        }

        .settings-section h3 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
        }

        .form-label {
            color: var(--text-secondary);
            font-size: 0.875rem;
            margin-bottom: 0.5rem;
        }

        .form-control,
        .form-select {
            background: var(--secondary-bg);
            border: 1px solid rgba(255,255,255,0.1);
            color: var(--text-primary);
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
        }

        .form-control:focus,
        .form-select:focus {
            background: var(--secondary-bg);
            border-color: var(--accent-purple);
            color: var(--text-primary);
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.25);
        }

        /* Light mode form controls */
        [data-theme="light"] .form-control,
        [data-theme="light"] .form-select {
            background: #ffffff !important;
            border: 1px solid #dee2e6 !important;
            color: #212529 !important;
        }

        [data-theme="light"] .form-control:focus,
        [data-theme="light"] .form-select:focus {
            background: #ffffff !important;
            border-color: #007bff !important;
            color: #212529 !important;
            box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25) !important;
        }

        [data-theme="light"] .form-control::placeholder {
            color: #6c757d !important;
        }

        /* Light mode text elements */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #212529 !important;
        }

        [data-theme="light"] p,
        [data-theme="light"] span,
        [data-theme="light"] div,
        [data-theme="light"] label {
            color: #212529 !important;
        }

        [data-theme="light"] .form-label {
            color: #495057 !important;
        }

        [data-theme="light"] .text-muted {
            color: #6c757d !important;
        }

        /* Light mode radio buttons and checkboxes */
        [data-theme="light"] .form-check-input {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .form-check-input:checked {
            background-color: #007bff !important;
            border-color: #007bff !important;
        }

        [data-theme="light"] .form-check-label {
            color: #212529 !important;
        }

        /* Light mode buttons */
        [data-theme="light"] .btn-outline-secondary {
            color: #6c757d !important;
            border-color: #6c757d !important;
        }

        [data-theme="light"] .btn-outline-secondary:hover {
            color: #ffffff !important;
            background-color: #6c757d !important;
            border-color: #6c757d !important;
        }

        /* Light mode table styles */
        [data-theme="light"] .table {
            color: #212529 !important;
        }

        [data-theme="light"] .table th,
        [data-theme="light"] .table td {
            border-color: #dee2e6 !important;
            color: #212529 !important;
        }

        /* Light mode modal styles */
        [data-theme="light"] .modal-content {
            background-color: #ffffff !important;
            color: #212529 !important;
        }

        [data-theme="light"] .modal-header {
            border-bottom-color: #dee2e6 !important;
        }

        [data-theme="light"] .modal-footer {
            border-top-color: #dee2e6 !important;
        }

        .btn-save {
            background: var(--accent-purple);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-save:hover {
            background: var(--accent-pink);
            transform: translateY(-2px);
        }

        .btn-test {
            background: var(--accent-blue);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-test:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        .color-picker {
            width: 3rem;
            height: 3rem;
            padding: 0;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
        }

        .color-picker::-webkit-color-swatch {
            border: none;
            border-radius: 0.5rem;
            padding: 0;
        }

        .color-picker::-webkit-color-swatch-wrapper {
            border: none;
            border-radius: 0.5rem;
            padding: 0;
        }

        .theme-preview {
            width: 100%;
            height: 100px;
            border-radius: 0.5rem;
            margin-top: 1rem;
            transition: all 0.3s ease;
        }

        /* Light mode theme preview and color elements */
        [data-theme="light"] .theme-preview {
            border: 1px solid #dee2e6 !important;
        }

        [data-theme="light"] .color-hex {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
            color: #212529 !important;
        }

        [data-theme="light"] .color-picker {
            border: 1px solid #dee2e6 !important;
        }

        /* Light mode theme mode cards */
        [data-theme="light"] .theme-mode-card {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
            color: #212529 !important;
        }

        [data-theme="light"] .theme-mode-card:hover {
            border-color: #007bff !important;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.15) !important;
        }

        [data-theme="light"] .theme-mode-card.active {
            border-color: #007bff !important;
            background-color: rgba(0, 123, 255, 0.1) !important;
        }

        /* Light mode preview cards */
        [data-theme="light"] .preview-card {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .preview-card-title,
        [data-theme="light"] .preview-card-value {
            color: #212529 !important;
        }

        /* Light mode color preset buttons */
        [data-theme="light"] .color-preset-btn {
            border: 2px solid #dee2e6 !important;
        }

        [data-theme="light"] .color-preset-btn.active {
            border-color: #007bff !important;
            box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25) !important;
        }

        /* Backup Section Styles */
        .backup-actions {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .backup-actions .btn {
            width: 100%;
        }

        .backup-list-section {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .backup-list-section h4 {
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
        }

        /* Light mode backup section styles */
        [data-theme="light"] .backup-list {
            background: #f8f9fa !important;
            border: 1px solid #dee2e6 !important;
        }

        [data-theme="light"] .backup-item {
            background: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .backup-item:hover {
            border-color: #007bff !important;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.15) !important;
        }

        [data-theme="light"] .backup-name {
            color: #212529 !important;
        }

        [data-theme="light"] .backup-name i {
            color: #007bff !important;
        }

        [data-theme="light"] .backup-details {
            color: #6c757d !important;
        }

        [data-theme="light"] .auto-backup-status {
            background: #f8f9fa !important;
            border: 1px solid #dee2e6 !important;
        }

        [data-theme="light"] .status-card {
            background: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .status-card:hover {
            border-color: #007bff !important;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.15) !important;
        }

        [data-theme="light"] .status-text {
            color: #212529 !important;
        }

        [data-theme="light"] .cron-instructions {
            background: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .cron-instructions h6 {
            color: #212529 !important;
        }

        .backup-list {
            background: var(--secondary-bg);
            border-radius: 0.75rem;
            padding: 1.5rem;
            min-height: 200px;
        }

        .backup-items {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .backup-item {
            background: var(--card-bg);
            border-radius: 0.5rem;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }

        .backup-item:hover {
            border-color: var(--accent-purple);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.15);
        }

        .backup-info {
            flex: 1;
        }

        .backup-name {
            color: var(--text-primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .backup-name i {
            color: var(--accent-purple);
        }

        .backup-details {
            display: flex;
            gap: 1rem;
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .backup-details span {
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }

        .backup-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }

        .backup-actions .btn {
            min-width: 80px;
            font-size: 0.875rem;
            padding: 0.375rem 0.75rem;
        }

        /* Visual feedback for updated fields */
        .updated-field {
            background-color: #d4edda !important;
            border-color: #28a745 !important;
            transition: all 0.3s ease;
            animation: fieldUpdate 2s ease-in-out;
        }

        html[data-theme="dark"] .updated-field {
            background-color: #155724 !important;
            border-color: #28a745 !important;
            color: #ffffff !important;
        }

        @keyframes fieldUpdate {
            0% {
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.7);
            }
            50% {
                transform: scale(1.02);
                box-shadow: 0 0 0 10px rgba(40, 167, 69, 0);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(40, 167, 69, 0);
            }
        }

        .backup-actions .btn i {
            margin-right: 0.25rem;
        }

        /* Auto Backup Status Styles */
        .auto-backup-status-section h4 {
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .auto-backup-status {
            background: var(--secondary-bg);
            border-radius: 0.75rem;
            padding: 1.5rem;
            min-height: 200px;
        }

        .status-overview {
            margin-bottom: 1.5rem;
        }

        .status-card {
            background: var(--card-bg);
            border-radius: 0.5rem;
            padding: 1rem;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
            height: 100%;
        }

        .status-card:hover {
            border-color: var(--accent-purple);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.15);
        }

        .status-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .status-text {
            color: var(--text-primary);
        }

        .status-text strong {
            color: var(--text-primary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .cron-instructions {
            background: var(--card-bg);
            border-radius: 0.5rem;
            padding: 1rem;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .cron-instructions h6 {
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .cron-command {
            background: var(--primary-bg);
            border-radius: 0.25rem;
            padding: 0.75rem;
            margin: 0.5rem 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .cron-command code {
            background: transparent;
            color: var(--accent-green);
            font-family: 'Courier New', monospace;
            font-size: 0.875rem;
            flex: 1;
            margin-right: 1rem;
        }

        /* Text color overrides for better visibility */
        .form-text, .text-muted, small.text-muted {
            color: #ffffff !important;
        }

        .cron-instructions p.text-muted {
            color: #ffffff !important;
        }

        .cron-instructions small.text-muted {
            color: #ffffff !important;
        }

        /* Logo upload help text */
        .logo-upload-info .form-text {
            color: #ffffff !important;
        }

        /* Site name help text */
        .site-name-help {
            color: #ffffff !important;
        }

        @media (max-width: 768px) {
            .backup-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }

            .backup-actions {
                width: 100%;
                justify-content: space-between;
            }

            .backup-actions .btn {
                flex: 1;
                min-width: auto;
            }

            .backup-details {
                flex-direction: column;
                gap: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .backup-actions {
                flex-direction: column;
                gap: 0.5rem;
            }

            .backup-actions .btn {
                width: 100%;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--primary-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--accent-purple);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-pink);
        }

        /* Theme settings styles */
        .theme-mode-card {
            padding: 1.5rem;
            text-align: center;
            border-radius: 12px;
            transition: all 0.3s ease;
            height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border: 2px solid rgba(255,255,255,0.1);
            background: var(--card-bg);
            color: var(--text-primary);
            position: relative;
            overflow: hidden;
        }

        /* Light mode text colors */
        [data-theme="light"] .theme-mode-card {
            color: #212529 !important;
            border-color: rgba(0,0,0,0.1);
        }

        /* Light Mode H1 and Headers Text Colors for Settings Page */
        [data-theme="light"] h1,
        [data-theme="light"] h2,
        [data-theme="light"] h3,
        [data-theme="light"] h4,
        [data-theme="light"] h5,
        [data-theme="light"] h6 {
            color: #ffffff !important;
        }

        [data-theme="light"] .settings-content h3,
        [data-theme="light"] .settings-content h4,
        [data-theme="light"] .settings-content h5,
        [data-theme="light"] .settings-content h6 {
            color: #ffffff !important;
        }

        [data-theme="light"] .settings-content p,
        [data-theme="light"] .settings-content span,
        [data-theme="light"] .settings-content div,
        [data-theme="light"] .settings-content label {
            color: #212529 !important;
        }

        [data-theme="light"] .form-label {
            color: #212529 !important;
        }

        [data-theme="light"] .text-muted {
            color: #6c757d !important;
        }

        [data-theme="light"] .nav-link {
            color: #212529 !important;
        }

        [data-theme="light"] .preview-card-title,
        [data-theme="light"] .preview-card-value {
            color: #ffffff !important;
        }

        [data-theme="light"] .color-preset-btn {
            color: #212529 !important;
            border-color: rgba(0,0,0,0.1);
        }

        [data-theme="light"] .form-control,
        [data-theme="light"] .form-select {
            background-color: #ffffff !important;
            border-color: #ced4da !important;
            color: #212529 !important;
        }

        [data-theme="light"] .form-control:focus,
        [data-theme="light"] .form-select:focus {
            background-color: #ffffff !important;
            border-color: #86b7fe !important;
            color: #212529 !important;
        }

        [data-theme="light"] .color-hex {
            background-color: #f8f9fa !important;
            border-color: #ced4da !important;
            color: #212529 !important;
        }

        [data-theme="light"] .btn {
            color: #212529 !important;
        }

        [data-theme="light"] .btn-outline-primary {
            color: #0d6efd !important;
            border-color: #0d6efd !important;
        }

        [data-theme="light"] .btn-outline-warning {
            color: #fd7e14 !important;
            border-color: #fd7e14 !important;
        }

        [data-theme="light"] .btn-outline-info {
            color: #0dcaf0 !important;
            border-color: #0dcaf0 !important;
        }

        [data-theme="light"] .btn-outline-success {
            color: #198754 !important;
            border-color: #198754 !important;
        }

        [data-theme="light"] .btn-outline-secondary {
            color: #6c757d !important;
            border-color: #6c757d !important;
        }

        [data-theme="light"] .nav-pills .nav-link {
            color: #212529 !important;
        }

        [data-theme="light"] .nav-pills .nav-link.active {
            background-color: #0d6efd !important;
            color: #ffffff !important;
        }

        [data-theme="light"] .settings-nav {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .settings-content {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
        }

        [data-theme="light"] .card,
        [data-theme="light"] .settings-section {
            background-color: #ffffff !important;
            border-color: #dee2e6 !important;
            color: #212529 !important;
        }

        [data-theme="light"] .border-top {
            border-color: #dee2e6 !important;
        }

        /* Custom Colors Section Border for Light Mode */
        [data-theme="light"] .custom-colors-section {
            border: 2px solid #e3f2fd !important;
            border-radius: 12px !important;
            padding: 1.5rem !important;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%) !important;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.1) !important;
        }

        [data-theme="light"] .custom-colors-section h5 {
            color: #1976d2 !important;
            border-bottom: 2px solid #e3f2fd !important;
            padding-bottom: 0.5rem !important;
            margin-bottom: 1.5rem !important;
        }

        [data-theme="light"] .custom-colors-section h6 {
            color: #1565c0 !important;
            font-weight: 600 !important;
        }

        /* Theme Preview Section Border for Light Mode */
        [data-theme="light"] .theme-preview-section {
            border: 2px solid #e8f5e8 !important;
            border-radius: 12px !important;
            padding: 1.5rem !important;
            background: linear-gradient(135deg, #ffffff 0%, #f1f8e9 100%) !important;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.1) !important;
        }

        [data-theme="light"] .theme-preview-section h5 {
            color: #388e3c !important;
            border-bottom: 2px solid #e8f5e8 !important;
            padding-bottom: 0.5rem !important;
            margin-bottom: 1.5rem !important;
        }

        [data-theme="light"] .theme-preview-container {
            border: 2px solid #c8e6c9 !important;
            box-shadow: 0 6px 16px rgba(76, 175, 80, 0.15) !important;
        }

        /* Color Input Groups Border for Light Mode */
        [data-theme="light"] .color-input-group .form-control-color {
            border: 2px solid #bbdefb !important;
            box-shadow: 0 2px 8px rgba(33, 150, 243, 0.2) !important;
        }

        [data-theme="light"] .color-input-group .color-hex {
            border: 2px solid #e1f5fe !important;
            background: linear-gradient(135deg, #ffffff 0%, #f0f8ff 100%) !important;
        }

        /* Color Preset Buttons Border for Light Mode */
        [data-theme="light"] .color-preset-btn {
            border: 2px solid #e3f2fd !important;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%) !important;
            box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1) !important;
            transition: all 0.3s ease !important;
        }

        [data-theme="light"] .color-preset-btn:hover {
            border-color: #2196f3 !important;
            box-shadow: 0 4px 12px rgba(33, 150, 243, 0.2) !important;
            transform: translateY(-2px) !important;
        }

        [data-theme="light"] .color-preset-btn.active {
            border-color: #1976d2 !important;
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%) !important;
            box-shadow: 0 6px 16px rgba(25, 118, 210, 0.3) !important;
        }

        .theme-mode-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(236, 72, 153, 0.1) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 0;
        }

        .theme-mode-card:hover::before {
            opacity: 1;
        }

        .theme-mode-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.3);
            border-color: var(--accent-purple);
        }

        .theme-mode-card > * {
            position: relative;
            z-index: 1;
        }

        .btn-check:checked + .theme-mode-card {
            border-color: var(--accent-purple);
            background: rgba(139, 92, 246, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(139, 92, 246, 0.4);
        }

        .btn-check:checked + .theme-mode-card::before {
            opacity: 1;
        }

        .theme-preview {
            width: 100%;
            height: 40px;
            border-radius: 8px;
            border: 2px solid rgba(255,255,255,0.2);
            margin-bottom: 0.75rem;
            position: relative;
            overflow: hidden;
        }

        .light-preview {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 50%, #e9ecef 100%);
            border-color: #dee2e6;
            position: relative;
        }

        .light-preview::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #ffc107 30%, transparent 30%);
            border-radius: 50%;
        }

        .dark-preview {
            background: linear-gradient(135deg, #21243A 0%, #2A2D35 50%, #1a1c23 100%);
            border-color: #2A2D35;
            position: relative;
        }

        .dark-preview::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 16px;
            height: 16px;
            background: #8b5cf6;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
        }

        .theme-mode-card i {
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }

        .theme-mode-card:hover i {
            transform: scale(1.1);
        }

        .theme-mode-card small {
            opacity: 0.8;
            font-size: 0.75rem;
            margin-top: 0.25rem;
        }

        /* Color Presets */
        .color-presets .color-preset-btn {
            padding: 0.75rem 0.5rem;
            border: 2px solid rgba(255,255,255,0.1);
            background: var(--card-bg);
            color: var(--text-primary);
            border-radius: 8px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .color-presets .color-preset-btn:hover {
            border-color: var(--accent-purple);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
        }

        .color-presets .color-preset-btn.active {
            border-color: var(--accent-purple);
            background: rgba(139, 92, 246, 0.2);
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
        }

        .color-preview-row {
            display: flex;
            gap: 2px;
            margin-bottom: 0.5rem;
            justify-content: center;
        }

        .color-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 1px solid rgba(255,255,255,0.2);
        }

        /* Color Input Groups */
        .color-input-group {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }

        .color-input-group .form-control-color {
            width: 50px;
            height: 38px;
            border-radius: 6px;
            border: 2px solid rgba(255,255,255,0.1);
            background: transparent;
            cursor: pointer;
        }

        .color-input-group .color-hex {
            flex: 1;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: var(--text-primary);
            font-family: 'Courier New', monospace;
            font-size: 0.875rem;
        }

        /* Theme Preview Container */
        .theme-preview-container {
            background: var(--card-bg);
            border: 2px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            overflow: hidden;
            height: 200px;
            display: flex;
            position: relative;
            transition: all 0.3s ease;
        }

        /* Light Mode Theme Preview */
        [data-theme="light"] .theme-preview-container {
            background: #f8f9fa !important;
            border-color: #c8e6c9 !important;
        }

        [data-theme="light"] .theme-preview-container .preview-sidebar {
            background: #ffffff !important;
            border-right: 1px solid #e9ecef !important;
        }

        [data-theme="light"] .theme-preview-container .preview-content {
            background: #f8f9fa !important;
        }

        /* Dark Mode Theme Preview */
        [data-theme="dark"] .theme-preview-container {
            background: #21243A !important;
            border-color: rgba(255,255,255,0.1) !important;
        }

        [data-theme="dark"] .theme-preview-container .preview-sidebar {
            background: #2A2D35 !important;
        }

        [data-theme="dark"] .theme-preview-container .preview-content {
            background: #21243A !important;
        }

        .preview-sidebar {
            width: 200px;
            background: var(--sidebar-bg, #2A2D35);
            color: #ffffff !important; /* Always white text */
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .preview-logo {
            font-weight: bold;
            font-size: 1rem;
            margin-bottom: 1rem;
            color: var(--accent-purple) !important;
        }

        .preview-menu-item {
            padding: 0.5rem 0.75rem;
            border-radius: 6px;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            color: #ffffff !important; /* Always white text */
        }

        .preview-menu-item:hover {
            background: rgba(255,255,255,0.1);
        }

        .preview-menu-item.active {
            background: var(--primary-color, #007bff);
            color: white !important;
        }

        .preview-content {
            flex: 1;
            background: var(--background-color, #21243A);
            color: #ffffff !important; /* Always white text */
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .preview-header h6 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #ffffff !important; /* Always white text */
        }

        .preview-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .preview-btn {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .preview-btn-primary {
            background: var(--primary-color, #007bff);
            color: white;
        }

        .preview-btn-success {
            background: var(--success-color, #28a745);
            color: white;
        }

        .preview-btn-warning {
            background: var(--warning-color, #ffc107);
            color: #212529;
        }

        .preview-btn-danger {
            background: var(--danger-color, #dc3545);
            color: white;
        }

        .preview-cards {
            display: flex;
            gap: 1rem;
        }

        .preview-card {
            flex: 1;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        /* Light Mode Preview Cards */
        [data-theme="light"] .theme-preview-container .preview-card {
            background: rgba(255,255,255,0.8) !important;
            border: 1px solid #e9ecef !important;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1) !important;
        }

        /* Dark Mode Preview Cards */
        [data-theme="dark"] .theme-preview-container .preview-card {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid rgba(255,255,255,0.1) !important;
        }

        .preview-card-title {
            font-size: 0.75rem;
            opacity: 0.8;
            margin-bottom: 0.5rem;
            color: #ffffff !important; /* Always white text */
        }

        .preview-card-value {
            font-size: 1.25rem;
            font-weight: bold;
            color: #ffffff !important; /* Always white text */
        }

        /* Override light mode for preview elements - keep white text */
        [data-theme="light"] .preview-sidebar,
        [data-theme="light"] .preview-content,
        [data-theme="light"] .preview-menu-item,
        [data-theme="light"] .preview-header h6,
        [data-theme="light"] .preview-card-title,
        [data-theme="light"] .preview-card-value {
            color: #ffffff !important;
        }

        .color-preset-btn {
            padding: 0.5rem;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            background: var(--card-bg);
            transition: all 0.3s ease;
            color: var(--text-primary);
        }

        .color-preset-btn:hover {
            border-color: var(--accent-purple);
            transform: translateY(-1px);
            color: var(--text-primary);
        }

        .color-preset-btn.active {
            border-color: var(--accent-purple);
            background: rgba(139, 92, 246, 0.2);
            color: var(--text-primary);
        }

        .color-preview-row {
            display: flex;
            justify-content: center;
            gap: 2px;
            margin-bottom: 4px;
        }

        .color-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .color-input-group {
            display: flex;
            gap: 8px;
        }

        .color-input-group .form-control-color {
            width: 50px;
            height: 38px;
            border-radius: 6px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .color-input-group .color-hex {
            flex: 1;
            font-family: monospace;
            font-size: 0.875rem;
        }

        /* Theme preview container */
        .theme-preview-container {
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 8px;
            overflow: hidden;
            height: 200px;
            display: flex;
            background: var(--preview-bg, #21243A);
        }

        .preview-sidebar {
            width: 200px;
            background: var(--preview-sidebar, #2A2D35);
            padding: 1rem;
            color: var(--preview-text, #ffffff);
        }

        .preview-logo {
            font-weight: bold;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .preview-menu-item {
            padding: 0.5rem;
            margin-bottom: 0.25rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .preview-menu-item:hover {
            background: rgba(255,255,255,0.1);
        }

        .preview-menu-item.active {
            background: var(--preview-primary, #007bff);
        }

        .preview-content {
            flex: 1;
            padding: 1rem;
            background: var(--preview-bg, #21243A);
            color: var(--preview-text, #ffffff);
        }

        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .preview-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .preview-btn {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            color: white;
        }

        .preview-btn-primary { background: var(--preview-primary, #007bff); }
        .preview-btn-success { background: var(--preview-success, #28a745); }
        .preview-btn-warning { background: var(--preview-warning, #ffc107); color: #000; }
        .preview-btn-danger { background: var(--preview-danger, #dc3545); }

        .preview-cards {
            display: flex;
            gap: 1rem;
        }

        .preview-card {
            flex: 1;
            padding: 1rem;
            background: var(--preview-sidebar, #2A2D35);
            border-radius: 6px;
            text-align: center;
        }

        .preview-card-title {
            font-size: 0.75rem;
            opacity: 0.7;
            margin-bottom: 0.5rem;
        }

        .preview-card-value {
            font-size: 1.25rem;
            font-weight: bold;
            color: var(--preview-primary, #007bff);
        }
    </style>
</head>
<body>
    <script>
        // Apply theme immediately on body load to prevent flash
        (function() {
            const savedTheme = localStorage.getItem('theme_mode') || 'dark';

            // Apply to both html and body
            document.documentElement.setAttribute('data-theme', savedTheme);
            document.body.setAttribute('data-theme', savedTheme);

            // Apply styles immediately and aggressively
            if (savedTheme === 'light') {
                // Remove critical dark CSS if light mode
                const criticalCSS = document.getElementById('critical-theme-css');
                if (criticalCSS) criticalCSS.remove();

                document.documentElement.style.backgroundColor = '#f8f9fa';
                document.documentElement.style.color = '#212529';
                document.body.style.backgroundColor = '#f8f9fa';
                document.body.style.color = '#212529';
            } else {
                document.documentElement.style.backgroundColor = '#21243A';
                document.documentElement.style.color = '#ffffff';
                document.body.style.backgroundColor = '#21243A';
                document.body.style.color = '#ffffff';
            }

            // Apply to ALL elements aggressively
            const allElements = document.querySelectorAll('*');
            allElements.forEach(element => {
                if (savedTheme === 'light') {
                    if (element.classList.contains('page-content-wrapper') ||
                        element.classList.contains('settings-container')) {
                        element.style.backgroundColor = '#f8f9fa';
                        element.style.color = '#212529';
                    } else if (element.classList.contains('settings-content') ||
                               element.classList.contains('settings-nav') ||
                               element.classList.contains('page-header')) {
                        element.style.backgroundColor = '#ffffff';
                        element.style.color = '#212529';
                    }
                } else {
                    if (element.classList.contains('page-content-wrapper') ||
                        element.classList.contains('settings-container')) {
                        element.style.backgroundColor = '#21243A';
                        element.style.color = '#ffffff';
                    } else if (element.classList.contains('settings-content') ||
                               element.classList.contains('settings-nav') ||
                               element.classList.contains('page-header')) {
                        element.style.backgroundColor = '#2A2D35';
                        element.style.color = '#ffffff';
                    }
                }
            });
        })();
    </script>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="settings-container">
            <!-- Page Header -->
            <div class="page-header" data-aos="fade-down">
                <h1>
                    <i class="fas fa-cog"></i>
                    <span data-translate="settings">
                        <?php echo htmlspecialchars($translations['settings'] ?? 'Settings'); ?>
                    </span>
                </h1>
                <p class="text-secondary" data-translate="configure_system_settings">
                    <?php echo htmlspecialchars($translations['configure_system_settings'] ?? 'Configure system settings and preferences'); ?>
                </p>
            </div>

            <div class="row">
                <!-- Settings Navigation -->
                <div class="col-md-3">
                    <div class="settings-nav" data-aos="fade-right">
                        <div class="nav flex-column nav-pills" role="tablist">
                            <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#general">
                                <i class="fas fa-sliders-h"></i>
                                <span data-translate="general">General</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#localization">
                                <i class="fas fa-globe"></i>
                                <span data-translate="localization">Localization</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#notifications">
                                <i class="fas fa-bell"></i>
                                <span data-translate="notifications">Notifications</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#theme">
                                <i class="fas fa-palette"></i>
                                <span data-translate="theme">Theme</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#footer">
                                <i class="fas fa-info-circle"></i>
                                <span data-translate="footer">Footer</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#email">
                                <i class="fas fa-envelope"></i>
                                <span data-translate="email">Email</span>
                            </button>
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#backup">
                                <i class="fas fa-database"></i>
                                <span data-translate="backup">Backup</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Settings Content -->
                <div class="col-md-9">
                    <div class="tab-content">
                        <!-- General Settings -->
                        <div class="tab-pane fade show active" id="general">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="general_settings">General Settings</h3>

                                    <!-- Site Logo Upload -->
                                    <div class="mb-4">
                                        <label class="form-label" data-translate="site_logo">Site Logo</label>
                                        <div class="logo-upload-container">
                                            <div class="current-logo mb-3">
                                                <?php
                                                $currentLogo = $settings['site_logo'] ?? 'public/images/logo.png';
                                                ?>
                                                <img id="logoPreview" src="../<?php echo htmlspecialchars($currentLogo); ?>"
                                                     alt="Current Logo" style="max-width: 150px; max-height: 80px; border-radius: 8px; border: 2px solid var(--secondary-bg);">
                                            </div>
                                            <input type="file" class="form-control" id="logoUpload" name="site_logo"
                                                   accept="image/*" onchange="previewLogo(this)">
                                            <small class="text-muted logo-upload-info">
                                                <span data-translate="recommended_size">Recommended size</span>: 200x100px.
                                                <span data-translate="supported_formats">Supported formats</span>: JPG, PNG, SVG
                                            </small>
                                        </div>
                                    </div>

                                    <!-- System Name -->
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="system_name">System Name</label>
                                        <input type="text" class="form-control" name="site_name"
                                               value="<?php echo htmlspecialchars($settings['site_name'] ?? 'BitsTech POS'); ?>"
                                               data-translate="system_name_placeholder" placeholder="Enter your system name">
                                        <small class="text-muted site-name-help" data-translate="appear_navigation">This will appear in the navigation bar and system title</small>
                                    </div>

                                    <!-- Timezone -->
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="timezone">Timezone</label>
                                        <select class="form-select" name="timezone">
                                            <?php foreach ($timezones as $value => $display): ?>
                                                <option value="<?php echo htmlspecialchars($value); ?>"
                                                        <?php echo ($settings['timezone'] ?? '') === $value ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($display); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Localization Settings -->
                        <div class="tab-pane fade" id="localization">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="localization_settings">Localization Settings</h3>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="language">Language</label>
                                        <select class="form-select" name="language">
                                            <?php foreach ($languages as $code => $name): ?>
                                                <option value="<?php echo htmlspecialchars($code); ?>"
                                                        <?php echo ($settings['language'] ?? '') === $code ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($name); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="currency">Currency</label>
                                        <select class="form-select" name="currency">
                                            <?php foreach ($currencies as $code => $name): ?>
                                                <option value="<?php echo htmlspecialchars($code); ?>"
                                                        <?php echo ($settings['currency'] ?? '') === $code ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($name); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="date_format">Date Format</label>
                                        <select class="form-select" name="date_format">
                                            <?php foreach ($dateFormats as $format => $example): ?>
                                                <option value="<?php echo htmlspecialchars($format); ?>"
                                                        <?php echo ($settings['date_format'] ?? '') === $format ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($example); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Notification Settings -->
                        <div class="tab-pane fade" id="notifications">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="notification_settings">Notification Settings</h3>

                                    <div class="row">
                                        <!-- Notification Configuration -->
                                        <div class="col-md-6">
                                            <div class="notification-config">
                                                <!-- Master Notification Toggle -->
                                                <div class="mb-4">
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="notifications_enabled" id="notificationsEnabled"
                                                               <?php echo ($settings['notifications_enabled'] ?? 'true') === 'true' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label fw-bold" for="notificationsEnabled" data-translate="enable_notifications">
                                                            Enable Notifications
                                                        </label>
                                                    </div>
                                                    <small class="text-muted" data-translate="notification_help">
                                                        Show system notifications for low stock, sales, and other important events
                                                    </small>
                                                </div>

                                                <!-- Notification Types -->
                                                <div id="notificationTypes" class="notification-types">
                                                    <!-- Low Stock Notifications -->
                                                    <div class="mb-3">
                                                        <div class="form-check form-switch">
                                                            <input class="form-check-input" type="checkbox" name="low_stock_notifications" id="lowStockNotifications"
                                                                   <?php echo ($settings['low_stock_notifications'] ?? 'true') === 'true' ? 'checked' : ''; ?>>
                                                            <label class="form-check-label" for="lowStockNotifications" data-translate="low_stock_notifications">
                                                                <i class="fas fa-box text-danger me-2"></i>Low Stock Notifications
                                                            </label>
                                                        </div>
                                                        <small class="text-muted ms-4" data-translate="low_stock_help">
                                                            Get notified when product stock falls below minimum threshold
                                                        </small>
                                                    </div>

                                                    <!-- Sales Notifications -->
                                                    <div class="mb-3">
                                                        <div class="form-check form-switch">
                                                            <input class="form-check-input" type="checkbox" name="sales_notifications" id="salesNotifications"
                                                                   <?php echo ($settings['sales_notifications'] ?? 'true') === 'true' ? 'checked' : ''; ?>>
                                                            <label class="form-check-label" for="salesNotifications" data-translate="sales_notifications">
                                                                <i class="fas fa-shopping-cart text-success me-2"></i>Sales Notifications
                                                            </label>
                                                        </div>
                                                        <small class="text-muted ms-4" data-translate="sales_help">
                                                            Get notified about new sales and transactions
                                                        </small>
                                                    </div>

                                                    <!-- System Notifications -->
                                                    <div class="mb-3">
                                                        <div class="form-check form-switch">
                                                            <input class="form-check-input" type="checkbox" name="system_notifications" id="systemNotifications"
                                                                   <?php echo ($settings['system_notifications'] ?? 'true') === 'true' ? 'checked' : ''; ?>>
                                                            <label class="form-check-label" for="systemNotifications" data-translate="system_notifications">
                                                                <i class="fas fa-cog text-info me-2"></i>System Notifications
                                                            </label>
                                                        </div>
                                                        <small class="text-muted ms-4" data-translate="system_help">
                                                            Get notified about system updates, backups, and maintenance
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Notification Preview -->
                                        <div class="col-md-6">
                                            <div class="notification-preview-section">
                                                <h5 class="mb-3" data-translate="notification_preview">Notification Preview</h5>
                                                <div class="notification-preview-area" style="min-height: 250px; background: var(--secondary-bg); border-radius: 8px; padding: 1rem; position: relative;">
                                                    <div class="text-center text-muted" id="previewPlaceholder">
                                                        <i class="fas fa-bell-slash fa-3x mb-3 opacity-50"></i>
                                                        <p data-translate="notification_preview_text">Enable notifications to see preview</p>
                                                    </div>

                                                    <!-- Sample Notifications (hidden by default) -->
                                                    <div id="sampleNotifications" style="display: none;">
                                                        <div class="sample-notification mb-2 p-2 rounded" style="background: #dc3545; color: white; font-size: 0.875rem;">
                                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                                            <span data-translate="sample_low_stock">Low stock: Laptop ABC (5 remaining)</span>
                                                        </div>
                                                        <div class="sample-notification mb-2 p-2 rounded" style="background: #28a745; color: white; font-size: 0.875rem;">
                                                            <i class="fas fa-check-circle me-2"></i>
                                                            <span data-translate="sample_sale">New sale: $1,250.00</span>
                                                        </div>
                                                        <div class="sample-notification p-2 rounded" style="background: #17a2b8; color: white; font-size: 0.875rem;">
                                                            <i class="fas fa-info-circle me-2"></i>
                                                            <span data-translate="sample_system">Backup completed successfully</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Test Notification Button -->
                                                <div class="mt-3 text-center">
                                                    <button type="button" class="btn btn-outline-primary btn-sm" id="testNotificationBtn" disabled>
                                                        <i class="fas fa-vial me-2"></i>
                                                        <span data-translate="test_notification">Test Notification</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Theme Settings -->
                        <div class="tab-pane fade" id="theme">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="theme_settings">Theme Settings</h3>
                                    <p class="text-muted mb-4" data-translate="theme_settings_desc">
                                        Customize the appearance and colors of your POS system
                                    </p>

                                    <div class="row">
                                        <!-- Theme Mode -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="theme_mode">Theme Mode</h5>

                                            <div class="mb-4">
                                                <div class="theme-mode-selector">
                                                    <div class="row g-3">
                                                        <div class="col-6">
                                                            <input type="radio" class="btn-check" name="theme_mode" id="light_mode" value="light"
                                                                   <?php echo ($settings['theme_mode'] ?? 'dark') === 'light' ? 'checked' : ''; ?>>
                                                            <label class="btn btn-outline-primary w-100 theme-mode-card" for="light_mode">
                                                                <div class="theme-preview light-preview mb-2"></div>
                                                                <i class="fas fa-sun mb-2"></i>
                                                                <div data-translate="light_mode">Light Mode</div>
                                                            </label>
                                                        </div>
                                                        <div class="col-6">
                                                            <input type="radio" class="btn-check" name="theme_mode" id="dark_mode" value="dark"
                                                                   <?php echo ($settings['theme_mode'] ?? 'dark') === 'dark' ? 'checked' : ''; ?>>
                                                            <label class="btn btn-outline-primary w-100 theme-mode-card" for="dark_mode">
                                                                <div class="theme-preview dark-preview mb-2"></div>
                                                                <i class="fas fa-moon mb-2"></i>
                                                                <div data-translate="dark_mode">Dark Mode</div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Color Presets -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="color_presets">Color Presets</h5>

                                            <div class="color-presets mb-4">
                                                <div class="row g-2">
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn active" data-preset="default">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #21243A;"></span>
                                                                <span class="color-dot" style="background: #2A2D35;"></span>
                                                                <span class="color-dot" style="background: #007bff;"></span>
                                                            </div>
                                                            <small>Default</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="ocean">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #0f172a;"></span>
                                                                <span class="color-dot" style="background: #1e293b;"></span>
                                                                <span class="color-dot" style="background: #0ea5e9;"></span>
                                                            </div>
                                                            <small>Ocean</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="forest">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #0f1419;"></span>
                                                                <span class="color-dot" style="background: #1a2e1a;"></span>
                                                                <span class="color-dot" style="background: #10b981;"></span>
                                                            </div>
                                                            <small>Forest</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="sunset">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1a0f0a;"></span>
                                                                <span class="color-dot" style="background: #2d1b1b;"></span>
                                                                <span class="color-dot" style="background: #f97316;"></span>
                                                            </div>
                                                            <small>Sunset</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="royal">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1e1065;"></span>
                                                                <span class="color-dot" style="background: #312e81;"></span>
                                                                <span class="color-dot" style="background: #8b5cf6;"></span>
                                                            </div>
                                                            <small>Royal</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="crimson">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1a0a0a;"></span>
                                                                <span class="color-dot" style="background: #2d1b1b;"></span>
                                                                <span class="color-dot" style="background: #ef4444;"></span>
                                                            </div>
                                                            <small>Crimson</small>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Custom Colors -->
                                    <div class="row mt-4">
                                        <div class="col-12 custom-colors-section">
                                            <h5 class="mb-3" data-translate="custom_colors">Custom Colors</h5>

                                            <div class="row g-3">
                                                <!-- Primary Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="primary_colors">Primary Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="primary_color">Primary Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="primary_color"
                                                                   value="<?php echo htmlspecialchars($settings['primary_color'] ?? '#007bff'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['primary_color'] ?? '#007bff'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="secondary_color">Secondary Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="secondary_color"
                                                                   value="<?php echo htmlspecialchars($settings['secondary_color'] ?? '#6c757d'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['secondary_color'] ?? '#6c757d'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="accent_color">Accent Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="accent_color"
                                                                   value="<?php echo htmlspecialchars($settings['accent_color'] ?? '#17a2b8'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['accent_color'] ?? '#17a2b8'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Background Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="background_colors">Background Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="background_color">Background Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="background_color"
                                                                   value="<?php echo htmlspecialchars($settings['background_color'] ?? '#21243A'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['background_color'] ?? '#21243A'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="sidebar_color">Sidebar Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="sidebar_color"
                                                                   value="<?php echo htmlspecialchars($settings['sidebar_color'] ?? '#2A2D35'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['sidebar_color'] ?? '#2A2D35'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="text_color">Text Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="text_color"
                                                                   value="<?php echo htmlspecialchars($settings['text_color'] ?? '#ffffff'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['text_color'] ?? '#ffffff'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Status Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="status_colors">Status Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="success_color">Success Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="success_color"
                                                                   value="<?php echo htmlspecialchars($settings['success_color'] ?? '#28a745'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['success_color'] ?? '#28a745'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="warning_color">Warning Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="warning_color"
                                                                   value="<?php echo htmlspecialchars($settings['warning_color'] ?? '#ffc107'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['warning_color'] ?? '#ffc107'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="danger_color">Danger Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="danger_color"
                                                                   value="<?php echo htmlspecialchars($settings['danger_color'] ?? '#dc3545'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($settings['danger_color'] ?? '#dc3545'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Theme Preview -->
                                    <div class="mt-4 theme-preview-section">
                                        <h5 class="mb-3" data-translate="theme_preview">Theme Preview</h5>
                                        <div class="theme-preview-container" id="themePreview">
                                            <div class="preview-sidebar">
                                                <div class="preview-logo" style="color: #8b5cf6 !important;">BitsTech POS</div>
                                                <div class="preview-menu-item active" style="color: #ffffff !important;">Dashboard</div>
                                                <div class="preview-menu-item" style="color: #ffffff !important;">Inventory</div>
                                                <div class="preview-menu-item" style="color: #ffffff !important;">Reports</div>
                                            </div>
                                            <div class="preview-content">
                                                <div class="preview-header">
                                                    <h6 style="color: #ffffff !important;">Dashboard</h6>
                                                    <div class="preview-buttons">
                                                        <span class="preview-btn preview-btn-primary" style="color: #ffffff !important;">Primary</span>
                                                        <span class="preview-btn preview-btn-success" style="color: #ffffff !important;">Success</span>
                                                        <span class="preview-btn preview-btn-warning" style="color: #212529 !important;">Warning</span>
                                                        <span class="preview-btn preview-btn-danger" style="color: #ffffff !important;">Danger</span>
                                                    </div>
                                                </div>
                                                <div class="preview-cards">
                                                    <div class="preview-card">
                                                        <div class="preview-card-title" style="color: #ffffff !important;">Total Sales</div>
                                                        <div class="preview-card-value" style="color: #ffffff !important; font-weight: bold;">$12,345</div>
                                                    </div>
                                                    <div class="preview-card">
                                                        <div class="preview-card-title" style="color: #ffffff !important;">Products</div>
                                                        <div class="preview-card-value" style="color: #ffffff !important; font-weight: bold;">1,234</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <small class="text-muted mt-2 d-block" data-translate="theme_preview_help">
                                            This preview shows how your theme will look across the system
                                        </small>
                                    </div>

                                    <!-- Reset Theme -->
                                    <div class="mt-4 pt-3 border-top">
                                        <button type="button" class="btn btn-outline-secondary" id="resetTheme">
                                            <i class="fas fa-undo me-2"></i>
                                            <span data-translate="reset_theme">Reset to Default Theme</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Footer Settings -->
                        <div class="tab-pane fade" id="footer">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="footer_settings">Footer Settings</h3>
                                    <p class="text-muted mb-4" data-translate="footer_settings_desc">
                                        Configure footer information that appears at the bottom of all pages
                                    </p>

                                    <div class="row">
                                        <!-- Store Information -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="store_information">Store Information</h5>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="store_address">Store Address</label>
                                                <textarea class="form-control" name="store_address" rows="3"
                                                          placeholder="Yangon, Myanmar"><?php echo htmlspecialchars($settings['store_address'] ?? 'Yangon, Myanmar'); ?></textarea>
                                                <small class="text-muted" data-translate="store_address_help">
                                                    Enter your business address (will appear with location icon)
                                                </small>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="store_email">Store Email</label>
                                                <input type="email" class="form-control" name="store_email"
                                                       placeholder="info@example.com"
                                                       value="<?php echo htmlspecialchars($settings['store_email'] ?? 'info@example.com'); ?>">
                                                <small class="text-muted" data-translate="store_email_help">
                                                    Contact email address for customers
                                                </small>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="store_phone">Store Phone</label>
                                                <input type="tel" class="form-control" name="store_phone"
                                                       placeholder="+95 9123456789"
                                                       value="<?php echo htmlspecialchars($settings['store_phone'] ?? '+95 9123456789'); ?>">
                                                <small class="text-muted" data-translate="store_phone_help">
                                                    Contact phone number for customers
                                                </small>
                                            </div>
                                        </div>

                                        <!-- Legal Information -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="legal_information">Legal Information</h5>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="footer_copyright">Copyright Text</label>
                                                <input type="text" class="form-control" name="footer_copyright"
                                                       placeholder="© 2025 BitsTech. All rights reserved."
                                                       value="<?php echo htmlspecialchars($settings['footer_copyright'] ?? '© ' . date('Y') . ' BitsTech. All rights reserved.'); ?>">
                                                <small class="text-muted" data-translate="copyright_help">
                                                    Copyright notice that appears in the footer
                                                </small>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="privacy_policy_url">Privacy Policy URL</label>
                                                <input type="url" class="form-control" name="privacy_policy_url"
                                                       placeholder="https://example.com/privacy"
                                                       value="<?php echo htmlspecialchars($settings['privacy_policy_url'] ?? ''); ?>">
                                                <small class="text-muted" data-translate="privacy_policy_help">
                                                    Link to your privacy policy page (optional)
                                                </small>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label" data-translate="terms_of_service_url">Terms of Service URL</label>
                                                <input type="url" class="form-control" name="terms_of_service_url"
                                                       placeholder="https://example.com/terms"
                                                       value="<?php echo htmlspecialchars($settings['terms_of_service_url'] ?? ''); ?>">
                                                <small class="text-muted" data-translate="terms_service_help">
                                                    Link to your terms of service page (optional)
                                                </small>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Footer Preview -->
                                    <div class="mt-4">
                                        <h5 class="mb-3" data-translate="footer_preview">Footer Preview</h5>
                                        <div class="footer-preview-container" style="background: #1a1a1a; color: #ffffff; padding: 20px; border-radius: 8px; font-size: 0.875rem;">
                                            <div class="store-info mb-2">
                                                <small>
                                                    <i class="fas fa-map-marker-alt me-1"></i> <span id="preview-address">Yangon, Myanmar</span> |
                                                    <i class="fas fa-envelope me-1 ms-2"></i> <span id="preview-email">info@example.com</span> |
                                                    <i class="fas fa-phone me-1 ms-2"></i> <span id="preview-phone">+95 9123456789</span>
                                                </small>
                                            </div>
                                            <div class="copyright">
                                                <small>
                                                    <i class="fas fa-microchip circuit-icon me-1"></i>
                                                    <span id="preview-copyright">© 2025 BitsTech. All rights reserved.</span>
                                                    |
                                                    <a href="#" class="text-light ms-2" data-translate="privacy_policy">Privacy Policy</a> |
                                                    <a href="#" class="text-light ms-2" data-translate="terms_of_service">Terms of Service</a>
                                                </small>
                                            </div>
                                        </div>
                                        <small class="text-muted mt-2 d-block" data-translate="footer_preview_help">
                                            This is how your footer will appear on all pages
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Email Settings -->
                        <div class="tab-pane fade" id="email">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="email_settings">Email Settings</h3>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="email_host">SMTP Host</label>
                                        <input type="text" class="form-control" name="email_host"
                                               value="<?php echo htmlspecialchars($settings['email_host'] ?? ''); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="email_port">SMTP Port</label>
                                        <input type="number" class="form-control" name="email_port"
                                               value="<?php echo htmlspecialchars($settings['email_port'] ?? ''); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="email_username">SMTP Username</label>
                                        <input type="text" class="form-control" name="email_username"
                                               value="<?php echo htmlspecialchars($settings['email_username'] ?? ''); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="email_password">SMTP Password</label>
                                        <input type="password" class="form-control" name="email_password"
                                               value="<?php echo htmlspecialchars($settings['email_password'] ?? ''); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" data-translate="email_from">From Address</label>
                                        <input type="email" class="form-control" name="email_from"
                                               value="<?php echo htmlspecialchars($settings['email_from'] ?? ''); ?>">
                                    </div>
                                    <button type="button" class="btn btn-test" onclick="testEmail()">
                                        <i class="fas fa-paper-plane"></i>
                                        <span data-translate="test_email">Test Email</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Backup Settings -->
                        <div class="tab-pane fade" id="backup">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="backup_settings">Backup Settings</h3>

                                    <!-- Backup Configuration -->
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" name="backup_enabled"
                                                           <?php echo ($settings['backup_enabled'] ?? '') === 'true' ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" data-translate="enable_automatic_backup">
                                                        Enable Automatic Backup
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" data-translate="backup_frequency">Backup Frequency</label>
                                                <select class="form-select" name="backup_frequency">
                                                    <option value="daily" <?php echo ($settings['backup_frequency'] ?? '') === 'daily' ? 'selected' : ''; ?> data-translate="daily">Daily</option>
                                                    <option value="weekly" <?php echo ($settings['backup_frequency'] ?? '') === 'weekly' ? 'selected' : ''; ?> data-translate="weekly">Weekly</option>
                                                    <option value="monthly" <?php echo ($settings['backup_frequency'] ?? '') === 'monthly' ? 'selected' : ''; ?> data-translate="monthly">Monthly</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="backup-actions">
                                                <button type="button" class="btn btn-primary mb-2" onclick="backupNow()">
                                                    <i class="fas fa-download"></i>
                                                    <span data-translate="backup_now">Backup Now</span>
                                                </button>
                                                <button type="button" class="btn btn-secondary mb-2" onclick="loadBackupList()">
                                                    <i class="fas fa-list"></i>
                                                    <span data-translate="view_backups">View Backups</span>
                                                </button>
                                                <button type="button" class="btn btn-outline-secondary" onclick="checkAutoBackupStatus()">
                                                    <i class="fas fa-info-circle"></i>
                                                    <span data-translate="check_status">Check Status</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Auto Backup Status -->
                                    <div class="auto-backup-status-section mb-4">
                                        <h4 data-translate="auto_backup_status">Automatic Backup Status</h4>
                                        <div id="autoBackupStatus" class="auto-backup-status">
                                            <div class="text-center text-muted">
                                                <i class="fas fa-robot fa-2x mb-2"></i>
                                                <p data-translate="click_check_status">Click "Check Status" to view automatic backup information</p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Backup List -->
                                    <div class="backup-list-section">
                                        <h4 data-translate="backup_history">Backup History</h4>
                                        <div id="backupList" class="backup-list">
                                            <div class="text-center text-muted">
                                                <i class="fas fa-database fa-2x mb-2"></i>
                                                <p data-translate="click_view_backups">Click "View Backups" to load backup history</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Theme Settings -->
                        <div class="tab-pane fade" id="theme">
                            <div class="settings-content" data-aos="fade-left">
                                <div class="settings-section">
                                    <h3 data-translate="theme_settings">Theme Settings</h3>
                                    <p class="text-muted mb-4" data-translate="theme_settings_desc">
                                        Customize the appearance and colors of your POS system
                                    </p>

                                    <div class="row">
                                        <!-- Theme Mode Selection -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="theme_mode">Theme Mode</h5>

                                            <div class="mb-4">
                                                <div class="theme-mode-selector">
                                                    <div class="row g-3">
                                                        <div class="col-6">
                                                            <input type="radio" class="btn-check" name="theme_mode" id="light_mode" value="light"
                                                                   <?php echo ($themeSettings['theme_mode'] ?? 'dark') === 'light' ? 'checked' : ''; ?>>
                                                            <label class="btn btn-outline-primary w-100 theme-mode-card" for="light_mode">
                                                                <div class="theme-preview light-preview mb-2"></div>
                                                                <i class="fas fa-sun mb-2" style="font-size: 1.5rem; color: #ffc107;"></i>
                                                                <div data-translate="light_mode">Light Mode</div>
                                                                <small class="text-muted" data-translate="light_mode_desc">Clean and bright interface</small>
                                                            </label>
                                                        </div>
                                                        <div class="col-6">
                                                            <input type="radio" class="btn-check" name="theme_mode" id="dark_mode" value="dark"
                                                                   <?php echo ($themeSettings['theme_mode'] ?? 'dark') === 'dark' ? 'checked' : ''; ?>>
                                                            <label class="btn btn-outline-primary w-100 theme-mode-card" for="dark_mode">
                                                                <div class="theme-preview dark-preview mb-2"></div>
                                                                <i class="fas fa-moon mb-2" style="font-size: 1.5rem; color: #8b5cf6;"></i>
                                                                <div data-translate="dark_mode">Dark Mode</div>
                                                                <small class="text-muted" data-translate="dark_mode_desc">Easy on the eyes</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Quick Theme Switch -->
                                            <div class="mb-4">
                                                <h6 class="mb-3" data-translate="quick_actions">Quick Actions</h6>
                                                <div class="d-flex gap-2">
                                                    <button type="button" class="btn btn-sm btn-outline-warning" id="testLightTheme">
                                                        <i class="fas fa-sun me-1"></i>
                                                        <span data-translate="test_light">Test Light</span>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-info" id="testDarkTheme">
                                                        <i class="fas fa-moon me-1"></i>
                                                        <span data-translate="test_dark">Test Dark</span>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-success" id="applyThemeNow">
                                                        <i class="fas fa-check me-1"></i>
                                                        <span data-translate="apply_now">Apply Now</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Color Presets -->
                                        <div class="col-md-6">
                                            <h5 class="mb-3" data-translate="color_presets">Color Presets</h5>

                                            <div class="color-presets mb-4">
                                                <div class="row g-2">
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn active" data-preset="default">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #21243A;"></span>
                                                                <span class="color-dot" style="background: #2A2D35;"></span>
                                                                <span class="color-dot" style="background: #007bff;"></span>
                                                            </div>
                                                            <small>Default</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="ocean">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #0f172a;"></span>
                                                                <span class="color-dot" style="background: #1e293b;"></span>
                                                                <span class="color-dot" style="background: #0ea5e9;"></span>
                                                            </div>
                                                            <small>Ocean</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="forest">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #0f1419;"></span>
                                                                <span class="color-dot" style="background: #1a2e1a;"></span>
                                                                <span class="color-dot" style="background: #10b981;"></span>
                                                            </div>
                                                            <small>Forest</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="sunset">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1a0f0a;"></span>
                                                                <span class="color-dot" style="background: #2d1b1b;"></span>
                                                                <span class="color-dot" style="background: #f97316;"></span>
                                                            </div>
                                                            <small>Sunset</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="royal">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1e1065;"></span>
                                                                <span class="color-dot" style="background: #312e81;"></span>
                                                                <span class="color-dot" style="background: #8b5cf6;"></span>
                                                            </div>
                                                            <small>Royal</small>
                                                        </button>
                                                    </div>
                                                    <div class="col-4">
                                                        <button type="button" class="btn btn-sm w-100 color-preset-btn" data-preset="crimson">
                                                            <div class="color-preview-row">
                                                                <span class="color-dot" style="background: #1a0a0a;"></span>
                                                                <span class="color-dot" style="background: #2d1b1b;"></span>
                                                                <span class="color-dot" style="background: #ef4444;"></span>
                                                            </div>
                                                            <small>Crimson</small>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Custom Colors -->
                                    <div class="row mt-4">
                                        <div class="col-12">
                                            <h5 class="mb-3" data-translate="custom_colors">Custom Colors</h5>

                                            <div class="row g-3">
                                                <!-- Primary Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="primary_colors">Primary Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="primary_color">Primary Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="primary_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['primary_color'] ?? '#007bff'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['primary_color'] ?? '#007bff'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="secondary_color">Secondary Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="secondary_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['secondary_color'] ?? '#6c757d'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['secondary_color'] ?? '#6c757d'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="accent_color">Accent Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="accent_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['accent_color'] ?? '#17a2b8'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['accent_color'] ?? '#17a2b8'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Background Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="background_colors">Background Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="background_color">Background Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="background_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['background_color'] ?? '#21243A'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['background_color'] ?? '#21243A'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="sidebar_color">Sidebar Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="sidebar_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['sidebar_color'] ?? '#2A2D35'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['sidebar_color'] ?? '#2A2D35'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="text_color">Text Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="text_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['text_color'] ?? '#ffffff'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['text_color'] ?? '#ffffff'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Status Colors -->
                                                <div class="col-md-4">
                                                    <h6 class="mb-3" data-translate="status_colors">Status Colors</h6>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="success_color">Success Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="success_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['success_color'] ?? '#28a745'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['success_color'] ?? '#28a745'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="warning_color">Warning Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="warning_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['warning_color'] ?? '#ffc107'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['warning_color'] ?? '#ffc107'); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label" data-translate="danger_color">Danger Color</label>
                                                        <div class="color-input-group">
                                                            <input type="color" class="form-control form-control-color" name="danger_color"
                                                                   value="<?php echo htmlspecialchars($themeSettings['danger_color'] ?? '#dc3545'); ?>">
                                                            <input type="text" class="form-control color-hex"
                                                                   value="<?php echo htmlspecialchars($themeSettings['danger_color'] ?? '#dc3545'); ?>" readonly>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Theme Preview -->
                                    <div class="mt-4">
                                        <h5 class="mb-3" data-translate="theme_preview">Theme Preview</h5>
                                        <div class="theme-preview-container" id="themePreview">
                                            <div class="preview-sidebar">
                                                <div class="preview-logo">BitsTech POS</div>
                                                <div class="preview-menu-item active">Dashboard</div>
                                                <div class="preview-menu-item">Inventory</div>
                                                <div class="preview-menu-item">Reports</div>
                                            </div>
                                            <div class="preview-content">
                                                <div class="preview-header">
                                                    <h6>Dashboard</h6>
                                                    <div class="preview-buttons">
                                                        <span class="preview-btn preview-btn-primary">Primary</span>
                                                        <span class="preview-btn preview-btn-success">Success</span>
                                                        <span class="preview-btn preview-btn-warning">Warning</span>
                                                        <span class="preview-btn preview-btn-danger">Danger</span>
                                                    </div>
                                                </div>
                                                <div class="preview-cards">
                                                    <div class="preview-card">
                                                        <div class="preview-card-title">Total Sales</div>
                                                        <div class="preview-card-value">$12,345</div>
                                                    </div>
                                                    <div class="preview-card">
                                                        <div class="preview-card-title">Products</div>
                                                        <div class="preview-card-value">1,234</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <small class="text-muted mt-2 d-block" data-translate="theme_preview_help">
                                            This preview shows how your theme will look across the system
                                        </small>
                                    </div>

                                    <!-- Reset Theme -->
                                    <div class="mt-4 pt-3 border-top">
                                        <button type="button" class="btn btn-outline-secondary" id="resetTheme">
                                            <i class="fas fa-undo me-2"></i>
                                            <span data-translate="reset_theme">Reset to Default Theme</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Save Button -->
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" class="btn btn-save" onclick="saveSettings()">
                            <i class="fas fa-save"></i>
                            <span data-translate="save_settings">Save Settings</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="../public/js/theme-manager.js"></script>
    <script>
        // Pass PHP theme settings to JavaScript
        window.phpThemeSettings = <?php echo json_encode($themeSettings); ?>;
        console.log('🎨 PHP Theme Settings loaded:', window.phpThemeSettings);



        // Make current language available to JavaScript
        window.currentLanguage = '<?php echo $language; ?>';

        // Theme translations for JavaScript
        window.themeTranslations = {
            'en': {
                'theme_applied': 'Theme Applied!',
                'theme_applied_desc': 'Theme settings have been applied successfully.',
                'light_mode': 'Light Mode',
                'dark_mode': 'Dark Mode',
                'test_light': 'Test Light',
                'test_dark': 'Test Dark',
                'apply_now': 'Apply Now',
                'applied': 'Applied!',
                'quick_actions': 'Quick Actions',
                'theme_settings': 'Theme Settings',
                'theme_settings_desc': 'Customize the appearance and colors of your POS system',
                'light_mode_desc': 'Clean and bright interface',
                'dark_mode_desc': 'Easy on the eyes'
            },
            'mm': {
                'theme_applied': 'Theme လုပ်ပြီးပါပြီ!',
                'theme_applied_desc': 'Theme ဆက်တင်များကို အောင်မြင်စွာ အသုံးပြုပြီးပါပြီ။',
                'light_mode': 'အလင်းရောင် Mode',
                'dark_mode': 'အမှောင်ရောင် Mode',
                'test_light': 'အလင်းရောင် စမ်းကြည့်ရန်',
                'test_dark': 'အမှောင်ရောင် စမ်းကြည့်ရန်',
                'apply_now': 'ယခုပင် အသုံးပြုရန်',
                'applied': 'အသုံးပြုပြီး!',
                'quick_actions': 'မြန်ဆန်သော လုပ်ဆောင်ချက်များ',
                'theme_settings': 'Theme ဆက်တင်များ',
                'theme_settings_desc': 'သင့် POS စနစ်၏ အသွင်အပြင်နှင့် အရောင်များကို စိတ်ကြိုက်ပြင်ဆင်ပါ',
                'light_mode_desc': 'သန့်ရှင်းပြီး တောက်ပသော interface',
                'dark_mode_desc': 'မျက်လုံးအတွက် သက်သာသော'
            }
        };

        // Get translation function
        function getTranslation(key) {
            const lang = window.currentLanguage || 'en';
            return window.themeTranslations[lang] && window.themeTranslations[lang][key]
                ? window.themeTranslations[lang][key]
                : window.themeTranslations['en'][key] || key;
        }
    </script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true
        });

        // Update theme preview
        function updateThemePreview() {
            console.log('🎨 Updating theme preview...');

            const mode = $('input[name="theme_mode"]:checked').val() || 'dark';
            const primaryColor = $('input[name="primary_color"]').val() || '#007bff';
            const successColor = $('input[name="success_color"]').val() || '#28a745';
            const warningColor = $('input[name="warning_color"]').val() || '#ffc107';
            const dangerColor = $('input[name="danger_color"]').val() || '#dc3545';

            // Set different backgrounds based on theme mode
            let backgroundColor, sidebarColor;
            if (mode === 'light') {
                backgroundColor = '#f8f9fa'; // Light gray background for light mode
                sidebarColor = '#ffffff';   // White sidebar for light mode
            } else {
                backgroundColor = $('input[name="background_color"]').val() || '#21243A'; // Dark background
                sidebarColor = $('input[name="sidebar_color"]').val() || '#2A2D35';      // Dark sidebar
            }

            const preview = $('#themePreview');
            if (preview.length) {
                const textColor = '#ffffff'; // Always use white text in preview

                // Update preview container with mode-specific background
                preview.css({
                    'background': backgroundColor,
                    'color': textColor
                });

                // Update preview sidebar with mode-specific background
                preview.find('.preview-sidebar').css({
                    'background': sidebarColor,
                    'color': textColor
                });

                // Update preview content with mode-specific background
                preview.find('.preview-content').css({
                    'background': backgroundColor,
                    'color': textColor
                });

                // Update all text elements in preview - always white
                preview.find('.preview-logo, .preview-menu-item, .preview-header h6, .preview-card-title').css('color', textColor);

                // Update preview buttons
                preview.find('.preview-btn-primary').css('background', primaryColor);
                preview.find('.preview-btn-success').css('background', successColor);
                preview.find('.preview-btn-warning').css('background', warningColor);
                preview.find('.preview-btn-danger').css('background', dangerColor);

                // Update preview card values - always white
                preview.find('.preview-card-value').css({
                    'color': '#ffffff',
                    'font-weight': 'bold'
                });

                // Update preview cards based on mode
                if (mode === 'light') {
                    preview.find('.preview-card').css({
                        'background': 'rgba(255,255,255,0.8)',
                        'border': '1px solid #e9ecef',
                        'box-shadow': '0 2px 8px rgba(0,0,0,0.1)'
                    });
                } else {
                    preview.find('.preview-card').css({
                        'background': 'rgba(255,255,255,0.05)',
                        'border': '1px solid rgba(255,255,255,0.1)',
                        'box-shadow': 'none'
                    });
                }

                // Update active menu item
                preview.find('.preview-menu-item.active').css('background', primaryColor);

                console.log('🎨 Theme preview updated successfully for', mode, 'mode');
            }
        }

        // Logo preview function
        function previewLogo(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#logoPreview').attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Initialize preview and theme
        $(document).ready(function() {
            console.log('🎨 Initializing theme settings page...');

            // Apply current theme mode to page
            const currentMode = $('input[name="theme_mode"]:checked').val() || 'dark';
            applyThemeModeToPage(currentMode);

            // Apply current colors to page
            $('input[type="color"]').each(function() {
                const colorName = $(this).attr('name');
                const colorValue = $(this).val();
                if (colorName && colorValue) {
                    applyColorToPage(colorName, colorValue);
                }
            });

            // Update theme preview
            updateThemePreview();

            // Update preview on color change
            $('input[type="color"]').on('input change', function() {
                const colorName = $(this).attr('name');
                const colorValue = $(this).val();

                // Update hex display
                $(this).siblings('.color-hex').val(colorValue);

                // Apply color and update preview
                applyColorToPage(colorName, colorValue);
                updateThemePreview();
            });

            // Update preview on theme mode change
            $('input[name="theme_mode"]').on('change', function() {
                const mode = $(this).val();
                applyThemeModeToPage(mode);
                updateThemePreview();
            });

            console.log('🎨 Theme settings page initialized');
        });

        function saveSettings() {
            // Show loading state
            const saveBtn = $('.btn-save');
            const originalText = saveBtn.html();
            saveBtn.html('<i class="fas fa-spinner fa-spin"></i> <span data-translate="saving">Saving...</span>');
            saveBtn.prop('disabled', true);

            // Create FormData for file upload
            const formData = new FormData();
            formData.append('action', 'save_settings');
            formData.append('site_name', $('input[name="site_name"]').val());
            formData.append('timezone', $('select[name="timezone"]').val());
            formData.append('language', $('select[name="language"]').val());
            formData.append('currency', $('select[name="currency"]').val());
            formData.append('date_format', $('select[name="date_format"]').val());
            formData.append('email_host', $('input[name="email_host"]').val());
            formData.append('email_port', $('input[name="email_port"]').val());
            formData.append('email_username', $('input[name="email_username"]').val());
            formData.append('email_password', $('input[name="email_password"]').val());
            formData.append('email_from', $('input[name="email_from"]').val());
            formData.append('backup_enabled', $('input[name="backup_enabled"]').is(':checked') ? 'true' : 'false');
            formData.append('backup_frequency', $('select[name="backup_frequency"]').val());

            // Add theme settings
            formData.append('theme_mode', $('input[name="theme_mode"]:checked').val());

            // Add all color settings
            formData.append('primary_color', $('input[name="primary_color"]').val());
            formData.append('secondary_color', $('input[name="secondary_color"]').val());
            formData.append('accent_color', $('input[name="accent_color"]').val());
            formData.append('background_color', $('input[name="background_color"]').val());
            formData.append('sidebar_color', $('input[name="sidebar_color"]').val());
            formData.append('text_color', $('input[name="text_color"]').val());
            formData.append('success_color', $('input[name="success_color"]').val());
            formData.append('warning_color', $('input[name="warning_color"]').val());
            formData.append('danger_color', $('input[name="danger_color"]').val());

            // Add notification settings
            formData.append('notifications_enabled', $('input[name="notifications_enabled"]').is(':checked') ? 'true' : 'false');
            formData.append('low_stock_notifications', $('input[name="low_stock_notifications"]').is(':checked') ? 'true' : 'false');
            formData.append('sales_notifications', $('input[name="sales_notifications"]').is(':checked') ? 'true' : 'false');
            formData.append('system_notifications', $('input[name="system_notifications"]').is(':checked') ? 'true' : 'false');

            // Add footer settings
            formData.append('store_address', $('textarea[name="store_address"]').val());
            formData.append('store_email', $('input[name="store_email"]').val());
            formData.append('store_phone', $('input[name="store_phone"]').val());
            formData.append('footer_copyright', $('input[name="footer_copyright"]').val());
            formData.append('privacy_policy_url', $('input[name="privacy_policy_url"]').val());
            formData.append('terms_of_service_url', $('input[name="terms_of_service_url"]').val());

            // Add theme settings
            formData.append('theme_mode', $('input[name="theme_mode"]:checked').val());
            formData.append('primary_color', $('input[name="primary_color"]').val());
            formData.append('secondary_color', $('input[name="secondary_color"]').val());
            formData.append('accent_color', $('input[name="accent_color"]').val());
            formData.append('background_color', $('input[name="background_color"]').val());
            formData.append('sidebar_color', $('input[name="sidebar_color"]').val());
            formData.append('text_color', $('input[name="text_color"]').val());
            formData.append('success_color', $('input[name="success_color"]').val());
            formData.append('warning_color', $('input[name="warning_color"]').val());
            formData.append('danger_color', $('input[name="danger_color"]').val());
            formData.append('info_color', $('input[name="info_color"]').val() || '#17a2b8');

            // Add logo file if selected
            const logoFile = $('#logoUpload')[0].files[0];
            if (logoFile) {
                formData.append('site_logo', logoFile);
            }

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log('🔍 AJAX Response:', response);
                    console.log('🔍 Response type:', typeof response);
                    console.log('🔍 Updated settings:', response.updated_settings);

                    if (response.success) {
                        showSuccessMessage(response.message);

                        // Update navbar with new site name if changed
                        if (response.updated_settings && response.updated_settings.site_name) {
                            console.log('🏢 Settings: Site name changed to:', response.updated_settings.site_name);

                            // Force update navbar immediately
                            const newName = response.updated_settings.site_name;

                            // Update all possible selectors
                            $('.system-name').text(newName);
                            $('.brand-text').text(newName);
                            $('.navbar-brand .brand-text').text(newName);
                            $('[data-translate="system_name"]').text(newName);

                            console.log('🏢 Force updated navbar elements with:', newName);

                            // Update local function
                            updateNavbarSiteName(newName);

                            // Update global function if available
                            if (typeof window.updateNavbarSiteName === 'function') {
                                window.updateNavbarSiteName(newName);
                            }

                            // Update the input field to show the saved value
                            $('input[name="site_name"]').val(response.updated_settings.site_name);

                            // Show visual feedback
                            $('input[name="site_name"]').addClass('updated-field');
                            setTimeout(() => {
                                $('input[name="site_name"]').removeClass('updated-field');
                            }, 2000);
                        } else {
                            // If site_name not in response, check if it was in the form data
                            const formSiteName = $('input[name="site_name"]').val();
                            if (formSiteName && formSiteName.trim() !== '') {
                                console.log('🏢 Site name not in response, using form value:', formSiteName);

                                // Force update with form value
                                $('.system-name').text(formSiteName);
                                $('.brand-text').text(formSiteName);
                                $('.navbar-brand .brand-text').text(formSiteName);
                                $('[data-translate="system_name"]').text(formSiteName);

                                // Update functions
                                updateNavbarSiteName(formSiteName);
                                if (typeof window.updateNavbarSiteName === 'function') {
                                    window.updateNavbarSiteName(formSiteName);
                                }

                                console.log('🏢 Force updated navbar with form value:', formSiteName);
                            }
                        }

                        // Update navbar with new logo if changed
                        if (response.updated_settings && response.updated_settings.site_logo) {
                            if (typeof window.updateNavbarLogo === 'function') {
                                window.updateNavbarLogo('../' + response.updated_settings.site_logo);
                            }
                        }

                        // Update navbar datetime if timezone changed
                        if (response.updated_settings && response.updated_settings.timezone) {
                            if (typeof window.updateNavbarDateTime === 'function') {
                                window.updateNavbarDateTime(response.updated_settings.timezone);
                            }
                        }

                        // Update language if changed
                        if (response.updated_settings && response.updated_settings.language) {
                            if (typeof window.switchLanguage === 'function') {
                                window.switchLanguage(response.updated_settings.language, false); // false = no page refresh
                            }
                        }

                        // Update currency if changed
                        if (response.updated_settings && response.updated_settings.currency) {
                            if (typeof window.switchCurrency === 'function') {
                                window.switchCurrency(response.updated_settings.currency, false); // false = no page refresh
                            }
                        }

                        // Update datetime if date format changed
                        if (response.updated_settings && response.updated_settings.date_format) {
                            if (typeof window.updateNavbarDateFormat === 'function') {
                                // Update navbar with new date format
                                window.updateNavbarDateFormat();
                            }
                        }

                        // Handle automatic backup settings changes
                        if (formData.has('backup_enabled')) {
                            const enabled = formData.get('backup_enabled') === 'true';
                            localStorage.setItem('autoBackupEnabled', enabled);
                            console.log('🤖 Auto backup enabled setting updated:', enabled);

                            // Restart auto backup monitor if it exists
                            if (window.autoBackupMonitor) {
                                window.autoBackupMonitor.checkAndStart();
                            }
                        }

                        if (formData.has('backup_frequency')) {
                            const frequency = formData.get('backup_frequency');
                            localStorage.setItem('autoBackupFrequency', frequency);
                            console.log('🤖 Auto backup frequency updated:', frequency);

                            // Restart auto backup monitor if it exists
                            if (window.autoBackupMonitor) {
                                window.autoBackupMonitor.checkAndStart();
                            }
                        }

                        // Handle notification settings changes
                        if (formData.has('notifications_enabled')) {
                            const enabled = formData.get('notifications_enabled') === 'true';
                            localStorage.setItem('notificationsEnabled', enabled.toString());
                            console.log('🔔 Notifications enabled setting updated:', enabled);

                            // Update notification system if it exists
                            if (window.notificationManager) {
                                window.notificationManager.setEnabled(enabled);
                            }
                        }

                        // Handle specific notification type settings
                        ['low_stock_notifications', 'sales_notifications', 'system_notifications'].forEach(type => {
                            if (formData.has(type)) {
                                const enabled = formData.get(type) === 'true';
                                localStorage.setItem(type, enabled.toString());
                                console.log(`🔔 ${type} setting updated:`, enabled);

                                // Update notification system if it exists
                                if (window.notificationManager) {
                                    window.notificationManager.setTypeEnabled(type, enabled);
                                }
                            }
                        });

                        // Trigger notification settings change event
                        $(document).trigger('notificationSettingsChanged', {
                            enabled: formData.has('notifications_enabled') ? formData.get('notifications_enabled') === 'true' : undefined,
                            types: {
                                low_stock_notifications: formData.has('low_stock_notifications') ? formData.get('low_stock_notifications') === 'true' : undefined,
                                sales_notifications: formData.has('sales_notifications') ? formData.get('sales_notifications') === 'true' : undefined,
                                system_notifications: formData.has('system_notifications') ? formData.get('system_notifications') === 'true' : undefined
                            }
                        });

                        // Update notification bell visibility
                        if (typeof window.updateNotificationBellVisibility === 'function') {
                            window.updateNotificationBellVisibility();
                        }

                        // Update footer if footer settings changed
                        const footerSettings = ['store_address', 'store_email', 'store_phone', 'footer_copyright'];
                        const footerData = {};
                        let hasFooterChanges = false;

                        footerSettings.forEach(setting => {
                            if (response.updated_settings && response.updated_settings[setting]) {
                                footerData[setting] = response.updated_settings[setting];
                                hasFooterChanges = true;
                            }
                        });

                        if (hasFooterChanges && typeof window.updateFooterInfo === 'function') {
                            console.log('🦶 Updating footer with new settings:', footerData);
                            window.updateFooterInfo(footerData);
                        }

                        // Update theme if theme settings changed
                        const themeSettings = ['theme_mode', 'primary_color', 'secondary_color', 'accent_color',
                                             'background_color', 'sidebar_color', 'text_color', 'success_color',
                                             'warning_color', 'danger_color', 'info_color'];
                        const themeData = {};
                        let hasThemeChanges = false;

                        themeSettings.forEach(setting => {
                            if (response.updated_settings && response.updated_settings[setting]) {
                                themeData[setting] = response.updated_settings[setting];
                                hasThemeChanges = true;
                            }
                        });

                        if (hasThemeChanges && typeof window.themeManager !== 'undefined') {
                            console.log('🎨 Updating theme with new settings:', themeData);

                            // Update theme mode if changed
                            if (themeData.theme_mode) {
                                window.themeManager.setThemeMode(themeData.theme_mode);
                            }

                            // Update colors if changed
                            const colorUpdates = {};
                            Object.keys(themeData).forEach(key => {
                                if (key !== 'theme_mode') {
                                    colorUpdates[key] = themeData[key];
                                }
                            });

                            if (Object.keys(colorUpdates).length > 0) {
                                window.themeManager.setColors(colorUpdates);
                            }

                            // Trigger theme change event for other components
                            window.dispatchEvent(new CustomEvent('themeChanged', {
                                detail: {
                                    mode: themeData.theme_mode,
                                    colors: colorUpdates
                                }
                            }));
                        }

                        // Broadcast settings change to other tabs/windows
                        if (response.updated_settings.site_name) {
                            // Use localStorage to communicate with other tabs
                            localStorage.setItem('system_name_updated', JSON.stringify({
                                name: response.updated_settings.site_name,
                                timestamp: Date.now()
                            }));

                            // Remove after 5 seconds to prevent stale data
                            setTimeout(() => {
                                localStorage.removeItem('system_name_updated');
                            }, 5000);
                        }

                        // No page reload needed - all updates are done dynamically
                        console.log('✅ Settings saved successfully without page refresh');
                    } else {
                        showErrorMessage(response.message || 'Failed to save settings');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    // Reset button state
                    saveBtn.html(originalText);
                    saveBtn.prop('disabled', false);
                }
            });
        }

        // Function to update navbar site name
        function updateNavbarSiteName(newName) {
            console.log('🏢 Settings: Updating navbar site name to:', newName);

            // Update all possible site name elements
            $('.navbar-brand .brand-text').text(newName);
            $('.system-name').text(newName);
            $('.brand-text').text(newName);

            // Update page title if it contains the old name
            const currentTitle = document.title;
            if (currentTitle.includes('BitsTech')) {
                document.title = currentTitle.replace(/BitsTech[^-]*/, newName + ' ');
            }

            // Update session storage for immediate effect
            if (typeof(Storage) !== "undefined") {
                sessionStorage.setItem('system_name', newName);
            }

            console.log('🏢 Settings: Site name updated successfully');
        }

        // Global function to update navbar datetime with new timezone
        window.updateNavbarDateTime = function(timezone) {
            console.log('🕐 Updating navbar datetime with timezone:', timezone);

            // Make AJAX request to get updated datetime
            $.ajax({
                url: '../includes/get_datetime.php',
                type: 'POST',
                data: { timezone: timezone },
                dataType: 'json',
                success: function(response) {
                    if (response && response.success) {
                        $('.datetime').text(response.datetime);
                        console.log('🕐 Navbar datetime updated:', response.datetime);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🕐 Failed to update navbar datetime:', error);
                }
            });
        };

        function testEmail() {
            const btn = $('.btn-test').first();
            const originalText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i> <span data-translate="testing">Testing...</span>');
            btn.prop('disabled', true);

            // Get current email settings from form
            const emailData = {
                action: 'test_email',
                email_host: $('input[name="email_host"]').val(),
                email_port: $('input[name="email_port"]').val(),
                email_username: $('input[name="email_username"]').val(),
                email_password: $('input[name="email_password"]').val(),
                email_from: $('input[name="email_from"]').val()
            };

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: emailData,
                success: function(response) {
                    if (response.success) {
                        showSuccessMessage(response.message || window.translations?.test_email_sent || 'Test email sent successfully');
                    } else {
                        showErrorMessage(response.message || window.translations?.failed_send_test_email || 'Failed to send test email');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    btn.html(originalText);
                    btn.prop('disabled', false);
                }
            });
        }

        function backupNow() {
            const btn = $('button[onclick="backupNow()"]');
            const originalText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i> <span data-translate="backing_up">Backing up...</span>');
            btn.prop('disabled', true);

            console.log('🗄️ Starting backup process...');

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: { action: 'backup_database' },
                dataType: 'json',
                timeout: 30000, // 30 second timeout
                beforeSend: function() {
                    console.log('🗄️ Sending backup request...');
                },
                success: function(response) {
                    console.log('🗄️ Backup response:', response);
                    if (response && response.success) {
                        let message = response.message;
                        if (response.filename && response.size) {
                            message += `\n📁 File: ${response.filename}\n📊 Size: ${response.size}`;
                        }
                        showSuccessMessage(message);

                        // Refresh backup list if it's loaded
                        if ($('#backupList .backup-item').length > 0) {
                            loadBackupList();
                        }
                    } else {
                        console.error('🗄️ Backup failed:', response);
                        showErrorMessage(response.message || 'Failed to create backup');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🗄️ Backup AJAX error:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText,
                        readyState: xhr.readyState,
                        statusText: xhr.statusText
                    });

                    let errorMessage = 'An error occurred while creating backup';
                    try {
                        const response = JSON.parse(xhr.responseText);
                        errorMessage = response.message || errorMessage;
                    } catch (e) {
                        console.error('🗄️ Error parsing error response:', e);
                        if (xhr.responseText) {
                            errorMessage = 'Server error: ' + xhr.responseText.substring(0, 100);
                        }
                    }

                    showErrorMessage(errorMessage);
                },
                complete: function() {
                    console.log('🗄️ Backup request completed');
                    btn.html(originalText);
                    btn.prop('disabled', false);
                }
            });
        }

        function loadBackupList() {
            const btn = $('button[onclick="loadBackupList()"]');
            const originalText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i> Loading...');
            btn.prop('disabled', true);

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: { action: 'list_backups' },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        displayBackupList(response.backups);
                    } else {
                        showErrorMessage(response.message || 'Failed to load backup list');
                    }
                },
                error: handleAjaxError,
                complete: function() {
                    btn.html(originalText);
                    btn.prop('disabled', false);
                }
            });
        }

        function displayBackupList(backups) {
            const backupList = $('#backupList');

            if (backups.length === 0) {
                backupList.html(`
                    <div class="text-center text-muted">
                        <i class="fas fa-database fa-2x mb-2"></i>
                        <p data-translate="no_backups_found">No backups found</p>
                    </div>
                `);
                return;
            }

            let html = '<div class="backup-items">';
            backups.forEach(backup => {
                html += `
                    <div class="backup-item">
                        <div class="backup-info">
                            <div class="backup-name">
                                <i class="fas fa-file-archive"></i>
                                ${backup.filename}
                            </div>
                            <div class="backup-details">
                                <span class="backup-date">
                                    <i class="fas fa-calendar"></i>
                                    ${backup.date}
                                </span>
                                <span class="backup-size">
                                    <i class="fas fa-hdd"></i>
                                    ${backup.size}
                                </span>
                            </div>
                        </div>
                        <div class="backup-actions">
                            <button class="btn btn-sm btn-outline-primary me-2" onclick="downloadBackup('${backup.filename}')">
                                <i class="fas fa-download"></i>
                                Download
                            </button>
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteBackup('${backup.filename}')">
                                <i class="fas fa-trash"></i>
                                Delete
                            </button>
                        </div>
                    </div>
                `;
            });
            html += '</div>';

            backupList.html(html);
        }

        function downloadBackup(filename) {
            // Create a form to download the backup file
            const form = $('<form>', {
                method: 'POST',
                action: 'settings.php',
                style: 'display: none;'
            });

            form.append($('<input>', {
                type: 'hidden',
                name: 'action',
                value: 'download_backup'
            }));

            form.append($('<input>', {
                type: 'hidden',
                name: 'filename',
                value: filename
            }));

            $('body').append(form);
            form.submit();
            form.remove();
        }



        function checkAutoBackupStatus() {
            const btn = $('button[onclick="checkAutoBackupStatus()"]');
            const originalText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i> <span data-translate="checking">Checking...</span>');
            btn.prop('disabled', true);

            console.log('📊 Checking auto backup status...');

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: { action: 'check_auto_backup_status' },
                dataType: 'json',
                success: function(response) {
                    console.log('📊 Auto backup status:', response);
                    if (response && response.success) {
                        displayAutoBackupStatus(response);
                    } else {
                        showErrorMessage('Failed to check automatic backup status');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('📊 Status check error:', error);
                    showErrorMessage('An error occurred while checking backup status');
                },
                complete: function() {
                    btn.html(originalText);
                    btn.prop('disabled', false);
                }
            });
        }

        function displayAutoBackupStatus(status) {
            const statusContainer = $('#autoBackupStatus');

            let html = '<div class="auto-backup-info">';

            // Status overview
            html += '<div class="status-overview mb-3">';
            html += '<div class="row">';

            // Enabled status
            html += '<div class="col-md-3">';
            html += '<div class="status-card">';
            html += '<div class="status-icon">';
            if (status.enabled) {
                html += '<i class="fas fa-check-circle text-success"></i>';
            } else {
                html += '<i class="fas fa-times-circle text-danger"></i>';
            }
            html += '</div>';
            html += '<div class="status-text">';
            html += '<strong>Status</strong><br>';
            html += status.enabled ? 'Enabled' : 'Disabled';
            html += '</div>';
            html += '</div>';
            html += '</div>';

            // Frequency
            html += '<div class="col-md-3">';
            html += '<div class="status-card">';
            html += '<div class="status-icon">';
            html += '<i class="fas fa-clock text-info"></i>';
            html += '</div>';
            html += '<div class="status-text">';
            html += '<strong>Frequency</strong><br>';
            html += status.frequency.charAt(0).toUpperCase() + status.frequency.slice(1);
            html += '</div>';
            html += '</div>';
            html += '</div>';

            // Last backup
            html += '<div class="col-md-3">';
            html += '<div class="status-card">';
            html += '<div class="status-icon">';
            html += '<i class="fas fa-history text-warning"></i>';
            html += '</div>';
            html += '<div class="status-text">';
            html += '<strong>Last Backup</strong><br>';
            html += status.last_backup ? status.last_backup : 'Never';
            html += '</div>';
            html += '</div>';
            html += '</div>';

            // Next backup
            html += '<div class="col-md-3">';
            html += '<div class="status-card">';
            html += '<div class="status-icon">';
            if (status.is_due) {
                html += '<i class="fas fa-exclamation-triangle text-danger"></i>';
            } else {
                html += '<i class="fas fa-calendar-alt text-primary"></i>';
            }
            html += '</div>';
            html += '<div class="status-text">';
            html += '<strong>Next Backup</strong><br>';
            if (status.is_due) {
                html += '<span class="text-danger">Due Now!</span>';
            } else if (status.next_backup) {
                html += status.next_backup;
            } else {
                html += 'Not scheduled';
            }
            html += '</div>';
            html += '</div>';
            html += '</div>';

            html += '</div>';
            html += '</div>';

            // Cron job instructions
            if (status.enabled) {
                html += '<div class="cron-instructions mt-3">';
                html += '<h6><i class="fas fa-terminal"></i> Cron Job Setup Instructions</h6>';
                html += '<p class="text-muted mb-2" style="color: #ffffff !important;">To enable automatic backups, add this cron job to your server:</p>';

                let cronExpression = '';
                switch (status.frequency) {
                    case 'daily':
                        cronExpression = '0 2 * * *';
                        break;
                    case 'weekly':
                        cronExpression = '0 3 * * 0';
                        break;
                    case 'monthly':
                        cronExpression = '0 4 1 * *';
                        break;
                }

                html += '<div class="cron-command">';
                html += '<code>' + cronExpression + ' /usr/bin/php ' + window.location.origin + window.location.pathname.replace('/pages/settings.php', '') + '/cron_backup.php</code>';
                html += '<button class="btn btn-sm btn-outline-secondary ms-2" onclick="copyCronCommand(this)"><i class="fas fa-copy"></i> Copy</button>';
                html += '</div>';
                html += '<small class="text-muted" style="color: #ffffff !important;">Adjust the path according to your server configuration.</small>';
                html += '</div>';
            }

            html += '</div>';

            statusContainer.html(html);
        }

        function copyCronCommand(button) {
            const code = $(button).siblings('code').text();
            navigator.clipboard.writeText(code).then(function() {
                $(button).html('<i class="fas fa-check"></i> Copied!');
                setTimeout(() => {
                    $(button).html('<i class="fas fa-copy"></i> Copy');
                }, 2000);
            });
        }

        function deleteBackup(filename) {
            console.log('🗑️ Delete backup requested for:', filename);

            // Show confirmation dialog
            Swal.fire({
                title: 'Delete Backup?',
                text: `Are you sure you want to delete "${filename}"? This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log('🗑️ User confirmed deletion');

                    // Show loading state
                    Swal.fire({
                        title: 'Deleting...',
                        text: 'Please wait while the backup file is being deleted.',
                        icon: 'info',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    console.log('🗑️ Sending delete request...');

                    // Send delete request
                    $.ajax({
                        url: 'settings.php',
                        type: 'POST',
                        data: {
                            action: 'delete_backup',
                            filename: filename
                        },
                        dataType: 'json',
                        timeout: 10000,
                        beforeSend: function() {
                            console.log('🗑️ Delete request sent for:', filename);
                        },
                        success: function(response) {
                            console.log('🗑️ Delete response:', response);

                            if (response && response.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: response.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });

                                // Refresh backup list
                                console.log('🗑️ Refreshing backup list...');
                                loadBackupList();
                            } else {
                                console.error('🗑️ Delete failed:', response);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Delete Failed',
                                    text: response.message || 'Failed to delete backup file'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('🗑️ Delete AJAX error:', {
                                status: status,
                                error: error,
                                responseText: xhr.responseText,
                                readyState: xhr.readyState,
                                statusText: xhr.statusText
                            });

                            let errorMessage = 'An error occurred while deleting backup';
                            try {
                                const response = JSON.parse(xhr.responseText);
                                errorMessage = response.message || errorMessage;
                            } catch (e) {
                                console.error('🗑️ Error parsing error response:', e);
                                if (xhr.responseText) {
                                    errorMessage = 'Server error: ' + xhr.responseText.substring(0, 100);
                                }
                            }

                            Swal.fire({
                                icon: 'error',
                                title: 'Delete Failed',
                                text: errorMessage
                            });
                        }
                    });
                } else {
                    console.log('🗑️ User cancelled deletion');
                }
            });
        }

        function showSuccessMessage(message) {
            Swal.fire({
                icon: 'success',
                title: window.translations?.success || 'Success',
                text: message,
                timer: 2000,
                showConfirmButton: false
            });
        }

        function showErrorMessage(message) {
            Swal.fire({
                icon: 'error',
                title: window.translations?.error || 'Error',
                text: message
            });
        }

        function handleAjaxError(xhr, status, error) {
            let errorMessage = window.translations?.an_error_occurred || 'An error occurred';
            try {
                const response = JSON.parse(xhr.responseText);
                errorMessage = response.message || errorMessage;
            } catch (e) {
                console.error('Error parsing error response:', e);
            }

            showErrorMessage(errorMessage);
        }

        // Language switching support - prevent page refresh
        window.updatePageForNewLanguage = function(lang, newTranslations) {
            console.log('🌐 Updating settings page language to:', lang);

            try {
                // Define English fallback translations
                const englishFallbacks = {
                    'settings': 'Settings',
                    'settings_desc': 'Configure system settings and preferences',
                    'general': 'General',
                    'localization': 'Localization',
                    'email': 'Email',
                    'backup': 'Backup',
                    'theme': 'Theme',
                    'general_settings': 'General Settings',
                    'site_logo': 'Site Logo',
                    'system_name': 'System Name',
                    'site_name': 'System Name',
                    'system_name_placeholder': 'Enter your system name',
                    'timezone': 'Timezone',
                    'localization_settings': 'Localization Settings',
                    'language': 'Language',
                    'currency': 'Currency',
                    'date_format': 'Date Format',
                    'email_settings': 'Email Settings',
                    'email_host': 'SMTP Host',
                    'email_port': 'SMTP Port',
                    'email_username': 'SMTP Username',
                    'email_password': 'SMTP Password',
                    'email_from': 'From Address',
                    'test_email': 'Test Email',
                    'backup_settings': 'Backup Settings',
                    'auto_backup': 'Enable Automatic Backup',
                    'backup_frequency': 'Backup Frequency',
                    'backup_now': 'Backup Now',
                    'theme_settings': 'Theme Settings',
                    'theme_color': 'Primary Color',
                    'theme_mode': 'Theme Mode',
                    'save_settings': 'Save Settings',
                    'daily': 'Daily',
                    'weekly': 'Weekly',
                    'monthly': 'Monthly',
                    'dark': 'Dark',
                    'light': 'Light',
                    'date_format': 'Date Format',
                    'localization_settings': 'Localization Settings',
                    'language': 'Language',
                    'currency': 'Currency',
                    'loading': 'Loading...',
                    'saving': 'Saving...',
                    'success': 'Success',
                    'error': 'Error',
                    'required': 'Required',
                    'optional': 'Optional',
                    'testing': 'Testing...',
                    'backing_up': 'Backing up...',
                    'test_email_sent': 'Test email sent successfully',
                    'failed_send_test_email': 'Failed to send test email',
                    'failed_create_backup': 'Failed to create backup',
                    'an_error_occurred': 'An error occurred',
                    'configure_system_settings': 'Configure system settings and preferences',
                    'recommended_size': 'Recommended size',
                    'supported_formats': 'Supported formats',
                    'business_name': 'Enter your business name',
                    'appear_navigation': 'This will appear in the navigation bar and system title',
                    'enable_automatic_backup': 'Enable Automatic Backup'
                };

                // Update static text elements
                $('[data-translate]').each(function() {
                    const key = $(this).data('translate');
                    let translation = newTranslations[key];

                    // Use English fallback if translation not found
                    if (!translation && lang === 'en') {
                        translation = englishFallbacks[key];
                    }

                    if (translation) {
                        // Update text content
                        if ($(this).is('input[type="text"], input[type="email"]')) {
                            $(this).attr('placeholder', translation);
                        } else {
                            $(this).text(translation);
                        }
                    }
                });

                // Update placeholder texts specifically
                if (newTranslations.system_name_placeholder || englishFallbacks.system_name_placeholder) {
                    $('input[name="site_name"]').attr('placeholder', newTranslations.system_name_placeholder || englishFallbacks.system_name_placeholder);
                }

                // Update date format dropdown options
                updateDateFormatOptions(lang);

                console.log('🌐 Settings page language updated successfully without refresh');
                return true; // Indicate successful update

            } catch (error) {
                console.error('🌐 Error updating settings page language:', error);
                return false; // Indicate failure, will trigger page refresh
            }
        };

        // Function to update date format dropdown options based on language
        function updateDateFormatOptions(lang) {
            console.log('📅 Updating date format options for language:', lang);

            const dateFormatSelect = $('select[name="date_format"]');
            const currentValue = dateFormatSelect.val();

            // Define date format options for each language
            const dateFormats = {
                'en': {
                    'Y-m-d': new Date().toISOString().split('T')[0] + ' (ISO Format)',
                    'd/m/Y': new Date().toLocaleDateString('en-GB') + ' (European Format)',
                    'm/d/Y': new Date().toLocaleDateString('en-US') + ' (US Format)',
                    'Y/m/d': new Date().getFullYear() + '/' + String(new Date().getMonth() + 1).padStart(2, '0') + '/' + String(new Date().getDate()).padStart(2, '0') + ' (Asian Format)',
                    'F j, Y': new Date().toLocaleDateString('en-US', {year: 'numeric', month: 'long', day: 'numeric'}) + ' (Long Format)',
                    'M j, Y': new Date().toLocaleDateString('en-US', {year: 'numeric', month: 'short', day: 'numeric'}) + ' (Medium Format)',
                    'j F Y': new Date().getDate() + ' ' + new Date().toLocaleDateString('en-US', {month: 'long'}) + ' ' + new Date().getFullYear() + ' (Day Month Year)',
                    'd-m-Y': String(new Date().getDate()).padStart(2, '0') + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-' + new Date().getFullYear() + ' (Dash Format)',
                    'Y.m.d': new Date().getFullYear() + '.' + String(new Date().getMonth() + 1).padStart(2, '0') + '.' + String(new Date().getDate()).padStart(2, '0') + ' (Dot Format)'
                },
                'mm': {
                    'Y-m-d': new Date().toISOString().split('T')[0] + ' (ISO ပုံစံ)',
                    'd/m/Y': new Date().toLocaleDateString('en-GB') + ' (ဥရောပပုံစံ)',
                    'm/d/Y': new Date().toLocaleDateString('en-US') + ' (အမေရိကန်ပုံစံ)',
                    'Y/m/d': new Date().getFullYear() + '/' + String(new Date().getMonth() + 1).padStart(2, '0') + '/' + String(new Date().getDate()).padStart(2, '0') + ' (အာရှပုံစံ)',
                    'F j, Y': new Date().toLocaleDateString('en-US', {year: 'numeric', month: 'long', day: 'numeric'}) + ' (ရှည်လျားသောပုံစံ)',
                    'M j, Y': new Date().toLocaleDateString('en-US', {year: 'numeric', month: 'short', day: 'numeric'}) + ' (အလယ်အလတ်ပုံစံ)',
                    'j F Y': new Date().getDate() + ' ' + new Date().toLocaleDateString('en-US', {month: 'long'}) + ' ' + new Date().getFullYear() + ' (ရက် လ နှစ်)',
                    'd-m-Y': String(new Date().getDate()).padStart(2, '0') + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-' + new Date().getFullYear() + ' (မျဉ်းတွဲပုံစံ)',
                    'Y.m.d': new Date().getFullYear() + '.' + String(new Date().getMonth() + 1).padStart(2, '0') + '.' + String(new Date().getDate()).padStart(2, '0') + ' (အစက်ပုံစံ)'
                }
            };

            const formats = dateFormats[lang] || dateFormats['en'];

            // Clear and rebuild options
            dateFormatSelect.empty();

            Object.entries(formats).forEach(([value, display]) => {
                const option = $('<option></option>')
                    .attr('value', value)
                    .text(display);

                if (value === currentValue) {
                    option.attr('selected', 'selected');
                }

                dateFormatSelect.append(option);
            });

            console.log('📅 Date format options updated for language:', lang);
        }

        // Date format change handler for real-time preview
        $(document).on('change', 'select[name="date_format"]', function() {
            const selectedFormat = $(this).val();
            console.log('📅 Date format changed to:', selectedFormat);

            // Test direct navbar update first
            console.log('📅 Testing direct navbar update...');

            // Direct AJAX call to datetime_handler.php (updated path)
            $.ajax({
                url: '../utilities/datetime_handler.php',
                type: 'POST',
                data: {
                    action: 'update_format',
                    format: selectedFormat
                },
                dataType: 'json',
                success: function(response) {
                    console.log('📅 Direct update response:', response);
                    if (response && response.success) {
                        // Update navbar with new datetime
                        $('.datetime').text(response.datetime);
                        console.log('📅 Navbar updated directly with:', response.datetime);

                        // Add visual feedback
                        $('.datetime').addClass('updated');
                        setTimeout(() => $('.datetime').removeClass('updated'), 1000);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('📅 Direct update failed:', error);

                    // Fallback to original method
                    console.log('📅 Trying fallback method...');
                    updateDateFormatFallback(selectedFormat);
                }
            });
        });

        // Fallback method using update_settings.php
        function updateDateFormatFallback(selectedFormat) {
            $.ajax({
                url: '../includes/update_settings.php',
                type: 'POST',
                data: {
                    date_format: selectedFormat,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                success: function(response) {
                    console.log('📅 Fallback update response:', response);
                    if (response && response.success) {
                        // Try to update navbar
                        if (typeof window.updateNavbarDateFormat === 'function') {
                            window.updateNavbarDateFormat();
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('📅 Fallback update failed:', error);
                }
            });
        }

        // Load notification settings from database
        function loadNotificationSettingsFromDB() {
            return $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: { action: 'get_notification_settings' },
                dataType: 'json'
            });
        }

        // Initialize notification settings display
        function initializeNotificationSettings() {
            console.log('🔔 Initializing notification settings...');

            // First try to load from database
            loadNotificationSettingsFromDB()
                .done(function(response) {
                    if (response && response.success && response.settings) {
                        console.log('🔔 Loaded settings from database:', response.settings);

                        // Use database values
                        const notificationsEnabled = response.settings.notifications_enabled === 'true' || response.settings.notifications_enabled === '1';
                        const lowStockEnabled = response.settings.low_stock_notifications === 'true' || response.settings.low_stock_notifications === '1';
                        const salesEnabled = response.settings.sales_notifications === 'true' || response.settings.sales_notifications === '1';
                        const systemEnabled = response.settings.system_notifications === 'true' || response.settings.system_notifications === '1';

                        // Update checkboxes
                        $('#notificationsEnabled').prop('checked', notificationsEnabled);
                        $('#lowStockNotifications').prop('checked', lowStockEnabled);
                        $('#salesNotifications').prop('checked', salesEnabled);
                        $('#systemNotifications').prop('checked', systemEnabled);

                        // Sync with localStorage
                        localStorage.setItem('notificationsEnabled', notificationsEnabled.toString());
                        localStorage.setItem('low_stock_notifications', lowStockEnabled.toString());
                        localStorage.setItem('sales_notifications', salesEnabled.toString());
                        localStorage.setItem('system_notifications', systemEnabled.toString());

                        console.log('🔔 Settings synced with database:', {
                            enabled: notificationsEnabled,
                            lowStock: lowStockEnabled,
                            sales: salesEnabled,
                            system: systemEnabled
                        });
                    } else {
                        // Fallback to localStorage/defaults
                        initializeFromLocalStorage();
                    }

                    // Update preview and test button
                    updateNotificationPreview();
                })
                .fail(function() {
                    console.log('🔔 Failed to load from database, using localStorage/defaults');
                    initializeFromLocalStorage();
                    updateNotificationPreview();
                });
        }

        // Fallback initialization from localStorage
        function initializeFromLocalStorage() {
            // Get values from localStorage, with proper defaults
            const notificationsEnabledValue = localStorage.getItem('notificationsEnabled');
            const lowStockValue = localStorage.getItem('low_stock_notifications');
            const salesValue = localStorage.getItem('sales_notifications');
            const systemValue = localStorage.getItem('system_notifications');

            console.log('🔔 localStorage values:', {
                notificationsEnabled: notificationsEnabledValue,
                lowStock: lowStockValue,
                sales: salesValue,
                system: systemValue
            });

            // Set defaults if not set (first time)
            const notificationsEnabled = notificationsEnabledValue === null ? true : notificationsEnabledValue === 'true';
            const lowStockEnabled = lowStockValue === null ? true : lowStockValue === 'true';
            const salesEnabled = salesValue === null ? true : salesValue === 'true';
            const systemEnabled = systemValue === null ? true : systemValue === 'true';

            // Update checkboxes
            $('#notificationsEnabled').prop('checked', notificationsEnabled);
            $('#lowStockNotifications').prop('checked', lowStockEnabled);
            $('#salesNotifications').prop('checked', salesEnabled);
            $('#systemNotifications').prop('checked', systemEnabled);

            // Save to localStorage if not set
            if (notificationsEnabledValue === null) {
                localStorage.setItem('notificationsEnabled', 'true');
            }
            if (lowStockValue === null) {
                localStorage.setItem('low_stock_notifications', 'true');
            }
            if (salesValue === null) {
                localStorage.setItem('sales_notifications', 'true');
            }
            if (systemValue === null) {
                localStorage.setItem('system_notifications', 'true');
            }
        }

        // Update notification preview based on settings
        function updateNotificationPreview() {
            const notificationsEnabled = $('#notificationsEnabled').is(':checked');
            const lowStockEnabled = $('#lowStockNotifications').is(':checked');
            const salesEnabled = $('#salesNotifications').is(':checked');
            const systemEnabled = $('#systemNotifications').is(':checked');

            const $placeholder = $('#previewPlaceholder');
            const $sampleNotifications = $('#sampleNotifications');
            const $testBtn = $('#testNotificationBtn');

            if (notificationsEnabled) {
                $placeholder.hide();
                $sampleNotifications.show();
                $testBtn.prop('disabled', false);

                // Show/hide specific notification types
                $sampleNotifications.find('.sample-notification').each(function(index) {
                    const $notification = $(this);
                    switch(index) {
                        case 0: // Low stock
                            $notification.toggle(lowStockEnabled);
                            break;
                        case 1: // Sales
                            $notification.toggle(salesEnabled);
                            break;
                        case 2: // System
                            $notification.toggle(systemEnabled);
                            break;
                    }
                });

                // If no notification types are enabled, show message
                const visibleNotifications = $sampleNotifications.find('.sample-notification:visible').length;
                if (visibleNotifications === 0) {
                    $sampleNotifications.html('<div class="text-center text-muted"><i class="fas fa-bell-slash fa-2x mb-2"></i><p>No notification types enabled</p></div>');
                }
            } else {
                $placeholder.show();
                $sampleNotifications.hide();
                $testBtn.prop('disabled', true);
            }
        }

        // Test notification function
        function testNotification() {
            if (window.notificationManager) {
                window.notificationManager.showInfo('This is a test notification!', {
                    duration: 3000
                });
            } else {
                alert('Notification system not available');
            }
        }

        // Footer preview update functions
        function updateFooterPreview() {
            const address = $('textarea[name="store_address"]').val() || 'Yangon, Myanmar';
            const email = $('input[name="store_email"]').val() || 'info@example.com';
            const phone = $('input[name="store_phone"]').val() || '+95 9123456789';
            const copyright = $('input[name="footer_copyright"]').val() || '© 2025 BitsTech. All rights reserved.';

            $('#preview-address').text(address);
            $('#preview-email').text(email);
            $('#preview-phone').text(phone);
            $('#preview-copyright').text(copyright);
        }

        // Theme settings functions
        function initializeThemeSettings() {
            console.log('🎨 Initializing theme settings...');

            // Get current theme from theme manager first (if available)
            let currentTheme = 'dark'; // default
            if (typeof window.themeManager !== 'undefined') {
                currentTheme = window.themeManager.currentTheme;
                console.log('🎨 Got current theme from theme manager:', currentTheme);
            } else if (localStorage.getItem('theme_mode')) {
                currentTheme = localStorage.getItem('theme_mode');
                console.log('🎨 Got current theme from localStorage:', currentTheme);
            } else if (window.phpThemeSettings && window.phpThemeSettings.theme_mode) {
                currentTheme = window.phpThemeSettings.theme_mode;
                console.log('🎨 Got current theme from database:', currentTheme);
            }

            // Set radio buttons based on current theme
            console.log('🎨 Setting radio button for theme:', currentTheme);
            $('input[name="theme_mode"][value="' + currentTheme + '"]').prop('checked', true);

            // Apply current theme to settings page immediately
            applyThemeModeToPage(currentTheme);

            // Force apply current theme to settings page immediately
            forceApplyThemeToSettingsPage();

            // Initialize color input listeners
            $('.form-control-color').on('input', function() {
                const colorValue = $(this).val();
                const colorName = $(this).attr('name');
                const hexInput = $(this).siblings('.color-hex');
                hexInput.val(colorValue);

                // Apply color immediately to page
                applyColorToPage(colorName, colorValue);

                // Also update theme manager if available
                if (typeof window.themeManager !== 'undefined' && colorName) {
                    window.themeManager.setColor(colorName, colorValue);
                }

                updateThemePreview();
            });

            // Initialize color preset buttons
            $('.color-preset-btn').on('click', function() {
                const preset = $(this).data('preset');
                applyColorPreset(preset);
                $('.color-preset-btn').removeClass('active');
                $(this).addClass('active');

                // Apply preset immediately to page
                applyPresetToPage(preset);

                // Also apply via theme manager if available
                if (typeof window.themeManager !== 'undefined') {
                    window.themeManager.applyPreset(preset);
                }
            });

            // Initialize theme mode change
            $('input[name="theme_mode"]').on('change', function() {
                const selectedMode = $(this).val();
                console.log('🎨 Theme mode changed to:', selectedMode);

                // Apply theme mode immediately to page
                applyThemeModeToPage(selectedMode);

                // Update theme manager if available
                if (typeof window.themeManager !== 'undefined') {
                    console.log('🎨 Updating theme manager with new mode:', selectedMode);
                    window.themeManager.setThemeFromSettings(selectedMode);
                }

                // Update theme preview
                updateThemePreview();

                // Save to database immediately
                $.ajax({
                    url: 'settings.php',
                    type: 'POST',
                    data: {
                        action: 'update_theme_mode',
                        theme_mode: selectedMode,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response && response.success) {
                            console.log('🎨 Settings: Theme mode saved to database:', selectedMode);

                            // Broadcast theme change to other tabs/windows (including navbar)
                            localStorage.setItem('theme_changed', JSON.stringify({
                                theme: selectedMode,
                                timestamp: Date.now()
                            }));

                            // Remove after 5 seconds
                            setTimeout(() => {
                                localStorage.removeItem('theme_changed');
                            }, 5000);

                            // Show success message
                            if (typeof showSuccessMessage === 'function') {
                                showSuccessMessage('Theme mode updated to ' + selectedMode + ' mode');
                            }
                        } else {
                            console.error('🎨 Settings: Failed to save theme mode:', response.message);
                            if (typeof showErrorMessage === 'function') {
                                showErrorMessage('Failed to save theme mode: ' + (response.message || 'Unknown error'));
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('🎨 Settings: Theme mode save error:', error);
                        if (typeof showErrorMessage === 'function') {
                            showErrorMessage('Failed to save theme mode: ' + error);
                        }
                    }
                });

                // Also save to server using the existing function (for other theme settings)
                saveThemeSettingsToServer();
            });

            // Initialize quick action buttons
            $('#testLightTheme').on('click', function() {
                console.log('🎨 Testing light theme...');
                $('input[name="theme_mode"][value="light"]').prop('checked', true);
                applyThemeModeToPage('light');
                if (typeof window.themeManager !== 'undefined') {
                    window.themeManager.setThemeMode('light');
                }
                updateThemePreview();

                // Show feedback
                $(this).addClass('btn-warning').removeClass('btn-outline-warning');
                setTimeout(() => {
                    $(this).removeClass('btn-warning').addClass('btn-outline-warning');
                }, 1000);
            });

            $('#testDarkTheme').on('click', function() {
                console.log('🎨 Testing dark theme...');
                $('input[name="theme_mode"][value="dark"]').prop('checked', true);
                applyThemeModeToPage('dark');
                if (typeof window.themeManager !== 'undefined') {
                    window.themeManager.setThemeMode('dark');
                }
                updateThemePreview();

                // Show feedback
                $(this).addClass('btn-info').removeClass('btn-outline-info');
                setTimeout(() => {
                    $(this).removeClass('btn-info').addClass('btn-outline-info');
                }, 1000);
            });

            $('#applyThemeNow').on('click', function() {
                console.log('🎨 Applying current theme settings...');
                const selectedMode = $('input[name="theme_mode"]:checked').val();

                // Apply theme immediately
                applyThemeModeToPage(selectedMode);
                if (typeof window.themeManager !== 'undefined') {
                    window.themeManager.setThemeMode(selectedMode);
                    window.themeManager.applyTheme();
                }

                // Show success feedback
                $(this).addClass('btn-success').removeClass('btn-outline-success');
                $(this).find('span').text('Applied!');
                setTimeout(() => {
                    $(this).removeClass('btn-success').addClass('btn-outline-success');
                    $(this).find('span').text('Apply Now');
                }, 2000);

                // Show toast notification
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: getTranslation('theme_applied'),
                        text: getTranslation('theme_applied_desc'),
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false,
                        background: '#16213e',
                        color: '#ffffff',
                        toast: true,
                        position: 'top-end'
                    });
                }
            });

            // Initialize color preset buttons
            $('.color-preset-btn').on('click', function() {
                const preset = $(this).data('preset');
                console.log('🎨 Color preset selected:', preset);

                // Remove active class from all preset buttons
                $('.color-preset-btn').removeClass('active');
                // Add active class to clicked button
                $(this).addClass('active');

                // Apply preset colors
                applyPresetToPage(preset);
                updateThemePreview();

                // Show feedback
                $(this).addClass('btn-primary').removeClass('btn-outline-primary');
                setTimeout(() => {
                    $(this).removeClass('btn-primary').addClass('btn-outline-primary');
                }, 1000);
            });

            // Initialize color input changes for all color pickers
            $('input[type="color"], .form-control-color, .color-picker').on('input change', function() {
                const colorName = $(this).attr('name');
                const colorValue = $(this).val();
                console.log('🎨 Color changed:', colorName, colorValue);

                // Update hex display for both old and new design
                const hexInput = $(this).siblings('.color-hex, .color-hex-compact');
                hexInput.val(colorValue);

                // Apply color immediately to page
                applyColorToPage(colorName, colorValue);

                // Update CSS variables for dynamic styling
                updateCSSVariables(colorName, colorValue);

                // Also update theme manager if available
                if (typeof window.themeManager !== 'undefined' && colorName) {
                    console.log('🎨 Updating theme manager color:', colorName, colorValue);
                    window.themeManager.colors = window.themeManager.colors || {};
                    window.themeManager.colors[colorName] = colorValue;

                    // Apply color to CSS variables
                    const cssVar = `--${colorName.replace('_', '-')}`;
                    document.documentElement.style.setProperty(cssVar, colorValue);
                }

                // Force immediate application
                setTimeout(() => {
                    applyColorToPage(colorName, colorValue);
                    updateThemePreview();
                }, 10);

                console.log('🎨 Color applied:', colorName, colorValue);
            });

            // Initialize reset theme button
            $('#resetTheme').on('click', function() {
                resetToDefaultTheme();
            });

            // Initial preview update
            updateThemePreview();
        }

        function applyColorPreset(preset) {
            console.log('🎨 Applying color preset:', preset);

            const presets = {
                default: {
                    primary_color: '#007bff',
                    secondary_color: '#6c757d',
                    accent_color: '#17a2b8',
                    background_color: '#21243A',
                    sidebar_color: '#2A2D35',
                    text_color: '#ffffff',
                    success_color: '#28a745',
                    warning_color: '#ffc107',
                    danger_color: '#dc3545'
                },
                ocean: {
                    primary_color: '#0ea5e9',
                    secondary_color: '#64748b',
                    accent_color: '#06b6d4',
                    background_color: '#0f172a',
                    sidebar_color: '#1e293b',
                    text_color: '#ffffff',
                    success_color: '#10b981',
                    warning_color: '#f59e0b',
                    danger_color: '#ef4444'
                },
                forest: {
                    primary_color: '#10b981',
                    secondary_color: '#64748b',
                    accent_color: '#34d399',
                    background_color: '#0f1419',
                    sidebar_color: '#1a2e1a',
                    text_color: '#ffffff',
                    success_color: '#22c55e',
                    warning_color: '#f59e0b',
                    danger_color: '#ef4444'
                },
                sunset: {
                    primary_color: '#f97316',
                    secondary_color: '#64748b',
                    accent_color: '#fb923c',
                    background_color: '#1a0f0a',
                    sidebar_color: '#2d1b1b',
                    text_color: '#ffffff',
                    success_color: '#10b981',
                    warning_color: '#fbbf24',
                    danger_color: '#ef4444'
                },
                royal: {
                    primary_color: '#8b5cf6',
                    secondary_color: '#64748b',
                    accent_color: '#a78bfa',
                    background_color: '#1e1065',
                    sidebar_color: '#312e81',
                    text_color: '#ffffff',
                    success_color: '#10b981',
                    warning_color: '#f59e0b',
                    danger_color: '#ef4444'
                },
                crimson: {
                    primary_color: '#ef4444',
                    secondary_color: '#64748b',
                    accent_color: '#f87171',
                    background_color: '#1a0a0a',
                    sidebar_color: '#2d1b1b',
                    text_color: '#ffffff',
                    success_color: '#10b981',
                    warning_color: '#f59e0b',
                    danger_color: '#dc2626'
                }
            };

            const colors = presets[preset];
            if (colors) {
                Object.keys(colors).forEach(key => {
                    const input = $(`input[name="${key}"]`);
                    input.val(colors[key]);
                    input.siblings('.color-hex').val(colors[key]);
                });
                updateThemePreview();
            }
        }

        function updateThemePreview() {
            console.log('🎨 Updating theme preview...');

            const themeMode = $('input[name="theme_mode"]:checked').val() || 'dark';
            const primaryColor = $('input[name="primary_color"]').val() || '#007bff';
            const backgroundColor = $('input[name="background_color"]').val() || '#21243A';
            const sidebarColor = $('input[name="sidebar_color"]').val() || '#2A2D35';
            const textColor = $('input[name="text_color"]').val() || '#ffffff';
            const successColor = $('input[name="success_color"]').val() || '#28a745';
            const warningColor = $('input[name="warning_color"]').val() || '#ffc107';
            const dangerColor = $('input[name="danger_color"]').val() || '#dc3545';

            // Update CSS custom properties for preview
            const previewContainer = document.getElementById('themePreview');
            if (previewContainer) {
                previewContainer.style.setProperty('--preview-bg', backgroundColor);
                previewContainer.style.setProperty('--preview-sidebar', sidebarColor);
                previewContainer.style.setProperty('--preview-text', textColor);
                previewContainer.style.setProperty('--preview-primary', primaryColor);
                previewContainer.style.setProperty('--preview-success', successColor);
                previewContainer.style.setProperty('--preview-warning', warningColor);
                previewContainer.style.setProperty('--preview-danger', dangerColor);
            }

            console.log('🎨 Theme preview updated with colors:', {
                mode: themeMode,
                primary: primaryColor,
                background: backgroundColor,
                sidebar: sidebarColor
            });
        }

        function resetToDefaultTheme() {
            console.log('🎨 Resetting to default theme...');

            // Show confirmation
            Swal.fire({
                title: 'Reset Theme?',
                text: 'This will reset all theme settings to default values. Are you sure?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Reset',
                cancelButtonText: 'Cancel',
                background: '#16213e',
                color: '#ffffff'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Reset to default values
                    $('input[name="theme_mode"][value="dark"]').prop('checked', true);
                    applyColorPreset('default');

                    // Remove active class from all preset buttons and add to default
                    $('.color-preset-btn').removeClass('active');
                    $('.color-preset-btn[data-preset="default"]').addClass('active');

                    Swal.fire({
                        title: 'Theme Reset!',
                        text: 'Theme has been reset to default settings.',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false,
                        background: '#16213e',
                        color: '#ffffff'
                    });
                }
            });
        }

        // Theme mode application functions
        function applyThemeModeToPage(mode) {
            console.log('🎨 Applying theme mode to page immediately:', mode);

            // Set theme attributes immediately
            document.documentElement.setAttribute('data-theme', mode);
            document.body.setAttribute('data-theme', mode);

            // Store in localStorage for persistence
            localStorage.setItem('theme_mode', mode);

            // Apply to navbar and sidebar specifically
            const navbar = document.querySelector('.navbar-top');
            const sidebar = document.querySelector('.left-sidebar');

            if (navbar) {
                navbar.setAttribute('data-theme', mode);
            }
            if (sidebar) {
                sidebar.setAttribute('data-theme', mode);
            }

            // Force CSS variables update
            if (mode === 'light') {
                document.documentElement.style.setProperty('--primary-bg', '#f8f9fa');
                document.documentElement.style.setProperty('--secondary-bg', '#ffffff');
                document.documentElement.style.setProperty('--card-bg', '#ffffff');
                document.documentElement.style.setProperty('--text-primary', '#212529');
                document.documentElement.style.setProperty('--text-secondary', '#6c757d');
            } else {
                document.documentElement.style.setProperty('--primary-bg', '#21243A');
                document.documentElement.style.setProperty('--secondary-bg', '#2A2D35');
                document.documentElement.style.setProperty('--card-bg', '#2a2d35');
                document.documentElement.style.setProperty('--text-primary', '#ffffff');
                document.documentElement.style.setProperty('--text-secondary', 'rgba(255,255,255,0.7)');
            }

            console.log('🎨 Theme mode applied immediately:', mode);
        }

        // Update CSS variables for dynamic styling
        function updateCSSVariables(colorName, colorValue) {
            const root = document.documentElement;
            const cssVar = `--${colorName.replace('_', '-')}`;
            root.style.setProperty(cssVar, colorValue);

            console.log('🎨 Updated CSS variable:', cssVar, colorValue);
        }

        function applyColorToPage(colorName, colorValue) {
            console.log('🎨 Applying color to page:', colorName, colorValue);

            // Apply color to CSS custom properties
            document.documentElement.style.setProperty(`--${colorName.replace('_', '-')}`, colorValue);

            // Apply specific color changes based on color name
            switch(colorName) {
                case 'background_color':
                    document.body.style.backgroundColor = colorValue;
                    $('.settings-container, .page-content-wrapper').css('background-color', colorValue);
                    break;
                case 'text_color':
                    document.body.style.color = colorValue;
                    $('.settings-content h1, .settings-content h2, .settings-content h3, .settings-content h4, .settings-content h5, .settings-content h6').css('color', colorValue);
                    $('.settings-content p, .settings-content span, .settings-content div, .settings-content label').css('color', colorValue);
                    break;
                case 'sidebar_color':
                    const sidebar = document.querySelector('.left-sidebar');
                    if (sidebar) sidebar.style.backgroundColor = colorValue;
                    $('.settings-card, .card').css('background-color', colorValue);
                    break;
                case 'primary_color':
                    // Update primary color elements
                    $('.btn-primary, .nav-pills .nav-link.active').css('background-color', colorValue);
                    $('.color-preset-btn.active').css('border-color', colorValue);
                    break;
                case 'success_color':
                    $('.btn-success').css('background-color', colorValue);
                    break;
                case 'warning_color':
                    $('.btn-warning').css('background-color', colorValue);
                    break;
                case 'danger_color':
                    $('.btn-danger').css('background-color', colorValue);
                    break;
            }

            // Force refresh of themed elements
            $('[data-theme]').each(function() {
                const currentTheme = $(this).attr('data-theme');
                $(this).attr('data-theme', currentTheme);
            });
        }

        function applyPresetToPage(preset) {
            console.log('🎨 Applying preset to page:', preset);

            const presets = {
                default: {
                    background_color: '#21243A',
                    sidebar_color: '#2A2D35',
                    primary_color: '#007bff'
                },
                ocean: {
                    background_color: '#0f172a',
                    sidebar_color: '#1e293b',
                    primary_color: '#0ea5e9'
                },
                forest: {
                    background_color: '#0f1419',
                    sidebar_color: '#1a2e1a',
                    primary_color: '#10b981'
                },
                sunset: {
                    background_color: '#1a0f0a',
                    sidebar_color: '#2d1b1b',
                    primary_color: '#f97316'
                },
                royal: {
                    background_color: '#1e1065',
                    sidebar_color: '#312e81',
                    primary_color: '#8b5cf6'
                },
                crimson: {
                    background_color: '#1a0a0a',
                    sidebar_color: '#2d1b1b',
                    primary_color: '#ef4444'
                }
            };

            const colors = presets[preset];
            if (colors) {
                Object.keys(colors).forEach(key => {
                    applyColorToPage(key, colors[key]);
                });
            }
        }

        function forceApplyThemeToSettingsPage() {
            console.log('🎨 Force applying theme to settings page...');

            // Get current theme mode
            const currentMode = $('input[name="theme_mode"]:checked').val() || 'dark';

            // Apply theme mode
            applyThemeModeToPage(currentMode);

            // Apply colors if theme manager is available
            if (typeof window.themeManager !== 'undefined') {
                window.themeManager.applyTheme();
            }
        }

        // Debug functions for theme testing
        window.testLightMode = function() {
            console.log('🎨 Testing light mode...');
            applyThemeModeToPage('light');
            $('input[name="theme_mode"][value="light"]').prop('checked', true);
            console.log('🎨 Light mode applied');
        };

        window.testDarkMode = function() {
            console.log('🎨 Testing dark mode...');
            applyThemeModeToPage('dark');
            $('input[name="theme_mode"][value="dark"]').prop('checked', true);
            console.log('🎨 Dark mode applied');
        };

        // Save theme settings to server
        function saveThemeSettingsToServer() {
            console.log('🎨 Saving theme settings to server...');

            const selectedMode = $('input[name="theme_mode"]:checked').val();

            if (!selectedMode) {
                console.warn('🎨 No theme mode selected, skipping save');
                return;
            }

            // Also ensure localStorage is updated
            localStorage.setItem('theme_mode', selectedMode);

            $.ajax({
                url: 'settings.php',
                type: 'POST',
                data: {
                    action: 'update_theme_mode',
                    theme_mode: selectedMode
                },
                dataType: 'json',
                success: function(response) {
                    console.log('🎨 Theme settings saved to server:', response);
                    if (response && response.success) {
                        console.log('✅ Theme mode saved successfully:', selectedMode);

                        // Ensure theme persists across page navigation
                        localStorage.setItem('theme_mode', selectedMode);

                        // Apply to current page immediately
                        applyThemeModeToPage(selectedMode);

                        // Show success feedback
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Theme Updated!',
                                text: `Theme mode changed to ${selectedMode} mode`,
                                icon: 'success',
                                timer: 2000,
                                showConfirmButton: false,
                                toast: true,
                                position: 'top-end'
                            });
                        }
                    } else {
                        console.error('🎨 Server returned error:', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.warn('🎨 Failed to save theme settings to server:', error);
                    console.warn('🎨 Response text:', xhr.responseText);

                    // Still save to localStorage even if server save fails
                    localStorage.setItem('theme_mode', selectedMode);

                    // Show error feedback
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Theme Save Failed',
                            text: 'Theme applied locally but failed to save to server',
                            icon: 'warning',
                            timer: 3000,
                            showConfirmButton: false,
                            toast: true,
                            position: 'top-end'
                        });
                    }
                }
            });
        }



        window.checkThemeStatus = function() {
            console.log('🎨 Theme Status Check:');
            console.log('- HTML data-theme:', document.documentElement.getAttribute('data-theme'));
            console.log('- Body data-theme:', document.body.getAttribute('data-theme'));
            console.log('- Body background:', document.body.style.backgroundColor);
            console.log('- Body color:', document.body.style.color);
            console.log('- Selected radio:', $('input[name="theme_mode"]:checked').val());
            console.log('- Theme manager:', typeof window.themeManager !== 'undefined' ? 'Available' : 'Not available');
            if (typeof window.themeManager !== 'undefined') {
                console.log('- Current theme:', window.themeManager.currentTheme);
                console.log('- Colors:', window.themeManager.colors);
            }
        };

        window.forceApplyTheme = function() {
            console.log('🎨 Force applying theme...');
            const currentTheme = localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Current theme:', currentTheme);

            // Force apply to all elements
            document.documentElement.setAttribute('data-theme', currentTheme);
            document.body.setAttribute('data-theme', currentTheme);

            // Apply to navbar and sidebar specifically
            const navbar = document.querySelector('.navbar-top');
            const sidebar = document.querySelector('.left-sidebar');

            if (navbar) navbar.setAttribute('data-theme', currentTheme);
            if (sidebar) sidebar.setAttribute('data-theme', currentTheme);

            // Apply theme mode to page
            applyThemeModeToPage(currentTheme);

            console.log('🎨 Theme force-applied successfully');
        };

        // Test functions
        window.testLightMode = function() {
            console.log('🎨 Testing light mode...');
            $('input[name="theme_mode"][value="light"]').prop('checked', true);
            applyThemeModeToPage('light');
            console.log('🎨 Light mode applied');
        };

        window.testDarkMode = function() {
            console.log('🎨 Testing dark mode...');
            $('input[name="theme_mode"][value="dark"]').prop('checked', true);
            applyThemeModeToPage('dark');
            console.log('🎨 Dark mode applied');
        };

        // Initialize date format options on page load
        $(document).ready(function() {
            const currentLang = '<?php echo $language; ?>';
            console.log('📅 Initializing date format options for language:', currentLang);
            updateDateFormatOptions(currentLang);

            // Initialize notification settings
            initializeNotificationSettings();

            // Initialize footer preview
            updateFooterPreview();

            // Setup footer preview update listeners
            $('textarea[name="store_address"], input[name="store_email"], input[name="store_phone"], input[name="footer_copyright"]').on('input', function() {
                updateFooterPreview();
            });

            // Initialize theme settings
            console.log('🎨 Initializing theme settings...');
            initializeThemeSettings();

            // Use preloaded theme to prevent flash
            const currentTheme = window.preloadedTheme || localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Using preloaded theme:', currentTheme);

            // Update radio button to match current theme
            $('input[name="theme_mode"][value="' + currentTheme + '"]').prop('checked', true);

            // Apply theme to page (should already be applied by preloader)
            applyThemeModeToPage(currentTheme);

            // Listen for theme changes from navbar toggle
            window.addEventListener('storage', function(e) {
                if (e.key === 'theme_changed' && e.newValue) {
                    try {
                        const data = JSON.parse(e.newValue);
                        console.log('🎨 Settings: Detected theme change from navbar:', data.theme);

                        // Update radio button to match navbar change
                        $('input[name="theme_mode"][value="' + data.theme + '"]').prop('checked', true);

                        // Apply theme to settings page
                        applyThemeModeToPage(data.theme);

                        // Update theme manager if available
                        if (typeof window.themeManager !== 'undefined') {
                            window.themeManager.setThemeMode(data.theme);
                        }

                        console.log('🎨 Settings: Synced with navbar theme change');
                    } catch (error) {
                        console.error('🎨 Settings: Error parsing theme change:', error);
                    }
                }
            });

            // Remove critical CSS after theme is applied
            setTimeout(() => {
                const criticalCSS = document.getElementById('critical-theme-css');
                if (criticalCSS) {
                    criticalCSS.remove();
                    console.log('🎨 Critical theme CSS removed');
                }
            }, 100);

            // Add test buttons for debugging
            if (window.location.hostname === 'localhost') {
                console.log('🎨 Adding debug theme buttons...');
                const debugContainer = $('<div class="mt-3 p-3 border rounded bg-warning bg-opacity-10">');
                debugContainer.append('<h6>Debug Theme Controls</h6>');
                debugContainer.append('<button class="btn btn-sm btn-outline-primary me-2" onclick="testLightMode()">Test Light</button>');
                debugContainer.append('<button class="btn btn-sm btn-outline-secondary me-2" onclick="testDarkMode()">Test Dark</button>');
                debugContainer.append('<button class="btn btn-sm btn-outline-info me-2" onclick="checkThemeStatus()">Check Status</button>');
                debugContainer.append('<button class="btn btn-sm btn-outline-success" onclick="forceApplyTheme()">Force Apply</button>');
                $('#theme .settings-content').append(debugContainer);
            }

            // Initialize notification bell visibility immediately
            if (typeof window.updateNotificationBellVisibility === 'function') {
                window.updateNotificationBellVisibility();
                console.log('🔔 Settings: Notification bell visibility updated');
            }

            // Setup notification toggle event listeners
            $('#notificationsEnabled, #lowStockNotifications, #salesNotifications, #systemNotifications').on('change', function() {
                const $this = $(this);
                const isChecked = $this.is(':checked');
                const settingName = $this.attr('name');

                console.log('🔔 Notification toggle changed:', settingName, isChecked);

                // Update localStorage immediately
                if (settingName === 'notifications_enabled') {
                    localStorage.setItem('notificationsEnabled', isChecked.toString());
                } else {
                    localStorage.setItem(settingName, isChecked.toString());
                }

                // Update preview
                updateNotificationPreview();

                // Update notification bell visibility when master toggle changes
                if (this.id === 'notificationsEnabled' && typeof window.updateNotificationBellVisibility === 'function') {
                    console.log('🔔 Calling updateNotificationBellVisibility');
                    window.updateNotificationBellVisibility();
                }

                // Update notification count when low stock notifications toggle changes
                if (this.id === 'lowStockNotifications' && typeof window.updateNotificationBellVisibility === 'function') {
                    console.log('🔔 Low Stock Notifications changed, updating count');
                    window.updateNotificationBellVisibility();
                }
            });

            // Setup test notification button
            $('#testNotificationBtn').on('click', testNotification);

            // Test if updateNavbarDateFormat function exists
            if (typeof window.updateNavbarDateFormat === 'function') {
                console.log('✅ updateNavbarDateFormat function is available');
            } else {
                console.error('❌ updateNavbarDateFormat function is NOT available');
            }
        });
    </script>

    <!-- Theme Manager Script -->
    <script src="../public/js/theme-manager.js"></script>
    <script>
        // Initialize theme manager for settings page with enhanced consistency
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🎨 Settings: DOM loaded, initializing theme manager...');

            // Initialize theme manager
            window.themeManager = new ThemeManager();

            // Get current theme
            const currentTheme = localStorage.getItem('theme_mode') || 'dark';
            console.log('🎨 Settings: Current theme from localStorage:', currentTheme);

            // Force apply theme multiple times to ensure consistency
            window.themeManager.forceApplyTheme(currentTheme);

            // Additional force applications with delays
            setTimeout(() => {
                window.themeManager.forceApplyTheme(currentTheme);
                console.log('🎨 Settings: Theme force applied (100ms)');
            }, 100);

            setTimeout(() => {
                window.themeManager.forceApplyTheme(currentTheme);
                console.log('🎨 Settings: Theme force applied (300ms)');

                // Force update all settings page elements manually
                const settingsElements = document.querySelectorAll('.settings-container, .page-content-wrapper, .main-content, .settings-content, .settings-nav, .page-header, .card, .card-body');
                settingsElements.forEach(element => {
                    element.setAttribute('data-theme', currentTheme);
                    if (currentTheme === 'light') {
                        if (element.classList.contains('settings-content') || element.classList.contains('page-header') || element.classList.contains('card') || element.classList.contains('card-body')) {
                            element.style.backgroundColor = '#ffffff';
                        } else {
                            element.style.backgroundColor = '#f8f9fa';
                        }
                        element.style.color = '#212529';
                    } else {
                        if (element.classList.contains('settings-content') || element.classList.contains('page-header') || element.classList.contains('card') || element.classList.contains('card-body')) {
                            element.style.backgroundColor = '#2A2D35';
                        } else {
                            element.style.backgroundColor = '#21243A';
                        }
                        element.style.color = '#ffffff';
                    }
                });

                console.log('🎨 Settings: All elements manually updated for theme:', currentTheme);

                // Remove critical CSS after theme is fully applied
                const criticalCSS = document.getElementById('critical-theme-css');
                if (criticalCSS) {
                    criticalCSS.remove();
                    console.log('🎨 Settings: Critical CSS removed');
                }
            }, 300);

            // Final consistency check
            setTimeout(() => {
                window.themeManager.forceApplyTheme(currentTheme);
                console.log('🎨 Settings: Final theme consistency check');
            }, 500);

            console.log('🎨 Settings: Theme manager initialization complete');
        });
    </script>

    <!-- Auto Backup Monitor Script -->
    <script src="../public/js/auto-backup-monitor.js"></script>

    <!-- Notification Manager Script -->
    <script src="../public/js/notification-manager.js"></script>

    <?php include BASEPATH . 'includes/footer.php'; ?>
</body>
</html>