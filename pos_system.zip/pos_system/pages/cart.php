<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get currency settings
$currency = $_SESSION['currency'] ?? 'USD';
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency_symbols = ['USD' => '$', 'THB' => '฿', 'MMK' => 'Ks'];

// Calculate cart totals
function calculateTotals($cart, $tax_rate = 0, $shipping = 0) {
    global $pdo, $currency, $exchange_rates;

    $subtotal = 0;
    $items = [];

    // Fetch all products in cart
    if (!empty($cart)) {
        $product_ids = array_keys($cart);
        $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
        $stmt = $pdo->prepare("SELECT product_id, product_name, unit_price, discount FROM products WHERE product_id IN ($placeholders)");
        $stmt->execute($product_ids);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($products as $product) {
            $quantity = $cart[$product['product_id']];
            $price = floatval($product['unit_price']);
            $discount = floatval($product['discount'] ?? 0);

            // Calculate item total with discount
            $item_price = $price * (1 - ($discount / 100));
            $item_total = $item_price * $quantity;

            $subtotal += $item_total;

            $items[] = [
                'id' => $product['product_id'],
                'name' => $product['product_name'],
                'price' => $price,
                'discount' => $discount,
                'quantity' => $quantity,
                'total' => $item_total
            ];
        }
    }

    // Convert to selected currency
    $subtotal = floatval($subtotal) * floatval($exchange_rates[$currency]);
    $shipping = floatval($shipping);
    $tax_rate = floatval($tax_rate);

    // Calculate tax amount
    $tax_amount = ($subtotal * $tax_rate) / 100;

    // Calculate grand total
    $total = $subtotal + $tax_amount + $shipping;

    return [
        'items' => $items,
        'subtotal' => $subtotal,
        'tax_rate' => $tax_rate,
        'tax_amount' => $tax_amount,
        'shipping' => $shipping,
        'total' => $total
    ];
}

// Handle AJAX requests for cart updates
if (isset($_POST['action'])) {
    $response = ['success' => false];

    switch ($_POST['action']) {
        case 'update_totals':
            $tax_rate = isset($_POST['tax']) ? floatval($_POST['tax']) : 0;
            $shipping = isset($_POST['shipping']) ? floatval($_POST['shipping']) : 0;

            $_SESSION['tax_rate'] = $tax_rate;
            $_SESSION['shipping'] = $shipping;

            $totals = calculateTotals($_SESSION['cart'], $tax_rate, $shipping);

            $response = [
                'success' => true,
                'subtotal' => number_format($totals['subtotal'], 2),
                'tax_amount' => number_format($totals['tax_amount'], 2),
                'shipping' => number_format($totals['shipping'], 2),
                'total' => number_format($totals['total'], 2)
            ];
            break;

        case 'update_quantity':
            if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
                $product_id = intval($_POST['product_id']);
                $quantity = intval($_POST['quantity']);

                // Get current stock
                $stmt = $pdo->prepare("SELECT stock_quantity FROM products WHERE product_id = ?");
                $stmt->execute([$product_id]);
                $current_stock = $stmt->fetchColumn();

                // Get current cart quantity
                $current_quantity = isset($_SESSION['cart'][$product_id]) ? $_SESSION['cart'][$product_id] : 0;

                if ($quantity > $current_quantity) {
                    // Increasing quantity
                    $increase = $quantity - $current_quantity;
                    if ($current_stock >= $increase) {
                        $_SESSION['cart'][$product_id] = $quantity;
                        // Decrease stock
                        $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?")
                            ->execute([$increase, $product_id]);
                        $response['success'] = true;
                    } else {
                        $response['error'] = 'Not enough stock';
                    }
                } else {
                    // Decreasing quantity
                    $decrease = $current_quantity - $quantity;
                    if ($quantity > 0) {
                        $_SESSION['cart'][$product_id] = $quantity;
                    } else {
                        unset($_SESSION['cart'][$product_id]);
                    }
                    // Increase stock
                    $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?")
                        ->execute([$decrease, $product_id]);
                    $response['success'] = true;
                }

                // Recalculate totals
                $totals = calculateTotals($_SESSION['cart'], $_SESSION['tax_rate'] ?? 0, $_SESSION['shipping'] ?? 0);
                $response['totals'] = [
                    'subtotal' => number_format($totals['subtotal'], 2),
                    'tax_amount' => number_format($totals['tax_amount'], 2),
                    'shipping' => number_format($totals['shipping'], 2),
                    'total' => number_format($totals['total'], 2)
                ];
            }
            break;

        case 'remove_item':
            if (isset($_POST['product_id'])) {
                $product_id = intval($_POST['product_id']);
                if (isset($_SESSION['cart'][$product_id])) {
                    // Return quantity to stock
                    $quantity = $_SESSION['cart'][$product_id];
                    $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?")
                        ->execute([$quantity, $product_id]);

                    // Remove from cart
                    unset($_SESSION['cart'][$product_id]);

                    // Recalculate totals
                    $totals = calculateTotals($_SESSION['cart'], $_SESSION['tax_rate'] ?? 0, $_SESSION['shipping'] ?? 0);
                    $response['success'] = true;
                    $response['totals'] = [
                        'subtotal' => number_format($totals['subtotal'], 2),
                        'tax_amount' => number_format($totals['tax_amount'], 2),
                        'shipping' => number_format($totals['shipping'], 2),
                        'total' => number_format($totals['total'], 2)
                    ];
                }
            }
            break;
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Example form submission handling
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_now'])) {
    // Set customer information from the form
    $_SESSION['customer_info'] = [
        'name' => $_POST['customer_name'] ?? 'N/A',
        'address' => $_POST['customer_address'] ?? 'N/A',
        'phone' => $_POST['customer_phone'] ?? 'N/A'
    ];

    // Set tax and shipping
    $_SESSION['tax_rate'] = floatval($_POST['tax_rate'] ?? 0);
    $_SESSION['shipping'] = floatval($_POST['shipping'] ?? 0);

    // Calculate final totals
    $totals = calculateTotals($_SESSION['cart'], $_SESSION['tax_rate'], $_SESSION['shipping']);
    $_SESSION['order_totals'] = $totals;

    // Debug: Log session data
    error_log("Cart.php - Before saving session: " . print_r($_SESSION, true));

    // Force session save
    session_write_close();

    // Redirect to invoice.php
    header("Location: invoice.php");
    exit();
}

// Get settings for navbar
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Error fetching settings: " . $e->getMessage());
    $settings = [];
}

// Default values for navbar (let navbar.php handle system_name from database)
$language = $_SESSION['language'] ?? ($settings['language'] ?? 'en');
$translations = loadLanguage($language);
$logo_path = $_SESSION['logo_path'] ?? '../public/images/logo.png';
// $system_name will be handled by navbar.php from database
$current_page = 'cart';

// Calculate initial totals
$current_totals = calculateTotals($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($translations['cart'] ?? 'Cart'); ?> - BitsTech POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="container">
                <div class="cart-container">
        <div class="cart-items">
            <?php if (empty($_SESSION['cart'])): ?>
                <p>Your cart is empty.</p>
            <?php else: ?>
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($current_totals['items'] as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['name']) ?></td>
                                <td><?= $currency_symbols[$currency] . number_format($item['price'] * $exchange_rates[$currency], 2) ?></td>
                                <td class="quantity-cell">
                                    <div class="quantity-controls">
                                        <button type="button" class="btn-quantity minus" data-product-id="<?= $item['id'] ?>">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <input type="number" class="quantity-input" value="<?= $item['quantity'] ?>"
                                               min="1" data-product-id="<?= $item['id'] ?>"
                                               onchange="updateQuantity(<?= $item['id'] ?>, this.value)">
                                        <button type="button" class="btn-quantity plus" data-product-id="<?= $item['id'] ?>">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </td>
                                <td class="item-total">
                                    <?= $currency_symbols[$currency] . number_format($item['total'] * $exchange_rates[$currency], 2) ?>
                                    <button type="button" class="btn-remove" onclick="removeItem(<?= $item['id'] ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="cart-summary">
            <h3>Order Summary</h3>
            <form method="POST" action="" id="cart-form">
                <div class="summary-row">
                    <label>Subtotal:</label>
                    <div class="amount-display">
                        <span id="subtotal"><?= $currency_symbols[$currency] . number_format($current_totals['subtotal'], 2) ?></span>
                    </div>
                </div>
                <div class="summary-row">
                    <div class="tax-row">
                        <label>Tax Rate:</label>
                        <div class="tax-input">
                            <input type="number" name="tax_rate" id="tax_rate" min="0" max="100" step="0.01" value="<?= $_SESSION['tax_rate'] ?? 0 ?>" class="number-input">
                            <span class="percentage">%</span>
                        </div>
                    </div>
                    <div class="amount-display">
                        <span id="tax_amount"><?= $currency_symbols[$currency] . number_format($current_totals['tax_amount'], 2) ?></span>
                    </div>
                </div>
                <div class="summary-row">
                    <div class="shipping-row">
                        <label>Shipping:</label>
                        <div class="shipping-input">
                            <span class="currency-symbol"><?= $currency_symbols[$currency] ?></span>
                            <input type="number" name="shipping" id="shipping" min="0" step="0.01" value="<?= $_SESSION['shipping'] ?? 0 ?>" class="number-input">
                        </div>
                    </div>
                </div>
                <div class="summary-row total">
                    <label>Total:</label>
                    <div class="amount-display total">
                        <span id="total"><?= $currency_symbols[$currency] . number_format($current_totals['total'], 2) ?></span>
                    </div>
                </div>

                <div class="customer-info">
                    <h3>Customer Information</h3>
                    <div class="form-group">
                        <label>Name:</label>
                        <input type="text" name="customer_name" required>
                    </div>
                    <div class="form-group">
                        <label>Address:</label>
                        <input type="text" name="customer_address" required>
                    </div>
                    <div class="form-group">
                        <label>Phone:</label>
                        <input type="text" name="customer_phone" required>
                    </div>
                </div>

                <button type="submit" name="buy_now" class="btn-primary">Proceed to Checkout</button>
            </form>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        function formatCurrency(amount) {
            return parseFloat(amount).toFixed(2);
        }

        function updateTotals() {
            var tax = parseFloat($('#tax_rate').val() || 0);
            var shipping = parseFloat($('#shipping').val() || 0);

            // Ensure values are valid numbers
            tax = isNaN(tax) ? 0 : tax;
            shipping = isNaN(shipping) ? 0 : shipping;

            // Show loading state
            $('#total').text('Calculating...');

            $.ajax({
                url: 'cart.php',
                method: 'POST',
                data: {
                    action: 'update_totals',
                    tax: tax,
                    shipping: shipping
                },
                success: function(response) {
                    var currencySymbol = '<?= $currency_symbols[$currency] ?>';

                    // Store current values
                    $('#tax_rate').val(tax);
                    $('#shipping').val(shipping);

                    // Update display with proper formatting
                    $('#subtotal').text(currencySymbol + ' ' + response.subtotal);
                    $('#tax_amount').text(currencySymbol + ' ' + response.tax_amount);
                    $('#total').text(currencySymbol + ' ' + response.total);
                },
                error: function() {
                    console.error('Failed to update totals');
                    // Restore previous values on error
                    updateTotals();
                }
            });
        }

        // Delay function to prevent too many requests
        var updateTimer;
        function delayedUpdate() {
            clearTimeout(updateTimer);
            updateTimer = setTimeout(updateTotals, 300);
        }

        // Update totals when tax or shipping changes
        $('#tax_rate, #shipping').on('input', delayedUpdate);

        // Handle enter key press
        $('#tax_rate, #shipping').on('keypress', function(e) {
            if (e.which === 13) { // Enter key code
                e.preventDefault(); // Prevent form submission
                $(this).blur(); // Remove focus from input
                updateTotals();
            }
        });

        // Handle focus out (when user clicks away)
        $('#tax_rate, #shipping').on('blur', updateTotals);

        // Initial calculation when page loads
        $(window).on('load', function() {
            updateTotals();
        });

        // Handle quantity changes
        function updateQuantity(productId, quantity) {
            $.ajax({
                url: 'cart.php',
                method: 'POST',
                data: {
                    action: 'update_quantity',
                    product_id: productId,
                    quantity: quantity
                },
                success: function(response) {
                    if (response.success) {
                        // Update totals
                        $('#subtotal').text('<?= $currency_symbols[$currency] ?> ' + response.totals.subtotal);
                        $('#tax_amount').text('<?= $currency_symbols[$currency] ?> ' + response.totals.tax_amount);
                        $('#total').text('<?= $currency_symbols[$currency] ?> ' + response.totals.total);

                        // Update item total
                        location.reload(); // Temporary solution to update all values
                    } else {
                        alert(response.error || 'Failed to update quantity');
                        location.reload(); // Refresh to restore correct values
                    }
                },
                error: function() {
                    alert('Error updating quantity');
                    location.reload();
                }
            });
        }

        // Handle quantity buttons
        $('.btn-quantity.minus').click(function() {
            var productId = $(this).data('product-id');
            var input = $(this).siblings('.quantity-input');
            var currentVal = parseInt(input.val());
            if (currentVal > 1) {
                updateQuantity(productId, currentVal - 1);
            }
        });

        $('.btn-quantity.plus').click(function() {
            var productId = $(this).data('product-id');
            var input = $(this).siblings('.quantity-input');
            var currentVal = parseInt(input.val());
            updateQuantity(productId, currentVal + 1);
        });

        // Handle direct quantity input
        $('.quantity-input').change(function() {
            var productId = $(this).data('product-id');
            var quantity = parseInt($(this).val());
            if (quantity >= 1) {
                updateQuantity(productId, quantity);
            } else {
                $(this).val(1);
            }
        });

        // Handle item removal
        window.removeItem = function(productId) {
            if (confirm('Are you sure you want to remove this item?')) {
                $.ajax({
                    url: 'cart.php',
                    method: 'POST',
                    data: {
                        action: 'remove_item',
                        product_id: productId
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        }
                    }
                });
            }
        };
    });
    </script>
                </div>
            </div>
        </div>
    </div>
</body>
</html>