<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/security_check.php';

header('Content-Type: application/json');

// Mock payment verification for testing
function mockVerifyPayment($method, $reference, $amount = null) {
    // Test reference number patterns
    $patterns = [
        'KBZPAY' => '/^KBZ[0-9]{10}$/',         // e.g., KBZ1234567890
        'WAVEPAY' => '/^WP[0-9]{8}[A-Z]$/',     // e.g., WP12345678A
        'CARD' => '/^CARD[0-9]{6}$/',           // e.g., CARD123456
        'BANK' => '/^TRX[0-9]{8}$/'             // e.g., TRX12345678
    ];

    // Verify reference number format
    if (!isset($patterns[$method]) || !preg_match($patterns[$method], $reference)) {
        return [
            'success' => false,
            'error' => "Invalid $method reference number format. Example format: " . getExampleReference($method)
        ];
    }

    // Simulate API delay
    usleep(rand(300000, 800000)); // 0.3-0.8 seconds delay

    // Mock successful response (90% success rate for testing)
    if (rand(1, 100) <= 90) {
        return [
            'success' => true,
            'message' => 'Payment verified successfully',
            'data' => [
                'transactionId' => $reference,
                'amount' => $amount,
                'currency' => 'MMK',
                'status' => 'SUCCESS',
                'paymentMethod' => $method,
                'timestamp' => date('Y-m-d H:i:s'),
                'merchantName' => 'BitsTech Computer Store'
            ]
        ];
    } else {
        // Simulate random errors
        $errors = [
            'Network timeout',
            'Invalid transaction',
            'Transaction expired',
            'Amount mismatch'
        ];
        return [
            'success' => false,
            'error' => $errors[array_rand($errors)]
        ];
    }
}

function getExampleReference($method) {
    switch ($method) {
        case 'KBZPAY':
            return 'KBZ1234567890';
        case 'WAVEPAY':
            return 'WP12345678A';
        case 'CARD':
            return 'CARD123456';
        case 'BANK':
            return 'TRX12345678';
        default:
            return '';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate required fields
        if (!isset($_POST['reference']) || !isset($_POST['method']) || !isset($_POST['amount'])) {
            throw new Exception('Missing required fields');
        }

        $reference = $_POST['reference'];
        $method = $_POST['method'];
        $amount = floatval($_POST['amount']);

        // Mock verify payment
        $result = mockVerifyPayment($method, $reference, $amount);

        if ($result['success']) {
            // Update payment status in database
            $stmt = $pdo->prepare("
                UPDATE payments 
                SET status = 'verified',
                    verification_date = CURRENT_TIMESTAMP,
                    response_data = ?
                WHERE reference_number = ?
            ");
            $stmt->execute([json_encode($result['data']), $reference]);

            // Log the verification
            $stmt = $pdo->prepare("
                INSERT INTO payment_logs (
                    payment_reference,
                    verification_status,
                    response_data,
                    created_at
                ) VALUES (?, 'success', ?, CURRENT_TIMESTAMP)
            ");
            $stmt->execute([$reference, json_encode($result)]);

            echo json_encode([
                'success' => true,
                'message' => $result['message'],
                'data' => $result['data']
            ]);
        } else {
            throw new Exception($result['error']);
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
} 