<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$language = $_SESSION['language'] ?? 'en';
$language_file = "../languages/{$language}.php";
$translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";

$currency = $_SESSION['currency'] ?? 'USD';
$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];

$sale_id = 3; // Fixed to Sale ID 3 as per request
$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total_amount = filter_input(INPUT_POST, 'total_amount', FILTER_VALIDATE_FLOAT);
    $sale_date = filter_input(INPUT_POST, 'sale_date', FILTER_SANITIZE_STRING);

    if ($total_amount !== false && $total_amount >= 0 && !empty($sale_date)) {
        try {
            $stmt = $pdo->prepare("UPDATE sales SET total_amount = ?, sale_date = ? WHERE sale_id = ?");
            $stmt->execute([$total_amount, $sale_date, $sale_id]);
            $success = true;
            $message = $translations['sale_updated'] ?? 'Sale updated successfully.';
            // Redirect to dashboard after a short delay to show success message
            header("Refresh: 2; url=dashboard.php");
        } catch (PDOException $e) {
            $message = $translations['error_updating_sale'] ?? 'Error updating sale.';
            error_log("Error updating sale ID $sale_id: " . $e->getMessage());
        }
    } else {
        $message = $translations['invalid_input'] ?? 'Invalid input. Please check the amount and date.';
    }
}

// Fetch current sale data
try {
    $stmt = $pdo->prepare("SELECT s.total_amount, s.sale_date, c.customer_name 
                           FROM sales s 
                           LEFT JOIN customers c ON s.customer_id = c.customer_id 
                           WHERE s.sale_id = ?");
    $stmt->execute([$sale_id]);
    $sale = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$sale) {
        $message = $translations['sale_not_found'] ?? 'Sale not found.';
    }
} catch (PDOException $e) {
    $message = $translations['error_fetching_sale'] ?? 'Error fetching sale data.';
    error_log("Error fetching sale ID $sale_id: " . $e->getMessage());
    $sale = ['total_amount' => 0, 'sale_date' => date('Y-m-d H:i:s'), 'customer_name' => 'N/A'];
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $translations['edit_sale_title'] ?? 'Edit Sale - BitsTech POS'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Myanmar&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>
    <div class="page-content-wrapper">
        <div class="main-content">
            <div class="container">
                <div class="dashboard-card">
                    <h4><?php echo $translations['edit_sale'] ?? 'Edit Sale'; ?> (ID: <?php echo htmlspecialchars($sale_id); ?>)</h4>
                    <?php if ($message): ?>
                        <div class="alert <?php echo $success ? 'alert-success' : 'alert-danger'; ?>" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="customer_name" class="form-label"><?php echo $translations['customer_name'] ?? 'Customer Name'; ?></label>
                            <input type="text" class="form-control" id="customer_name" value="<?php echo htmlspecialchars($sale['customer_name'] ?? 'N/A'); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="total_amount" class="form-label"><?php echo $translations['amount'] ?? 'Amount'; ?> (<?php echo htmlspecialchars($currency); ?>)</label>
                            <input type="number" class="form-control" id="total_amount" name="total_amount" step="0.01" min="0" value="<?php echo htmlspecialchars($sale['total_amount']); ?>" required>
                            <div class="invalid-feedback"><?php echo $translations['required_amount'] ?? 'Please enter a valid amount.'; ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="sale_date" class="form-label"><?php echo $translations['date'] ?? 'Date'; ?></label>
                            <input type="datetime-local" class="form-control" id="sale_date" name="sale_date" value="<?php echo date('Y-m-d\TH:i', strtotime($sale['sale_date'])); ?>" required>
                            <div class="invalid-feedback"><?php echo $translations['required_date'] ?? 'Please enter a valid date.'; ?></div>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo $translations['save_changes'] ?? 'Save Changes'; ?></button>
                        <a href="dashboard.php" class="btn btn-secondary"><?php echo $translations['cancel'] ?? 'Cancel'; ?></a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Bootstrap form validation
        (function () {
            'use strict';
            const forms = document.querySelectorAll('.needs-validation');
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        })();
    </script>
</body>
</html>