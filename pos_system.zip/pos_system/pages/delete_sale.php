<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
header('Content-Type: application/json');

if (isset($_POST['sale_id'])) {
    $sale_id = $_POST['sale_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM sales WHERE sale_id = ?");
        $stmt->execute([$sale_id]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to delete sale: ' . $e->getMessage()]);
        error_log("Error deleting sale: " . $e->getMessage());
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid sale ID']);
}
?>