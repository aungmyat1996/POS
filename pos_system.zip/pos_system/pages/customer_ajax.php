<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

header('Content-Type: application/json');

if (isset($_POST['update_customer'])) {
    $_SESSION['customer_info'] = [
        'name' => htmlspecialchars($_POST['customer_name'] ?? ''),
        'address' => htmlspecialchars($_POST['address'] ?? ''),
        'phone' => htmlspecialchars($_POST['phone'] ?? '')
    ];
    echo json_encode(['success' => true, 'customer_info' => $_SESSION['customer_info']]);
    exit;
}

if (isset($_POST['clear_customer'])) {
    $_SESSION['customer_info'] = ['name' => '', 'address' => '', 'phone' => ''];
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false]);