<?php
define('BASEPATH', dirname(__DIR__) . '/');
require_once BASEPATH . 'includes/security_check.php';
require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Require authentication for this page
requireAuth();
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : '';

$where_clause = '';
$params = [];
if (!empty($search_query)) {
    if (is_numeric($search_query)) {
        $where_clause = "WHERE p.product_id = ?";
        $params[] = $search_query;
    } else {
        $where_clause = "WHERE p.product_name LIKE ?";
        $params[] = "%$search_query%";
    }
}
if (!empty($category_id)) {
    $where_clause .= (!empty($where_clause) ? " AND " : "WHERE ") . "p.category_id = ?";
    $params[] = $category_id;
}

$stmt = $pdo->prepare("SELECT p.*, c.category_name 
                       FROM products p 
                       LEFT JOIN categories c ON p.category_id = c.category_id 
                       $where_clause");
$stmt->execute($params);
$products = $stmt->fetchAll();

$exchange_rates = ['USD' => 1, 'THB' => 33, 'MMK' => 2100];
$currency = isset($_SESSION['currency']) ? $_SESSION['currency'] : 'USD';

// Fetch categories for the edit modal
$stmt = $pdo->query("SELECT * FROM categories");
$categories = $stmt->fetchAll();

if (empty($products)) {
    echo '<tr><td colspan="10" class="text-center">No products found.</td></tr>';
} else {
    foreach ($products as $product) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($product['product_id']) . '</td>';
        echo '<td><img src="../public/images/' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['product_name']) . '"></td>';
        echo '<td>' . htmlspecialchars($product['product_name']) . '</td>';
        echo '<td>' . htmlspecialchars($product['description'] ?? 'No description') . '</td>';
        echo '<td>' . htmlspecialchars($product['category_name'] ?? 'Uncategorized') . '</td>';
        echo '<td>' . format_currency($product['price'], $currency, $exchange_rates, $product['discount']) . '</td>';
        echo '<td>' . htmlspecialchars($product['discount']) . '%</td>';
        echo '<td>' . htmlspecialchars($product['stock_quantity']) . '</td>';
        echo '<td>' . htmlspecialchars($product['barcode'] ?? 'N/A') . '</td>';
        echo '<td>';
        echo '<button class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#editModal' . $product['product_id'] . '"><i class="fas fa-edit"></i></button>';
        echo '<form method="POST" style="display:inline;" onsubmit="return confirm(\'Are you sure you want to delete this product?\');">';
        echo '<input type="hidden" name="product_id" value="' . $product['product_id'] . '">';
        echo '<button type="submit" class="btn btn-delete" name="delete_product"><i class="fas fa-trash"></i></button>';
        echo '</form>';
        echo '</td>';
        echo '</tr>';

        // Edit Modal
        echo '<div class="modal fade edit-modal" id="editModal' . $product['product_id'] . '" tabindex="-1" aria-labelledby="editModalLabel' . $product['product_id'] . '" aria-hidden="true">';
        echo '<div class="modal-dialog">';
        echo '<div class="modal-content">';
        echo '<div class="modal-header">';
        echo '<h5 class="modal-title" id="editModalLabel' . $product['product_id'] . '">Edit Product</h5>';
        echo '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
        echo '</div>';
        echo '<div class="modal-body">';
        echo '<form method="POST" enctype="multipart/form-data">';
        echo '<input type="hidden" name="product_id" value="' . $product['product_id'] . '">';
        echo '<input type="hidden" name="current_image" value="' . $product['image'] . '">';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Product Name</label>';
        echo '<input type="text" class="form-control" name="product_name" value="' . htmlspecialchars($product['product_name']) . '" required>';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Category</label>';
        echo '<select class="form-select" name="category_id" required>';
        foreach ($categories as $category) {
            echo '<option value="' . $category['category_id'] . '"' . ($category['category_id'] == $product['category_id'] ? ' selected' : '') . '>' . htmlspecialchars($category['category_name']) . '</option>';
        }
        echo '</select>';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Price</label>';
        echo '<input type="number" step="0.01" class="form-control" name="price" value="' . $product['price'] . '" required>';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Stock Quantity</label>';
        echo '<input type="number" class="form-control" name="stock_quantity" value="' . $product['stock_quantity'] . '" required>';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Discount (%)</label>';
        echo '<input type="number" min="0" max="100" class="form-control" name="discount" value="' . $product['discount'] . '">';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Barcode</label>';
        echo '<input type="text" class="form-control" name="barcode" value="' . htmlspecialchars($product['barcode'] ?? '') . '">';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Description</label>';
        echo '<textarea class="form-control" name="description">' . htmlspecialchars($product['description'] ?? '') . '</textarea>';
        echo '</div>';
        echo '<div class="mb-3">';
        echo '<label class="form-label">Image</label>';
        echo '<input type="file" class="form-control" name="image" accept="image/*">';
        echo '<img src="../public/images/' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['product_name']) . '" style="max-width: 100px; margin-top: 10px;">';
        echo '</div>';
        echo '<button type="submit" class="btn btn-save" name="edit_product">Save Changes</button>';
        echo '</form>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
}