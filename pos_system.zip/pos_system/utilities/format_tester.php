<?php
/**
 * Date Format Testing Utility
 * Comprehensive testing tool for date format functionality
 */

// Set the base path
define('BASEPATH', dirname(__DIR__) . '/');

require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Get current settings
function getCurrentSettings($pdo) {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('timezone', 'date_format', 'language', 'currency')");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
}

// Test date format conversion
function testDateFormatConversion() {
    $formats = [
        'Y-m-d' => 'ISO Format (2025-05-27)',
        'd/m/Y' => 'European Format (27/05/2025)',
        'm/d/Y' => 'US Format (05/27/2025)',
        'Y/m/d' => 'Asian Format (2025/05/27)',
        'F j, Y' => 'Long Format (May 27, 2025)',
        'M j, Y' => 'Medium Format (May 27, 2025)',
        'j F Y' => 'Day Month Year (27 May 2025)',
        'd-m-Y' => 'Dash Format (27-05-2025)',
        'Y.m.d' => 'Dot Format (2025.05.27)'
    ];
    
    echo "<h3>Date Format Conversion Test:</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Format</th><th>Description</th><th>PHP Format</th><th>Sample Output</th></tr>";
    
    foreach ($formats as $format => $description) {
        $phpFormat = convertDateFormatToPhp($format);
        $sample = date($phpFormat);
        echo "<tr>";
        echo "<td><code>$format</code></td>";
        echo "<td>$description</td>";
        echo "<td><code>$phpFormat</code></td>";
        echo "<td><strong>$sample</strong></td>";
        echo "</tr>";
    }
    
    echo "</table>";
}

// Test timezone functionality
function testTimezones($pdo) {
    $timezones = [
        'Asia/Yangon' => 'Myanmar Time',
        'Asia/Bangkok' => 'Thailand Time',
        'Asia/Singapore' => 'Singapore Time',
        'UTC' => 'Coordinated Universal Time',
        'America/New_York' => 'Eastern Time',
        'Europe/London' => 'Greenwich Mean Time'
    ];
    
    echo "<h3>Timezone Test:</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Timezone</th><th>Description</th><th>Current Time</th><th>Offset</th></tr>";
    
    foreach ($timezones as $timezone => $description) {
        try {
            $tz = new DateTimeZone($timezone);
            $dt = new DateTime('now', $tz);
            $offset = $dt->format('P');
            $time = $dt->format('Y-m-d H:i:s');
            
            echo "<tr>";
            echo "<td><code>$timezone</code></td>";
            echo "<td>$description</td>";
            echo "<td><strong>$time</strong></td>";
            echo "<td>$offset</td>";
            echo "</tr>";
        } catch (Exception $e) {
            echo "<tr>";
            echo "<td><code>$timezone</code></td>";
            echo "<td>$description</td>";
            echo "<td colspan='2'><span style='color: red;'>Error: " . $e->getMessage() . "</span></td>";
            echo "</tr>";
        }
    }
    
    echo "</table>";
}

// Test database operations
function testDatabaseOperations($pdo) {
    echo "<h3>Database Operations Test:</h3>";
    
    try {
        // Test reading settings
        echo "<h4>Current Settings:</h4>";
        $settings = getCurrentSettings($pdo);
        echo "<pre>";
        print_r($settings);
        echo "</pre>";
        
        // Test updating date format
        echo "<h4>Testing Date Format Update:</h4>";
        $testFormat = 'F j, Y';
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('date_format', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result = $stmt->execute([$testFormat, $testFormat]);
        
        if ($result) {
            echo "<span style='color: green;'>✓ Successfully updated date format to: $testFormat</span><br>";
            $newDatetime = get_current_datetime('', $pdo);
            echo "New datetime output: <strong>$newDatetime</strong><br>";
        } else {
            echo "<span style='color: red;'>✗ Failed to update date format</span><br>";
        }
        
        // Test updating timezone
        echo "<h4>Testing Timezone Update:</h4>";
        $testTimezone = 'Asia/Bangkok';
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('timezone', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result = $stmt->execute([$testTimezone, $testTimezone]);
        
        if ($result) {
            echo "<span style='color: green;'>✓ Successfully updated timezone to: $testTimezone</span><br>";
            $newDatetime = get_current_datetime($testTimezone, $pdo);
            echo "New datetime output: <strong>$newDatetime</strong><br>";
        } else {
            echo "<span style='color: red;'>✗ Failed to update timezone</span><br>";
        }
        
    } catch (Exception $e) {
        echo "<span style='color: red;'>Database Error: " . $e->getMessage() . "</span><br>";
    }
}

// Main testing interface
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System - Date Format Tester</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #8b5cf6;
            padding-bottom: 10px;
        }
        h3 {
            color: #555;
            margin-top: 30px;
        }
        table {
            margin: 10px 0;
        }
        th {
            background-color: #8b5cf6;
            color: white;
            padding: 10px;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        code {
            background-color: #f0f0f0;
            padding: 2px 4px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        .test-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🕐 POS System - Date Format Tester</h1>
        <p>This utility tests date format and timezone functionality for the POS system.</p>
        
        <div class="test-section">
            <?php
            echo "<h2>System Information</h2>";
            echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";
            echo "<p><strong>Current Time:</strong> " . date('Y-m-d H:i:s T') . "</p>";
            echo "<p><strong>Server Timezone:</strong> " . date_default_timezone_get() . "</p>";
            ?>
        </div>
        
        <div class="test-section">
            <?php testDateFormatConversion(); ?>
        </div>
        
        <div class="test-section">
            <?php testTimezones($pdo); ?>
        </div>
        
        <div class="test-section">
            <?php testDatabaseOperations($pdo); ?>
        </div>
        
        <div class="test-section">
            <h3>Function Test:</h3>
            <?php
            echo "<h4>get_current_datetime() Function Test:</h4>";
            $currentSettings = getCurrentSettings($pdo);
            $datetime = get_current_datetime('', $pdo);
            echo "<p>Current datetime with system settings: <strong>$datetime</strong></p>";
            
            echo "<h4>Different Timezone Test:</h4>";
            $testTimezones = ['Asia/Yangon', 'Asia/Bangkok', 'UTC', 'America/New_York'];
            foreach ($testTimezones as $tz) {
                $datetime = get_current_datetime($tz, $pdo);
                echo "<p>$tz: <strong>$datetime</strong></p>";
            }
            ?>
        </div>
        
        <div class="test-section">
            <h3>Test Complete</h3>
            <p class="success">✓ All tests have been executed. Check the results above for any issues.</p>
            <p><em>Last updated: <?php echo date('Y-m-d H:i:s'); ?></em></p>
        </div>
    </div>
</body>
</html>
