<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System - Utilities</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            padding-top: 50px;
        }
        .utility-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .utility-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }
        .utility-icon {
            font-size: 3rem;
            color: #8b5cf6;
            margin-bottom: 20px;
        }
        .utility-title {
            color: #333;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .utility-description {
            color: #666;
            margin-bottom: 20px;
        }
        .btn-utility {
            background: linear-gradient(45deg, #8b5cf6, #667eea);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-utility:hover {
            background: linear-gradient(45deg, #7c3aed, #5b21b6);
            color: white;
            transform: scale(1.05);
        }
        .header-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 40px;
            text-align: center;
            color: white;
        }
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <a href="../pages/settings.php" class="back-btn">
        <i class="fas fa-arrow-left"></i> Back to Settings
    </a>

    <div class="container">
        <div class="header-card">
            <h1><i class="fas fa-tools"></i> POS System Utilities</h1>
            <p class="lead">Development and testing tools for the POS system</p>
        </div>

        <div class="row">
            <!-- DateTime Handler -->
            <div class="col-md-6">
                <div class="utility-card text-center">
                    <div class="utility-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3 class="utility-title">DateTime Handler</h3>
                    <p class="utility-description">
                        Handle date format updates and datetime retrieval. 
                        Test timezone changes and date format conversions in real-time.
                    </p>
                    <div class="mb-3">
                        <strong>Features:</strong>
                        <ul class="text-start mt-2">
                            <li>Update date formats</li>
                            <li>Change timezones</li>
                            <li>Get current datetime</li>
                            <li>Combined settings update</li>
                        </ul>
                    </div>
                    <a href="datetime_handler.php" class="btn btn-utility">
                        <i class="fas fa-play"></i> Open Handler
                    </a>
                </div>
            </div>

            <!-- Format Tester -->
            <div class="col-md-6">
                <div class="utility-card text-center">
                    <div class="utility-icon">
                        <i class="fas fa-vial"></i>
                    </div>
                    <h3 class="utility-title">Format Tester</h3>
                    <p class="utility-description">
                        Comprehensive testing tool for date format functionality. 
                        Test all supported formats and timezone combinations.
                    </p>
                    <div class="mb-3">
                        <strong>Features:</strong>
                        <ul class="text-start mt-2">
                            <li>Date format conversion tests</li>
                            <li>Timezone functionality tests</li>
                            <li>Database operations tests</li>
                            <li>Function validation tests</li>
                        </ul>
                    </div>
                    <a href="format_tester.php" class="btn btn-utility">
                        <i class="fas fa-flask"></i> Run Tests
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- API Documentation -->
            <div class="col-md-12">
                <div class="utility-card">
                    <h3 class="utility-title">
                        <i class="fas fa-book"></i> API Documentation
                    </h3>
                    <p class="utility-description">
                        Available API endpoints for datetime operations:
                    </p>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>DateTime Handler Endpoints:</h5>
                            <ul>
                                <li><code>POST /utilities/datetime_handler.php</code></li>
                                <li><strong>Actions:</strong></li>
                                <ul>
                                    <li><code>update_format</code> - Update date format</li>
                                    <li><code>get_datetime</code> - Get current datetime</li>
                                    <li><code>update_timezone</code> - Update timezone</li>
                                    <li><code>update_datetime_settings</code> - Update both</li>
                                </ul>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h5>Example Usage:</h5>
                            <pre class="bg-light p-3 rounded"><code>$.ajax({
    url: 'utilities/datetime_handler.php',
    type: 'POST',
    data: {
        action: 'update_format',
        format: 'Y-m-d'
    },
    dataType: 'json',
    success: function(response) {
        console.log(response.datetime);
    }
});</code></pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- System Information -->
            <div class="col-md-12">
                <div class="utility-card">
                    <h3 class="utility-title">
                        <i class="fas fa-info-circle"></i> System Information
                    </h3>
                    <div class="row">
                        <div class="col-md-3">
                            <strong>PHP Version:</strong><br>
                            <span class="text-muted"><?php echo PHP_VERSION; ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Server Time:</strong><br>
                            <span class="text-muted"><?php echo date('Y-m-d H:i:s T'); ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Server Timezone:</strong><br>
                            <span class="text-muted"><?php echo date_default_timezone_get(); ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Available Utilities:</strong><br>
                            <span class="text-muted">2 tools</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
