<?php
/**
 * DateTime Handler Utility
 * Handles date format updates and datetime retrieval for the POS system
 */

// Set the base path
define('BASEPATH', dirname(__DIR__) . '/');

require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Handle date format update requests
if ($_POST['action'] ?? '' === 'update_format') {
    try {
        $format = $_POST['format'] ?? 'Y-m-d';
        
        // Validate format
        $allowedFormats = ['Y-m-d', 'd/m/Y', 'm/d/Y', 'Y/m/d', 'F j, Y', 'M j, Y', 'j F Y', 'd-m-Y', 'Y.m.d'];
        if (!in_array($format, $allowedFormats)) {
            throw new Exception('Invalid date format');
        }

        // Update database
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('date_format', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result = $stmt->execute([$format, $format]);

        if ($result) {
            echo json_encode([
                'success' => true,
                'format' => $format,
                'datetime' => get_current_datetime('', $pdo),
                'message' => 'Date format updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update date format in database');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// Handle datetime retrieval requests
if ($_POST['action'] ?? '' === 'get_datetime') {
    try {
        $timezone = $_POST['timezone'] ?? '';
        
        echo json_encode([
            'success' => true,
            'datetime' => get_current_datetime($timezone, $pdo),
            'timestamp' => time()
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// Handle timezone update requests
if ($_POST['action'] ?? '' === 'update_timezone') {
    try {
        $timezone = $_POST['timezone'] ?? 'Asia/Yangon';
        
        // Validate timezone
        if (!in_array($timezone, timezone_identifiers_list())) {
            throw new Exception('Invalid timezone');
        }

        // Update database
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('timezone', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result = $stmt->execute([$timezone, $timezone]);

        if ($result) {
            echo json_encode([
                'success' => true,
                'timezone' => $timezone,
                'datetime' => get_current_datetime($timezone, $pdo),
                'message' => 'Timezone updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update timezone in database');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// Handle combined format and timezone update
if ($_POST['action'] ?? '' === 'update_datetime_settings') {
    try {
        $format = $_POST['format'] ?? 'Y-m-d';
        $timezone = $_POST['timezone'] ?? 'Asia/Yangon';
        
        // Validate inputs
        $allowedFormats = ['Y-m-d', 'd/m/Y', 'm/d/Y', 'Y/m/d', 'F j, Y', 'M j, Y', 'j F Y', 'd-m-Y', 'Y.m.d'];
        if (!in_array($format, $allowedFormats)) {
            throw new Exception('Invalid date format');
        }
        
        if (!in_array($timezone, timezone_identifiers_list())) {
            throw new Exception('Invalid timezone');
        }

        // Update both settings
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('date_format', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result1 = $stmt->execute([$format, $format]);
        
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('timezone', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $result2 = $stmt->execute([$timezone, $timezone]);

        if ($result1 && $result2) {
            echo json_encode([
                'success' => true,
                'format' => $format,
                'timezone' => $timezone,
                'datetime' => get_current_datetime($timezone, $pdo),
                'message' => 'DateTime settings updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update datetime settings in database');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// If no valid action, return error
echo json_encode([
    'success' => false,
    'error' => 'Invalid action or missing parameters'
]);
?>
