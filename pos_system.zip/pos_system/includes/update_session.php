<?php
/**
 * Update session variables when settings change
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/**
 * Update session variables from database settings
 */
function updateSessionFromSettings($pdo) {
    try {
        // Get current settings from database
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Update session variables
        if (isset($settings['site_name'])) {
            $_SESSION['system_name'] = $settings['site_name'];
        }
        
        if (isset($settings['site_logo'])) {
            $_SESSION['logo_path'] = '../' . $settings['site_logo'];
        }
        
        if (isset($settings['language'])) {
            $_SESSION['language'] = $settings['language'];
        }
        
        if (isset($settings['currency'])) {
            $_SESSION['currency'] = $settings['currency'];
        }
        
        if (isset($settings['timezone'])) {
            $_SESSION['timezone'] = $settings['timezone'];
        }
        
        return [
            'success' => true,
            'updated_settings' => [
                'system_name' => $_SESSION['system_name'] ?? null,
                'logo_path' => $_SESSION['logo_path'] ?? null,
                'language' => $_SESSION['language'] ?? null,
                'currency' => $_SESSION['currency'] ?? null,
                'timezone' => $_SESSION['timezone'] ?? null
            ]
        ];
        
    } catch (PDOException $e) {
        error_log("Error updating session from settings: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

// If called directly via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_session') {
    header('Content-Type: application/json');
    
    try {
        $result = updateSessionFromSettings($pdo);
        echo json_encode($result);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}
?>
