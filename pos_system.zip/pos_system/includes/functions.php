<?php
// Set session cookie parameters and start session
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 3600,           // 1 hour
        'path' => '/',
        'secure' => true,             // Use HTTPS only
        'httponly' => true,           // Prevent JavaScript access
        'samesite' => 'Strict',       // CSRF protection
    ]);
    session_start();

    // Regenerate session ID every 30 minutes for security
    if (!isset($_SESSION['last_regeneration']) || (time() - $_SESSION['last_regeneration']) > 1800) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

/**
 * Redirects to login page if user is not authenticated.
 *
 * @return never No return, exits after redirection
 */
function requireLogin(): void {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
    if (function_exists('logAction') && isset($GLOBALS['pdo'])) {
        logAction($GLOBALS['pdo'], (int)$_SESSION['user_id'], 'Checked login status');
    }
}

/**
 * Checks if the current user has admin privileges.
 *
 * @return bool True if user is an admin, false otherwise
 */
function isAdmin(): bool {
    return isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'admin';
}

/**
 * Checks if a user is logged in.
 *
 * @return bool True if user is logged in, false otherwise
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

/**
 * Logs user actions to the database with a timestamp.
 *
 * @param PDO $pdo Database connection object
 * @param int $userId The ID of the user performing the action
 * @param string $action The action being logged
 * @return void
 * @throws RuntimeException If database operation fails
 */
function logAction(PDO $pdo, int $userId, string $action): void {
    try {
        if (!$pdo instanceof PDO) {
            throw new RuntimeException('Invalid PDO instance provided for logging');
        }

        $checkTable = $pdo->query("SHOW TABLES LIKE 'logs'");
        if ($checkTable->rowCount() === 0) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                action VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        }

        $stmt = $pdo->prepare("INSERT INTO logs (user_id, action) VALUES (:user_id, :action)");
        $stmt->execute([':user_id' => $userId, ':action' => $action]);
    } catch (Exception $e) {
        error_log("Log action failed for user ID $userId: " . $e->getMessage());
    }
}

/**
 * Sanitizes input data to prevent XSS attacks.
 *
 * @param mixed $input The input to sanitize
 * @return mixed Sanitized input (string or array of strings)
 */
function sanitize_input(mixed $input): mixed {
    if (is_array($input)) {
        return array_map('sanitize_input', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Retrieves the current date and time in the specified timezone and format.
 *
 * @param string $timezone Timezone string (e.g., 'Asia/Yangon'), defaults to system timezone
 * @param PDO|null $pdo Database connection to fetch timezone and date format from settings
 * @return string Formatted date and time (e.g., "Friday, May 23, 2025, 12:06 PM MMT")
 */
function get_current_datetime(string $timezone = '', ?PDO $pdo = null): string {
    try {
        $dateFormat = 'l, F j, Y, h:i A T'; // Default format

        // Always try to get settings from database if PDO is available
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('timezone', 'date_format')");
                $stmt->execute();
                $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

                error_log("GET_CURRENT_DATETIME: Retrieved settings: " . print_r($settings, true));

                // Use timezone from database if not provided
                if (empty($timezone) && isset($settings['timezone']) && $settings['timezone']) {
                    $timezone = $settings['timezone'];
                    error_log("GET_CURRENT_DATETIME: Using timezone from DB: " . $timezone);
                }

                // Always use date_format from database if available
                if (isset($settings['date_format']) && $settings['date_format']) {
                    $originalFormat = $settings['date_format'];
                    $dateFormat = convertDateFormatToPhp($settings['date_format']);
                    error_log("GET_CURRENT_DATETIME: Using date format from DB: $originalFormat -> $dateFormat");
                }
            } catch (Exception $e) {
                error_log("Failed to get settings from database: " . $e->getMessage());
            }
        }

        // Use provided timezone or fallback to system default
        $timezoneToUse = $timezone ?: date_default_timezone_get();

        // Handle offset format like '+08:00' by converting to proper timezone
        if (preg_match('/^[+-]\d{2}:\d{2}$/', $timezoneToUse)) {
            $dateTimeZone = new DateTimeZone($timezoneToUse);
        } else {
            $dateTimeZone = new DateTimeZone($timezoneToUse);
        }

        $date = new DateTime('now', $dateTimeZone);
        return $date->format($dateFormat);
    } catch (Exception $e) {
        error_log("Failed to get current datetime: " . $e->getMessage());
        return date('l, F j, Y, h:i A T'); // Fallback to server time
    }
}

/**
 * Converts date format setting to PHP date format string.
 *
 * @param string $format Date format from settings
 * @return string PHP date format string
 */
function convertDateFormatToPhp(string $format): string {
    // Map common date formats to PHP format with time and timezone
    $formatMap = [
        'Y-m-d' => 'l, Y-m-d, h:i A T',
        'd/m/Y' => 'l, d/m/Y, h:i A T',
        'm/d/Y' => 'l, m/d/Y, h:i A T',
        'Y/m/d' => 'l, Y/m/d, h:i A T',
        'F j, Y' => 'l, F j, Y, h:i A T',
        'M j, Y' => 'l, M j, Y, h:i A T',
        'j F Y' => 'l, j F Y, h:i A T',
        'd-m-Y' => 'l, d-m-Y, h:i A T',
        'Y.m.d' => 'l, Y.m.d, h:i A T'
    ];

    return $formatMap[$format] ?? 'l, F j, Y, h:i A T';
}

/**
 * Formats a currency amount with optional discount and exchange rate conversion.
 *
 * @param float $price The original price
 * @param string $currency The currency code (e.g., 'USD', 'MMK', 'THB')
 * @param array $exchangeRates Array of exchange rates (e.g., ['USD' => 1, 'THB' => 33])
 * @param float $discount Discount percentage (e.g., 10 for 10%), defaults to 0
 * @return string Formatted currency string with symbol
 */
function format_currency(float $price, string $currency, array $exchangeRates, float $discount = 0): string {
    $currencySymbols = [
        'USD' => '$',
        'THB' => '฿',
        'MMK' => 'Ks',
    ];

    if ($price < 0 || !isset($exchangeRates[$currency]) || !is_numeric($exchangeRates[$currency])) {
        return 'Invalid Amount';
    }

    $exchangeRate = floatval($exchangeRates[$currency]);
    $convertedPrice = $price * $exchangeRate;
    $discountedPrice = $convertedPrice * (1 - ($discount / 100));

    $symbol = $currencySymbols[$currency] ?? $currency;
    $formattedPrice = number_format($convertedPrice, 2, '.', ',');
    $formattedDiscounted = number_format($discountedPrice, 2, '.', ',');

    $result = "$symbol $formattedPrice";
    if ($discount > 0) {
        $result .= ' <span style="color: #28a745;">(' . $symbol . ' ' . $formattedDiscounted . ')</span>';
    }
    return $result;
}

/**
 * Handles image upload and returns the file name.
 *
 * @param array $file The uploaded file array from $_FILES
 * @param string $defaultImage Default image name if upload fails, defaults to 'default.jpg'
 * @return string The uploaded file name or default image name
 */
function upload_image(array $file, string $defaultImage = 'default.jpg'): string {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        error_log("Image upload failed: Error code " . ($file['error'] ?? 'N/A'));
        return $defaultImage;
    }

    $uploadDir = '../public/images/';
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        error_log("Failed to create upload directory: $uploadDir");
        return $defaultImage;
    }

    $fileType = mime_content_type($file['tmp_name']);
    if (!in_array($fileType, $allowedTypes)) {
        error_log("Invalid image type: $fileType");
        return $defaultImage;
    }

    if ($file['size'] > $maxSize) {
        error_log("Image size exceeds limit: " . $file['size']);
        return $defaultImage;
    }

    $imageName = time() . '_' . preg_replace('/[^A-Za-z0-9\._-]/', '', basename($file['name']));
    $targetFile = $uploadDir . $imageName;

    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return $imageName;
    }

    error_log("Failed to upload image: " . $file['name']);
    return $defaultImage;
}

/**
 * Generates a unique barcode for a product.
 *
 * @param string $prefix A prefix for the barcode (e.g., product name), defaults to empty
 * @param int $length The length of the random part, defaults to 8
 * @return string The generated barcode (e.g., "PROD-ABC12345")
 */
function generate_barcode(string $prefix = '', int $length = 8): string {
    $prefix = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', substr($prefix, 0, 10)));
    $randomPart = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, $length);
    return $prefix . ($prefix ? '-' : '') . $randomPart;
}

/**
 * Validates if a barcode is unique in the database.
 *
 * @param PDO $pdo Database connection object
 * @param string $barcode The barcode to validate
 * @param int|null $excludeProductId Product ID to exclude (for edits), defaults to null
 * @return bool True if barcode is unique, false otherwise
 */
function validate_barcode(PDO $pdo, string $barcode, ?int $excludeProductId = null): bool {
    try {
        $query = "SELECT COUNT(*) FROM products WHERE barcode = :barcode";
        $params = [' :barcode' => $barcode];
        if ($excludeProductId !== null) {
            $query .= " AND product_id != :exclude_id";
            $params[':exclude_id'] = $excludeProductId;
        }
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchColumn() === 0;
    } catch (PDOException $e) {
        error_log("Barcode validation failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Translates a key to the current language.
 *
 * @param string $key The key to translate
 * @return string The translated string or the key if not found
 */
function translate(string $key): string {
    global $translations;
    return $translations[$key] ?? $key;
}

/**
 * Switches the user's language in the session.
 *
 * @param string $lang Language code (e.g., 'en', 'my')
 * @return bool True on success, false on failure
 */
function switchLanguage(string $lang): bool {
    $allowedLanguages = ['en', 'my'];
    if (in_array(strtolower($lang), $allowedLanguages, true)) {
        $_SESSION['language'] = strtolower($lang);
        return true;
    }
    return false;
}

/**
 * Gets the current language from session or database.
 *
 * @param PDO $pdo Database connection
 * @return string Current language code
 */
function getCurrentLanguage(PDO $pdo): string {
    if (isset($_SESSION['language'])) {
        return $_SESSION['language'];
    }

    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_name = 'language' LIMIT 1");
        $stmt->execute();
        $language = $stmt->fetchColumn();
        if ($language && in_array($language, ['en', 'my'], true)) {
            $_SESSION['language'] = $language;
            return $language;
        }
    } catch (Exception $e) {
        error_log("Error getting language setting: " . $e->getMessage());
    }

    return 'en'; // Default to English
}

/**
 * Loads language file based on the specified language.
 *
 * @param string $language Language code (e.g., 'en', 'my'), defaults to current language
 * @return array Language translations
 */
function loadLanguage(string $language = ''): array {
    global $pdo;
    $language = $language ?: getCurrentLanguage($pdo);
    $languageFile = __DIR__ . "/../languages/{$language}.php";
    return file_exists($languageFile) ? require $languageFile : require __DIR__ . "/../languages/en.php";
}

/**
 * Changes the system language for the current user.
 *
 * @param PDO $pdo Database connection
 * @param string $language Language code to change to
 * @param int $userId Current user ID
 * @return bool Success status
 */
function changeLanguage(PDO $pdo, string $language, int $userId): bool {
    try {
        if (!in_array(strtolower($language), ['en', 'my'], true)) {
            return false;
        }

        $_SESSION['language'] = strtolower($language);

        $stmt = $pdo->prepare("INSERT INTO settings (setting_name, setting_value) VALUES ('language', ?)
                              ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$language, $language]);

        logAction($pdo, $userId, "Changed language to $language");
        return true;
    } catch (Exception $e) {
        error_log("Error changing language: " . $e->getMessage());
        return false;
    }
}

/**
 * Gets the current logged-in user's data.
 *
 * @param PDO|null $pdo PDO database connection object, optional
 * @return array|null User data as an associative array, or null if not logged in or error
 */
function getCurrentUser(?PDO $pdo = null): ?array {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    if (isset($_SESSION['user_data'])) {
        return $_SESSION['user_data'];
    }

    if ($pdo) {
        try {
            $stmt = $pdo->prepare("SELECT user_id, username, email, role, first_name, last_name, language_preference, theme_preference
                                 FROM users WHERE user_id = :user_id LIMIT 1");
            $stmt->execute([':user_id' => $_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $_SESSION['user_data'] = $user;
                return $user;
            }
        } catch (PDOException $e) {
            error_log("Error fetching current user: " . $e->getMessage());
        }
    }

    return [
        'user_id' => (int)$_SESSION['user_id'],
        'username' => $_SESSION['username'] ?? 'User',
        'role' => $_SESSION['role'] ?? 'guest',
    ];
}

/**
 * Get unread notifications count for a user
 */
function getUnreadNotificationsCount($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE");
        $stmt->execute([$user_id]);
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error getting unread notifications count: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get notifications for a user
 */
function getUserNotifications($pdo, $user_id, $limit = 10) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$user_id, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting user notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Create a new notification
 */
function createNotification($pdo, $user_id, $message, $type = 'system') {
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)");
        return $stmt->execute([$user_id, $type, $message]);
    } catch (PDOException $e) {
        error_log("Error creating notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark notifications as read
 */
function markNotificationsAsRead($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = ? AND is_read = FALSE");
        return $stmt->execute([$user_id]);
    } catch (PDOException $e) {
        error_log("Error marking notifications as read: " . $e->getMessage());
        return false;
    }
}

function notifyLowStockProducts($pdo, $user_id, $threshold = 5) {
    $stmt = $pdo->prepare("SELECT product_id, product_name, stock_quantity FROM products WHERE stock_quantity > 0 AND stock_quantity <= ?");
    $stmt->execute([$threshold]);
    $lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($lowStockProducts as $product) {
        $message = "Low stock alert: {$product['product_name']} (ID: {$product['product_id']}) has only {$product['stock_quantity']} left!";
        // Check if this notification already exists (avoid duplicates)
        $check = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND message = ?");
        $check->execute([$user_id, $message]);
        if ($check->fetchColumn() == 0) {
            createNotification($pdo, $user_id, $message, 'low_stock');
        }
    }
}

/**
 * Save theme settings to database
 */
function saveThemeSettings($pdo, $themeSettings) {
    try {
        $pdo->beginTransaction();

        foreach ($themeSettings as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                                  ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $value, $value]);
        }

        $pdo->commit();
        return true;
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error saving theme settings: " . $e->getMessage());
        return false;
    }
}

/**
 * Load theme settings from database
 */
function loadThemeSettings($pdo) {
    try {
        $themeKeys = [
            'theme_mode', 'primary_color', 'secondary_color', 'accent_color',
            'background_color', 'sidebar_color', 'text_color', 'success_color',
            'warning_color', 'danger_color', 'info_color'
        ];

        $placeholders = str_repeat('?,', count($themeKeys) - 1) . '?';
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ($placeholders)");
        $stmt->execute($themeKeys);

        $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        // Set defaults for missing settings
        $defaults = [
            'theme_mode' => 'dark',
            'primary_color' => '#007bff',
            'secondary_color' => '#6c757d',
            'accent_color' => '#17a2b8',
            'background_color' => '#21243A',
            'sidebar_color' => '#2A2D35',
            'text_color' => '#ffffff',
            'success_color' => '#28a745',
            'warning_color' => '#ffc107',
            'danger_color' => '#dc3545',
            'info_color' => '#17a2b8'
        ];

        return array_merge($defaults, $settings);
    } catch (PDOException $e) {
        error_log("Error loading theme settings: " . $e->getMessage());
        return [
            'theme_mode' => 'dark',
            'primary_color' => '#007bff',
            'secondary_color' => '#6c757d',
            'accent_color' => '#17a2b8',
            'background_color' => '#21243A',
            'sidebar_color' => '#2A2D35',
            'text_color' => '#ffffff',
            'success_color' => '#28a745',
            'warning_color' => '#ffc107',
            'danger_color' => '#dc3545',
            'info_color' => '#17a2b8'
        ];
    }
}