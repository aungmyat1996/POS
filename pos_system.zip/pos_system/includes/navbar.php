<?php
// Include required files with proper path handling
if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
}

// Include database and functions if not already included
if (!class_exists('PDO') || !isset($pdo)) {
    require_once BASEPATH . 'config/db.php';
}
if (!function_exists('loadLanguage')) {
    require_once BASEPATH . 'includes/functions.php';
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$user_id_session = $_SESSION['user_id'] ?? null;
error_log("[Navbar] Current Session User ID: " . ($user_id_session ?: 'NOT SET'));

$user = null;
if ($user_id_session && isset($pdo) && $pdo !== null) {
    try {
        $stmt_user_nav = $pdo->prepare("SELECT username FROM users WHERE user_id = ?");
        $stmt_user_nav->execute([$user_id_session]);
        $user = $stmt_user_nav->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("[Navbar] Error fetching username: " . $e->getMessage());
    }
} else {
    error_log("[Navbar] PDO connection not available or user_id not set");
}

// These should be provided by the including page (e.g., products.php, pos.php)
// $logo_path = $_SESSION['logo_path'] ?? '../public/images/logo.png';
// $system_name = $_SESSION['system_name'] ?? 'BitsTech POS';
// $language = $_SESSION['language'] ?? 'en';
// $language_file = "../languages/{$language}.php";
// $translations = file_exists($language_file) ? require $language_file : require "../languages/en.php";
// $currency = $_SESSION['currency'] ?? 'USD';
// $notifications = isset($notifications) ? $notifications : []; // Keep this, parent might pass it or it's fetched here

// Fetch settings from database for logo, site name, and theme settings
$site_logo = '../public/images/logo.png'; // Default logo
$site_name = 'BitsTech P'; // Default site name (updated to match database)
$settings = []; // Initialize settings array

if (isset($pdo) && $pdo !== null) {
    try {
        // Get all settings from database
        $stmt_settings = $pdo->prepare("SELECT setting_key, setting_value FROM settings");
        $stmt_settings->execute();
        $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

        // Load theme settings specifically
        $themeSettings = loadThemeSettings($pdo);
        $settings = array_merge($settings, $themeSettings);

        if (isset($settings['site_logo']) && !empty($settings['site_logo'])) {
            $site_logo = '../' . $settings['site_logo'];
        }
        if (isset($settings['site_name']) && !empty($settings['site_name'])) {
            $site_name = $settings['site_name'];
        }
    } catch (PDOException $e) {
        error_log("[Navbar] Error fetching settings: " . $e->getMessage());
        // Load default theme settings on error
        $themeSettings = loadThemeSettings($pdo);
        $settings = array_merge($settings, $themeSettings);
    }
} else {
    // Load default theme settings if no PDO connection
    if (function_exists('loadThemeSettings')) {
        $themeSettings = loadThemeSettings($pdo);
        $settings = array_merge($settings, $themeSettings);
    }
}

// Get fresh database values for system name and logo
$db_site_name = 'BitsTech P'; // Default fallback (updated to match database)
$db_site_logo = '../public/images/logo.png'; // Default fallback

if (isset($pdo) && $pdo !== null) {
    try {
        // Get site_name from database
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_name'");
        $stmt->execute();
        $db_site_name_result = $stmt->fetchColumn();
        if ($db_site_name_result) {
            $db_site_name = $db_site_name_result;
        }

        // Get site_logo from database
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_logo'");
        $stmt->execute();
        $db_site_logo_result = $stmt->fetchColumn();
        if ($db_site_logo_result) {
            $db_site_logo = '../' . $db_site_logo_result;
        }

        error_log("Navbar: Database site_name: " . $db_site_name);
        error_log("Navbar: Database site_logo: " . $db_site_logo);

        // Debug logging (can be removed in production)
        // echo "<!-- DEBUG: Database site_name: " . htmlspecialchars($db_site_name) . " -->";
        // echo "<!-- DEBUG: Database site_logo: " . htmlspecialchars($db_site_logo) . " -->";
    } catch (PDOException $e) {
        error_log("Navbar: Error fetching database settings: " . $e->getMessage());
    }
}

// Use database values first, then session, then parent page variables
$logo_path = $db_site_logo ?? ($_SESSION['logo_path'] ?? ($logo_path ?? '../public/images/logo.png'));
$system_name = $db_site_name ?? ($_SESSION['system_name'] ?? ($system_name ?? 'BitsTech P'));
$language = $language ?? ($_SESSION['language'] ?? 'en');
$translations = $translations ?? loadLanguage($language); // Use loadLanguage consistently
$currency = $currency ?? ($_SESSION['currency'] ?? 'USD');

// Debug final values (can be removed in production)
// echo "<!-- DEBUG: Final system_name: " . htmlspecialchars($system_name) . " -->";
// echo "<!-- DEBUG: Final logo_path: " . htmlspecialchars($logo_path) . " -->";
error_log("Navbar: Final system_name: " . $system_name);
error_log("Navbar: Final logo_path: " . $logo_path);

// Get notifications for the current user
$notifications_data = []; // Renamed to avoid conflict with parent page's $notifications variable if any
$unread_count_data = 0; // Renamed

if ($user_id_session && isset($pdo) && $pdo !== null) {
    error_log("[Navbar] Fetching notifications for user_id: " . $user_id_session);

    // Check notification settings first
    $lowStockNotificationsEnabled = true; // Default to true
    try {
        $stmt_notif_settings = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'lowStockNotifications'");
        $stmt_notif_settings->execute();
        $lowStockSetting = $stmt_notif_settings->fetchColumn();
        $lowStockNotificationsEnabled = ($lowStockSetting === '1' || $lowStockSetting === 'true');
        error_log("[Navbar] Low Stock Notifications Enabled: " . ($lowStockNotificationsEnabled ? 'true' : 'false'));
    } catch (PDOException $e) {
        error_log("[Navbar] Error fetching notification settings: " . $e->getMessage());
    }

    if (function_exists('getUserNotifications') && function_exists('getUnreadNotificationsCount')) {
        $notifications_data = getUserNotifications($pdo, $user_id_session);

        // Filter notifications based on settings
        if (!$lowStockNotificationsEnabled) {
            $notifications_data = array_filter($notifications_data, function($notification) {
                return strpos(strtolower($notification['message']), 'low stock') === false;
            });
        }

        $unread_count_data = count(array_filter($notifications_data, function($notification) {
            return !$notification['is_read'];
        }));

        error_log("[Navbar] Filtered Notifications Count: " . count($notifications_data));
        error_log("[Navbar] Unread Count Data: " . $unread_count_data);
    } else {
        error_log("[Navbar] Notification functions not available");
        $notifications_data = [];
        $unread_count_data = 0;
    }
} else {
    error_log("[Navbar] No user_id in session or PDO not available, skipping notification fetch.");
}

// Use get_current_datetime from functions.php for consistent timezone handling
if (function_exists('get_current_datetime')) {
    $current_datetime = get_current_datetime('', $pdo); // Get timezone from database settings
} else {
    $current_datetime = date('g:i A T \o\n l, F j, Y'); // Fallback format
}

// Determine the current page for active link highlighting
$current_page = basename($_SERVER['PHP_SELF'], ".php");
?>

<!-- Sidebar Navigation -->
<div class="left-sidebar">
    <div class="logo-container">
        <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="Logo" onerror="this.src='../public/images/logo.png';">
        <div class="system-name brand-text" data-translate="system_name"><?php echo htmlspecialchars($system_name); ?></div>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'pos' ? 'active' : ''; ?>" href="pos.php" data-label="pos">
                <i class="fas fa-cash-register"></i>
                <span class="nav-label" data-translate="nav_pos"><?php echo htmlspecialchars($translations['nav_pos'] ?? 'POS'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>" href="dashboard.php" data-label="dashboard">
                <i class="fas fa-tachometer-alt"></i>
                <span class="nav-label" data-translate="nav_dashboard"><?php echo htmlspecialchars($translations['nav_dashboard'] ?? 'Dashboard'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'products' ? 'active' : ''; ?>" href="products.php" data-label="products">
                <i class="fas fa-box"></i>
                <span class="nav-label" data-translate="nav_products"><?php echo htmlspecialchars($translations['nav_products'] ?? 'Products'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'sales' ? 'active' : ''; ?>" href="sales.php" data-label="sales">
                <i class="fas fa-shopping-cart"></i>
                <span class="nav-label" data-translate="nav_sales"><?php echo htmlspecialchars($translations['nav_sales'] ?? 'Sales'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'reports' ? 'active' : ''; ?>" href="reports.php" data-label="reports">
                <i class="fas fa-chart-line"></i>
                <span class="nav-label" data-translate="nav_reports"><?php echo htmlspecialchars($translations['nav_reports'] ?? 'Reports'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'inventory' ? 'active' : ''; ?>" href="inventory.php" data-label="inventory">
                <i class="fas fa-warehouse"></i>
                <span class="nav-label" data-translate="nav_inventory"><?php echo htmlspecialchars($translations['nav_inventory'] ?? 'Inventory'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'users' ? 'active' : ''; ?>" href="users.php" data-label="users">
                <i class="fas fa-users"></i>
                <span class="nav-label" data-translate="nav_users"><?php echo htmlspecialchars($translations['nav_users'] ?? 'Users'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'settings' ? 'active' : ''; ?>" href="settings.php" data-label="settings">
                <i class="fas fa-cog"></i>
                <span class="nav-label" data-translate="nav_settings"><?php echo htmlspecialchars($translations['nav_settings'] ?? 'Settings'); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $current_page === 'logout' ? 'active' : ''; ?>" href="logout.php" data-label="logout">
                <i class="fas fa-sign-out-alt"></i>
                <span class="nav-label" data-translate="nav_logout"><?php echo htmlspecialchars($translations['nav_logout'] ?? 'Logout'); ?></span>
            </a>
        </li>
    </ul>
</div>

<!-- Top Navigation Bar -->
<nav class="navbar-top">
    <div class="nav-left">
        <span class="datetime"><?php echo htmlspecialchars($current_datetime); ?></span>
    </div>
    <div class="nav-right">
        <div class="nav-item">
            <select id="currency-select" class="form-select" data-currency-selector="true">
                <option value="USD" <?php echo $currency === 'USD' ? 'selected' : ''; ?> data-translate="currency_usd"><?php echo htmlspecialchars($translations['currency_usd'] ?? 'USD'); ?></option>
                <option value="MMK" <?php echo $currency === 'MMK' ? 'selected' : ''; ?> data-translate="currency_mmk"><?php echo htmlspecialchars($translations['currency_mmk'] ?? 'MMK'); ?></option>
                <option value="THB" <?php echo $currency === 'THB' ? 'selected' : ''; ?> data-translate="currency_thb"><?php echo htmlspecialchars($translations['currency_thb'] ?? 'THB'); ?></option>
            </select>
        </div>
        <button type="button" class="nav-link theme-toggle" id="themeToggle" title="<?php echo ($settings['theme_mode'] ?? 'dark') === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'; ?>">
            <?php if (($settings['theme_mode'] ?? 'dark') === 'light'): ?>
                <i class="fas fa-moon"></i>
            <?php else: ?>
                <i class="fas fa-sun"></i>
            <?php endif; ?>
        </button>
        <a class="nav-link notification-bell" href="#" data-bs-toggle="modal" data-bs-target="#notificationModal" id="notificationBell">
            <i class="fas fa-bell"></i>
            <span class="badge" id="notificationBadge" data-count="<?php echo $unread_count_data; ?>" <?php echo $unread_count_data == 0 ? 'style="display: none;"' : ''; ?>><?php echo $unread_count_data; ?></span>
        </a>
        <button type="button" class="nav-link calculator-toggle" id="calculator-btn" title="Calculator">
            <i class="fas fa-calculator"></i>
        </button>
        <div class="nav-item language-toggle">
            <button class="language-btn" id="languageDropdown" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-globe"></i>
                <span class="language-label"><?php echo $language === 'en' ? htmlspecialchars($translations['lang_en'] ?? 'EN') : htmlspecialchars($translations['lang_mm'] ?? 'MM'); ?></span>
            </button>
            <ul class="dropdown-menu language-menu" aria-labelledby="languageDropdown">
                <li>
                    <button type="button" class="dropdown-item language-item" data-lang="en">
                        <i class="fas fa-flag"></i> <span data-translate="lang_en"><?php echo htmlspecialchars($translations['lang_en'] ?? 'English'); ?></span>
                    </button>
                </li>
                <li>
                    <button type="button" class="dropdown-item language-item" data-lang="mm">
                        <i class="fas fa-flag"></i> <span data-translate="lang_mm"><?php echo htmlspecialchars($translations['lang_mm'] ?? 'Myanmar'); ?></span>
                    </button>
                </li>
            </ul>
        </div>
        <a class="nav-link" href="profile.php">
            <i class="fas fa-user"></i> <?php echo htmlspecialchars($user['username'] ?? 'User'); ?>
        </a>
    </div>
</nav>

<!-- Notification Modal -->
<div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 500px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notificationModalLabel" data-translate="notifications"><?php echo htmlspecialchars($translations['notifications'] ?? 'Notifications'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="notificationBody">
                <!-- Notification Tabs -->
                <ul class="nav nav-tabs mb-3" id="notificationTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="low-stock-tab" data-bs-toggle="tab" data-bs-target="#low-stock-notifications" type="button" role="tab" aria-controls="low-stock-notifications" aria-selected="true">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            <span data-translate="low_stock">Low Stock</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="sales-tab" data-bs-toggle="tab" data-bs-target="#sales-notifications" type="button" role="tab" aria-controls="sales-notifications" aria-selected="false">
                            <i class="fas fa-chart-line me-1"></i>
                            <span data-translate="sales">Sales</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="system-tab" data-bs-toggle="tab" data-bs-target="#system-notifications" type="button" role="tab" aria-controls="system-notifications" aria-selected="false">
                            <i class="fas fa-cog me-1"></i>
                            <span data-translate="system">System</span>
                        </button>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="notificationTabContent">
                    <!-- Low Stock Notifications -->
                    <div class="tab-pane fade show active" id="low-stock-notifications" role="tabpanel" aria-labelledby="low-stock-tab">
                        <div id="notificationLoading" class="text-center" style="display: none;">
                            <div class="spinner-border spinner-border-sm" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <span class="ms-2">Loading notifications...</span>
                        </div>
                        <div id="notificationContent">
                            <?php if (!empty($notifications_data)): ?>
                                <?php foreach ($notifications_data as $notification_item): ?>
                                    <div class="notification-item <?php echo $notification_item['is_read'] ? 'read' : 'unread'; ?>">
                                        <p><?php echo htmlspecialchars($notification_item['message']); ?></p>
                                        <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($notification_item['created_at'])); ?></small>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p data-translate="no_notifications"><?php echo htmlspecialchars($translations['no_notifications'] ?? 'No notifications available.'); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Sales Notifications -->
                    <div class="tab-pane fade" id="sales-notifications" role="tabpanel" aria-labelledby="sales-tab">
                        <div id="sales-notifications-content">
                            <!-- Sales notifications will be loaded here -->
                            <div class="text-center py-4">
                                <i class="fas fa-chart-line text-muted mb-3" style="font-size: 2rem;"></i>
                                <p class="text-muted mb-0" data-translate="no_sales_notifications">
                                    <?php echo htmlspecialchars($translations['no_sales_notifications'] ?? 'No sales notifications'); ?>
                                </p>
                                <small class="text-muted d-block mt-2">
                                    (Feature coming soon - offline mode)
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- System Notifications -->
                    <div class="tab-pane fade" id="system-notifications" role="tabpanel" aria-labelledby="system-tab">
                        <div id="system-notifications-content">
                            <!-- System notifications will be loaded here -->
                            <div class="text-center py-4">
                                <i class="fas fa-cog text-muted mb-3" style="font-size: 2rem;"></i>
                                <p class="text-muted mb-0" data-translate="no_system_notifications">
                                    <?php echo htmlspecialchars($translations['no_system_notifications'] ?? 'No system notifications'); ?>
                                </p>
                                <small class="text-muted d-block mt-2">
                                    (Feature coming soon - offline mode)
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-translate="close"><?php echo htmlspecialchars($translations['close'] ?? 'Close'); ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Calculator Overlay (shared, only one instance in navbar) -->
<div class="calculator-overlay" id="calculator-overlay">
    <div class="calculator">
        <div class="calculator-display">
            <div id="display" class="display-screen">0</div>
        </div>
        <div class="calculator-keys">
            <!-- Row 1: Clear and Operators -->
            <button type="button" class="btn-clear">C</button>
            <button type="button" class="btn-operator" data-operator="/">/</button>
            <button type="button" class="btn-operator" data-operator="*">×</button>
            <button type="button" class="btn-operator" data-operator="-">-</button>

            <!-- Row 2: Numbers 7-9 and + -->
            <button type="button" class="btn-number">7</button>
            <button type="button" class="btn-number">8</button>
            <button type="button" class="btn-number">9</button>
            <button type="button" class="btn-operator" data-operator="+">+</button>

            <!-- Row 3: Numbers 4-6 and = (spans 2 rows) -->
            <button type="button" class="btn-number">4</button>
            <button type="button" class="btn-number">5</button>
            <button type="button" class="btn-number">6</button>
            <button type="button" class="btn-equal" rowspan="2">=</button>

            <!-- Row 4: Numbers 1-3 -->
            <button type="button" class="btn-number">1</button>
            <button type="button" class="btn-number">2</button>
            <button type="button" class="btn-number">3</button>

            <!-- Row 5: 0 (spans 2 columns) and decimal -->
            <button type="button" class="btn-zero">0</button>
            <button type="button" class="btn-decimal">.</button>
        </div>
    </div>
</div>
<!-- End Calculator Overlay -->

<!-- Theme CSS and JS -->
<link rel="stylesheet" href="<?php echo BASEPATH; ?>public/css/theme.css">

<!-- Pass PHP theme settings to JavaScript -->
<script>
window.phpThemeSettings = {
    theme_mode: '<?php echo htmlspecialchars($settings['theme_mode'] ?? 'dark'); ?>',
    primary_color: '<?php echo htmlspecialchars($settings['primary_color'] ?? '#007bff'); ?>',
    secondary_color: '<?php echo htmlspecialchars($settings['secondary_color'] ?? '#6c757d'); ?>',
    accent_color: '<?php echo htmlspecialchars($settings['accent_color'] ?? '#17a2b8'); ?>',
    background_color: '<?php echo htmlspecialchars($settings['background_color'] ?? '#21243A'); ?>',
    sidebar_color: '<?php echo htmlspecialchars($settings['sidebar_color'] ?? '#2A2D35'); ?>',
    text_color: '<?php echo htmlspecialchars($settings['text_color'] ?? '#ffffff'); ?>',
    success_color: '<?php echo htmlspecialchars($settings['success_color'] ?? '#28a745'); ?>',
    warning_color: '<?php echo htmlspecialchars($settings['warning_color'] ?? '#ffc107'); ?>',
    danger_color: '<?php echo htmlspecialchars($settings['danger_color'] ?? '#dc3545'); ?>',
    info_color: '<?php echo htmlspecialchars($settings['info_color'] ?? '#17a2b8'); ?>'
};
console.log('🎨 PHP Theme Settings loaded:', window.phpThemeSettings);
</script>

<script>
// Simple theme application for navbar - no theme manager conflicts
$(document).ready(function() {
    console.log('🎨 Navbar: Applying theme from localStorage...');

    // Get theme from localStorage
    const currentTheme = localStorage.getItem('theme_mode') || 'dark';
    console.log('🎨 Navbar: Current theme:', currentTheme);

    // Apply theme attributes immediately
    document.documentElement.setAttribute('data-theme', currentTheme);
    document.body.setAttribute('data-theme', currentTheme);

    // Apply to navbar and sidebar specifically
    const navbar = document.querySelector('.navbar-top');
    const sidebar = document.querySelector('.left-sidebar');

    if (navbar) navbar.setAttribute('data-theme', currentTheme);
    if (sidebar) sidebar.setAttribute('data-theme', currentTheme);

    console.log('🎨 Navbar: Theme applied successfully');

    // Setup theme toggle functionality
    $(document).on('click', '#themeToggle', function() {
        console.log('🎨 Navbar: Theme toggle clicked');

        // Get current theme and toggle
        const currentTheme = localStorage.getItem('theme_mode') || 'dark';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        console.log('🎨 Navbar: Toggling from', currentTheme, 'to', newTheme);

        // Save to localStorage immediately for instant UI response
        localStorage.setItem('theme_mode', newTheme);

        // Apply theme immediately
        document.documentElement.setAttribute('data-theme', newTheme);
        document.body.setAttribute('data-theme', newTheme);

        // Apply to navbar and sidebar
        const navbar = document.querySelector('.navbar-top');
        const sidebar = document.querySelector('.left-sidebar');

        if (navbar) navbar.setAttribute('data-theme', newTheme);
        if (sidebar) sidebar.setAttribute('data-theme', newTheme);

        // Update toggle button icon and title
        const icon = $(this).find('i');
        if (newTheme === 'light') {
            icon.removeClass('fa-sun').addClass('fa-moon');
            $(this).attr('title', 'Switch to Dark Mode');
        } else {
            icon.removeClass('fa-moon').addClass('fa-sun');
            $(this).attr('title', 'Switch to Light Mode');
        }

        // Update theme manager if available
        if (typeof window.themeManager !== 'undefined') {
            window.themeManager.setThemeMode(newTheme);
        }

        // Save to database
        $.ajax({
            url: '../pages/settings.php',
            type: 'POST',
            data: {
                action: 'update_theme_mode',
                theme_mode: newTheme,
                csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('🎨 Navbar: Theme saved to database:', response);

                // Update settings page radio buttons if on settings page
                const settingsRadio = document.querySelector(`input[name="theme_mode"][value="${newTheme}"]`);
                if (settingsRadio) {
                    settingsRadio.checked = true;
                    console.log('🎨 Navbar: Synced with settings page radio button');
                }

                // Broadcast theme change to other tabs
                localStorage.setItem('theme_changed', JSON.stringify({
                    theme: newTheme,
                    timestamp: Date.now()
                }));

                // Remove after 5 seconds
                setTimeout(() => {
                    localStorage.removeItem('theme_changed');
                }, 5000);
            },
            error: function(xhr, status, error) {
                console.warn('🎨 Navbar: Failed to save theme to database:', error);
                // Theme still works locally even if database save fails
            }
        });

        console.log('🎨 Navbar: Theme toggled to:', newTheme);
    });

    // Function to sync theme with settings page
    function syncThemeWithSettingsPage(theme) {
        const settingsRadio = document.querySelector(`input[name="theme_mode"][value="${theme}"]`);
        if (settingsRadio) {
            settingsRadio.checked = true;
            console.log('🎨 Navbar: Synced theme with settings page:', theme);
        }
    }

    // Function to force update navbar theme
    function forceUpdateNavbarTheme(theme) {
        console.log('🎨 Navbar: Force updating navbar theme to:', theme);

        // Update navbar container
        const navbar = document.querySelector('.navbar-top');
        if (navbar) {
            navbar.setAttribute('data-theme', theme);
        }

        // Update all navbar elements
        const navbarElements = document.querySelectorAll('.navbar-top .nav-link, .navbar-top .theme-toggle, .navbar-top .notification-bell, .navbar-top .calculator-toggle, .navbar-top .language-btn, .navbar-top button, .navbar-top #currency-select');

        navbarElements.forEach(element => {
            element.setAttribute('data-theme', theme);

            // Force CSS re-evaluation by triggering reflow
            const display = element.style.display;
            element.style.display = 'none';
            element.offsetHeight; // Trigger reflow
            element.style.display = display || '';
        });

        // Force update specific elements that might not update properly
        const currencySelect = document.querySelector('#currency-select');
        const languageBtn = document.querySelector('.language-btn');
        const themeToggle = document.querySelector('#themeToggle');
        const notificationBell = document.querySelector('#notificationBell');

        [currencySelect, languageBtn, themeToggle, notificationBell].forEach(element => {
            if (element) {
                element.setAttribute('data-theme', theme);
                // Force style recalculation
                element.classList.add('force-update');
                setTimeout(() => {
                    element.classList.remove('force-update');
                }, 1);
            }
        });

        console.log('🎨 Navbar: Force update completed');
    }

    // Force theme application on page load
    setTimeout(() => {
        if (typeof window.themeManager !== 'undefined') {
            console.log('🎨 Forcing theme application on navbar load');
            window.themeManager.forceRefreshAllElements();
        }
    }, 1000);
});
</script>

<style>
/* Theme Toggle Button Styles */
.theme-toggle {
    background: none !important;
    border: none !important;
    color: var(--text-color) !important;
    padding: 8px 12px !important;
    border-radius: 6px !important;
    transition: all 0.3s ease !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    font-size: 1.1rem !important;
}

.theme-toggle:hover {
    background: rgba(255, 255, 255, 0.1) !important;
    transform: scale(1.05) !important;
}

.theme-toggle:active {
    transform: scale(0.95) !important;
}

[data-theme="light"] .theme-toggle {
    color: #495057 !important;
}

[data-theme="light"] .theme-toggle:hover {
    background: rgba(0, 0, 0, 0.1) !important;
    color: #212529 !important;
}

/* Notification Styles */
.notification-item {
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 12px;
    margin-bottom: 8px;
    background: #f8f9fa;
    transition: all 0.3s ease;
}

.notification-item:hover {
    background: #e9ecef;
    border-color: #007bff;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0,123,255,0.15);
}

.low-stock-item {
    border-left: 4px solid #ffc107;
    background: #2A2D35;
    color: #ffffff;
}

.low-stock-item:hover {
    background: #343a46;
    border-left-color: #f39c12;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.notification-header {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    font-weight: 600;
    color: #495057;
}

.low-stock-item .notification-header {
    color: #ffffff;
}

.notification-content p {
    margin-bottom: 5px;
    line-height: 1.4;
}

.low-stock-item .notification-content p {
    color: #ffffff;
}

.low-stock-item .notification-content .text-muted {
    color: rgba(255,255,255,0.7) !important;
}

.low-stock-item .notification-content .text-danger {
    color: #ff6b6b !important;
}

.notification-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.notification-actions .btn {
    font-size: 0.875rem;
    padding: 6px 12px;
    border-radius: 6px;
    transition: all 0.2s ease;
}

.notification-actions .btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

.notification-item small {
    display: block;
    margin-top: 10px;
    font-size: 0.8rem;
    color: #6c757d;
    border-top: 1px solid #dee2e6;
    padding-top: 8px;
}

/* Loading spinner */
#notificationLoading {
    padding: 20px;
    color: #6c757d;
}

/* Modal adjustments */
#notificationModal .modal-body {
    max-height: 400px;
    overflow-y: auto;
    padding: 15px;
}

#notificationModal .modal-footer {
    border-top: 1px solid #dee2e6;
    background: #f8f9fa;
    padding: 10px 15px;
    justify-content: center;
}

#notificationModal .modal-header {
    padding: 15px;
    border-bottom: 1px solid #dee2e6;
}

#notificationModal .modal-title {
    font-size: 1.1rem;
    font-weight: 600;
}

/* Responsive design */
@media (max-width: 576px) {
    .notification-actions {
        flex-direction: column;
    }

    .notification-actions .btn {
        width: 100%;
        margin-bottom: 5px;
    }

    .notification-item {
        padding: 12px;
    }
}
</style>

<script>
console.log('🚀 NAVBAR SCRIPT: Loading...');

// Simple direct approach - wait for everything to load
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM Content Loaded');

    // Wait a bit more for jQuery and other scripts
    setTimeout(function() {
        console.log('⏰ Delayed initialization starting...');

        if (typeof jQuery === 'undefined') {
            console.error('❌ jQuery not found!');
            return;
        }

        console.log('✅ jQuery found, version:', jQuery.fn.jquery);

        // Test elements
        console.log('🔍 Testing elements:');
        console.log('- Calculator button:', $('#calculator-btn').length);
        console.log('- Currency select:', $('#currency-select').length);
        console.log('- Language items:', $('.language-item').length);
        console.log('- Calculator overlay:', $('#calculator-overlay').length);

        // Calculator button
        $('#calculator-btn').on('click', function(e) {
            e.preventDefault();
            console.log('🧮 Calculator clicked!');
            $('#calculator-overlay').toggleClass('active');
        });

        // Currency change handler - Direct approach
        $('#currency-select').on('change', function(e) {
            // Stop all default behaviors immediately
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();

            const currency = $(this).val();
            console.log('💰 NAVBAR: Currency changed to:', currency);

            // Validate currency
            if (!currency) {
                console.warn('💰 NAVBAR: No currency selected');
                return false;
            }

            console.log('💰 NAVBAR: Making AJAX request...');

            // Make AJAX request
            $.ajax({
                url: '../includes/update_currency.php',
                type: 'POST',
                data: {
                    currency: currency,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                cache: false,
                beforeSend: function() {
                    console.log('💰 NAVBAR: AJAX request started');
                },
                success: function(response) {
                    console.log('💰 NAVBAR: AJAX success:', response);

                    if (response && response.success) {
                        // Check if page has update function
                        if (typeof window.updatePageForNewCurrency === 'function') {
                            console.log('💰 NAVBAR: Calling page update function');
                            try {
                                window.updatePageForNewCurrency(currency, response);
                                console.log('💰 NAVBAR: Page updated successfully');
                            } catch (error) {
                                console.error('💰 NAVBAR: Page update error:', error);
                                // Don't reload on error, just log it
                            }
                        } else {
                            console.log('💰 NAVBAR: No page update function available');
                        }
                    } else {
                        console.error('💰 NAVBAR: Invalid response');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('💰 NAVBAR: AJAX error:', {
                        status: status,
                        error: error,
                        response: xhr.responseText
                    });
                }
            });

            // Prevent any form submission or navigation
            return false;
        });

        // Language items
        $('.language-item').on('click', function(e) {
            e.preventDefault();
            const lang = $(this).data('lang');
            console.log('🌐 Language clicked:', lang);

            if (!lang) {
                console.error('🌐 No language data found');
                return;
            }

            // Use the global language switching function
            window.switchLanguage(lang, true);
        });

        // Function to update navbar language elements
        function updateNavbarLanguage(translations) {
            console.log('🌐 Updating navbar language elements...');

            // Update navigation labels
            $('[data-translate="nav_dashboard"]').text(translations.nav_dashboard || 'Dashboard');
            $('[data-translate="nav_sales"]').text(translations.nav_sales || 'Sales');
            $('[data-translate="nav_reports"]').text(translations.nav_reports || 'Reports');
            $('[data-translate="nav_inventory"]').text(translations.nav_inventory || 'Inventory');
            $('[data-translate="nav_users"]').text(translations.nav_users || 'Users');
            $('[data-translate="nav_settings"]').text(translations.nav_settings || 'Settings');
            $('[data-translate="nav_logout"]').text(translations.nav_logout || 'Logout');

            // Update currency options
            $('[data-translate="currency_usd"]').text(translations.currency_usd || 'USD');
            $('[data-translate="currency_mmk"]').text(translations.currency_mmk || 'MMK');
            $('[data-translate="currency_thb"]').text(translations.currency_thb || 'THB');

            // Update language dropdown items
            $('[data-translate="lang_en"]').text(translations.lang_en || 'English');
            $('[data-translate="lang_mm"]').text(translations.lang_mm || 'Myanmar');

            // Update notification modal
            $('[data-translate="notifications"]').text(translations.notifications || 'Notifications');
            $('[data-translate="no_notifications"]').text(translations.no_notifications || 'No notifications available.');
            $('[data-translate="close"]').text(translations.close || 'Close');

            console.log('🌐 Navbar language elements updated');
        }

        // Global function to update navbar site name (called from settings page)
        window.updateNavbarSiteName = function(newName) {
            console.log('🏢 Updating navbar site name to:', newName);
            $('.brand-text').text(newName);
            $('.system-name').text(newName);

            // Update page title if it contains the old name
            const currentTitle = document.title;
            if (currentTitle.includes('BitsTech')) {
                document.title = currentTitle.replace(/BitsTech[^-]*/, newName + ' ');
            }
        };

        // Listen for system name updates from other tabs/windows
        window.addEventListener('storage', function(e) {
            if (e.key === 'system_name_updated' && e.newValue) {
                try {
                    const data = JSON.parse(e.newValue);
                    console.log('🏢 Navbar: Detected system name update from another tab:', data.name);

                    // Update navbar immediately
                    window.updateNavbarSiteName(data.name);

                    // Show notification that system name was updated
                    if (typeof showSuccessMessage === 'function') {
                        showSuccessMessage('System name updated to: ' + data.name);
                    }
                } catch (error) {
                    console.error('🏢 Error parsing system name update:', error);
                }
            }
        });

        // Global function to update navbar logo (called from settings page)
        window.updateNavbarLogo = function(newLogoPath) {
            console.log('🖼️ Updating navbar logo to:', newLogoPath);
            $('.logo-container img').attr('src', newLogoPath);
        };

        // Global function to update navbar datetime (called from settings page)
        window.updateNavbarDateTime = function(timezone) {
            console.log('🕐 Updating navbar datetime with timezone:', timezone);

            // Make AJAX request to get updated datetime with current date format
            $.ajax({
                url: '../includes/get_datetime.php',
                type: 'POST',
                data: { timezone: timezone },
                dataType: 'json',
                success: function(response) {
                    if (response && response.success) {
                        $('.datetime').text(response.datetime);
                        console.log('🕐 Navbar datetime updated:', response.datetime);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🕐 Failed to update navbar datetime:', error);
                }
            });
        };

        // Global function to update notification bell visibility and count
        window.updateNotificationBellVisibility = function() {
            const notificationsEnabled = localStorage.getItem('notificationsEnabled');
            const lowStockNotifications = localStorage.getItem('lowStockNotifications');
            const $notificationBell = $('#notificationBell');
            const $notificationBadge = $('#notificationBadge');

            console.log('🔔 Notification bell - localStorage value:', notificationsEnabled);
            console.log('🔔 Low Stock Notifications:', lowStockNotifications);
            console.log('🔔 Notification bell element found:', $notificationBell.length);

            if ($notificationBell.length === 0) {
                console.warn('🔔 Notification bell element not found!');
                return;
            }

            // Remove all classes first
            $notificationBell.removeClass('notification-enabled notification-disabled');

            // If notificationsEnabled is null (first time) or 'true', show the bell
            // If notificationsEnabled is 'false', hide the bell
            if (notificationsEnabled === 'false') {
                console.log('🔔 Hiding notification bell');
                $notificationBell.addClass('notification-disabled');
            } else {
                console.log('🔔 Showing notification bell');
                $notificationBell.addClass('notification-enabled');

                // Update notification count based on settings
                updateNotificationCount();
            }

            console.log('🔔 After update visibility:', $notificationBell.is(':visible'));
            console.log('🔔 Bell classes:', $notificationBell[0].className);
        };

        // Function to update notification count
        function updateNotificationCount() {
            const lowStockNotifications = localStorage.getItem('lowStockNotifications');
            const $notificationBadge = $('#notificationBadge');

            // Make AJAX request to get updated notification count
            $.ajax({
                url: '../includes/get_notification_count.php',
                type: 'POST',
                data: {
                    lowStockEnabled: lowStockNotifications !== 'false',
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response && response.success) {
                        const count = response.count;
                        $notificationBadge.text(count);
                        $notificationBadge.attr('data-count', count);

                        // Hide badge if count is 0
                        if (count === 0) {
                            $notificationBadge.hide();
                        } else {
                            $notificationBadge.show();
                        }

                        console.log('🔔 Notification count updated:', count);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🔔 Failed to update notification count:', error);
                }
            });
        }

        // Initialize notification bell visibility immediately on page load
        window.updateNotificationBellVisibility();

        // System name is now loaded directly from database on page load
        // No need for AJAX call on page load

        // Notification bell click handler
        $('#notificationBell').on('click', function(e) {
            e.preventDefault();
            console.log('🔔 Notification bell clicked');
            loadNotifications();
        });

        // Tab click handlers for different notification types
        $('#low-stock-tab').on('click', function() {
            console.log('🔔 Low stock tab clicked');
            loadNotifications();
        });

        $('#sales-tab').on('click', function() {
            console.log('📊 Sales tab clicked');
            loadSalesNotifications();
        });

        $('#system-tab').on('click', function() {
            console.log('⚙️ System tab clicked');
            loadSystemNotifications();
        });

        console.log('🔔 NAVBAR: Initial notification bell setup completed');

        // Function to load notifications
        function loadNotifications() {
            console.log('🔔 Loading notifications...');

            // Show loading state
            $('#notificationLoading').show();
            $('#notificationContent').hide();

            // Check if low stock notifications are enabled
            const lowStockEnabled = localStorage.getItem('lowStockNotifications') !== 'false';
            console.log('🔔 Low stock notifications enabled:', lowStockEnabled);

            if (!lowStockEnabled) {
                // Show no notifications message
                $('#notificationLoading').hide();
                $('#notificationContent').html('<p data-translate="no_notifications">No notifications available.</p>').show();
                return;
            }

            // Determine the correct path
            let notificationUrl = '';
            const currentPath = window.location.pathname;

            if (currentPath.includes('/pages/')) {
                notificationUrl = 'get_low_stock_notifications.php';
            } else {
                notificationUrl = 'pages/get_low_stock_notifications.php';
            }

            console.log('🔔 Using notification URL:', notificationUrl);

            // Load low stock notifications
            $.ajax({
                url: notificationUrl,
                type: 'GET',
                dataType: 'json',
                timeout: 10000,
                success: function(response) {
                    console.log('🔔 Notifications response:', response);

                    $('#notificationLoading').hide();

                    if (response && response.success) {
                        displayNotifications(response.notifications, response.translations);
                    } else {
                        $('#notificationContent').html('<p class="text-danger">Error loading notifications: ' + (response.error || 'Unknown error') + '</p>').show();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🔔 Error loading notifications:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText
                    });

                    $('#notificationLoading').hide();
                    $('#notificationContent').html('<p class="text-danger">Failed to load notifications. Please try again.</p>').show();
                }
            });
        }

        // Function to display notifications
        function displayNotifications(notifications, translations) {
            console.log('🔔 Displaying notifications:', notifications.length);

            if (!notifications || notifications.length === 0) {
                $('#notificationContent').html('<p data-translate="no_notifications">' + (translations?.no_notifications || 'No notifications available.') + '</p>').show();
                return;
            }

            let html = '';
            notifications.forEach(function(notification) {
                html += '<div class="notification-item low-stock-item" data-product-id="' + notification.product_id + '">';
                html += '<div class="notification-header">';
                html += '<i class="fas fa-exclamation-triangle text-warning me-2"></i>';
                html += '<strong>' + (translations?.low_stock_alert || 'Low Stock Alert') + '</strong>';
                html += '</div>';
                html += '<div class="notification-content">';
                html += '<p class="mb-1"><strong>' + escapeHtml(notification.product_name) + '</strong></p>';
                html += '<p class="mb-1 text-danger"><i class="fas fa-box me-1"></i>' + notification.stock_quantity + ' ' + (translations?.items_remaining || 'items remaining') + '</p>';

                if (notification.sku) {
                    html += '<p class="mb-1 text-muted small">SKU: ' + escapeHtml(notification.sku) + '</p>';
                }

                if (notification.category_name) {
                    html += '<p class="mb-1 text-muted small">' + (translations?.category || 'Category') + ': ' + escapeHtml(notification.category_name) + '</p>';
                }

                if (notification.supplier_name) {
                    html += '<p class="mb-1 text-muted small">' + (translations?.supplier || 'Supplier') + ': ' + escapeHtml(notification.supplier_name) + '</p>';
                }

                if (notification.reorder_level) {
                    html += '<p class="mb-1 text-muted small">' + (translations?.reorder_level || 'Reorder Level') + ': ' + notification.reorder_level + '</p>';
                }

                html += '</div>';
                html += '<div class="notification-actions mt-2">';
                html += '<button type="button" class="btn btn-sm btn-primary me-2" onclick="viewProduct(' + notification.product_id + ')">';
                html += '<i class="fas fa-eye me-1"></i>' + (translations?.view_product || 'View Product');
                html += '</button>';
                html += '<button type="button" class="btn btn-sm btn-success" onclick="restockProduct(' + notification.product_id + ')">';
                html += '<i class="fas fa-plus me-1"></i>' + (translations?.restock_now || 'Restock Now');
                html += '</button>';
                html += '</div>';
                html += '<small class="text-muted">' + formatDateTime(notification.created_at) + '</small>';
                html += '</div>';
            });

            $('#notificationContent').html(html).show();
        }

        // Function to load sales notifications (placeholder for future implementation)
        function loadSalesNotifications() {
            console.log('📊 Loading sales notifications...');

            // Show loading state
            $('#sales-notifications-content').html(`
                <div class="text-center py-4">
                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 mb-0">Loading sales notifications...</p>
                </div>
            `);

            // Simulate loading delay (remove when implementing real functionality)
            setTimeout(function() {
                // Placeholder content - replace with real implementation
                $('#sales-notifications-content').html(`
                    <div class="text-center py-4">
                        <i class="fas fa-chart-line text-muted mb-3" style="font-size: 2rem;"></i>
                        <p class="text-muted mb-0">No sales notifications available</p>
                        <small class="text-muted d-block mt-2">
                            (Feature coming soon - offline mode)
                        </small>
                        <div class="mt-3">
                            <small class="text-info">
                                <i class="fas fa-info-circle me-1"></i>
                                Future features: Daily sales reports, target achievements, low performance alerts
                            </small>
                        </div>
                    </div>
                `);
            }, 1000);
        }

        // Function to load system notifications (placeholder for future implementation)
        function loadSystemNotifications() {
            console.log('⚙️ Loading system notifications...');

            // Show loading state
            $('#system-notifications-content').html(`
                <div class="text-center py-4">
                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 mb-0">Loading system notifications...</p>
                </div>
            `);

            // Simulate loading delay (remove when implementing real functionality)
            setTimeout(function() {
                // Placeholder content - replace with real implementation
                $('#system-notifications-content').html(`
                    <div class="text-center py-4">
                        <i class="fas fa-cog text-muted mb-3" style="font-size: 2rem;"></i>
                        <p class="text-muted mb-0">No system notifications available</p>
                        <small class="text-muted d-block mt-2">
                            (Feature coming soon - offline mode)
                        </small>
                        <div class="mt-3">
                            <small class="text-info">
                                <i class="fas fa-info-circle me-1"></i>
                                Future features: System updates, backup status, security alerts, maintenance reminders
                            </small>
                        </div>
                    </div>
                `);
            }, 1000);
        }

        // Helper function to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Helper function to format datetime
        function formatDateTime(dateString) {
            try {
                const date = new Date(dateString);
                return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            } catch (e) {
                return dateString;
            }
        }

        // Global functions for notification actions
        window.viewProduct = function(productId) {
            console.log('🔍 Viewing product:', productId);
            // Close notification modal
            $('#notificationModal').modal('hide');

            // Navigate to product details page
            const currentPath = window.location.pathname;
            let productDetailsUrl = '';

            if (currentPath.includes('/pages/')) {
                // We're in pages directory
                productDetailsUrl = 'product_details.php?id=' + productId;
            } else {
                // We're in root directory
                productDetailsUrl = 'pages/product_details.php?id=' + productId;
            }

            console.log('🔍 Navigating to product details:', productDetailsUrl);
            window.location.href = productDetailsUrl;
        };

        window.restockProduct = function(productId) {
            console.log('📦 Restocking product:', productId);
            // Close notification modal
            $('#notificationModal').modal('hide');

            // Always navigate to inventory page with restock action
            const currentPath = window.location.pathname;
            let inventoryUrl = '';

            if (currentPath.includes('/pages/')) {
                // We're in pages directory
                inventoryUrl = 'inventory.php?product_id=' + productId + '&action=restock';
            } else {
                // We're in root directory
                inventoryUrl = 'pages/inventory.php?product_id=' + productId + '&action=restock';
            }

            console.log('📦 Navigating to:', inventoryUrl);
            window.location.href = inventoryUrl;
        };

        // Global function to switch language (called from settings page)
        window.switchLanguage = function(lang, allowRefresh = true) {
            console.log('🌐 GLOBAL: Switching language to:', lang, 'allowRefresh:', allowRefresh);

            $.ajax({
                url: '../includes/update_language.php',
                method: 'POST',
                data: {
                    language: lang,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                dataType: 'json',
                success: function(response) {
                    console.log('🌐 GLOBAL: Language response:', response);
                    if (response && response.success) {
                        // Update language button text immediately
                        const languageLabel = lang === 'en' ? 'EN' : 'MM';
                        $('.language-label').text(languageLabel);
                        console.log('🌐 GLOBAL: Language button updated to:', languageLabel);

                        // Update navbar language elements
                        updateNavbarLanguage(response.translations);

                        // Store translations globally
                        window.translations = response.translations;

                        if (typeof window.updatePageForNewLanguage === 'function') {
                            try {
                                const success = window.updatePageForNewLanguage(lang, response.translations);
                                if (!success && allowRefresh) {
                                    console.log('🌐 GLOBAL: Page update failed, reloading...');
                                    location.reload();
                                }
                            } catch (error) {
                                console.error('🌐 GLOBAL: Error in language update function:', error);
                                if (allowRefresh) {
                                    location.reload();
                                }
                            }
                        } else if (allowRefresh) {
                            console.log('🌐 GLOBAL: No page language function, reloading');
                            location.reload();
                        }
                    } else if (allowRefresh) {
                        console.log('🌐 GLOBAL: Invalid response, reloading...');
                        location.reload();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('🌐 GLOBAL: Language AJAX error:', error);
                    if (allowRefresh) {
                        location.reload();
                    }
                }
            });
        };

        // Global function to update date format (called from settings page)
        window.updateNavbarDateFormat = function() {
            console.log('📅 Updating navbar with new date format');

            // Get current timezone from settings and refresh datetime
            $.ajax({
                url: '../includes/get_datetime.php',
                type: 'POST',
                data: { timezone: 'current' }, // Use current timezone from DB
                dataType: 'json',
                cache: false, // Prevent caching
                timeout: 10000, // 10 second timeout
                beforeSend: function() {
                    console.log('📅 Sending request to get_datetime.php');
                },
                success: function(response) {
                    console.log('📅 Received response:', response);
                    if (response && response.success) {
                        $('.datetime').text(response.datetime);
                        console.log('📅 Navbar datetime updated with new format:', response.datetime);

                        // Add visual feedback
                        $('.datetime').addClass('updated');
                        setTimeout(() => $('.datetime').removeClass('updated'), 1000);
                    } else {
                        console.error('📅 Invalid response from get_datetime.php:', response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('📅 Failed to update navbar date format:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText,
                        readyState: xhr.readyState,
                        statusText: xhr.statusText
                    });
                }
            });
        };

        // Calculator functionality
        let currentInput = '0';
        let operator = null;
        let previousInput = null;
        let waitingForOperand = false;

        function updateDisplay() {
            // Format display value to limit decimal places
            let displayValue = currentInput;
            if (typeof displayValue === 'string' && displayValue.includes('.')) {
                const parts = displayValue.split('.');
                if (parts[1] && parts[1].length > 4) {
                    displayValue = parseFloat(displayValue).toFixed(4).replace(/\.?0+$/, '');
                }
            }
            $('#display').text(displayValue);
        }

        function inputNumber(num) {
            if (waitingForOperand) {
                currentInput = num;
                waitingForOperand = false;
            } else {
                currentInput = currentInput === '0' ? num : currentInput + num;
            }
        }

        function inputOperator(nextOperator) {
            const inputValue = parseFloat(currentInput);

            if (previousInput === null) {
                previousInput = inputValue;
            } else if (operator) {
                const currentValue = previousInput || 0;
                const newValue = calculate(currentValue, inputValue, operator);

                currentInput = String(newValue);
                previousInput = newValue;
            }

            waitingForOperand = true;
            operator = nextOperator;
        }

        function calculate(firstOperand, secondOperand, operator) {
            let result;
            switch (operator) {
                case '+':
                    result = firstOperand + secondOperand;
                    break;
                case '-':
                    result = firstOperand - secondOperand;
                    break;
                case '*':
                    result = firstOperand * secondOperand;
                    break;
                case '/':
                    result = firstOperand / secondOperand;
                    break;
                default:
                    result = secondOperand;
            }

            // Format result to limit decimal places
            if (typeof result === 'number' && !Number.isInteger(result)) {
                result = parseFloat(result.toFixed(4));
                // Remove trailing zeros
                if (result.toString().includes('.')) {
                    result = parseFloat(result.toString().replace(/\.?0+$/, ''));
                }
            }

            return result;
        }

        function clearCalculator() {
            currentInput = '0';
            previousInput = null;
            operator = null;
            waitingForOperand = false;
        }

        // Calculator button handlers
        $('.btn-number').on('click', function() {
            inputNumber($(this).text());
            updateDisplay();
        });

        $('.btn-operator').on('click', function() {
            inputOperator($(this).data('operator'));
            updateDisplay();
        });

        $('.btn-equal').on('click', function() {
            const inputValue = parseFloat(currentInput);

            if (previousInput !== null && operator) {
                const newValue = calculate(previousInput, inputValue, operator);
                currentInput = String(newValue);
                previousInput = null;
                operator = null;
                waitingForOperand = true;
            }
            updateDisplay();
        });

        $('.btn-clear').on('click', function() {
            clearCalculator();
            updateDisplay();
        });

        $('.btn-decimal').on('click', function() {
            if (waitingForOperand) {
                currentInput = '0.';
                waitingForOperand = false;
            } else if (currentInput.indexOf('.') === -1) {
                currentInput += '.';
            }
            updateDisplay();
        });

        $('.btn-zero').on('click', function() {
            inputNumber('0');
            updateDisplay();
        });

        // Close calculator
        $('#calculator-overlay').on('click', function(e) {
            if (e.target === this) {
                $(this).removeClass('active');
            }
        });

        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('#calculator-overlay').removeClass('active');
            }
        });

        console.log('✅ All navbar handlers initialized!');

    }, 1000); // Wait 1 second for everything to load
});


</script>