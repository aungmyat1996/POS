<?php
/**
 * Automatic Backup System
 * This file handles automatic database backups based on user settings
 */

// Prevent direct access
if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
}

require_once BASEPATH . 'config/db.php';
require_once BASEPATH . 'includes/functions.php';

// Function to check if automatic backup is due
function isBackupDue($lastBackupTime, $frequency) {
    if (!$lastBackupTime) {
        return true; // No previous backup, create one
    }

    $now = time();
    $timeDiff = $now - $lastBackupTime;

    switch ($frequency) {
        case 'daily':
            return $timeDiff >= (24 * 60 * 60); // 24 hours
        case 'weekly':
            return $timeDiff >= (7 * 24 * 60 * 60); // 7 days
        case 'monthly':
            return $timeDiff >= (30 * 24 * 60 * 60); // 30 days
        default:
            return false;
    }
}

// Function to create automatic backup
function createAutomaticBackup($pdo, $settings) {
    try {
        error_log("Auto Backup: Starting automatic backup process");

        // Create backup directory if it doesn't exist
        $backupDir = BASEPATH . 'backups';
        if (!is_dir($backupDir)) {
            if (!mkdir($backupDir, 0755, true)) {
                throw new Exception('Failed to create backup directory: ' . $backupDir);
            }
        }

        // Check if directory is writable
        if (!is_writable($backupDir)) {
            throw new Exception('Backup directory is not writable: ' . $backupDir);
        }

        // Generate backup filename with timestamp using user's timezone
        $userTimezone = $settings['timezone'] ?? 'Asia/Yangon';
        $dateTime = new DateTime('now', new DateTimeZone($userTimezone));
        $timestamp = $dateTime->format('Y-m-d_H-i-s');
        $backupFile = $backupDir . '/pos_system_auto_backup_' . $timestamp . '.sql';

        error_log("Auto Backup: Target file: $backupFile");

        // Create backup content
        $backupContent = createAutoBackup($pdo, $userTimezone);

        if (empty($backupContent)) {
            throw new Exception('Backup content is empty');
        }

        error_log("Auto Backup: Content size: " . strlen($backupContent) . " bytes");

        $bytesWritten = file_put_contents($backupFile, $backupContent);
        if ($bytesWritten === false) {
            throw new Exception('Failed to write backup file to disk');
        }

        if (!file_exists($backupFile)) {
            throw new Exception('Backup file was not created');
        }

        $fileSize = filesize($backupFile);
        if ($fileSize === 0) {
            throw new Exception('Backup file is empty');
        }

        error_log("Auto Backup: Successfully created backup file: " . basename($backupFile) . " (" . $fileSize . " bytes)");

        // Update last backup time in settings
        updateSetting($pdo, 'last_auto_backup', time());

        // Clean up old backups (keep only last 10 automatic backups)
        cleanupOldBackups($backupDir);

        return [
            'success' => true,
            'message' => 'Automatic backup created successfully',
            'filename' => basename($backupFile),
            'size' => formatBytes($fileSize)
        ];

    } catch (Exception $e) {
        error_log("Auto Backup error: " . $e->getMessage());
        error_log("Auto Backup error trace: " . $e->getTraceAsString());
        return [
            'success' => false,
            'message' => 'Automatic backup failed: ' . $e->getMessage()
        ];
    }
}

// Function to create backup content for automatic backups
function createAutoBackup($pdo, $userTimezone = 'Asia/Yangon') {
    $backup = "-- POS System Automatic Database Backup\n";

    // Use user's timezone for backup header
    $dateTime = new DateTime('now', new DateTimeZone($userTimezone));
    $backup .= "-- Generated on: " . $dateTime->format('Y-m-d H:i:s T') . "\n";
    $backup .= "-- Backup Type: Automatic\n";
    $backup .= "-- Timezone: " . $userTimezone . "\n";
    $backup .= "-- Database: " . DB_NAME . "\n\n";
    $backup .= "SET FOREIGN_KEY_CHECKS=0;\n";
    $backup .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $backup .= "SET AUTOCOMMIT = 0;\n";
    $backup .= "START TRANSACTION;\n\n";

    try {
        // Get all tables
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        error_log("Auto Backup: Found " . count($tables) . " tables");

        foreach ($tables as $table) {
            error_log("Auto Backup: Processing table $table");

            // Get table structure
            $backup .= "-- Table structure for `$table`\n";
            $backup .= "DROP TABLE IF EXISTS `$table`;\n";

            $createStmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $createTable = $createStmt->fetch(PDO::FETCH_ASSOC);

            // Handle different MySQL versions and column names
            $createTableSQL = '';
            if (isset($createTable['Create Table'])) {
                $createTableSQL = $createTable['Create Table'];
            } elseif (isset($createTable['Create View'])) {
                $createTableSQL = $createTable['Create View'];
            } else {
                // Fallback: get the second column value
                $values = array_values($createTable);
                $createTableSQL = isset($values[1]) ? $values[1] : '';
            }

            if (empty($createTableSQL)) {
                error_log("Auto Backup: Could not get CREATE statement for table $table");
                continue;
            }

            $backup .= $createTableSQL . ";\n\n";

            // Get table data
            $backup .= "-- Data for table `$table`\n";
            $dataStmt = $pdo->query("SELECT * FROM `$table`");
            $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($rows)) {
                $columns = array_keys($rows[0]);
                $backup .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES\n";

                $values = [];
                foreach ($rows as $row) {
                    $rowValues = [];
                    foreach ($row as $value) {
                        if ($value === null) {
                            $rowValues[] = 'NULL';
                        } else {
                            $rowValues[] = $pdo->quote($value);
                        }
                    }
                    $values[] = '(' . implode(', ', $rowValues) . ')';
                }
                $backup .= implode(",\n", $values) . ";\n\n";
            } else {
                $backup .= "-- No data for table `$table`\n\n";
            }
        }

        $backup .= "SET FOREIGN_KEY_CHECKS=1;\n";
        $backup .= "COMMIT;\n";

        error_log("Auto Backup: Successfully created backup content");
        return $backup;

    } catch (Exception $e) {
        error_log("Auto Backup error: " . $e->getMessage());
        throw new Exception('Failed to create automatic backup: ' . $e->getMessage());
    }
}

// Function to clean up old automatic backups
function cleanupOldBackups($backupDir, $keepCount = 10) {
    try {
        $files = glob($backupDir . '/pos_system_auto_backup_*.sql');

        if (count($files) <= $keepCount) {
            return; // No cleanup needed
        }

        // Sort files by modification time (oldest first)
        usort($files, function($a, $b) {
            return filemtime($a) - filemtime($b);
        });

        // Delete oldest files, keep only the specified count
        $filesToDelete = array_slice($files, 0, count($files) - $keepCount);

        foreach ($filesToDelete as $file) {
            if (unlink($file)) {
                error_log("Auto Backup: Cleaned up old backup: " . basename($file));
            }
        }

    } catch (Exception $e) {
        error_log("Auto Backup cleanup error: " . $e->getMessage());
    }
}

// Function to update a setting
function updateSetting($pdo, $key, $value) {
    try {
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$key, $value, $value]);
    } catch (Exception $e) {
        error_log("Failed to update setting $key: " . $e->getMessage());
    }
}

// Function to format file sizes (only if not already defined)
if (!function_exists('formatBytes')) {
    function formatBytes($size, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
            $size /= 1024;
        }
        return round($size, $precision) . ' ' . $units[$i];
    }
}

// Main execution when called directly or via cron
if (basename($_SERVER['PHP_SELF']) === 'auto_backup.php' || php_sapi_name() === 'cli') {
    try {
        // Get database connection
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Get settings
        $settings = [];
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        // Check if automatic backup is enabled
        if (($settings['backup_enabled'] ?? 'false') !== 'true') {
            error_log("Auto Backup: Automatic backup is disabled");
            exit;
        }

        $frequency = $settings['backup_frequency'] ?? 'daily';
        $lastBackupTime = $settings['last_auto_backup'] ?? null;

        // Check if backup is due
        if (isBackupDue($lastBackupTime, $frequency)) {
            error_log("Auto Backup: Backup is due, creating automatic backup");
            $result = createAutomaticBackup($pdo, $settings);

            if ($result['success']) {
                error_log("Auto Backup: " . $result['message']);
            } else {
                error_log("Auto Backup: " . $result['message']);
            }
        } else {
            error_log("Auto Backup: Backup not due yet");
        }

    } catch (Exception $e) {
        error_log("Auto Backup system error: " . $e->getMessage());
    }
}
?>
