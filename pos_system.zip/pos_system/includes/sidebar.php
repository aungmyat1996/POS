<?php
// Prevent direct access
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="left-sidebar">
    <div class="logo-container">
        <img src="<?php echo BASEPATH; ?>public/images/logo.png" alt="BitsTech" class="logo">
        <div class="system-name"><?php echo htmlspecialchars($_SESSION['system_name'] ?? 'BitsTech P'); ?></div>
    </div>

    <nav>
        <a href="<?php echo BASEPATH; ?>pages/pos.php" class="nav-link <?php echo $current_page === 'pos.php' ? 'active' : ''; ?>" data-label="POS">
            <i class="fas fa-cash-register"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/products.php" class="nav-link <?php echo $current_page === 'products.php' ? 'active' : ''; ?>" data-label="Products">
            <i class="fas fa-box"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/categories.php" class="nav-link <?php echo $current_page === 'categories.php' ? 'active' : ''; ?>" data-label="Categories">
            <i class="fas fa-tags"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/sales.php" class="nav-link <?php echo $current_page === 'sales.php' ? 'active' : ''; ?>" data-label="Sales">
            <i class="fas fa-chart-line"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/inventory.php" class="nav-link <?php echo $current_page === 'inventory.php' ? 'active' : ''; ?>" data-label="Inventory">
            <i class="fas fa-warehouse"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/customers.php" class="nav-link <?php echo $current_page === 'customers.php' ? 'active' : ''; ?>" data-label="Customers">
            <i class="fas fa-users"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/suppliers.php" class="nav-link <?php echo $current_page === 'suppliers.php' ? 'active' : ''; ?>" data-label="Suppliers">
            <i class="fas fa-truck"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/settings.php" class="nav-link <?php echo $current_page === 'settings.php' ? 'active' : ''; ?>" data-label="Settings">
            <i class="fas fa-cog"></i>
        </a>

        <a href="<?php echo BASEPATH; ?>pages/logout.php" class="nav-link" data-label="Logout">
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </nav>
</div>