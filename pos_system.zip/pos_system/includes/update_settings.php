<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Log incoming request
        error_log("UPDATE_SETTINGS: Received POST data: " . print_r($_POST, true));

        $updated_settings = [];

        // Handle individual setting updates
        $allowed_settings = [
            'site_name',
            'site_logo',
            'language',
            'currency',
            'date_format',
            'timezone',
            'theme',
            'backup_frequency',
            'auto_backup',
            'smtp_host',
            'smtp_port',
            'smtp_username',
            'smtp_password',
            'smtp_encryption',
            'email_from',
            'email_from_name'
        ];

        foreach ($allowed_settings as $setting_key) {
            if (isset($_POST[$setting_key])) {
                $setting_value = $_POST[$setting_key];

                // Validate setting value
                if ($setting_key === 'date_format') {
                    $valid_formats = ['Y-m-d', 'd/m/Y', 'm/d/Y', 'Y/m/d', 'F j, Y', 'M j, Y', 'j F Y', 'd-m-Y', 'Y.m.d'];
                    if (!in_array($setting_value, $valid_formats)) {
                        throw new Exception('Invalid date format');
                    }
                }

                if ($setting_key === 'language') {
                    $valid_languages = ['en', 'mm'];
                    if (!in_array($setting_value, $valid_languages)) {
                        throw new Exception('Invalid language');
                    }
                }

                if ($setting_key === 'currency') {
                    $valid_currencies = ['USD', 'MMK', 'THB'];
                    if (!in_array($setting_value, $valid_currencies)) {
                        throw new Exception('Invalid currency');
                    }
                }

                // Update or insert setting
                $stmt = $pdo->prepare("
                    INSERT INTO settings (setting_key, setting_value)
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                ");
                $result = $stmt->execute([$setting_key, $setting_value]);

                error_log("UPDATE_SETTINGS: Updated $setting_key = $setting_value, Result: " . ($result ? 'SUCCESS' : 'FAILED'));

                $updated_settings[$setting_key] = $setting_value;

                // Update session for immediate effect
                if ($setting_key === 'language') {
                    $_SESSION['language'] = $setting_value;
                }
                if ($setting_key === 'currency') {
                    $_SESSION['currency'] = $setting_value;
                }
                if ($setting_key === 'site_name') {
                    $_SESSION['system_name'] = $setting_value;
                }
            }
        }

        if (empty($updated_settings)) {
            throw new Exception('No valid settings to update');
        }

        echo json_encode([
            'success' => true,
            'message' => 'Settings updated successfully',
            'updated_settings' => $updated_settings
        ]);

    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>
