<?php
// Define BASEPATH if not defined
if (!defined('BASEPATH')) {
    define('BASEPATH', dirname(__DIR__) . '/');
}

// Check if the request is coming from the same domain
function isValidRequest() {
    if (!isset($_SERVER['HTTP_HOST']) || !isset($_SERVER['HTTP_REFERER'])) {
        return false;
    }
    
    $host = $_SERVER['HTTP_HOST'];
    $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
    
    return $host === $referer;
}

// Prevent direct file access
if (basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access to this file is not allowed.');
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in (for pages that require authentication)
function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        if (isAjaxRequest()) {
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized access']);
            exit();
        } else {
            header('Location: ' . BASEPATH . 'pages/login.php');
            exit();
        }
    }
}

// Check if request is AJAX
function isAjaxRequest() {
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
} 