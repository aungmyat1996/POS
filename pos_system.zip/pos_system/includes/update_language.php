<?php
session_start();
require_once __DIR__ . '/../config/config.php';

// Security check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// CSRF protection
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    // Generate new token if missing
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    // Allow request to proceed for now
}

// Validate language
$allowed_languages = ['en', 'mm'];
$language = $_POST['language'] ?? '';

if (!in_array($language, $allowed_languages)) {
    echo json_encode(['success' => false, 'message' => 'Invalid language']);
    exit;
}

try {
    // Update session
    $_SESSION['language'] = $language;
    
    // Load translations
    $translations = [];
    $translation_file = __DIR__ . "/../languages/{$language}.php";
    
    if (file_exists($translation_file)) {
        $translations = include $translation_file;
    } else {
        // Fallback translations
        if ($language === 'mm') {
            $translations = [
                'dashboard' => 'ထိန်းချုပ်မှုပြားခုံ',
                'products' => 'ကုန်ပစ္စည်းများ',
                'sales' => 'ရောင်းချမှုများ',
                'customers' => 'ဖောက်သည်များ',
                'reports' => 'အစီရင်ခံစာများ',
                'settings' => 'ဆက်တင်များ',
                'logout' => 'ထွက်ရန်',
                'search' => 'ရှာဖွေရန်',
                'add_new' => 'အသစ်ထည့်ရန်',
                'edit' => 'ပြင်ဆင်ရန်',
                'delete' => 'ဖျက်ရန်',
                'save' => 'သိမ်းရန်',
                'cancel' => 'ပယ်ဖျက်ရန်',
                'actions' => 'လုပ်ဆောင်ချက်များ',
                'status' => 'အခြေအနေ',
                'date' => 'ရက်စွဲ',
                'amount' => 'ပမာණ',
                'total' => 'စုစုပေါင်း',
                'recent_sales' => 'လတ်တလော ရောင်းချမှုများ',
                'sales_analytics' => 'ရောင်းချမှု ခွဲခြမ်းစိတ်ဖြာမှု',
                'today_sales' => 'ယနေ့ ရောင်းချမှု',
                'month_sales' => 'ဒီလ ရောင်းချမှု',
                'customer' => 'ဖောက်သည်',
                'staff' => 'ဝန်ထမ်း',
                'invoice' => 'ငွေတောင်းခံလွှာ',
                'payment_method' => 'ငွေပေးချေမှုနည်းလမ်း',
                'completed' => 'ပြီးစီး',
                'pending' => 'စောင့်ဆိုင်း',
                'cancelled' => 'ပယ်ဖျက်',
                'all_statuses' => 'အခြေအနေအားလုံး',
                'search_sales' => 'ရောင်းချမှုများ ရှာဖွေရန်...'
            ];
        } else {
            $translations = [
                'dashboard' => 'Dashboard',
                'products' => 'Products',
                'sales' => 'Sales',
                'customers' => 'Customers',
                'reports' => 'Reports',
                'settings' => 'Settings',
                'logout' => 'Logout',
                'search' => 'Search',
                'add_new' => 'Add New',
                'edit' => 'Edit',
                'delete' => 'Delete',
                'save' => 'Save',
                'cancel' => 'Cancel',
                'actions' => 'Actions',
                'status' => 'Status',
                'date' => 'Date',
                'amount' => 'Amount',
                'total' => 'Total',
                'recent_sales' => 'Recent Sales',
                'sales_analytics' => 'Sales Analytics',
                'today_sales' => "Today's Sales",
                'month_sales' => 'This Month',
                'customer' => 'Customer',
                'staff' => 'Staff',
                'invoice' => 'Invoice',
                'payment_method' => 'Payment Method',
                'completed' => 'Completed',
                'pending' => 'Pending',
                'cancelled' => 'Cancelled',
                'all_statuses' => 'All Statuses',
                'search_sales' => 'Search sales...'
            ];
        }
    }
    
    echo json_encode([
        'success' => true,
        'language' => $language,
        'translations' => $translations,
        'message' => 'Language updated successfully'
    ]);
    
} catch (Exception $e) {
    error_log("Language update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
