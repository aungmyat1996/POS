<?php
session_start();
require_once __DIR__ . '/../config/config.php';

// Security check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// CSRF protection
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    // Generate new token if missing
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    // Allow request to proceed for now
}

// Validate currency
$allowed_currencies = ['USD', 'MMK', 'EUR', 'GBP', 'JPY', 'CNY', 'THB', 'SGD'];
$currency = $_POST['currency'] ?? '';

if (!in_array($currency, $allowed_currencies)) {
    echo json_encode(['success' => false, 'message' => 'Invalid currency']);
    exit;
}

try {
    // Update session
    $_SESSION['currency'] = $currency;

    // Exchange rates (you can fetch from API in production)
    $exchange_rates = [
        'USD' => 1.0,
        'MMK' => 2100.0,
        'EUR' => 0.85,
        'GBP' => 0.73,
        'JPY' => 110.0,
        'CNY' => 6.45,
        'THB' => 33.0,
        'SGD' => 1.35
    ];

    // Currency symbols
    $currency_symbols = [
        'USD' => '$',
        'MMK' => 'Ks',
        'EUR' => '€',
        'GBP' => '£',
        'JPY' => '¥',
        'CNY' => '¥',
        'THB' => '฿',
        'SGD' => 'S$'
    ];

    echo json_encode([
        'success' => true,
        'currency' => $currency,
        'exchange_rate' => $exchange_rates[$currency],
        'currency_symbol' => $currency_symbols[$currency],
        'exchange_rates' => $exchange_rates,
        'currency_symbols' => $currency_symbols,
        'message' => 'Currency updated successfully'
    ]);

} catch (Exception $e) {
    error_log("Currency update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
