<?php
// Prevent direct access
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

// Fetch store info and translations if not already available
if (empty($translations)) {
    $language = $_SESSION['language'] ?? ($settings_array['language'] ?? 'en');
    $translations = loadLanguage($language); // Assuming loadLanguage is available
}

if (empty($settings_array)) {
    try {
        $stmt_settings_footer = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settings_array_footer = $stmt_settings_footer->fetchAll(PDO::FETCH_KEY_PAIR);
    } catch (PDOException $e) {
        error_log("Error fetching settings in footer: " . $e->getMessage());
        $settings_array_footer = [];
    }
} else {
    $settings_array_footer = $settings_array; // Use already fetched settings
}

$store_info_footer = $settings_array_footer['store_address'] ?? 'BitsTech POS System - 123 Tech Lane, Yangon, Myanmar';
$store_email_footer = $settings_array_footer['store_email'] ?? 'bitstech2025@gmail.com';
$store_phone_footer = $settings_array_footer['store_phone'] ?? '+959123456789';

?>
<footer>
    <div class="store-info mb-2">
        <small>
            <i class="fas fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($store_info_footer); ?> |
            <i class="fas fa-envelope me-1 ms-2"></i> <a href="mailto:<?php echo htmlspecialchars($store_email_footer); ?>" class="text-light"><?php echo htmlspecialchars($store_email_footer); ?></a> |
            <i class="fas fa-phone me-1 ms-2"></i> <a href="tel:<?php echo htmlspecialchars($store_phone_footer); ?>" class="text-light"><?php echo htmlspecialchars($store_phone_footer); ?></a>
        </small>
    </div>
    <div class="copyright">
        <small>
            <i class="fas fa-microchip circuit-icon me-1"></i>
            <?php echo htmlspecialchars($translations['footer_copyright'] ?? '© ' . date('Y') . ' BitsTech. All rights reserved.'); ?>
            |
            <a href="<?php echo BASEPATH; ?>pages/privacy_policy.php" class="text-light ms-2" data-translate="privacy_policy"><?php echo htmlspecialchars($translations['privacy_policy'] ?? 'Privacy Policy'); ?></a> |
            <a href="<?php echo BASEPATH; ?>pages/terms_of_service.php" class="text-light ms-2" data-translate="terms_of_service"><?php echo htmlspecialchars($translations['terms_of_service'] ?? 'Terms of Service'); ?></a>
        </small>
    </div>
</footer>

<script>
// Global function to update footer information (called from settings page)
window.updateFooterInfo = function(footerData) {
    console.log('🦶 Updating footer info:', footerData);

    if (footerData.store_address) {
        // Find the text node after the location icon
        const storeInfoText = $('footer .store-info small').contents();
        storeInfoText.each(function(index, node) {
            if (node.nodeType === 3 && node.textContent.includes('|')) {
                // This is the address text node
                const parts = node.textContent.split('|');
                parts[0] = ' ' + footerData.store_address + ' ';
                node.textContent = parts.join('|');
                return false; // Break the loop
            }
        });
    }

    if (footerData.store_email) {
        const emailLink = $('footer .store-info').find('a[href^="mailto:"]');
        emailLink.attr('href', 'mailto:' + footerData.store_email);
        emailLink.text(footerData.store_email);
    }

    if (footerData.store_phone) {
        const phoneLink = $('footer .store-info').find('a[href^="tel:"]');
        phoneLink.attr('href', 'tel:' + footerData.store_phone);
        phoneLink.text(footerData.store_phone);
    }

    if (footerData.footer_copyright) {
        // Find and update the copyright text
        const copyrightSmall = $('footer .copyright small');
        const iconHtml = copyrightSmall.find('i.fas.fa-microchip').prop('outerHTML');
        const linksHtml = copyrightSmall.find('a').map(function() {
            return this.outerHTML;
        }).get().join(' | ');

        copyrightSmall.html(iconHtml + ' ' + footerData.footer_copyright + ' | ' + linksHtml);
    }

    console.log('🦶 Footer updated successfully');
};
</script>