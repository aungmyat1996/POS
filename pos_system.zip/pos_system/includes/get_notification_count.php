<?php
session_start();
require_once '../config/db.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$user_id = $_SESSION['user_id'];
$lowStockEnabled = isset($_POST['lowStockEnabled']) ? (bool)$_POST['lowStockEnabled'] : true;

try {
    // Get all notifications for the user
    if (function_exists('getUserNotifications')) {
        $notifications = getUserNotifications($pdo, $user_id);
        
        // Filter notifications based on settings
        if (!$lowStockEnabled) {
            $notifications = array_filter($notifications, function($notification) {
                return strpos(strtolower($notification['message']), 'low stock') === false;
            });
        }
        
        // Count unread notifications
        $unreadCount = count(array_filter($notifications, function($notification) {
            return !$notification['is_read'];
        }));
        
        echo json_encode([
            'success' => true,
            'count' => $unreadCount,
            'lowStockEnabled' => $lowStockEnabled
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'count' => 0,
            'lowStockEnabled' => $lowStockEnabled
        ]);
    }
} catch (Exception $e) {
    error_log("Error getting notification count: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Failed to get notification count'
    ]);
}
?>
