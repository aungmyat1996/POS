<?php
require_once 'db.php';
require_once 'functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $timezone = $_POST['timezone'] ?? '';

        error_log("GET_DATETIME: Received timezone: " . $timezone);

        // If timezone is 'current', get from database settings
        if ($timezone === 'current' || empty($timezone)) {
            $timezone = ''; // Let function get from database
        }

        error_log("GET_DATETIME: Using timezone: " . $timezone);

        // Get formatted datetime with the specified timezone and date format from settings
        $datetime = get_current_datetime($timezone, $pdo);

        error_log("GET_DATETIME: Generated datetime: " . $datetime);

        echo json_encode([
            'success' => true,
            'datetime' => $datetime,
            'timezone' => $timezone
        ]);

    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>
