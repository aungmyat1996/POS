# Database Setup Instructions

## Setting up Product Images Table

To enable advanced image management for products, you need to run the SQL script to create the `product_images` table.

### Method 1: Using phpMyAdmin
1. Open phpMyAdmin in your browser
2. Select your POS database
3. Go to the "SQL" tab
4. Copy and paste the contents of `product_images.sql`
5. Click "Go" to execute

### Method 2: Using MySQL Command Line
```bash
mysql -u your_username -p your_database_name < product_images.sql
```

### Method 3: Using the SQL file directly
1. Navigate to the `database/` folder
2. Open `product_images.sql`
3. Copy all the SQL commands
4. Execute them in your MySQL interface

## What this creates:
- `product_images` table for managing multiple images per product
- Proper foreign key relationships
- Default images migration from existing products
- Indexes for better performance

## Features enabled:
- ✅ Multiple images per product (up to 6 images)
- ✅ Set primary image
- ✅ Upload new images
- ✅ Delete images (with protection for primary image)
- ✅ Database-backed image management
- ✅ Image persistence across sessions
- ✅ Proper file organization in `/public/images/products/`

## File Structure:
```
public/
└── images/
    ├── products/          # New organized image folder
    └── default.jpg        # Fallback image
```

## Security Notes:
- Images are validated for type and size
- Only authenticated users can manage images
- File uploads are sanitized and renamed
- Database tracks who uploaded each image

After running the SQL script, the image management features will be fully functional! 