<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'config/db.php';

echo "🚀 Setting up Product Images Database...\n";
echo "=====================================\n\n";

try {
    // Check if table already exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'product_images'");
    $table_exists = $stmt->rowCount() > 0;
    
    if ($table_exists) {
        echo "⚠️  Table 'product_images' already exists. Skipping creation...\n";
    } else {
        echo "📊 Creating product_images table...\n";
        
        // Create product_images table
        $sql = "
        CREATE TABLE IF NOT EXISTS `product_images` (
          `image_id` int(11) NOT NULL AUTO_INCREMENT,
          `product_id` int(11) NOT NULL,
          `image_path` varchar(255) NOT NULL,
          `image_name` varchar(255) NOT NULL,
          `image_type` varchar(50) DEFAULT 'additional',
          `is_primary` tinyint(1) DEFAULT 0,
          `display_order` int(11) DEFAULT 0,
          `uploaded_by` int(11) DEFAULT NULL,
          `uploaded_at` timestamp DEFAULT CURRENT_TIMESTAMP,
          `file_size` int(11) DEFAULT NULL,
          `mime_type` varchar(100) DEFAULT NULL,
          `alt_text` varchar(255) DEFAULT NULL,
          `status` enum('active','inactive','deleted') DEFAULT 'active',
          PRIMARY KEY (`image_id`),
          KEY `product_id` (`product_id`),
          KEY `uploaded_by` (`uploaded_by`),
          KEY `is_primary` (`is_primary`),
          KEY `status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        $pdo->exec($sql);
        echo "✅ Table 'product_images' created successfully!\n";
        
        // Add foreign key constraints
        try {
            $pdo->exec("ALTER TABLE `product_images` 
                        ADD CONSTRAINT `fk_product_images_product` 
                        FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE");
            echo "✅ Foreign key constraint for products added!\n";
        } catch (PDOException $e) {
            echo "⚠️  Foreign key for products: " . $e->getMessage() . "\n";
        }
        
        try {
            $pdo->exec("ALTER TABLE `product_images` 
                        ADD CONSTRAINT `fk_product_images_user` 
                        FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL");
            echo "✅ Foreign key constraint for users added!\n";
        } catch (PDOException $e) {
            echo "⚠️  Foreign key for users: " . $e->getMessage() . "\n";
        }
        
        // Create indexes
        try {
            $pdo->exec("CREATE INDEX `idx_product_images_product_primary` ON `product_images` (`product_id`, `is_primary`)");
            $pdo->exec("CREATE INDEX `idx_product_images_order` ON `product_images` (`product_id`, `display_order`)");
            echo "✅ Performance indexes created!\n";
        } catch (PDOException $e) {
            echo "⚠️  Indexes: " . $e->getMessage() . "\n";
        }
    }
    
    // Migrate existing product images
    echo "\n📸 Migrating existing product images...\n";
    
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO `product_images` (`product_id`, `image_path`, `image_name`, `image_type`, `is_primary`, `display_order`)
        SELECT 
            `product_id`, 
            CONCAT('images/', COALESCE(`image`, 'default.jpg')), 
            COALESCE(`image`, 'default.jpg'),
            'primary',
            1,
            1
        FROM `products` 
        WHERE `product_id` NOT IN (SELECT DISTINCT `product_id` FROM `product_images`)
        AND `image` IS NOT NULL AND `image` != ''
    ");
    
    $result = $stmt->execute();
    $migrated_count = $stmt->rowCount();
    
    if ($migrated_count > 0) {
        echo "✅ Migrated {$migrated_count} existing product images!\n";
    } else {
        echo "ℹ️  No new images to migrate.\n";
    }
    
    // Create upload directory
    $upload_dir = BASEPATH . 'public/images/products/';
    if (!is_dir($upload_dir)) {
        if (mkdir($upload_dir, 0755, true)) {
            echo "✅ Created upload directory: {$upload_dir}\n";
        } else {
            echo "❌ Failed to create upload directory: {$upload_dir}\n";
        }
    } else {
        echo "ℹ️  Upload directory already exists.\n";
    }
    
    // Show summary
    $stmt = $pdo->query("SELECT COUNT(*) FROM product_images WHERE status = 'active'");
    $image_count = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(DISTINCT product_id) FROM product_images WHERE status = 'active'");
    $product_count = $stmt->fetchColumn();
    
    echo "\n=====================================\n";
    echo "🎉 Setup Complete!\n";
    echo "=====================================\n";
    echo "📊 Statistics:\n";
    echo "  • Total Images: {$image_count}\n";
    echo "  • Products with Images: {$product_count}\n";
    echo "  • Upload Directory: {$upload_dir}\n\n";
    
    echo "🚀 What's available now:\n";
    echo "  ✅ Upload multiple images per product (max 6)\n";
    echo "  ✅ Set primary images\n";
    echo "  ✅ Delete images (with protection)\n";
    echo "  ✅ Database-backed image management\n";
    echo "  ✅ Add to cart → POS integration\n\n";
    
    echo "🎯 You can now use the product details page with full image management!\n";
    echo "   → Test: http://localhost/pos_system/pages/product_details.php?id=1\n";
    echo "   → POS:  http://localhost/pos_system/pages/pos.php\n\n";
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
    echo "Please check your database connection and try again.\n";
} catch (Exception $e) {
    echo "❌ General Error: " . $e->getMessage() . "\n";
}

echo "Setup completed!\n";
?> 