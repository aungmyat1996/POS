<?php
require_once __DIR__ . '/../config/config.php';
require_once BASEPATH . 'config/db.php';

echo "<h2>🚀 Setting up Product Images Database...</h2>\n";

try {
    // Check if table already exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'product_images'");
    $table_exists = $stmt->rowCount() > 0;
    
    if ($table_exists) {
        echo "<p style='color: orange;'>⚠️ Table 'product_images' already exists. Skipping creation...</p>\n";
    } else {
        echo "<p>📊 Creating product_images table...</p>\n";
        
        // Create product_images table
        $sql = "
        CREATE TABLE IF NOT EXISTS `product_images` (
          `image_id` int(11) NOT NULL AUTO_INCREMENT,
          `product_id` int(11) NOT NULL,
          `image_path` varchar(255) NOT NULL,
          `image_name` varchar(255) NOT NULL,
          `image_type` varchar(50) DEFAULT 'additional',
          `is_primary` tinyint(1) DEFAULT 0,
          `display_order` int(11) DEFAULT 0,
          `uploaded_by` int(11) DEFAULT NULL,
          `uploaded_at` timestamp DEFAULT CURRENT_TIMESTAMP,
          `file_size` int(11) DEFAULT NULL,
          `mime_type` varchar(100) DEFAULT NULL,
          `alt_text` varchar(255) DEFAULT NULL,
          `status` enum('active','inactive','deleted') DEFAULT 'active',
          PRIMARY KEY (`image_id`),
          KEY `product_id` (`product_id`),
          KEY `uploaded_by` (`uploaded_by`),
          KEY `is_primary` (`is_primary`),
          KEY `status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        $pdo->exec($sql);
        echo "<p style='color: green;'>✅ Table 'product_images' created successfully!</p>\n";
        
        // Add foreign key constraints
        try {
            $pdo->exec("ALTER TABLE `product_images` 
                        ADD CONSTRAINT `fk_product_images_product` 
                        FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE");
            echo "<p style='color: green;'>✅ Foreign key constraint for products added!</p>\n";
        } catch (PDOException $e) {
            echo "<p style='color: orange;'>⚠️ Foreign key for products: " . $e->getMessage() . "</p>\n";
        }
        
        try {
            $pdo->exec("ALTER TABLE `product_images` 
                        ADD CONSTRAINT `fk_product_images_user` 
                        FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL");
            echo "<p style='color: green;'>✅ Foreign key constraint for users added!</p>\n";
        } catch (PDOException $e) {
            echo "<p style='color: orange;'>⚠️ Foreign key for users: " . $e->getMessage() . "</p>\n";
        }
        
        // Create indexes
        try {
            $pdo->exec("CREATE INDEX `idx_product_images_product_primary` ON `product_images` (`product_id`, `is_primary`)");
            $pdo->exec("CREATE INDEX `idx_product_images_order` ON `product_images` (`product_id`, `display_order`)");
            echo "<p style='color: green;'>✅ Performance indexes created!</p>\n";
        } catch (PDOException $e) {
            echo "<p style='color: orange;'>⚠️ Indexes: " . $e->getMessage() . "</p>\n";
        }
    }
    
    // Migrate existing product images
    echo "<p>📸 Migrating existing product images...</p>\n";
    
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO `product_images` (`product_id`, `image_path`, `image_name`, `image_type`, `is_primary`, `display_order`)
        SELECT 
            `product_id`, 
            CONCAT('images/', COALESCE(`image`, 'default.jpg')), 
            COALESCE(`image`, 'default.jpg'),
            'primary',
            1,
            1
        FROM `products` 
        WHERE `product_id` NOT IN (SELECT DISTINCT `product_id` FROM `product_images`)
        AND `image` IS NOT NULL AND `image` != ''
    ");
    
    $result = $stmt->execute();
    $migrated_count = $stmt->rowCount();
    
    if ($migrated_count > 0) {
        echo "<p style='color: green;'>✅ Migrated {$migrated_count} existing product images!</p>\n";
    } else {
        echo "<p style='color: blue;'>ℹ️ No new images to migrate.</p>\n";
    }
    
    // Create upload directory
    $upload_dir = BASEPATH . 'public/images/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
        echo "<p style='color: green;'>✅ Created upload directory: {$upload_dir}</p>\n";
    } else {
        echo "<p style='color: blue;'>ℹ️ Upload directory already exists.</p>\n";
    }
    
    // Show summary
    $stmt = $pdo->query("SELECT COUNT(*) FROM product_images WHERE status = 'active'");
    $image_count = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(DISTINCT product_id) FROM product_images WHERE status = 'active'");
    $product_count = $stmt->fetchColumn();
    
    echo "<hr>";
    echo "<h3 style='color: green;'>🎉 Setup Complete!</h3>\n";
    echo "<p><strong>📊 Statistics:</strong></p>\n";
    echo "<ul>\n";
    echo "<li>Total Images: {$image_count}</li>\n";
    echo "<li>Products with Images: {$product_count}</li>\n";
    echo "<li>Upload Directory: {$upload_dir}</li>\n";
    echo "</ul>\n";
    
    echo "<p><strong>🚀 What's available now:</strong></p>\n";
    echo "<ul>\n";
    echo "<li>✅ Upload multiple images per product (max 6)</li>\n";
    echo "<li>✅ Set primary images</li>\n";
    echo "<li>✅ Delete images (with protection)</li>\n";
    echo "<li>✅ Database-backed image management</li>\n";
    echo "<li>✅ Add to cart → POS integration</li>\n";
    echo "</ul>\n";
    
    echo "<p style='color: green; font-weight: bold;'>🎯 You can now use the product details page with full image management!</p>\n";
    echo "<p><a href='../pages/product_details.php?id=1' style='color: blue;'>→ Test Product Details Page</a></p>\n";
    echo "<p><a href='../pages/pos.php' style='color: blue;'>→ Go to POS System</a></p>\n";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database Error: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<p>Please check your database connection and try again.</p>\n";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ General Error: " . htmlspecialchars($e->getMessage()) . "</p>\n";
}
?>

<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background: #f8fafc;
    color: #334155;
}
h2, h3 {
    color: #1e293b;
}
p {
    margin: 10px 0;
    padding: 8px;
    border-radius: 6px;
}
ul {
    background: white;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
hr {
    margin: 30px 0;
    border: none;
    height: 2px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6, #ec4899);
}
</style> 