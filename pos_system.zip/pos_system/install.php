<?php
// POS System Installation Script
session_start();

// Configuration
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'pos_system';
$isInstalled = false;
$error = '';
$success = '';

// Check if already installed
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Check if users table exists and has records
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
        $userCount = $stmt->fetchColumn();
        if ($userCount > 0) {
            $isInstalled = true;
        }
    }
} catch (PDOException $e) {
    // Database doesn't exist or connection error - proceed with installation
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
    try {
        // Create database if it doesn't exist
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Create database
        $sql = "CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        $pdo->exec($sql);
        $success .= "Database created successfully.<br>";
        
        // Connect to the new database
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Read SQL file and execute
        $sql = file_get_contents('sql/schema.sql');
        $statements = explode(';', $sql);
        
        foreach ($statements as $statement) {
            if (trim($statement) != '') {
                $pdo->exec($statement);
            }
        }
        
        $success .= "Database tables created successfully.<br>";
        
        // Create admin account if specified
        if (!empty($_POST['admin_username']) && !empty($_POST['admin_password']) && !empty($_POST['admin_email'])) {
            $adminUsername = $_POST['admin_username'];
            $adminEmail = $_POST['admin_email'];
            $adminPassword = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
            $stmt->execute([$adminUsername, $adminEmail, $adminPassword]);
            
            $success .= "Admin account created successfully.<br>";
        }
        
        $success .= "Installation completed successfully! <a href='public/index.php'>Go to login</a>";
        $isInstalled = true;
        
    } catch (PDOException $e) {
        $error = "Installation failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BitsTech POS System - Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .installation-form {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            padding: 25px;
            border-radius: 50%;
            background-color: #4361ee;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
        }
        .step {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="installation-form">
            <div class="header">
                <div class="logo">
                    <i class="bi bi-shop"></i>
                </div>
                <h2>BitsTech POS System</h2>
                <p class="text-muted">Installation Wizard</p>
            </div>
            
            <?php if ($isInstalled && empty($error)): ?>
                <div class="alert alert-success">
                    <h4 class="alert-heading">Already Installed!</h4>
                    <p>The system is already installed and ready to use.</p>
                    <hr>
                    <a href="public/index.php" class="btn btn-success">Go to Login</a>
                </div>
            <?php elseif (!empty($success)): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="step">
                        <h4><i class="bi bi-1-circle-fill me-2"></i>Database Configuration</h4>
                        <p class="text-muted">The application will use these settings to connect to the database.</p>
                        <div class="mb-3">
                            <label for="host" class="form-label">Database Host</label>
                            <input type="text" class="form-control" id="host" name="host" value="localhost" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Database Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="root" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Database Password</label>
                            <input type="password" class="form-control" id="password" name="password" value="" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="dbname" class="form-label">Database Name</label>
                            <input type="text" class="form-control" id="dbname" name="dbname" value="pos_system" readonly>
                        </div>
                    </div>
                    
                    <div class="step">
                        <h4><i class="bi bi-2-circle-fill me-2"></i>Admin Account</h4>
                        <p class="text-muted">Create an administrator account to manage the system.</p>
                        <div class="mb-3">
                            <label for="admin_username" class="form-label">Admin Username</label>
                            <input type="text" class="form-control" id="admin_username" name="admin_username" required>
                        </div>
                        <div class="mb-3">
                            <label for="admin_email" class="form-label">Admin Email</label>
                            <input type="email" class="form-control" id="admin_email" name="admin_email" required>
                        </div>
                        <div class="mb-3">
                            <label for="admin_password" class="form-label">Admin Password</label>
                            <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                        </div>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" name="install" class="btn btn-primary btn-lg">Install Now</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 